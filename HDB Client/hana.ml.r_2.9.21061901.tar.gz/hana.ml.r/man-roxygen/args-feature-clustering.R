#' @param features    \code{character or list of characters, optional}\cr
#' Names of features columns.\cr
#' If is not provided, it defaults to all non-key columns of \code{data}.
