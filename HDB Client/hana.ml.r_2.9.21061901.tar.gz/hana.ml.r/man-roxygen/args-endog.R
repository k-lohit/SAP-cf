#' @param     endog \code{character, optional}\cr
#'            The endogenous variable, i.e. time series.\cr
#'            Defaults to the first non-ID column.
