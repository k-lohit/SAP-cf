#' @param seed \code{integer, optional}\cr
#' Indicates the seed used to initialize the random number generator:
#' \itemize{
#'   \item{0}: Uses the system time.
#'   \item{Not 0}: Uses the specified seed.}
#'  Note that when multithreading is enabled, the random number sequences
#'  of different runs might be different even if the \code{seed} value remains
#'  the same.\cr
#'  Defaults to 0.
