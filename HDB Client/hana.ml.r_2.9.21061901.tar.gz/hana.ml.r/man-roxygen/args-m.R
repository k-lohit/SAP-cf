#' @param m \code{integer, optional}\cr
#' Specifies the number of random data to be generated.\cr
#' Defaults to 100.
