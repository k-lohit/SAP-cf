#'@param      key \code{character, optional}\cr
#'            Name of the ID column.
#'            If not provided, the \emph{data} is assumed to have no ID column.\cr
#'            No default value.
