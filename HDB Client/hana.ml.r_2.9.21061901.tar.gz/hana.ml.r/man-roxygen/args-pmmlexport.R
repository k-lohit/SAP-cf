#'@param  pmml.export \code{{"no", "single-row", "multi-row"}, optional}\cr
#'        Controls whether to output a PMML representation of the model,
#'        and how to format the PMML.
#'        \itemize{
#'            \item{\code{"no":} No PMML model.}
#'            \item{\code{"single-row":} Exports a PMML model in a maximum of
#'                one row. Fails if the model doesn't fit in one row.}
#'            \item{\code{"multi-row":} Exports a PMML model, splitting it
#'                across multiple rows if it doesn't fit in one.}
#'        }
#'        Default to "no".
