#' @param normalization \code{character, optional}\cr
#' Specifies the normalization type:
#' \itemize{
#' \item{\code{'no'}:} no normalization.
#' \item{\code{'l1.norm'}:} For each point
#'   X = \ifelse{html}{\out{(x<sub>1</sub>,x<sub>2</sub>,...,x<sub>n</sub>)}}{\eqn{(x_1, x_2, ..., x_n)}},
#'   the normalized value will be
#'   X' = \ifelse{html}{\out{(x<sub>1</sub>/S,x<sub>2</sub>/S,...,x<sub>n</sub>/S)}}{\eqn{(x_1, x_2, ..., x_n)}},
#'   where S = \ifelse{html}{\out{|x<sub>1</sub>|+|x<sub>2</sub>|+...|x<sub>n</sub>|}}{\eqn{|x_1|+|x_2|+...+|x_n|}}.
#' \item{\code{min.max}: Yes, for each column C, get the min and max value of C,
#' and then C[i] = (C[i]-min)/(max-min).}
#' }
#' Defaults to 'no'.
