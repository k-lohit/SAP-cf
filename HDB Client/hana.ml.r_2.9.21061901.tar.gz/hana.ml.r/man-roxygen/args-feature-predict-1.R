#'@param      features \code{character, optional}\cr
#'            Name of feature column for prediciton.\cr
#'            If not provided, it defaults to the first non-key column of \emph{data}.
