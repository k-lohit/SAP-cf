#' @param adjusted.r2 \code{logical, optional}\cr
#'  If TRUE, include the adjusted R^2 value in the statistics table.\cr
#'  Defaults to FALSE.
