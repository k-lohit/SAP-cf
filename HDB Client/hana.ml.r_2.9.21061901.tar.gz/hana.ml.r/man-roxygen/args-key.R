#' @param key  \code{character}\cr
#' Name of the ID column.\cr
