#' @param  repeat.times  \code{numeric, optional}\cr
#'         Specifies the number of repeat times for resampling.\cr
#'         Defaults to 1.
#' @param  param.search.strategy   \code{c('grid', 'random'), optional}\cr
#'         Specifies the method to activate parameter selection.
#'         If not specified, model parameter selection shall not be triggered.
#' @param  random.search.times \code{integer, optional}\cr
#'         Specifies the number of times to randomly select candidate parameters for selection.
#'         Mandatory and valid only when \code{param.search.strategy} is 'random'.
#' @param  random.state   \code{numeric, optional}\cr
#'         Specifies the seed for random generation. \cr
#'         Use system time when 0 is specified.
#' @param  timeout \code{integer, optional}\cr
#'         Specifies maximum running time for model evaluation or parameter selection in seconds.\cr
#'         No timeout when 0 is specified.
#' @param  progress.indicator.id  \code{character, optional}\cr
#'         Sets an ID of progress indicator for model evaluation or parameter selection.\cr
#'         No progress indicator is active if no value is provided.
