#' @param     formula     \code{formula type, optional}\cr
#'            Formula to be used for model generation.
#'            format = label~<feature_list>
#'            e.g.: formula=CATEGORY~V1+V2+V3 \cr
#'            You can either give the formula,
#'            or a feature and label combination, but do not provide both.\cr
#'            Defaults to NULL.
