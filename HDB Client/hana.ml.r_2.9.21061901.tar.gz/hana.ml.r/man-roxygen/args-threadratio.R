#' @param thread.ratio \code{double, optional}\cr
#' Controls the proportion of available threads that can be used by this
#' function.\cr
#' The value range is from 0 to 1, where 0 indicates a single thread,
#' and 1 indicates all available threads.\cr
#' Values between 0 and 1 will use up to
#' that percentage of available threads.Values outside this
#' range are ignored.\cr
#' Defaults to 0.
