#' @title Sampling
#' @description  hanaml.Sampling is a R wrapper
#' for SAP HANA PAL sampling.
#' @details This function is used to choose a small portion of the records
#' as representatives.
#' @name hanaml.Sampling
#' @template args-data
#' @param  method \code{character}\cr
#' \itemize{
#'      \item{\code{'first_n'}: The first n data. }
#'      \item{\code{'middle_n'}: Middle n data. }
#'      \item{\code{'last_n'}: The last n data.}
#'      \item{\code{'every_nth'}: based on interval to sample data.}
#'      \item{\code{'simple_random_with_replacement'}:
#'      For the random methods, the system time is used for the seed.}
#'      \item{\code{'simple_random_without_replacement'}:
#'      For the random methods, the system time is used for the seed.}
#'      \item{\code{'systematic'}:
#'      For the random methods, the system time is used for the seed.}
#'      \item{\code{'stratified_with_replacement'}}
#'      \item{\code{'stratified_without_replacement'}}
#'      }
#' @param interval \code{integer, optional}\cr
#' The interval between two samples.\cr
#' Note that Only valid when \code{method} is \emph{'every_nth'}.\cr
#' If this parameter is not specified, then \code{sampling.size} parameter will
#' be used.
#' @param features \code{vector/list of character, optional(deprecated)}\cr
#' The column that is used to do the stratified sampling.
#' Only required when \code{method} is \emph{"stratified_with_replacement"},
#' or \emph{"stratified_without_replacement"}.\cr
#' Will be replaced by another parameter \code{stratified.columns} in future release.
#' @param sampling.size \code{integer, optional}\cr
#' Number of the samples.\cr
#' Not effective when \code{method} is \emph{'every_nth'} and \code{interval}
#' is specified, or when \code{pencentage} is specified.\cr
#' Default to 1.
#' @param random.state \code{integer, optional}\cr
#' \itemize{Indicates the seed used to initialize the random number generator.
#' It can be set to 0 or a positive value.\cr
#'   \item{\code{0}: Uses the system time}
#'   \item{\code{Not 0}: Uses the specified seed}
#'   }
#' Default to 0.
#' @param percentage \code{double, optional}\cr
#'  Percentage of the samples.
#'  Use this parameter when \emph{sampling.size} is not set.
#'  If both \emph{sampling.size} and \emph{percentage} are specified,
#'  \emph{percentage} takes precedence. \cr
#'  Default to 0.1.
#' @param stratified.columns \code{vector/list of character, optional}\cr
#' Specifies the set of columns that are used to do the stratified sampling.\cr
#' Only required when \code{method} is \emph{"stratified_with_replacement"},
#' or \emph{"stratified_without_replacement"}.
#' If both \code{features} and \code{stratified.columns} are specified,
#' \code{stratified.columns} takes precedence.
#' @return
#' \code{DataFrame}\cr
#'  The same column structure (number of columns, column names, and column
#'  types) with the table with which the model is trained.
#'
#' @section Examples:
#'  Input DataFrame data:
#' \preformatted{
#'  > data$Collect()
#'     EMPNO GENDER INCOME
#'  1      1   male 4000.5
#'  2      2   male 5000.7
#'  3      3 female 5100.8
#'  4      4   male 5400.9
#'  5      5 female 5500.2
#'  ....
#'  23    23   male 8576.9
#'  24    24   male 9560.9
#'  25    25 female 8794.9
#' }
#' Call Sampling function:
#' \preformatted{
#' > sampling <- hanaml.Sampling(data, method = 'first_n',
#'                                sampling.size = 8,
#'                                interval = 5,
#'                                features = "GENDER")
#' }
#' Output:
#' \preformatted{
#' > sampling$Collect()
#'   EMPNO GENDER INCOME
#' 1     1   male 4000.5
#' 2     2   male 5000.7
#' 3     3 female 5100.8
#' 4     4   male 5400.9
#' 5     5 female 5500.2
#' 6     6   male 5540.4
#' 7     7   male 4500.9
#' 8     8 female 6000.8
#' }
#' @keywords Preprocessing
#' @export
hanaml.Sampling <- function(data,
                            method,
                            interval = NULL,
                            features = NULL,
                            sampling.size = NULL,
                            random.state = NULL,
                            percentage = NULL,
                            stratified.columns = NULL) {
  method.map <- list("first_n" = 0, "middle_n" = 1, "last_n" = 2,
                     "every_nth" = 3, "simple_random_with_replacement" = 4,
                     "simple_random_without_replacement" = 5, "systematic" = 6,
                     "stratified_with_replacement" = 7,
                     "stratified_without_replacement" = 8)

  method <- validateInput("method", method, method.map, required = TRUE)
  interval <- validateInput("interval", interval, "integer")

  cols <- data$columns
  features <- validateInput("features", features, cols,
                            case.sensitive = TRUE)
  sampling.size <- validateInput("sampling.size", sampling.size, "integer")
  random.state <- validateInput("random.state", random.state, "integer")
  if (!is.null(random.state)) {
    if (random.state < 0) {
      msg <- "It should be set to 0 or a positive value."
      flog.error(msg)
      stop(msg)
    }
  }
  if (exists("features")){
    stratified.columns <-
      validateInput("stratified.columns",
                    stratified.columns,
                    cols,
                    case.sensitive = TRUE,
                    required = (grepl("strat", method) && is.null(features)))
  } else {
    stratified.columns <-
      validateInput("stratified.columns",
                    stratified.columns,
                    cols,
                    case.sensitive = TRUE,
                    required = grepl("strat", method))
  }
  if (is.null(stratified.columns)){
    stratified.columns <- features
  }
  percentage <- validateInput("percentage", percentage, "double")
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  conn <- data$connection.context
  CheckConnection(data)
  if (!is.null(stratified.columns)){
    column.choose <- list()
    for (each in stratified.columns){
      column.choose <- append(column.choose, which(each == cols))
    }
  }
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_PARAMETER_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_SAMPLING_RESULT_TBL_%s", unique.id)
  tables <- list(param.tbl, result.tbl)
  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl)
  param.array <- list(
    tuple("SAMPLING_METHOD", map.null(method, method.map), NULL, NULL),
    tuple("SAMPLING_SIZE", sampling.size, NULL, NULL),
    tuple("INTERVAL", interval, NULL, NULL),
    tuple("RANDOM_SEED", random.state, NULL, NULL),
    tuple("PERCENTAGE", NULL, percentage, NULL)
  )
  if (length(column.choose) > 0){
    for (each in column.choose){
      param.array <- append(param.array,
                            list(tuple("COLUMN_CHOOSE",
                                       each, NULL, NULL)))
    }
  }

  tryCatch({
    errorhelper(CreateTWithConnection(conn,
               (ParameterTable$new(param.tbl))$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_SAMPLING",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return (conn$table(result.tbl))
}
