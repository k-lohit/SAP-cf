# Wrap up PAL conditional random field algorithm

CRF <- R6Class(
  "CRF",
  inherit = MlBase,
  public = list(
    enet.lambda = NULL,
    tol = NULL,
    max.iter = NULL,
    lbfgs.m = NULL,
    use.class.feature = NULL,
    use.word = NULL,
    use.ngrams = NULL,
    no.mid.ngrams = NULL,
    max.ngram.length = NULL,
    use.prev.word = NULL,
    use.next.word = NULL,
    use.disjunctive = NULL,
    disjunction.width = NULL,
    use.sequences = NULL,
    use.prev.sequences = NULL,
    use.type.seqs = NULL,
    use.type.seqs2 = NULL,
    use.type.ysequences = NULL,
    use.word.shape = NULL,
    model = NULL,
    statistics = NULL,
    optim.param = NULL,
    col.names = list("document.id", "word.pos", "word"),
    initialize = function(data = NULL,
                          used.cols = NULL,
                          label = NULL,
                          enet.lambda = NULL,
                          tol = NULL,
                          max.iter = NULL,
                          lbfgs.m = NULL,
                          thread.ratio = NULL,
                          use.class.feature = NULL,
                          use.word = NULL,
                          use.ngrams = NULL,
                          no.mid.ngrams = NULL,
                          max.ngram.length = NULL,
                          use.prev.word = NULL,
                          use.next.word = NULL,
                          use.disjunctive = NULL,
                          disjunction.width = NULL,
                          use.sequences = NULL,
                          use.prev.sequences = NULL,
                          use.type.seqs = NULL,
                          use.type.seqs2 = NULL,
                          use.type.ysequences = NULL,
                          use.word.shape = NULL){
      super$initialize()
      conn.context <- data$connection.context
      if (!is.null(data)){
        self$enet.lambda <- validateInput("enet.lambda", enet.lambda,
                                          "numeric")
        self$tol <- validateInput("tol", tol, "numeric")
        self$max.iter <- validateInput("max.iter", max.iter,
                                       "integer")
        self$lbfgs.m <- validateInput("lbfgs.m", lbfgs.m, "integer")
        thread.ratio <- validateInput("thread.ratio", thread.ratio, "numeric")
        self$use.class.feature <- validateInput("use.class.feature",
                                                use.class.feature,
                                                "logical")
        self$use.word <- validateInput("use.word", use.word,
                                       "logical")
        self$use.ngrams <- validateInput("use.ngrams", use.ngrams,
                                         "logical")
        self$max.ngram.length <- validateInput("max.ngram.length",
                                                max.ngram.length,
                                                "integer")
        self$no.mid.ngrams <- validateInput("no.mid.ngrams", no.mid.ngrams,
                                            "logical")
        self$use.prev.word <- validateInput("use.prev.word", use.prev.word,
                                            "logical")
        self$use.next.word <- validateInput("use.next.word", use.next.word,
                                            "logical")
        self$use.disjunctive <- validateInput("use.disjunctive",
                                              use.disjunctive,
                                              "logical")
        self$disjunction.width <- validateInput("disjunction.width",
                                                disjunction.width,
                                                "integer")
        self$use.sequences <- validateInput("use.sequences", use.sequences,
                                            "logical")
        self$use.prev.sequences <- validateInput("use.prev.sequences",
                                                 use.prev.sequences,
                                                 "logical")
        self$use.type.seqs <- validateInput("use.type.seqs", use.type.seqs,
                                            "logical")
        self$use.type.seqs2 <- validateInput("use.type.seqs2", use.type.seqs2,
                                             "logical")
        self$use.type.ysequences <- validateInput("use.type.ysequences",
                                                  use.type.ysequences,
                                                  "logical")
        self$use.word.shape <- validateInput("use.word.shape", use.word.shape,
                                             "logical")
        cols <- data$columns
        if (length(cols) < 4){
          msg <- paste("Invalid data.",
                       "Input data should contain at least four columns.")
          flog.error(msg)
          stop(msg)
        }
        label <- validateInput("label", label, cols,
                               case.sensitive = TRuE)
        if (is.null(label)){
          label <- cols[[length(cols)]]
        }
        cols <- cols[! cols %in% label]
        if (!is.null(used.cols)){
          use.cols <- as.list(used.cols)
          use.cols <- validateInput("used.cols", used.cols, cols,
                                    case.sensitive = TRUE)
          if (length(used.cols) < 3){
            msg <- paste("Invalid column number.",
                         "Three columns should be specified from the input.")
            flog.error(msg)
            stop(msg)

          }
          names(used.cols) <- validateInput("Names of used columns",
                                            names(used.cols),
                                            self$col.names)
          if (is.null(names(used.cols))){
            names(used.cols) <- self$col.names
          }
        } else {
          used.cols <- cols[1:3]
          names(used.cols) <- self$col.names
        }
        if (!inherits(data, "DataFrame")){
          msg <- "If training data is not omitted, it must be DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        data <- data$Select(list(used.cols[["document.id"]],
                                 used.cols[["word.pos"]],
                                 used.cols[["word"]],
                                 label))
        param.rows <- list(
          tuple("ENET_LAMBDA", NULL, self$enet.lambda, NULL),
          tuple("EXIT_THRESHOLD", NULL, self$tol, NULL),
          tuple("MAX_ITERATION", self$max.iter, NULL, NULL),
          tuple("LBFGS_M", self$lbfgs.m, NULL, NULL),
          tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
          tuple("USE_CLASS_FEATURE", to.integer(self$use.class.feature),
                NULL, NULL),
          tuple("USE_WORD", to.integer(self$use.word), NULL, NULL),
          tuple("USE_NGRAMS", to.integer(self$use.ngrams), NULL, NULL),
          tuple("NO_MIDNGRAMS", to.integer(no.mid.ngrams), NULL, NULL),
          tuple("MAX_NGRAM_LENGTH", to.integer(self$max.ngram.length),
                NULL, NULL),
          tuple("USE_PREV", to.integer(self$use.prev.word), NULL, NULL),
          tuple("USE_NEXT", to.integer(self$use.next.word), NULL, NULL),
          tuple("USE_DISJUNCTIVE", to.integer(self$use.disjunctive),
                NULL, NULL),
          tuple("DISJUNCTION_WIDTH", self$disjunction.width, NULL, NULL),
          tuple("USE_SEQUENCES", to.integer(self$use.sequences), NULL, NULL),
          tuple("USE_PREVSEQUENCES", to.integer(self$use.prev.sequences),
                NULL, NULL),
          tuple("USE_TYPE_SEQS", to.integer(self$use.type.seqs), NULL, NULL),
          tuple("USE_TYPE_SEQS2", to.integer(self$use.type.seqs2), NULL, NULL),
          tuple("USE_TYPE_YSEQUENCES", to.integer(self$use.type.ysequences),
                NULL, NULL),
          tuple("WORD_SHAPE", to.integer(self$use.word.shape), NULL, NULL)
        )

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#CRF_PARAM_TBL_%s_%s", self$id, unique.id)
        model.tbl <- sprintf("#CRF_MODEL_TBL_%s_%s", self$id, unique.id)
        stats.tbl <- sprintf("#CRF_STATS_TBL_%s_%s", self$id, unique.id)
        optim.param.tbl <- sprintf("#CRF_OPTIM_PARAM_TBL_%s_%s", self$id, unique.id)
        in.tables <- list(data, param.tbl)
        out.tables <- list(model.tbl, stats.tbl, optim.param.tbl)
        tables <- c(param.tbl, out.tables)
        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
            ParameterTable$new(param.tbl)$WithData(param.rows)))#nolint
          errorhelper(CallPalAutoWithConnection(conn.context,
            "PAL_CRF", in.tables, out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        self$model <- conn.context$table(model.tbl)
        self$statistics <- conn.context$table(stats.tbl)
        self$optim.param <- conn.context$table(optim.param.tbl)
      }
    }
  )
)

#' @title Conditional Random Field
#' @name hanaml.CRF
#' @description hanaml.CRF is an R wrapper
#' for SAP HANA PAL conditional random field algorithm.
#' @seealso \code{\link{predict.CRF}}
#' @details
#' Conditional random fields (CRFs) are a probabilistic framework for
#' labeling and segmenting structured data, such as sequences.
#' It can be put into the general framework of maximum likelihood.
#' In PAL, L-BFGS algorithms is adopted for for maximizing the (penalized)
#' likelihood function.
#' @keywords Classification
#' @template args-data
#' @param      used.cols \code{list of character, optional}\cr
#'            This parameter specifies the three columns used for training a conditional random field model.
#'            Namely, one column should correspond to Document ID, another column should correspond to
#'            word position, and a 3rd column corresponds to word.\cr
#'            If not NULL, this parameter should be specified in two ways:
#'            \itemize{
#'            \item{(1)} used.cols = list(document.id = "xxx",
#'                                        word.pos = "yyy",
#'                                        word = "zzz")
#'            \item{(2)} used.cols = list("xxx", "yyy", "zzz")
#'            }
#'            In case (2), "xxx", "yyy" and "zzz" must be the column data of document ID, word position
#'            and word respectively.\cr
#'            Defaults to the first three non-label columns of \emph{data} if not provided.
#' @template args-label
#' @param      enet.lambda \code{numeric, optional}\cr
#'            Elastic-net penalization weight. The value should be greater than 0.\cr
#'            Defaults to 1.0.
#' @param      tol \code{numeric, optional}\cr
#'            Convergence tolerance in optimization(i.e. l-bfgs algorithm).\cr
#'            Defaults to 1e-4.
#' @param      max.iter \code{integer, optional}\cr
#'            Maximum number of iterations in optimization(i.e. l-bfgs algorithm).\cr
#'            Defaults to 1000.
#' @param      lbfgs.m \code{integer, optional}\cr
#'            Number of previous memories to keep for l-bfgs algorithm.\cr
#'            Defaults to 25.
#' @param      use.class.feature \code{logical, optional}\cr
#'            Whether to include a feature for the class or not, the same as having a bias
#'            vector in the model.\cr
#'            Defaults to TRUE.
#' @param      use.word  \code{logical, optional}\cr
#'            Whether to use the feature for current word or not.\cr
#'            Defaults to TRUE.
#' @param      use.ngrams  \code{logical, optional}\cr
#'            Whether or not to make feature from letter n-grams(i.e. substrings of the word).\cr
#'            Defaults to TRUE.
#' @param      no.mid.ngrams \code{logical, optional}\cr
#'            TRUE means not to include character n-gram features for n-grams that contain neither
#'            the beginning nor the end of the word.\cr
#'            Defaults to TRUE
#' @param      max.ngram.length  \code{integer, optional}\cr
#'            Threshold for the size of n-grams to be used in the model.
#'            Must be positive.\cr
#'            Defaults to 6.
#' @param      use.prev.word  \code{logical, optional}\cr
#'            Whether to make a feature from both the current word and the previous word.\cr
#'            Defaults to TRUE.
#' @param      use.next.word  \code{logical, optional}]\cr
#'            Whether to make a feature from both the current word and its next word.\cr
#'            Defauls to TRUE.
#' @param      use.disjunctive  \code{logical, optional}\cr
#'            Whether to include in features giving disjunctions of words anywhere
#'            in left or right \code{disjunction.width} words.\cr
#'            Defaults to TRUE.
#' @param      disjunction.width  \code{logical, optional}\cr
#'            See \code{use.disjunctive}.\cr
#'            Defaults to 4.
#' @param      use.sequences \code{logical, optional}\cr
#'            Whether or not to use class combination features.\cr
#'            Defaults to TRUE.
#' @param      use.prev.sequences  \code{logical, optional}\cr
#'            Whether or not to use any class combination features using the previous class.\cr
#'            Defaults to TRUE.
#' @param      use.type.seqs   \code{logical, optional}\cr
#'            Whether to use basic 0th order word shape features or not.\cr
#'            Defaults to TRUE.
#' @param      use.type.seqs2  \code{logical, optional}\cr
#'            Whethr to use additional 1st and 2nd order word shape features.\cr
#'            Defaults to TRUE.
#' @param      use.type.ysequences  \code{logical, optional}\cr
#'            Whehter or not to use some first order word shape patterns.\cr
#'            Defaults to TRUE.
#' @param      use.word.shape  \code{logical, optional}\cr
#'            Whether or not to use word shape(e.g. capitalized or numeric).
#'            Only supports chris2UseLC currently.\cr
#'            Defaults to FALSE.
#' @template args-threadratio
#' @return
#'  A "CRF" object with the following attributes:
#'  \itemize{
#'  \item{model:  \code{DataFrame}} CRF model.
#'  \item{statistics:  \code{DataFrame}} Summary of the CRF model training process.
#'  \item{optim.param: \code{DataFrame}} Optimal parameter of the CRF model.
#'  Reserved for future use and currently empty.
#'  }
#' @section Examples:
#'  Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    DOC_ID WORD_POSITION        WORD            LABEL
#' 1       1             1      RECORD                O
#' 2       1             2     #497321                O
#' 3       1             3    78554939                O
#' 4       1             4           |                O
#' .......
#' 88      3            29          on OxygenSaturation
#' 89      3            30           2 OxygenSaturation
#' 90      3            31      liters OxygenSaturation
#' 91      3            32          of OxygenSaturation
#' 92      3            33      oxygen OxygenSaturation
#' }
#' Call the function:
#' \preformatted{
#' > crf <- hanaml.CRF(data = df, thread.ratio = 1.0,
#'                     enet.lambda = 0.1, max.iter = 1000, tol = 1e-4,
#'                     use.word.shape = FALSE, lbfgs.m = 25)
#' }
#' Output:
#' \preformatted{
#' > crf$statistics$Collect()
#'          STAT_NAME          STAT_VALUE
#' 1              obj 0.44251900977373015
#' 2             iter                  22
#' 3  solution status           Converged
#' 4      numSentence                   2
#' 5          numWord                  92
#' ......
#' 25         iter 19        obj=0.442519
#' 26         iter 20        obj=0.442519
#' 27         iter 21        obj=0.442519
#' 28         iter 22        obj=0.442519
#'}
#' @export
hanaml.CRF <- function(data = NULL,
                       used.cols = NULL, label = NULL, enet.lambda = NULL,
                       tol = NULL, max.iter = NULL,
                       lbfgs.m = NULL, thread.ratio = NULL,
                       use.class.feature = NULL, use.word = NULL,
                       use.ngrams = NULL, no.mid.ngrams = NULL,
                       max.ngram.length = NULL, use.prev.word = NULL,
                       use.next.word = NULL, use.disjunctive = NULL,
                       disjunction.width = NULL, use.sequences = NULL,
                       use.prev.sequences = NULL, use.type.seqs = NULL,
                       use.type.seqs2 = NULL, use.type.ysequences = NULL,
                       use.word.shape = NULL){
  CRF$new(data, used.cols, label, enet.lambda, tol,
          max.iter, lbfgs.m, thread.ratio, use.class.feature,
          use.word, use.ngrams, no.mid.ngrams, max.ngram.length,
          use.prev.word, use.next.word, use.disjunctive,
          disjunction.width, use.sequences, use.prev.sequences,
          use.type.seqs, use.type.seqs2, use.type.ysequences,
          use.word.shape)
}

#' @title Make Predictions from a "CRF" Object
#' @name predict.CRF
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "CRF“ object.
#' @seealso \code{\link{hanaml.CRF}}
#' @format     \code{\link{S3}} methods
#' @param      model \code{R6Class object}\cr
#'  A "CRF" object for prediction.
#' @template args-data
#' @param      used.cols \code{list of character, optional}\cr
#' This parameter specifies the three columns used for training a conditional random field model.
#' Namely, one column should correspond to Document ID, another column should correspond to
#' word position, and a 3rd column corresponds to word.
#' If not NULL, this parameter should be specified in two ways:
#' \itemize{
#' \item{(1)} used.cols = list("document.id" = "xxx",
#'                             "word.pos" = "yyy",
#'                             "word" = "zzz")
#' \item{(2)} used.cols = list("xxx", "yyy", "zzz")
#' }
#' In case (2), "xxx", "yyy" and "zzz" must be the column data of document ID, word position
#' and word respectively.\cr
#' Defaults to the first three column names of \emph{data} if not provided.
#' @template args-threadratio
#' @return
#' \code{DataFrame}\cr
#' Prediction result, structured as follows:
#' \itemize{
#'  \item{1st column}: document ID
#'  \item{2nd column}: word position
#'  \item{3rd column}: label
#' }
#' @section Examples:
#' Call the function with a "CRF" object cf:
#' \preformatted{
#' > predict(cf, data)
#' }
#' @keywords Classification
#' @export
predict.CRF <- function(model, data, used.cols = NULL,
                        thread.ratio = NULL){
  if (!inherits(model$model, "DataFrame") ){
    msg <- "Model not initialized. Perform a fit first."
    flog.error(msg)
    stop(msg)
  }
  conn.context <- data$connection.context
  if (!inherits(data, "DataFrame")){
    msg <- "Data for prediction must be DataFrame."
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  cols <- data$columns
  used.cols <- validateInput("used.cols", used.cols, cols,
                             case.sensitive = TRUE)
  thread.ratio <- validateInput("thread.ratio", thread.ratio,
                                "numeric")
  if (is.null(used.cols)){
    used.cols <- cols[1:3]
    names(used.cols) <- list("document.id", "word.pos", "word")
  } else {
    if (is.null(names(used.cols))){
      names(used.cols) <- list("document.id", "word.pos", "word")
    } else {
      names(used.cols) <- validateInput("Names of used columns",
                                        names(used.cols),
                                        model$col.names)
    }
  }
  data <- data$Select(list(used.cols[["document.id"]],
                           used.cols[["word.pos"]],
                           used.cols[["word"]]))
  param.rows <- list(
    tuple("THREAD_RATIO", NULL, thread.ratio, NULL))
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#CRF_INFERENCE_PARAM_TBL_%s_%s", model$id,
                       unique.id)
  result.tbl <- sprintf("#CRF_INFERENCE_RESULT_TBL_%s_%s", model$id,
                       unique.id)
  in.tables <- list(data, model$model$name, param.tbl)
  out.tables <- list(result.tbl)
  tables <- c(param.tbl, out.tables)
  tryCatch({
    errorhelper(CreateTWithConnection(conn.context,
      ParameterTable$new(param.tbl)$WithData(param.rows)))#nolint
    errorhelper(CallPalAutoWithConnection(conn.context,
      "PAL_CRF_INFERENCE", in.tables, out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn.context, tables)
    stop(msg)
  })
  return(conn.context$table(result.tbl))
}
