SVM.base <- R6Class(
  "SVM.base",
  inherit = MlBase,
  public = list(
    type.map = list(
      "1" = "SVC",
      "2" = "SVR",
      "3" = "SVRANKING",
      "4" = "ONECLASSSVM"
    ),
    kernel.map = list(
      "linear" = 0,
      "poly" = 1,
      "rbf" = 2,
      "sigmoid" = 3
    ),
    scale.info.map = list(
      "no" = 0,
      "standardization" = 1,
      "rescale" = 2
    ),
    svm.type = NULL,
    svm.c = NULL,
    kernel.type = NULL,
    poly.degree = NULL,
    rbf.gamma = NULL,
    coef.lin = NULL,
    coef.const = NULL,
    probability = NULL,
    shrink = NULL,
    tol = NULL,
    evaluation.seed = NULL,
    thread.ratio = NULL,
    nu = NULL,
    scale.info = NULL,
    scale.label = NULL,
    categorical.variable = NULL,
    category.weight = NULL,
    regression.eps = NULL,
    handle.missing = NULL,
    compression = NULL,
    max.bits = NULL,
    max.quantization.iter = NULL,
    resampling.method = NULL,
    evaluation.metric = NULL,
    fold.num = NULL,
    repeat.times = NULL,
    param.search.strategy = NULL,
    random.search.times = NULL,
    random.state = NULL,
    timeout = NULL,
    progress.indicator.id = NULL,
    parameter.range = NULL,
    parameter.values = NULL,
    model.type = NULL,
    model = NULL,
    stat = NULL,
    optim.param = NULL,
    initialize = function(svm.type,
                          data = NULL, key = NULL, features = NULL, label = NULL,
                          qid = NULL,
                          kernel = NULL, thread.ratio = NULL, degree=NULL,
                          gamma = NULL, nu = NULL, coef.lin = NULL,
                          coef.const = NULL, c = NULL, regression.eps = NULL,
                          scale.info = NULL, scale.label = NULL, shrink = NULL,
                          handle.missing = NULL, categorical.variable = NULL,
                          category.weight = NULL, tol = NULL,
                          evaluation.seed = NULL, probability = NULL,
                          compression = NULL, max.bits = NULL, max.quantization.iter = NULL,
                          resampling.method = NULL, evaluation.metric = NULL,
                          fold.num = NULL, repeat.times = NULL,
                          param.search.strategy = NULL, random.search.times = NULL,
                          random.state = NULL, timeout = NULL, progress.indicator.id = NULL,
                          parameter.range = NULL, parameter.values = NULL){
      super$initialize()
      self$svm.type <- svm.type
      if (!is.null(data)){
        self$kernel.type <- validateInput("kernel", kernel, self$kernel.map)
        self$thread.ratio <- validateInput("thread.ratio",
                                           thread.ratio,
                                           "double")
        self$poly.degree <- validateInput("degree", degree, "integer")
        self$rbf.gamma <- validateInput("gamma", gamma, "double")
        self$nu <- validateInput("nu", nu, "double")
        self$coef.lin <- validateInput("coef.lin", coef.lin, "double")
        self$coef.const <- validateInput("coef.const", coef.const, "double")
        self$svm.c <- validateInput("c", c, "double")
        self$regression.eps <- validateInput("regression.eps",
                                             regression.eps,
                                             "double")
        self$scale.info <- validateInput("scale.info", scale.info,
                                         self$scale.info.map)
        self$scale.label <- validateInput("scale.label",
                                          scale.label,
                                          "logical")
        self$shrink <- validateInput("shrink", shrink, "logical")
        self$handle.missing <- validateInput("handle.missing",
                                             handle.missing,
                                             "logical")
        self$category.weight <- validateInput("category.weight",
                                              category.weight,
                                              "double")
        self$tol <- validateInput("tol", tol, "double")
        self$evaluation.seed <- validateInput("evaluation.seed",
                                              evaluation.seed,
                                              "integer")
        self$probability <- validateInput("probability", probability, "logical")
        self$compression <- validateInput("compression", compression, "logical")
        self$max.bits <- validateInput("max.bits", max.bits, "integer")
        self$max.quantization.iter <- validateInput("max.quantization.iter",
                                                    max.quantization.iter,
                                                    "integer")


        self$model.type <- self$type.map[[self$svm.type]]
        model.type <- self$model.type
        cols.left <- data$columns
        key <- validateInput("key", key, cols.left, case.sensitive = TRUE)
        cols.left <- cols.left[! cols.left %in% key]
        label <- validateInput("label", label, cols.left, case.sensitive = TRUE)
        self$categorical.variable <- validateInput("categorical.variable",
                                                   categorical.variable,
                                                   cols.left,
                                                   case.sensitive = TRUE)
        if (self$svm.type != 4){
          if (is.null(label)){
            label <- cols.left[[length(cols.left)]]
          }
          cols.left <- cols.left[! cols.left %in% label]
        }
        if (self$svm.type == 3){
          qid <- validateInput("qid", qid, cols.left, case.sensitive = TRUE)
          if (is.null(qid)){
            qid <- cols.left[[length(cols.left)]]
          }
          cols.left <- cols.left[! cols.left %in% qid]
        }
        features <- validateInput("features", features, cols.left,
                                  case.sensitive = TRUE)
        if (is.null(features)){
          features <- cols.left
        }
        chain.list <- c(key, features, qid, label)
        used.cols <- list()
        for (col in chain.list){
          if (!is.null(col))
            used.cols <- append(used.cols, col)
        }
        if ( (self$svm.type != 3) && (!is.null(qid))){#nolint
          msg <- "Qid will only be valid when type is SVRanking."
          flog.error(msg)
          stop(msg)
        }
        self$resampling.method <-
          validateInput("resampling.method",
                        resampling.method,
                        list(cv = "cv",
                             stratified_cv = "stratified_cv",
                             bootstrap = "bootstrap",
                             stratified_bootstrap = "stratified_bootstrap"
                        ))
        metric.map <- list(accuracy = "ACCURACY",
                           f1_score = "F1_SCORE",
                           auc = "AUC",
                           nll = "NLL")
        self$evaluation.metric <-
          validateInput("evaluation.metric",
                        evaluation.metric,
                        metric.map)
        self$repeat.times <- validateInput("repeat.times",
                                           repeat.times,
                                           "integer")
        self$fold.num <-
          validateInput("fold.num", fold.num, "integer",
                        required = isTRUE(self$resampling.method %in%
                                          c("cv", "stratified_cv")))
        self$param.search.strategy <-
          validateInput("param.search.strategy",
                        param.search.strategy,
                        list(grid = "grid",
                             random = "random"))
        self$random.search.times <-
          validateInput("random.search.times", random.search.times, "integer",
                        required = isTRUE(self$param.search.strategy == "random"))
        self$random.state <- validateInput("random.state",
                                           random.state,
                                           "integer")
        self$timeout <- validateInput("timeout", timeout, "integer")
        self$progress.indicator.id <- validateInput("progress.indicator.id",
                                                    progress.indicator.id,
                                                    "character")
        if (length(parameter.values) != 0){
          validateInput("Parameters for value specification",
                        names(parameter.values),
                        list("c", "nu", "gamma",
                             "degree", "coef.lin", "coef.const"),
                        case.sensitive = TRUE)
        }
        for (name in names(parameter.values)){
          attr.name <- ifelse(name == "gamma",
                              "rbf.gamma",
                              ifelse(name == "c", "svm.c",
                                     name))
          if (!is.null(self[[attr.name]])){
            msg <- paste(sprintf("Parameter '%s' cannot be specified", name),
                         "both inside and outside parameter.values")
            flog.error(msg)
            stop(msg)
          }
        }
        if (length(parameter.range) != 0){
          validateInput("Parameters for range specification",
                        names(parameter.range),
                        list("c", "nu", "gamma",
                             "degree", "coef.lin", "coef.const"),
                        case.sensitive = TRUE)
        }
        for (name in names(parameter.range)){
          attr.name <- ifelse(name == "gamma",
                              "rbf.gamma",
                              ifelse(name == "c", "svm.c",
                                     name))
          if (!is.null(self[[attr.name]]) || !is.null(parameter.values[[name]])){
            msg <- paste(sprintf("Parameter '%s' cannot be specified", name),
                         "both inside and outside parameter.range")
            flog.error(msg)
            stop(msg)
          }
        }
        self$parameter.range <- parameter.range
        self$parameter.values <- parameter.values
        if (!inherits(data, "DataFrame")){
          msg <- "If training data is not omitted, it must be DataFrame."
          flog.error(msg)
          stop(msg)
        }
        conn <- data$connection.context
        CheckConnection(data)

        training.data <- data$Select(used.cols)
        param.array <- list(
          tuple("TYPE", self$svm.type, NULL, NULL),
          tuple("KERNEL_TYPE",
                map.null(self$kernel.type, self$kernel.map),
                NULL, NULL),
          tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
          tuple("POLY_DEGREE", self$poly.degree, NULL, NULL),
          tuple("RBF_GAMMA", NULL, self$rbf.gamma, NULL),
          tuple("NU", NULL, self$nu, NULL),
          tuple("COEF_LIN", NULL, self$coef.lin, NULL),
          tuple("COEF_CONST", NULL, self$coef.const, NULL),
          tuple("SVM_C", NULL, self$svm.c, NULL),
          tuple("REGRESSION_EPS", NULL, self$regression.eps, NULL),
          tuple("SCALE_INFO",
                map.null(self$scale.info, self$scale.info.map),
                NULL, NULL),
          tuple("SCALE_LABEL", to.integer(self$scale.label), NULL, NULL),
          tuple("SHRINK", to.integer(self$shrink), NULL, NULL),
          tuple("HAS_ID", as.integer(!is.null(key)), NULL, NULL),
          tuple("HANDLE_MISSING", to.integer(self$handle.missing), NULL, NULL),
          tuple("CATEGORY_WEIGHT", NULL, self$category.weight, NULL),
          tuple("ERROR_TOL", NULL, self$tol, NULL),
          tuple("EVALUATION_SEED", self$evaluation.seed, NULL, NULL),
          tuple("PROBABILITY", to.integer(self$probability), NULL, NULL),
          tuple("COMPRESSION", to.integer(self$compression), NULL, NULL),
          tuple("MAX_BITS", self$max.bits, NULL, NULL),
          tuple("MAX_QUANTIZATION_ITER", self$max.quantization.iter, NULL, NULL),

          # cv parameters
          tuple("RESAMPLING_METHOD", NULL, NULL, self$resampling.method),
          tuple("EVALUATION_METRIC", NULL, NULL,
                map.null(self$evaluation.metric, metric.map)),
          tuple("FOLD_NUM", self$fold.num, NULL, NULL),
          tuple("REPEAT_TIMES", self$repeat.times, NULL, NULL),
          tuple("PARAM_SEARCH_STRATEGY", NULL, NULL,
                self$param.search.strategy),
          tuple("RANDOM_SEARCH_TIMES", self$random.search.times, NULL, NULL),
          tuple("SEED", self$random.state, NULL, NULL),
          tuple("TIMEOUT", self$timeout, NULL, NULL),
          tuple("PROGRESS_INDICATOR_ID", NULL, NULL,
                self$progress.indicator.id)
        )
        if (!is.null(self$categorical.variable)) {
          for (variable in self$categorical.variable) {
            temp.list <- tuple("CATEGORICAL_VARIABLE", NULL, NULL, variable)
            param.array <- append(param.array, tuple(temp.list))
          }
        }
        param.map <- list(c = "svm.c", nu = "nu", gamma = "rbf.gamma",
                          degree = "poly.degree", coef.lin = "coef.lin",
                          coef.const = "coef.const")
        if (length(self$parameter.values) > 0){
          for (i in 1:length(self$parameter.values)){
            temp.name <- param.map[[names(self$parameter.values[i])]]
            param.name <- gsub("\\.", "_", toupper(temp.name))
            str.values <- paste("{",
                                paste0(self$parameter.values[[i]],
                                       collapse = ","),
                                "}", sep = "")
            temp.tup <- tuple(paste0(param.name, "_VALUES"),
                              NULL, NULL, str.values)
            param.array <-
              append(param.array,  list(temp.tup))
          }
        }
        if (length(self$parameter.range) > 0){
          for (i in 1:length(self$parameter.range)){
            temp.name <- param.map[[names(self$parameter.range[i])]]
            param.name <- gsub("\\.", "_", toupper(temp.name))
            range.temp <- self$parameter.range[[i]]
            cps <- ifelse(length(range.temp) == 2, ",,", ",")
            str.range <- paste("[",
                               paste0(range.temp,
                                      collapse = cps),
                               "]", sep = "")
            temp.tup <- tuple(paste0(param.name, "_RANGE"),
                              NULL, NULL, str.range)
            param.array <-
              append(param.array, list(temp.tup))
          }
        }

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <-
          sprintf("#%s_PARAMETER_TBL_%s_%s", model.type, self$id, unique.id)
        model.tbl <-
          sprintf("#PAL_%s_MODEL_TBL_%s_%s", model.type, self$id, unique.id)
        stat.tbl <-
          sprintf("#PAL_%s_STATISTIC_TBL_%s_%s", model.type, self$id, unique.id)
        ph.tbl <-
          sprintf("#PAL_%s_PLACEHOLDER_TBL_%s_%s", model.type, self$id, unique.id)
        tables <- list(param.tbl, model.tbl, stat.tbl, ph.tbl)
        in.tables <- list(training.data, param.tbl)
        out.tables <- list(model.tbl, stat.tbl, ph.tbl)
        tryCatch({
          errorhelper(CreateTWithConnection(conn,
                     ParameterTable$new(param.tbl)$WithData(param.array)))
          errorhelper(CallPalAutoWithConnection(conn,
                                                "PAL_SVM",
                                                in.tables,
                                                out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })
        self$model <- conn$table(model.tbl)
        self$stat <- conn$table(stat.tbl)
        self$optim.param <- conn$table(ph.tbl)
      }
    },
    predict = function(data,
                       key,
                       features = NULL,
                       qid = NULL,
                       verbose = NULL,
                       thread.ratio = NULL){
      if (is.null(self$model)){
        msg <- "Model for prediction is NULL!"
        flog.error(msg)
        stop(msg)
      }
      if (!inherits(data, "DataFrame")){
        msg <- "Data for prediction must be a DataFrame."
        flog.error(msg)
        stop(msg)
      }
      conn <- data$connection.context
      CheckConnection(data)

      verbose <- validateInput("verbose", verbose, "logical")
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      cols.left <- data$columns
      key <- validateInput("key", key, cols.left, case.sensitive = TRUE)
      cols.left <- cols.left[! cols.left %in% key]
      cols.left <- cols.left[! cols.left %in% qid]

      index.col <- key
      features <- validateInput("features", features, cols.left, case.sensitive = TRUE)
      if (length(features) == 0){
        features <- cols.left
      }

      chain.list <- c(index.col, features, qid)
      used.cols <- list()
      for (col in chain.list){
        if (!is.null(col))
          used.cols <- append(used.cols, col)
      }
      thread.ratio <- validateInput("thread.ratio", thread.ratio, "numeric")
      predict.set <- data$Select(used.cols)
      param.tbl <- sprintf("#PREDICT_PARAM_TBL_%s_%s", self$id, unique.id)
      param.array <- list(tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
                          tuple("VERBOSE_OUTPUT", to.integer(verbose),
                                NULL, NULL))
      result.tbl <- sprintf("#PREDICT_RESULT_TBL_%s_%s", self$id, unique.id)
      tables <- list(param.tbl, result.tbl)
      in.tables <- list(predict.set, self$model$name, param.tbl)
      out.tables <- list(result.tbl)

      tryCatch({
        errorhelper(CreateTWithConnection(conn,
                   ParameterTable$new(param.tbl)$WithData(param.array))) #nolint
        errorhelper(CallPalAutoWithConnection(conn,
                                              "PAL_SVM_PREDICT",
                                              in.tables,
                                              out.tables))
      },
      error = function(err){
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn, tables)
        stop(msg)
      })

      result <- conn$table(result.tbl)
      return(result)
    }
  )
)
SVC <- R6Class(
  "SVC",
  inherit = SVM.base,
  public = list(
    initialize = function(data = NULL,  key = NULL, features = NULL, label = NULL,
                          kernel = NULL, thread.ratio = NULL, degree=NULL,
                          gamma = NULL, coef.lin = NULL,
                          coef.const = NULL, c = NULL,
                          scale.info = NULL, shrink = NULL,
                          handle.missing = NULL, categorical.variable = NULL,
                          category.weight = NULL, tol = NULL,
                          evaluation.seed = NULL, probability = NULL,
                          compression = NULL, max.bits = NULL, max.quantization.iter = NULL,
                          resampling.method = NULL, evaluation.metric = NULL,
                          fold.num = NULL, repeat.times = NULL,
                          param.search.strategy = NULL, random.search.times = NULL,
                          random.state = NULL, timeout = NULL, progress.indicator.id = NULL,
                          parameter.range = NULL, parameter.values = NULL){
      super$initialize(1,
                       data, key, features, label, NULL,
                       kernel, thread.ratio, degree,
                       gamma, NULL, coef.lin,
                       coef.const, c, NULL,
                       scale.info, NULL, shrink,
                       handle.missing, categorical.variable,
                       category.weight, tol,
                       evaluation.seed, probability,
                       compression, max.bits, max.quantization.iter,
                       resampling.method, evaluation.metric,
                       fold.num, repeat.times,
                       param.search.strategy, random.search.times,
                       random.state, timeout, progress.indicator.id,
                       parameter.range, parameter.values)
    },
    score = function(data, key, features = NULL, label = NULL){
      conn <- data$connection.context
      CheckConnection(data)
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      cols <- data$columns
      key <- validateInput("key", key, cols, required = TRUE, case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      label <- validateInput("label", label, cols, case.sensitive = TRUE)
      if (is.null(label))
        label <- cols[[length(cols)]]
      cols <- cols[! cols %in% label]
      features <- validateInput("features", features, cols, case.sensitive = TRUE)
      if (!is.null(features)){
        features <- cols
      }

      label.df <- data$Select(list(key, label))
      pred.res <- self$predict(data, key, features)
      tryCatch({
        sql <- sprintf(paste0("SELECT COUNT(*) FROM (%s) res,",
                              "(%s) ori WHERE ",
                              "res.%s = ",
                              "ori.%s ",
                              "AND ori.%s = ",
                              "res.score;"),
                       pred.res$select.statement, label.df$select.statement,
                       QuoteName(data$columns[[1]]), QuoteName(data$columns[[1]]),
                       QuoteName(label))
        result <- ExecuteLogged(conn$connection, sql)
        error.check <- result[[1]] / as.double(data$nrows)
        return (result[[1]] / as.double(data$nrows))
      },
      error = function(err){
        msg <- paste("Error", err[["message"]])
        flog.error(msg)
        stop(msg)
      })
    }
  )
)
#' @title Support Vector Classification (SVC)
#' @name hanaml.SVC
#' @description hanaml.SVC is an R wrapper of SAP HANA PAL SVM for classification.
#' @seealso \code{\link{predict.SVC}}
#' @template args-data
#' @template args-key-optional
#' @template args-feature-multiple
#' @template args-label
#' @param     kernel \code{{"linear", "poly", "rbf", "sigmoid"}, optional}\cr
#'            kernel function.\cr
#'            Defaults to  "rbf".
#' @template args-threadratio
#' @param     degree \code{integer, optional}\cr
#'            Coefficient for the 'poly' kernel function.\cr
#'            Only valid when \emph{kernel} = 'poly'.
#'            Value range: >= 1.\cr
#'            Defaults to  3.
#' @param     gamma \code{double, optional}\cr
#'            Coefficient for the 'rbf' kernel function.\cr
#'            Only valid when \emph{kernel} = 'rbf'.\cr
#'            Defaults to  1.0/number of features in the dataset.
#' @param     coef.lin \code{double, optional}\cr
#'            Coefficient for the 'poly' or 'sigmoid' kernel function.\cr
#'            Only valid when \emph{kernel} = 'poly' or 'sigmoid'.\cr
#'            Defaults to 0.
#' @param     coef.const \code{double, optional}\cr
#'            Coefficient for the 'poly' or 'sigmoid' kernel function.\cr
#'            Only valid when \emph{kernel} = 'poly' or 'sigmoid'. \cr
#'            Defaults to 0.
#' @param     c \code{double}\cr Trade-off between training error and margin
#'            value range: > 0.\cr
#'            Defaults to  100.
#' @param     scale.info \code{character, optional}\cr
#'            \itemize{
#'               \item{"no" : No scale}
#'               \item{"standardization": The algorithm transforms the data to
#'               have zero mean and unit variance. }
#'               \item{"rescale" : The algorithm rescales the range of the
#'               features to scale the range in [-1,1].}
#'            }
#'            Defaults to "standardization".
#' @param     shrink \code{logical, optional}\cr Decides whether to use shrink strategy
#'            or not.Using shrink strategy may accelerate the training process.
#'            \itemize{
#'               \item{FALSE: Does not use shrink strategy.}
#'               \item{TRUE: Uses shrink strategy.}
#'            }
#'            Defaults to TRUE.
#' @param     handle.missing \code{logical, optional}\cr
#'            Whether to impute the missing values of the input data or not.
#'            If set to FALSE, all rows with missing values will be deleted.\cr
#'            Defaults to TRUE.
#' @template args-cate-var
#' @param     category.weight \code{double, optional}\cr Represents the weight of category
#'            attributes. The value must be greater than 0.\cr
#'            Defaults to 0.707.
#' @param     tol \code{double, optional}\cr Specifies the error tolerance in the training
#'            process. The value must be greater than 0.\cr
#'            Defaults to 0.001.
#' @param     evaluation.seed \code{integer, optional(deprecated)}\cr
#'            The random seed in parameter selection(same as \code{random.state}).
#'            The value must be no less than 0.\cr
#'            If set to 0, then system time is used for random generation.\cr
#'            Defaults to 0.
#'            If \code{evaluation.seed} and \code{random.state} are set simultaneously,
#'            \code{random.state} takes higher priority.\cr
#' @param     probability \code{logical, optional}\cr
#'            If you want to output probability when scoring, set this to TRUE.\cr
#'            Defaults to FALSE.
#' @param     compression \code{logical, optional}\cr
#'            Specifies if the model is stored in compressed format.
#'            New parameter added in SAP HANA Cloud and SPS05.\cr
#'            Defaults to TRUE in SAP HANA Cloud and FALSE in SAP HANA SPS05.
#' @param     max.bits \code{integer, optional}\cr
#'            The maximum number of bits to quantize continuous features.
#'            Equivalent to use
#'            \ifelse{html}{\out{2<sup>max.bits</sup>}}{\eqn{2^{max.bits}}} bins.
#'            Must be less than 31.
#'            Only valid Valid only when the value of compression is TRUE.
#'            New parameter added in SAP HANA Cloud and SPS05.\cr
#'            Defaults to 12.
#' @param     max.quantization.iter  \code{integer, optional}\cr
#'            The maximum iteration steps for quantization.
#'            Only valid Valid only when the value of compression is TRUE.
#'            New parameter added in SAP HANA Cloud and SPS05.\cr
#'            Defaults to 1000.
#'
#' @param  resampling.method   \code{character, optional}\cr
#'         Specifies the resampling values form below list.\cr
#'         valid options are listed as follows:\cr
#'         "cv", "stratified_cv", "bootstrap", "stratified_bootstrap".\cr
#'         If no value is specifier, neither model evaluation
#'         nor parameter selection is activated.
#' @param  evaluation.metric   \code{character, optional}\cr
#'         Specifies the evaluation metric for model evaluation or parameter selection.\cr
#'         Currently valid options are: "accuracy", "f1_score", "auc", "nll".
#' @param  fold.num \code{integer, optional}\cr
#'         Specifies the fold number for the cross-validation(cv).
#'         Mandatory and valid only when \code{resampling.method} is 'cv' or 'stratified_cv'.
#' @template args-crossvalidation-group
#' @param  parameter.range   \code{list, optional}\cr
#'         Specifies range of the following parameters for parameter selection:\cr
#'         \code{c, gamma, degree, nu, coef.lin, coef.const}.\cr
#'         Parameter range should be specified by 3 numbers in the form of c(start, step, end).\cr
#'         Examples:\cr
#'         parameter.range <- list(c = c(50, 10, 100)), which means taking
#'         \code{c} values from 50 to 100 with 10 being the step size, i.e.
#'         50, 60, 70, 80, 90, 100.\cr
#'         If \code{param.search.strategy} is 'random', then the middle term,
#'         i.e. step has no effect and thus can be omitted.
#' @param  parameter.values   \code{list, optional}\cr
#'         Specifies values of the following parameters for parameter selection:\cr
#'         \code{c, gamma, degree, nu, coef.lin, coef.const}.\cr
#'         Example: parameter.values <- list(gamma = c(0.01, 0.05, 0.07))
#'
#' @return
#' Returns a "SVC" object with following value:
#' \itemize{
#'   \item{model : \code{DataFrame}}\cr
#'         Model content.
#'   \item{stat : \code{DataFrame}}\cr
#'         statistics.
#' }
#' @section Examples:
#' Call the function:
#' \preformatted{
#' > svc <- hanaml.SVC(data, key = "ID", gamma = 0.005)
#' }
#' @keywords Classification
#' @export
hanaml.SVC <- function(data = NULL,  key = NULL, features = NULL, label = NULL,
                       kernel = NULL, thread.ratio = NULL, degree=NULL,
                       gamma = NULL, coef.lin = NULL,
                       coef.const = NULL, c = NULL,
                       scale.info = NULL, shrink = NULL,
                       handle.missing = NULL, categorical.variable = NULL,
                       category.weight = NULL, tol = NULL,
                       evaluation.seed = NULL, probability = NULL,
                       compression = NULL, max.bits = NULL, max.quantization.iter = NULL,
                       resampling.method = NULL, evaluation.metric = NULL,
                       fold.num = NULL, repeat.times = NULL,
                       param.search.strategy = NULL, random.search.times = NULL,
                       random.state = NULL, timeout = NULL, progress.indicator.id = NULL,
                       parameter.range = NULL, parameter.values = NULL){
  SVC$new(data,  key, features, label,
          kernel, thread.ratio, degree,
          gamma, coef.lin,
          coef.const, c,
          scale.info, shrink,
          handle.missing, categorical.variable,
          category.weight, tol,
          evaluation.seed, probability,
          compression, max.bits, max.quantization.iter,
          resampling.method, evaluation.metric,
          fold.num, repeat.times,
          param.search.strategy, random.search.times,
          random.state, timeout, progress.indicator.id,
          parameter.range, parameter.values)
}

#' @title Make Predictions from a "SVC" Object
#' @name predict.SVC
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "SVC" object.
#' @seealso \code{\link{hanaml.SVC}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#'  A 'SVC' object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @template args-verbose-svm
#' @template args-threadratio
#' @return
#'Predicted values are returned as a DataFrame, structured as follows.
#'\itemize{
#'   \item{ID: with same name and type as \emph{data}'s ID column.}
#'   \item{SCORE: type NVARCHAR, predicted class labels.}
#'   \item{PROBABILITY: type DOUBLE, Prediction probability. }
#'}
#' @section Examples:
#' Call the function with a "SVC" object svc:
#' \preformatted{
#' > predict(svc, data, key = 'ID')
#'}
#' @keywords Classification
#' @export
predict.SVC <- function(model,
                        data,
                        key,
                        features = NULL,
                        verbose = NULL,
                        thread.ratio = NULL){
  model$predict(data = data,
                key = key,
                features = features,
                qid = NULL,
                verbose = verbose,
                thread.ratio = thread.ratio)
}

SVR <- R6Class(
  "SVR",
  inherit = SVM.base,
  public = list(
    initialize = function(data = NULL,  key = NULL, features = NULL, label = NULL,
                          kernel = NULL, thread.ratio = NULL, degree=NULL,
                          gamma = NULL, coef.lin = NULL,
                          coef.const = NULL, c = NULL, regression.eps = NULL,
                          scale.info = NULL, scale.label = NULL, shrink = NULL,
                          handle.missing = NULL, categorical.variable = NULL,
                          category.weight = NULL, tol = NULL,
                          evaluation.seed = NULL,
                          compression = NULL, max.bits = NULL, max.quantization.iter = NULL,
                          resampling.method = NULL, evaluation.metric = NULL,
                          fold.num = NULL, repeat.times = NULL,
                          param.search.strategy = NULL, random.search.times = NULL,
                          random.state = NULL, timeout = NULL, progress.indicator.id = NULL,
                          parameter.range = NULL, parameter.values = NULL){
      super$initialize(2,
                       data, key, features, label, NULL,
                       kernel, thread.ratio, degree,
                       gamma, NULL, coef.lin,
                       coef.const, c, regression.eps,
                       scale.info, scale.label, shrink,
                       handle.missing, categorical.variable,
                       category.weight, tol,
                       evaluation.seed, NULL,
                       compression, max.bits, max.quantization.iter,
                       resampling.method, evaluation.metric,
                       fold.num, repeat.times,
                       param.search.strategy, random.search.times,
                       random.state, timeout, progress.indicator.id,
                       parameter.range, parameter.values)
    },
    score = function(data, key, features = NULL, label = NULL){
      if (is.null(self$model)){
        msg <- "Model not initialized. Perform a fit first"
        flog.error(msg)
        stop(msg)
      }
      conn <- data$connection.context
      CheckConnection(data)
      cols <- data$columns
      key <- validateInput("key", key, cols, required = TRUE, case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      label <- validateInput("label", label, cols, case.sensitive = TRUE)
      if (is.null(label))
        label <- cols[[length(cols)]]
      cols <- cols[! cols %in% label]
      features <- validateInput("features", features, cols, case.sensitive = TRUE)
      if (!is.null(features)){
        features <- cols
      }
      val.df <- data$Select(list(key, label))
      pred.res <- self$predict(data, key, features)
      unique.id <-
        toupper(gsub("-", "_", UUIDgenerate()))  #require UUID package
      comp.tbl <- sprintf("#SVR_COMPARE_TBL_%s_%s", self$id, unique.id)
      tryCatch({
        sql <- sprintf(paste0("CREATE LOCAL TEMPORARY COLUMN TABLE %s ",
                              "AS (SELECT res.%s, ori.%s AS ORI_VAL, ",
                              "res.SCORE AS PRED_VAL FROM (%s) ori,",
                              "(%s) res WHERE ori.%s = res.%s);"),
                       QuoteName(comp.tbl), QuoteName(data$columns[[1]]),
                       QuoteName(label), val.df$select.statement, pred.res$select.statement,
                       QuoteName(data$columns[[1]]), QuoteName(data$columns[[1]]))
        result <- ExecuteLogged(conn$connection, sql)
        result.sql <- sprintf(paste0("SELECT 1-(SUM(POWER(ORI_VAL - PRED_VAL,2)))",
                                     "%s(SUM(POWER(ORI_VAL - (SELECT AVG(ORI_VAL) ",
                                     "FROM %s),2))) FROM %s"), "/", comp.tbl, comp.tbl)
        result <- ExecuteLogged(conn$connection, result.sql)
        return (result[[1]])
      },
      error = function(err){
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        stop(msg)
      })
    }
  )
)

#' @title Support Vector Regression (SVR)
#' @name hanaml.SVR
#' @description hanaml.SVR is an R wrapper of SAP HANA PAL SVM  for regression.
#' @seealso \code{\link{predict.SVR}}
#' @template args-data
#' @template args-key-optional
#' @template args-feature-multiple
#' @template args-label
#' @param     kernel \code{{"linear", "poly", "rbf", "sigmoid"}, optional}\cr
#'            kernel function.\cr
#'            Defaults to  "rbf".
#' @template args-threadratio
#' @param     degree \code{integer, optional}\cr
#'            Coefficient for the 'poly' kernel function.\cr
#'            Only valid when \emph{kernel} = 'poly'.
#'            Value range: >= 1.\cr
#'            Defaults to 3.
#' @param     gamma \code{double, optional}\cr
#'            Coefficient for the 'rbf' kernel function.\cr
#'            Only valid when \emph{kernel} = 'rbf'.\cr
#'            Defaults to 1.0/number of features in the dataset.
#' @param     coef.lin \code{double, optional}\cr
#'            Coefficient for the 'poly' or 'sigmoid' kernel function.\cr
#'            Only valid when \emph{kernel} = 'poly' or 'sigmoid'. \cr
#'            Defaults to 0.
#' @param     coef.const \code{double, optional}\cr
#'            Coefficient for the 'poly' or 'sigmoid' kernel function.\cr
#'            Only valid when \emph{kernel} = 'poly' or 'sigmoid'\cr
#'            Defaults to 0.
#' @param     c \code{double}\cr Trade-off between training error and margin
#'            value range: > 0.\cr
#'            Defaults to 100.
#' @param     regression.eps \code{double, optional}\cr
#'            Epsilon width of tube for regression.\cr
#'            Defaults to 0.1.
#' @param     scale.info \code{character, optional}\cr
#'            \itemize{
#'               \item{"no" : No scale}
#'               \item{"standardization": The algorithm transforms the data to
#'               have zero mean and unit variance. }
#'               \item{"rescale" : The algorithm rescales the range of the
#'               features to scale the range in [-1,1].}
#'            }
#'            Defaults to "standardization".
#' @param     scale.label \code{logical, optional}\cr
#'            Controls whether to standardize the label for SVR.\cr
#'            Valid only when \emph{scale.info} is "standardization".
#'            Defaults to TRUE.
#' @param     shrink \code{logical, optional}\cr Decides whether to use shrink strategy
#'            or not.Using shrink strategy may accelerate the training process.
#'            \itemize{
#'               \item{FALSE: Does not use shrink strategy.}
#'               \item{TRUE: Uses shrink strategy.}
#'            }
#'            Defaults to TRUE.
#' @param     handle.missing \code{logical, optional}\cr
#'            Whether to impute the missing values of the input data or not.
#'            If set to FALSE, all rows with missing values will be deleted.\cr
#'            Defaults to TRUE.
#' @template args-cate-var
#' @param     category.weight \code{double, optional}\cr Represents the weight of category
#'            attributes. The value must be greater than 0.\cr
#'            Defaults to 0.707.
#' @param     tol \code{double, optional}\cr Specifies the error tolerance in the training
#'            process. The value must be greater than 0.\cr
#'            Defaults to 0.001.
#' @param     evaluation.seed \code{integer, optional(deprecated)}\cr
#'            The random seed in parameter selection(same as \code{random.state}).
#'            The value must be no less than 0.\cr
#'            If set to 0, then system time is used for random generation.\cr
#'            Defaults to 0.
#'            If \code{evaluation.seed} and \code{random.state} are set simultaneously,
#'            \code{random.state} takes higher priority.\cr
#' @param     compression \code{logical, optional}\cr
#'            Specifies if the model is stored in compressed format.
#'            New parameter added in SAP HANA Cloud and SPS05.\cr
#'            Defaults to TRUE in SAP HANA Cloud and FALSE in SAP HANA SPS05.
#' @param     max.bits \code{integer, optional}\cr
#'            The maximum number of bits to quantize continuous features.
#'            Equivalent to use
#'            \ifelse{html}{\out{2<sup>max.bits</sup>}}{\eqn{2^{max.bits}}}
#'            bins. Must be less than 31.
#'            Only valid Valid only when the value of compression is TRUE.
#'            New parameter added in SAP HANA Cloud and SPS05.\cr
#'            Defaults to 12.
#' @param     max.quantization.iter  \code{integer, optional}\cr
#'            The maximum iteration steps for quantization.
#'            Only valid Valid only when the value of compression is TRUE.
#'            New parameter added in SAP HANA Cloud and SPS05.\cr
#'            Defaults to 1000.
#'
#' @param  resampling.method   \code{character, optional}\cr
#'         Specifies the resampling values form below list.\cr
#'         valid options are listed as follows:\cr
#'         "cv", "stratified_cv", "bootstrap", "stratified_bootstrap".\cr
#'         If no value is specifier, neither model evaluation
#'         nor parameter selection is activated.
#' @param  evaluation.metric   \code{character, optional}\cr
#'         Specifies the evaluation metric for model evaluation or parameter selection.\cr
#'         Currently valid options are: "accuracy", "f1_score", "auc", "nll".
#' @param  fold.num \code{integer, optional}\cr
#'         Specifies the fold number for the cross-validation(cv).
#'         Mandatory and valid only when \code{resampling.method} is 'cv' or 'stratified_cv'.
#' @template args-crossvalidation-group
#' @param  parameter.range   \code{list, optional}\cr
#'         Specifies range of the following parameters for parameter selection:\cr
#'         \code{c, gamma, degree, nu, coef.lin, coef.const}.\cr
#'         Parameter range should be specified by 3 numbers in the form of c(start, step, end).\cr
#'         Examples:\cr
#'         parameter.range <- list(c = c(50, 10, 100)), which means taking
#'         \code{c} values from 50 to 100 with 10 being the step size, i.e.
#'         50, 60, 70, 80, 90, 100.\cr
#'         If \code{param.search.strategy} is 'random', then the middle term,
#'         i.e. step has no effect and thus can be omitted.
#' @param  parameter.values   \code{list, optional}\cr
#'         Specifies values of the following parameters for parameter selection:\cr
#'         \code{c, gamma, degree, nu, coef.lin, coef.const}.\cr
#'         Example: parameter.values <- list(gamma = c(0.01, 0.05, 0.07))
#' @return
#' \itemize{
#'   \item{model: \code{DataFrame}}\cr
#'    Model content.
#'   \item{stat: \code{DataFrame}}\cr
#'    Statistics.
#' }
#' @section Examples:
#' Call the function:
#' \preformatted{
#' > svr <- hanaml.SVR(data,
#'                     key = "ID",
#'                     kernel = "linear",
#'                     scale.info = 1,
#'                     scale.label = 1)
#'}
#' @keywords Regression
#' @export
hanaml.SVR <- function(data = NULL,  key = NULL, features = NULL, label = NULL,
                       kernel = NULL, thread.ratio = NULL, degree=NULL,
                       gamma = NULL, coef.lin = NULL,
                       coef.const = NULL, c = NULL, regression.eps = NULL,
                       scale.info = NULL, scale.label = NULL, shrink = NULL,
                       handle.missing = NULL, categorical.variable = NULL,
                       category.weight = NULL, tol = NULL,
                       evaluation.seed = NULL,
                       compression = NULL, max.bits = NULL, max.quantization.iter = NULL,
                       resampling.method = NULL, evaluation.metric = NULL,
                       fold.num = NULL, repeat.times = NULL,
                       param.search.strategy = NULL, random.search.times = NULL,
                       random.state = NULL, timeout = NULL, progress.indicator.id = NULL,
                       parameter.range = NULL, parameter.values = NULL){
  SVR$new(data,  key, features, label,
          kernel, thread.ratio, degree,
          gamma, coef.lin,
          coef.const, c, regression.eps,
          scale.info, scale.label, shrink,
          handle.missing, categorical.variable,
          category.weight, tol,
          evaluation.seed,
          compression, max.bits, max.quantization.iter,
          resampling.method, evaluation.metric,
          fold.num, repeat.times,
          param.search.strategy, random.search.times,
          random.state, timeout, progress.indicator.id,
          parameter.range, parameter.values)
}


#' @title Make Predictions from a "SVR" Object
#' @name predict.SVR
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "SVR" object.
#' @seealso \code{\link{hanaml.SVR}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#'  A 'SVR' object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @template args-verbose-svm
#' @template args-threadratio
#' @return
#'Predicted values are returned as a DataFrame, structured as follows.
#'\itemize{
#'   \item{ID: with same name and type as \emph{data}'s ID column.}
#'   \item{SCORE: type NVARCHAR, predicted values.}
#'   \item{PROBABILITY: type DOUBLE, Prediction probability. }
#'}
#' @section Examples:
#' Call the function and predict with a "SVR" object svr:
#' \preformatted{
#' > predict(svr, data, key = "ID")
#' }
#' @keywords Regression
#' @export
predict.SVR <- function(model,
                        data,
                        key,
                        features = NULL,
                        verbose = NULL,
                        thread.ratio = NULL){
  model$predict(data = data,
                key = key,
                features = features,
                qid = NULL,
                verbose = verbose,
                thread.ratio = thread.ratio);
}

SVRanking <- R6Class(
  "SVRanking",
  inherit = SVM.base,
  public = list(
    initialize = function(data = NULL,  key = NULL, features = NULL, label = NULL,
                          qid = NULL,
                          kernel = NULL, thread.ratio = NULL, degree=NULL,
                          gamma = NULL, coef.lin = NULL,
                          coef.const = NULL, c = NULL,
                          scale.info = NULL, shrink = NULL,
                          handle.missing = NULL, categorical.variable = NULL,
                          category.weight = NULL, tol = NULL,
                          evaluation.seed = NULL, probability = NULL,
                          compression = NULL, max.bits = NULL, max.quantization.iter = NULL,
                          resampling.method = NULL, evaluation.metric = NULL,
                          fold.num = NULL, repeat.times = NULL,
                          param.search.strategy = NULL, random.search.times = NULL,
                          random.state = NULL, timeout = NULL, progress.indicator.id = NULL,
                          parameter.range = NULL, parameter.values = NULL){
      super$initialize(3,
                       data, key, features, label, qid,
                       kernel, thread.ratio, degree,
                       gamma, NULL, coef.lin,
                       coef.const, c, NULL,
                       scale.info, NULL, shrink,
                       handle.missing, categorical.variable,
                       category.weight, tol,
                       evaluation.seed, probability,
                       compression, max.bits, max.quantization.iter,
                       resampling.method, evaluation.metric,
                       fold.num, repeat.times,
                       param.search.strategy, random.search.times,
                       random.state, timeout, progress.indicator.id,
                       parameter.range, parameter.values)
    }
  )
)


#' @title Support Vector Ranking
#' @name hanaml.SVRanking
#' @description hanaml.SVRanking is an R wrapper of SAP HANA PAL SVM for ranking.
#' @seealso \code{\link{predict.SVRanking}}
#' @keywords Classification
#' @template args-data
#' @template args-key-optional
#' @template args-feature-multiple
#' @template args-label
#' @param     qid \code{character}\cr
#'            Column name of QueryID.
#'            If not provided, it defaults to the last non-ID, non-label column.
#' @param     kernel \code{{"linear", "poly", "rbf", "sigmoid"}, optional}\cr
#'            kernel function.\cr
#'            Defaults to  "rbf".
#' @template args-threadratio
#' @param     degree \code{integer, optional}\cr
#'            Coefficient for the 'poly' kernel function.\cr
#'            Only valid when \emph{kernel} = 'poly'.
#'            Value range: >= 1.\cr
#'            Defaults to 3.
#' @param     gamma \code{double, optional}\cr
#'            Coefficient for the 'rbf' kernel function.\cr
#'            Only valid when \emph{kernel} = 'rbf'.\cr
#'            Defaults to 1.0/number of features in the dataset.
#' @param     coef.lin \code{double, optional}\cr
#'            Coefficient for the 'poly' or 'sigmoid' kernel function.\cr
#'            Only valid when \emph{kernel} = 'poly' or 'sigmoid'. \cr
#'            Defaults to 0.
#' @param     coef.const \code{double, optional}\cr
#'            Coefficient for the 'poly' or 'sigmoid' kernel function.\cr
#'            Only valid when \emph{kernel} = 'poly' or 'sigmoid'\cr
#'            Defaults to 0.
#' @param     c \code{double}\cr Trade-off between training error and margin
#'            value range: > 0.\cr
#'            Defaults to  100.
#' @param     scale.info \code{character, optional}\cr
#'            \itemize{
#'               \item{"no" : No scale}
#'               \item{"standardization": The algorithm transforms the data to
#'               have zero mean and unit variance. }
#'               \item{"rescale" : The algorithm rescales the range of the
#'               features to scale the range in [-1,1].}
#'            }
#'            Defaults to "standardization".
#' @param     shrink \code{logical, optional}\cr Decides whether to use shrink strategy
#'            or not.Using shrink strategy may accelerate the training process.
#'            \itemize{
#'               \item{FALSE: Does not use shrink strategy.}
#'               \item{TRUE: Uses shrink strategy.}
#'            }
#'            Defaults to TRUE.
#' @param     handle.missing \code{logical, optional}\cr
#'            Whether to impute the missing values of the input data or not.
#'            If set to FALSE, all rows with missing values will be deleted.\cr
#'            Defaults to TRUE.
#' @template args-cate-var
#' @param     category.weight \code{double, optional}\cr Represents the weight of category
#'            attributes. The value must be greater than 0.\cr
#'            Defaults to 0.707.
#' @param     tol \code{double, optional}\cr Specifies the error tolerance in the training
#'            process. The value must be greater than 0.\cr
#'            Defaults to 0.001.
#' @param     evaluation.seed \code{integer, optional(deprecated)}\cr
#'            The random seed in parameter selection(same as \code{random.state}).
#'            The value must be no less than 0.\cr
#'            If set to 0, then system time is used for random generation.\cr
#'            Defaults to 0.
#'            If \code{evaluation.seed} and \code{random.state} are set simultaneously,
#'            \code{random.state} takes higher priority.\cr
#' @param     probability \code{logical, optional}\cr
#'            If you want to output probability when scoring, set this to TRUE.\cr
#'            Defaults to FALSE.
#' @param     compression \code{logical, optional}\cr
#'            Specifies if the model is stored in compressed format.
#'            New parameter added in SAP HANA Cloud and SPS05.\cr
#'            Defaults to TRUE in SAP HANA Cloud and FALSE in SAP HANA SPS05.
#' @param     max.bits \code{integer, optional}\cr
#'            The maximum number of bits to quantize continuous features.
#'            Equivalent to use
#'            \ifelse{html}{\out{2<sup>max.bits</sup>}}{\eqn{2^{max.bits}}}
#'            bins. Must be less than 31.
#'            Only valid Valid only when the value of compression is TRUE.
#'            New parameter added in SAP HANA Cloud and SPS05.\cr
#'            Defaults to 12.
#' @param     max.quantization.iter  \code{integer, optional}\cr
#'            The maximum iteration steps for quantization.
#'            Only valid Valid only when the value of compression is TRUE.
#'            New parameter added in SAP HANA Cloud and SPS05.\cr
#'            Defaults to 1000.
#'
#' @param  resampling.method   \code{character, optional}\cr
#'         Specifies the resampling values form below list.\cr
#'         valid options are listed as follows:\cr
#'         "cv", "stratified_cv", "bootstrap", "stratified_bootstrap".\cr
#'         If no value is specifier, neither model evaluation
#'         nor parameter selection is activated.
#' @param  evaluation.metric   \code{character, optional}\cr
#'         Specifies the evaluation metric for model evaluation or parameter selection.\cr
#'         Currently valid options are: "accuracy", "f1_score", "auc", "nll".
#' @param  fold.num \code{integer, optional}\cr
#'         Specifies the fold number for the cross-validation(cv).
#'         Mandatory and valid only when \code{resampling.method} is 'cv' or 'stratified_cv'.
#' @template args-crossvalidation-group
#' @param  parameter.range   \code{list, optional}\cr
#'         Specifies range of the following parameters for parameter selection:\cr
#'         \code{c, gamma, degree, nu, coef.lin, coef.const}.\cr
#'         Parameter range should be specified by 3 numbers in the form of c(start, step, end).\cr
#'         Examples:\cr
#'         parameter.range <- list(c = c(50, 10, 100)), which means taking
#'         \code{c} values from 50 to 100 with 10 being the step size, i.e.
#'         50, 60, 70, 80, 90, 100.\cr
#'         If \code{param.search.strategy} is 'random', then the middle term,
#'         i.e. step has no effect and thus can be omitted.
#' @param  parameter.values   \code{list, optional}\cr
#'         Specifies values of the following parameters for parameter selection:\cr
#'         \code{c, gamma, degree, nu, coef.lin, coef.const}.\cr
#'         Example: parameter.values <- list(gamma = c(0.01, 0.05, 0.07))
#' @return
#'\itemize{
#'   \item{model: \code{DataFrame}}\cr
#'         Model content
#'   \item{stat: \code{DataFrame}}\cr
#'         statistics.
#'         }
#' @section Examples:
#' Call the function:
#' \preformatted{
#' > svranking <- hanaml.SVRanking(data,
#'                                 qid="QID",
#'                                 gamma = 0.005)
#' }
#' @export
hanaml.SVRanking <- function(data = NULL,  key = NULL, features = NULL, label = NULL,
                             qid = NULL,
                             kernel = NULL, thread.ratio = NULL, degree=NULL,
                             gamma = NULL, coef.lin = NULL,
                             coef.const = NULL, c = NULL,
                             scale.info = NULL, shrink = NULL,
                             handle.missing = NULL, categorical.variable = NULL,
                             category.weight = NULL, tol = NULL,
                             evaluation.seed = NULL, probability = NULL,
                             compression = NULL, max.bits = NULL, max.quantization.iter = NULL,
                             resampling.method = NULL, evaluation.metric = NULL,
                             fold.num = NULL, repeat.times = NULL,
                             param.search.strategy = NULL, random.search.times = NULL,
                             random.state = NULL, timeout = NULL, progress.indicator.id = NULL,
                             parameter.range = NULL, parameter.values = NULL){
  SVRanking$new(data, key, features, label,
                qid,
                kernel, thread.ratio, degree,
                gamma, coef.lin,
                coef.const, c,
                scale.info, shrink,
                handle.missing, categorical.variable,
                category.weight, tol,
                evaluation.seed, probability,
                compression, max.bits, max.quantization.iter,
                resampling.method, evaluation.metric,
                fold.num, repeat.times,
                param.search.strategy, random.search.times,
                random.state, timeout, progress.indicator.id,
                parameter.range, parameter.values)
}

#' @title Make Predictions from a "SVRanking" Object
#' @name predict.SVRanking
#' @description Similar to other predict methods, this function
#' predicts fitted values from a fitted "SVRanking" object.
#' @seealso \code{\link{hanaml.SVRanking}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#'  A "SVRanking" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @param qid \code{character}\cr
#' Name of the column for QueryID.
#' @template args-verbose-svm
#' @template args-threadratio
#' @return
#' Predicted values are returned as a \code{DataFrame}, structured as follows.
#' \itemize{
#'    \item{ID: with same name and type as \emph{data}'s ID column.}
#'    \item{SCORE: type NVARCHAR , predicted ranking.}
#'    \item{PROBABILITY: type DOUBLE, Prediction probability. }
#' }
#' @section Examples:
#' Call the function and predict with a "SVRanking" object svranking:
#' \preformatted{
#' > predict(svranking, data, key = 'ID', qid = 'QID')
#' }
#' @keywords Classification
#' @export
predict.SVRanking <- function(model,
                              data,
                              key,
                              features = NULL,
                              qid = NULL,
                              verbose = NULL,
                              thread.ratio = NULL){
  model$predict(data = data,
                key = key,
                features = features,
                qid = NULL,
                verbose = verbose,
                thread.ratio = thread.ratio);
}


OneClassSVM <- R6Class(
  "OneClassSVM",
  inherit = SVM.base,
  public = list(
    initialize = function(data = NULL,  key = NULL, features = NULL, label = NULL,
                          kernel = NULL, thread.ratio = NULL, degree=NULL,
                          gamma = NULL, nu = NULL, coef.lin = NULL,
                          coef.const = NULL, c = NULL,
                          scale.info = NULL, shrink = NULL,
                          handle.missing = NULL, categorical.variable = NULL,
                          category.weight = NULL, tol = NULL,
                          evaluation.seed = NULL,
                          compression = NULL, max.bits = NULL, max.quantization.iter = NULL,
                          resampling.method = NULL, evaluation.metric = NULL,
                          fold.num = NULL, repeat.times = NULL,
                          param.search.strategy = NULL, random.search.times = NULL,
                          random.state = NULL, timeout = NULL, progress.indicator.id = NULL,
                          parameter.range = NULL, parameter.values = NULL){
      super$initialize(4,
                       data, key, features, label, NULL,
                       kernel, thread.ratio, degree,
                       gamma, nu, coef.lin,
                       coef.const, c, NULL,
                       scale.info, NULL, shrink,
                       handle.missing, categorical.variable,
                       category.weight, tol,
                       evaluation.seed, NULL,
                       compression, max.bits, max.quantization.iter,
                       resampling.method, evaluation.metric,
                       fold.num, repeat.times,
                       param.search.strategy, random.search.times,
                       random.state, timeout, progress.indicator.id,
                       parameter.range, parameter.values)
    }
  )
)

#' @title One Class SVM
#' @name hanaml.OneClassSVM
#' @description hanaml.OneClassSVM is an R wrapper of SAP HANA PAL one class SVM.

#' @seealso \code{\link{predict.OneClassSVM}}
#' @template args-data
#' @template args-key-optional
#' @template args-feature-multiple
#' @template args-label
#' @param     kernel \code{{"linear", "poly", "rbf", "sigmoid"}, optional}\cr
#'            kernel function.\cr
#'            Defaults to  "rbf".
#' @template args-threadratio
#' @param     degree \code{integer, optional}\cr
#'            Coefficient for the 'poly' kernel function.\cr
#'            Only valid when \emph{kernel} = 'poly'.
#'            Value range: >= 1.\cr
#'            Defaults to 3.
#' @param     gamma \code{double, optional}\cr
#'            Coefficient for the 'rbf' kernel function.\cr
#'            Only valid when \emph{kernel} = 'rbf'.\cr
#'            Defaults to 1.0/number of features in the dataset.
#' @param     nu \code{double, optional}\cr
#'            The value for both the upper bound of the fraction
#'            of training errors and the lower bound of the fraction of support
#'            vectors.\cr
#'            Defaults to 0.5.
#' @param     coef.lin \code{double, optional}\cr
#'            Coefficient for the 'poly' or 'sigmoid' kernel function.\cr
#'            Only valid when \emph{kernel} = 'poly' or 'sigmoid'. \cr
#'            Defaults to 0.
#' @param     coef.const \code{double, optional}\cr
#'            Coefficient for the 'poly' or 'sigmoid' kernel function.\cr
#'            Only valid when \emph{kernel} = 'poly' or 'sigmoid'\cr
#'            Defaults to 0.
#' @param     c \code{double}\cr Trade-off between training error and margin
#'            value range: > 0.\cr
#'            Defaults to 100.
#' @param     scale.info \code{character, optional}\cr
#'            \itemize{
#'               \item{"no" : No scale}
#'               \item{"standardization": The algorithm transforms the data to
#'               have zero mean and unit variance. }
#'               \item{"rescale" : The algorithm rescales the range of the
#'               features to scale the range in [-1,1].}
#'            }
#'            Defaults to "standardization".
#' @param     shrink \code{logical, optional}\cr Decides whether to use shrink strategy
#'            or not.Using shrink strategy may accelerate the training process.
#'            \itemize{
#'               \item{FALSE: Does not use shrink strategy.}
#'               \item{TRUE: Uses shrink strategy.}
#'            }
#'            Defaults to TRUE.
#' @param     handle.missing \code{logical, optional}\cr
#'            Whether to impute the missing values of the input data or not.
#'            If set to FALSE, all rows with missing values will be deleted.\cr
#'            Defaults to TRUE.
#' @template args-cate-var
#' @param     category.weight \code{double, optional}\cr Represents the weight of category
#'            attributes. The value must be greater than 0.\cr
#'            Defaults to 0.707.
#' @param     tol \code{double, optional}\cr Specifies the error tolerance in the training
#'            process. The value must be greater than 0.\cr
#'            Defaults to 0.001.
#' @param     evaluation.seed \code{integer, optional(deprecated)}\cr
#'            The random seed in parameter selection(same as \code{random.state}).
#'            The value must be no less than 0.\cr
#'            If set to 0, then system time is used for random generation.\cr
#'            Defaults to 0.
#'            If \code{evaluation.seed} and \code{random.state} are set simultaneously,
#'            \code{random.state} takes higher priority.\cr
#' @param     compression \code{logical, optional}\cr
#'            Specifies if the model is stored in compressed format.
#'            New parameter added in SAP HANA Cloud and SPS05.\cr
#'            Defaults to TRUE in SAP HANA Cloud and FALSE in SAP HANA SPS05.
#' @param     max.bits \code{integer, optional}\cr
#'            The maximum number of bits to quantize continuous features.
#'            Equivalent to use
#'            \ifelse{html}{\out{2<sup>max.bits</sup>}}{\eqn{2^{max.bits}}}
#'            bins. Must be less than 31.
#'            Only valid Valid only when the value of compression is TRUE.
#'            New parameter added in SAP HANA Cloud and SPS05.\cr
#'            Defaults to 12.
#' @param     max.quantization.iter  \code{integer, optional}\cr
#'            The maximum iteration steps for quantization.
#'            Only valid Valid only when the value of compression is TRUE.
#'            New parameter added in SAP HANA Cloud and SPS05.\cr
#'            Defaults to 1000.
#'
#' @param  resampling.method   \code{character, optional}\cr
#'         Specifies the resampling values form below list.\cr
#'         valid options are listed as follows:\cr
#'         "cv", "stratified_cv", "bootstrap", "stratified_bootstrap".\cr
#'         If no value is specifier, neither model evaluation
#'         nor parameter selection is activated.
#' @param  evaluation.metric   \code{character, optional}\cr
#'         Specifies the evaluation metric for model evaluation or parameter selection.\cr
#'         Currently valid options are: "accuracy", "f1_score", "auc", "nll".
#' @param  fold.num \code{integer, optional}\cr
#'         Specifies the fold number for the cross-validation(cv).
#'         Mandatory and valid only when \code{resampling.method} is 'cv' or 'stratified_cv'.
#' @template args-crossvalidation-group
#' @param  parameter.range   \code{list, optional}\cr
#'         Specifies range of the following parameters for parameter selection:\cr
#'         \code{c, gamma, degree, nu, coef.lin, coef.const}.\cr
#'         Parameter range should be specified by 3 numbers in the form of c(start, step, end).\cr
#'         Examples:\cr
#'         parameter.range <- list(c = c(50, 10, 100)), which means taking
#'         \code{c} values from 50 to 100 with 10 being the step size, i.e.
#'         50, 60, 70, 80, 90, 100.\cr
#'         If \code{param.search.strategy} is 'random', then the middle term,
#'         i.e. step has no effect and thus can be omitted.
#' @param  parameter.values   \code{list, optional}\cr
#'         Specifies values of the following parameters for parameter selection:\cr
#'         \code{c, gamma, degree, nu, coef.lin, coef.const}.\cr
#'         Example: parameter.values <- list(gamma = c(0.01, 0.05, 0.07))
#' @return
#' Returns a "OneClassSVM" with the following attributes:
#' \itemize{
#'   \item{model : \code{DataFrame}}\cr
#'    Model content.
#'   \item{stat : \code{DataFrame}}\cr
#'   Statistics.
#' }
#' @section Examples:
#' Call the function:
#' \preformatted{
#' > svc.one <- hanaml.OneClassSVM(data,
#'                                 scale.info = 0,
#'                                 category.weight = 1)
#' }
#' @keywords Classification
#' @export
hanaml.OneClassSVM <- function(data = NULL,  key = NULL, features = NULL, label = NULL,
                               kernel = NULL, thread.ratio = NULL, degree=NULL,
                               gamma = NULL, nu = NULL, coef.lin = NULL,
                               coef.const = NULL, c = NULL,
                               scale.info = NULL, shrink = NULL,
                               handle.missing = NULL, categorical.variable = NULL,
                               category.weight = NULL, tol = NULL,
                               evaluation.seed = NULL,
                               compression = NULL, max.bits = NULL, max.quantization.iter = NULL,
                               resampling.method = NULL, evaluation.metric = NULL,
                               fold.num = NULL, repeat.times = NULL,
                               param.search.strategy = NULL, random.search.times = NULL,
                               random.state = NULL, timeout = NULL, progress.indicator.id = NULL,
                               parameter.range = NULL, parameter.values = NULL){
  OneClassSVM$new(data,  key, features, label,
                  kernel, thread.ratio, degree,
                  gamma, nu, coef.lin,
                  coef.const, c,
                  scale.info, shrink,
                  handle.missing, categorical.variable,
                  category.weight, tol,
                  evaluation.seed,
                  compression, max.bits, max.quantization.iter,
                  resampling.method, evaluation.metric,
                  fold.num, repeat.times,
                  param.search.strategy, random.search.times,
                  random.state, timeout, progress.indicator.id,
                  parameter.range, parameter.values)
}
#' @title Make Predictions from a "OneClassSVM" Object
#' @name predict.OneClassSVM
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "OneClassSVM" object.
#' @seealso \code{\link{hanaml.OneClassSVM}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#'  A 'OneClassSVM' object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @template args-verbose-svm
#' @template args-threadratio
#' @return
#' Predicted values are returned as a \code{DataFrame}, structured as follows.
#' \itemize{
#'   \item{ID: with same name and type as \emph{data}'s ID column.}
#'   \item{SCORE: type NVARCHAR. Predicted class labels, where "1" means normal, "-1" means outlier.}
#'   \item{PROBABILITY: type DOUBLE, Prediction probability. }
#' }
#' @section Examples:
#' Call the function and predict with a "OneClassSVM" object svc.one:
#' \preformatted{
#' > predict(svc.one, data, key = "ID")
#' }
#' @keywords Classification
#' @export
predict.OneClassSVM <- function(model,
                                data,
                                key,
                                features = NULL,
                                verbose = NULL,
                                thread.ratio = NULL){
  model$predict(data = data,
                key = key,
                features = features,
                qid = NULL,
                verbose = verbose,
                thread.ratio = thread.ratio);
}

#' @export
print.SVC <- function(x, ...){
  writeLines("\n")
  writeLines("SVC attributes:")
  cat(sprintf("c : %s", to.null(x$c)))
  writeLines("\n")
  cat(sprintf("kernel : %s", to.null(x$kernel)))
  writeLines("\n")
  cat(sprintf("degree : %s", to.null(x$poly.degree)))
  writeLines("\n")
  cat(sprintf("gamma : %s", to.null(x$rbf.gamma)))
  writeLines("\n")
  cat(sprintf("coef.lin : %s", to.null(x$coef.lin)))
  writeLines("\n")
  cat(sprintf("coef.const : %s", to.null(x$coef.const)))
  writeLines("\n")
  cat(sprintf("probability : %s", to.null(x$probability)))
  writeLines("\n")
  cat(sprintf("shrink : %s", to.null(x$shrink)))
  writeLines("\n")
  cat(sprintf("tol : %s", to.null(x$tol)))
  writeLines("\n")
  cat(sprintf("evaluation.seed : %s", to.null(x$evaluation.seed)))
  writeLines("\n")
  cat(sprintf("thread.ratio : %s", to.null(x$thread.ratio)))
  writeLines("\n")
  cat(sprintf("scale.info : %s", to.null(x$scale.info)))
  writeLines("\n")
  cat(sprintf("categorical.variable : %s", to.null(x$categorical.variable)))
  writeLines("\n")
  cat(sprintf("category.weight : %s", to.null(x$category.weight)))
  writeLines("\n")
  cat(sprintf("handle.missing : %s", to.null(x$handle.missing)))
  writeLines("\n")
}

#' @export
summary.SVC <- function(object, ...){
  if (!is.null(object$model)) {
    writeLines("SVC Model DataFrame:")
    print(object$model$Collect())
    writeLines("\n")
    writeLines("SVC Statistics DataFrame:")
    print(object$stat$Collect())
    writeLines("\n")
  } else {
    print("Please create a SVC object first!")
  }
}

#' @export
print.SVR <- function(x, ...){
  writeLines("\n")
  writeLines("SVR attributes:")
  cat(sprintf("c : %s", to.null(x$c)))
  writeLines("\n")
  cat(sprintf("kernel : %s", to.null(x$kernel)))
  writeLines("\n")
  cat(sprintf("degree : %s", to.null(x$poly.degree)))
  writeLines("\n")
  cat(sprintf("gamma : %s", to.null(x$rbf.gamma)))
  writeLines("\n")
  cat(sprintf("coef.lin : %s", to.null(x$coef.lin)))
  writeLines("\n")
  cat(sprintf("coef.const : %s", to.null(x$coef.const)))
  writeLines("\n")
  cat(sprintf("shrink : %s", to.null(x$shrink)))
  writeLines("\n")
  cat(sprintf("tol : %s", to.null(x$tol)))
  writeLines("\n")
  cat(sprintf("evaluation.seed : %s", to.null(x$evaluation.seed)))
  writeLines("\n")
  cat(sprintf("thread.ratio : %s", to.null(x$thread.ratio)))
  writeLines("\n")
  cat(sprintf("scale.info : %s", to.null(x$scale.info)))
  writeLines("\n")
  cat(sprintf("scale.label : %s", to.null(x$scale.label)))
  writeLines("\n")
  cat(sprintf("categorical.variable : %s", to.null(x$categorical.variable)))
  writeLines("\n")
  cat(sprintf("category.weight : %s", to.null(x$category.weight)))
  writeLines("\n")
  cat(sprintf("regression.eps : %s", to.null(x$regression.eps)))
  writeLines("\n")
  cat(sprintf("handle.missing : %s", to.null(x$handle.missing)))
  writeLines("\n")
}

#' @export
summary.SVR  <- function(object, ...){
  writeLines("SVR Model DataFrame:")
  print(object$model$Collect())
  writeLines("\n")
  writeLines("SVR Statistics DataFrame:")
  print(object$stat$Collect())
  writeLines("\n")
}

#' @export
print.SVRanking <- function(x, ...){
  writeLines("\n")
  writeLines("SVRanking attributes:")
  cat(sprintf("c : %s", to.null(x$c)))
  writeLines("\n")
  cat(sprintf("kernel : %s", to.null(x$kernel)))
  writeLines("\n")
  cat(sprintf("degree : %s", to.null(x$poly.degree)))
  writeLines("\n")
  cat(sprintf("gamma : %s", to.null(x$rbf.gamma)))
  writeLines("\n")
  cat(sprintf("coef.lin : %s", to.null(x$coef.lin)))
  writeLines("\n")
  cat(sprintf("coef.const : %s", to.null(x$coef.const)))
  writeLines("\n")
  cat(sprintf("probability : %s", to.null(x$probability)))
  writeLines("\n")
  cat(sprintf("shrink : %s", to.null(x$shrink)))
  writeLines("\n")
  cat(sprintf("tol : %s", to.null(x$tol)))
  writeLines("\n")
  cat(sprintf("evaluation.seed : %s", to.null(x$evaluation.seed)))
  writeLines("\n")
  cat(sprintf("thread.ratio : %s", to.null(x$thread.ratio)))
  writeLines("\n")
  cat(sprintf("scale.info : %s", to.null(x$scale.info)))
  writeLines("\n")
  cat(sprintf("categorical.variable : %s", to.null(x$categorical.variable)))
  writeLines("\n")
  cat(sprintf("category.weight : %s", to.null(x$category.weight)))
  writeLines("\n")
  cat(sprintf("handle.missing : %s", to.null(x$handle.missing)))
  writeLines("\n")
}

#' @export
summary.SVRanking <- function(object, ...){
  writeLines("SVRanking Model DataFrame:")
  print(object$model$Collect())
  writeLines("\n")
  writeLines("SVRanking Statistics DataFrame:")
  print(object$stat$Collect())
  writeLines("\n")
}

#' @export
print.OneClassSVM <- function(x, ...){
  writeLines("\n")
  writeLines("OneClassSVM attributes:")
  cat(sprintf("c : %s", to.null(x$c)))
  writeLines("\n")
  cat(sprintf("kernel : %s", to.null(x$kernel)))
  writeLines("\n")
  cat(sprintf("degree : %s", to.null(x$poly.degree)))
  writeLines("\n")
  cat(sprintf("gamma : %s", to.null(x$rbf.gamma)))
  writeLines("\n")
  cat(sprintf("coef.lin : %s", to.null(x$coef.lin)))
  writeLines("\n")
  cat(sprintf("coef.const : %s", to.null(x$coef.const)))
  writeLines("\n")
  cat(sprintf("shrink : %s", to.null(x$shrink)))
  writeLines("\n")
  cat(sprintf("tol : %s", to.null(x$tol)))
  writeLines("\n")
  cat(sprintf("evaluation.seed : %s", to.null(x$evaluation.seed)))
  writeLines("\n")
  cat(sprintf("thread.ratio : %s", to.null(x$thread.ratio)))
  writeLines("\n")
  cat(sprintf("nu : %s", to.null(x$nu)))
  writeLines("\n")
  cat(sprintf("scale.info : %s", to.null(x$scale.info)))
  writeLines("\n")
  cat(sprintf("categorical.variable : %s", to.null(x$categorical.variable)))
  writeLines("\n")
  cat(sprintf("category.weight : %s", to.null(x$category.weight)))
  writeLines("\n")
  cat(sprintf("handle.missing : %s", to.null(x$handle.missing)))
  writeLines("\n")
}

#' @export
summary.OneClassSVM <- function(object, ...){
  writeLines("OneClassSVM Model DataFrame:")
  print(object$model$Collect())
  writeLines("\n")
  writeLines("OneClassSVM Statistics DataFrame:")
  print(object$stat$Collect())
  writeLines("\n")
}
