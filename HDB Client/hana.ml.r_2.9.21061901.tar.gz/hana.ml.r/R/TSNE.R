
#' @title T-distributed Stochastic Neighbour Embedding
#' @name hanaml.TSNE
#' @description hanaml.TSNE is a R wrapper
#' for SAP HANA PAL T-distributed Stochastic Neighbour Embedding.
#' @details
#' This algorithm prepares the data for visualization of the data with the
#' TSNE method. It returns a DataFrame of two-dimensional
#' embeddings of the high-dimensional rows of input data.
#' @template args-data
#' @template args-key-first
#' @template args-feature-multiple
#' @param     max.iter \code{integer, optional}\cr
#'            Specifies the maximum number of iterations for optimization
#'            process.\cr
#'            Defaults to 250.
#' @param     obj.freq \code{integer, optional}\cr
#'            Specifies the Frequency of calculating the objective
#'            function and putting the result into OBJECTIVES table.\cr
#'            Defaults to 50.
#' @param     dim \code{integer, optional}\cr
#'            Dimension of the embedded space. Value other than 2 or 3 is
#'            illegal.\cr
#'            Defaults to 2.
#' @param     learning.rate \code{double, optional}\cr
#'            Secifies the learning rate.\cr
#'            Defaults to 200.0.
#' @param     theta \code{double, optional}\cr
#'            The legal value should be between 0.0 to 1.0. Setting it to 0.0
#'            means using the “exact” method
#'            which would run O(N^2) time, otherwise TSNE would employ
#'            Barnes-Hut approximation hich would run O(NlogN).
#'            This value is a tradeoff between accuracy and training speed
#'            for Barnes-Hut approximation. The training speed would be faster
#'            with higher value.\cr
#'            Defaults to 0.5.
#' @param     perplexity \code{double, optional}\cr
#'            The perplexity is related to the number of nearest neighbors.
#'            Larger value is suitable for large dataset.
#'            Make sure \code{perplexity} * 3 < [number of samples].\cr
#'            Default to 30.0.
#' @param     exaggeration \code{double, optional}\cr
#'            The natural clusters would be more separated with larger value,
#'            which means there would be more empty space on the map.
#'            It specifies the value to be multiplied on pij before 250
#'            iterations.\cr
#'            Default to 12.0.
#' @param     random.state \code{double, optional}\cr
#'            Specifies the seed for random number generation, where 0 means
#'            current system time s used as seed, and other values are simply
#'            real seed values.\cr
#'            Defaults to 0.
#' @template args-threadratio
#'
#' @return
#' Returns a list of DataFrame
#' \itemize{
#'   \item{\code{DataFrame 1 }\cr Result of points in low-dimensional embedded space, structured as follows}
#'   \itemize{
#'     \item{ID: ID (correspond to input table).}
#'     \item{x: Coordinate value of the 1st dimension.}
#'     \item{y: Coordinate value of the 2nd dimension.}
#'     \item{z: Coordinate value of the 3rd dimension.(NULL if the embedded space is 2 dimension)}
#'    }
#'   \item{\code{DataFrame 2 }\cr Statistical info, structured as follows}
#'   \itemize{
#'     \item{STAT_NAME: Statistics name.}
#'     \item{STAT_VALUE: Statistics value.}
#'    }
#'   \item{\code{DataFrame 3}\cr Recorded values of objective function for TSNE.}
#'   \itemize{
#'     \item{ITER: Iteration step.}
#'     \item{OBJ_VALUE: Objective value of the iteration.}
#'     }
#' }
#' @section Examples:
#' \preformatted{
#' > data$Collect()
#'   ID ATT1 ATT2 ATT3 ATT4 ATT5
#' 1  1    1    2  -10  -20    3
#' 2  2    4    5  -30  -10    6
#' 3  3    7    8  -40  -50    9
#' 4  4   10   11  -25  -15   12
#' 5  5   13   14  -12  -24   15
#' 6  6   16   17   -9  -13   18
#' }
#' Call the function:
#' \preformatted{
#' > results <- hanaml.TSNE(data = data, perplexity = 1, max.iter = 500,
#'                          dim = 3, theta = 0, obj.freq = 50, random.state = 30)
#' }
#' Results:
#' \preformatted{
#' > results[[1]]$Collect()
#'   ID          x         y         z
#' 1  1   4.875853 -189.0905 -229.5364
#' 2  2 -67.675459  213.6617  178.3976
#' 3  3 -68.852910  162.7109  284.9663
#' 4  4 -68.056108  193.1181  220.2754
#' 5  5  76.524624 -189.8509 -227.6257
#' 6  6 123.184000 -190.5492 -226.4772
#' }
#' @keywords Miscellaneous
#' @export

hanaml.TSNE  <- function(
  data = NULL,
  key = NULL,
  features = NULL,
  max.iter = NULL,
  obj.freq = NULL,
  dim = NULL,
  learning.rate = NULL,
  theta = NULL,
  perplexity = NULL,
  exaggeration = NULL,
  random.state = NULL,
  thread.ratio = NULL) {
  if (is.null(data)) {
    msg <- "data is NULL, please provide data to proceed!"
    flog.error(msg)
    stop(msg)
  }
  cols  <-  data$columns
  key <- validateInput("key", key, cols,
                       case.sensitive = TRUE)
  if (is.null(key)) {
    key  <-  cols[[1]]
  }
  cols <- cols[! cols %in% key]
  features <- validateInput("features", features, cols,
                            case.sensitive = TRUE)
  if (is.null(features)) {
    features  <-  cols
  }
  max.iter <- validateInput("max.iter", max.iter, "integer")
  learning.rate <- validateInput("learning.rate", learning.rate,
                                 "numeric")
  dim <- validateInput("dim", dim, "integer")
  obj.freq <- validateInput("obj.freq", obj.freq, "integer")
  check.list <- list(learning.rate = learning.rate,
                     max.iter = max.iter,
                     obj.freq = obj.freq)
  for (i in c(1:3)) {
    value <- check.list[[i]]
    if (!is.null(value)) {
      if (value < 0) {
        msg <- sprintf("Invalid input! %s is less than 0.",
                       names(check.list[i]))
        flog.error(msg)
        stop(msg)
      }
    }
  }
  if (!is.null(dim)) {
    if (!dim %in% c(2, 3)) {
      msg <- paste("The embedded space can not be other",
                   "than 2 or 3 dimensional.")
      flog.error(msg)
      stop(msg)
    }
  }
  if (!is.null(obj.freq) && !is.null(max.iter)) {
    if (obj.freq > max.iter) {
      msg <- "obj.freq should not exceed the value of max.iter!"
      flog.error(msg)
      stop(msg)
    }
  }
  thread.ratio <- validateInput("thread.ratio", thread.ratio, "numeric")
  if (!is.null(thread.ratio)) {
    if (thread.ratio < 0 || thread.ratio > 1) {
      msg <- "The thread.ratio value range is from 0 to 1!"
      flog.error(msg)
      stop(msg)
    }
  }
  theta <- validateInput("theta", theta, "numeric")
  if (!is.null(theta)) {
    if (theta < 0 || theta > 1) {
      msg <- "The legal value of theta should be between 0.0 to 1.0."
      flog.error(msg)
      stop(msg)
    }
  }
  perplexity <- validateInput("perplexity", perplexity, "numeric")
  if (!is.null(perplexity)) {
    if (!perplexity * 3 < data$Count()) {
      msg <- paste("perplexity times 3 must be less than number of",
                   "samples in input dataframe.")
      flog.error(msg)
      stop(msg)
    }
  }
  random.state <- validateInput("random.state", random.state,
                                "integer")
  exaggeration <- validateInput("exaggeration", exaggeration,
                                "numeric")
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame."
    flog.error(msg)
    stop(msg)
  }
  conn <- data$connection.context
  CheckConnection(data)
  data  <-  data$Select(c(key, features))
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_ENTROPY_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_RESULT_TBL_%s", unique.id)
  stat.tbl <- sprintf("#PAL_STAT_TBL_%s", unique.id)
  objectives.tbl <- sprintf("#PAL_OBJECTIVES_TBL_%s", unique.id)
  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl, stat.tbl, objectives.tbl)
  tables <-  c(param.tbl, out.tables)

  param.array <- list(
    tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
    tuple("MAX_ITER", max.iter, NULL, NULL),
    tuple("OBJ_FREQ", obj.freq, NULL, NULL),
    tuple("NO_DIM", dim, NULL, NULL),
    tuple("ETA", NULL, learning.rate, NULL),
    tuple("THETA", NULL, theta, NULL),
    tuple("PERPLEXITY", NULL, perplexity, NULL),
    tuple("EXAGGERATION", NULL, exaggeration, NULL),
    tuple("SEED", random.state, NULL, NULL)
  )
  tryCatch({
    errorhelper(CreateTWithConnection(
      conn, ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(
      conn, "PAL_TSNE", in.tables, out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  result <-  conn$table(result.tbl)
  stat <-  conn$table(stat.tbl)
  objectives  <-  conn$table(objectives.tbl)
  return(list(result, stat, objectives))
}
