PCA <- R6Class(
  "PCA",
  inherit = MlBase,
  public = list(
    scaling = NULL,
    thread.ratio = NULL,
    scores.output = NULL,
    loadings = NULL,
    loadings.stat = NULL,
    scores = NULL,
    scaling.stat = NULL,
    model = NULL,
    initialize = function(data = NULL,
                          key = NULL,
                          features = NULL,
                          formula = NULL,
                          scaling = NULL,
                          thread.ratio = NULL,
                          scores.output = NULL){
      super$initialize()
      if (!is.null(data)){
        self$scaling <- validateInput("scaling", scaling, "logical")
        self$thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
        if (!is.null(thread.ratio)){
          if (!(thread.ratio >= 0 && thread.ratio <= 1)){
            msg <- sprintf("thread.ratio %s is out of bounds!", thread.ratio)
            flog.error(msg)
            stop(msg)
          }
        }
        self$scores.output <- validateInput("scores.output", scores.output, "logical")
        cols <- data$columns
        key <- validateInput("key", key, cols, case.sensitive = TRUE, required = TRUE)

        if (inherits(formula, "formula")){
          parseformula <- ParseFormula(data, formula)
          features <- parseformula[[2]]
          features <- features[! features %in% key]
        }

        cols <- cols[! cols %in% key]
        features <- validateInput("features", features, cols, case.sensitive = TRUE)
        if (is.null(features)){
          features <- cols
        }
        if (!inherits(data, "DataFrame")) {
          msg <- "If data is not omitted, it must be DataFrame."
          flog.error(msg)
          stop(msg)
        }
        conn <- data$connection.context
        CheckConnection(data)
        data <- data$Select(list(key, unlist(features)))

        param.data <- list(
          tuple("SCALING", to.integer(self$scaling), NULL, NULL),
          tuple("SCORES", to.integer(self$scores.output), NULL, NULL),
          tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL)
        )

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PCA_PARAMS_%s_%s", self$id, unique.id)
        loadings.tbl <- sprintf("#LOADINGS_TBL_%s_%s", self$id, unique.id)
        loadingsinfo.tbl <- sprintf("#PCA_LOADINGSINFO_TBL_%s_%s", self$id, unique.id)
        scores.tbl <- sprintf("#PCA_SCORES_TBL_%s_%s", self$id, unique.id)
        scalinginfo.tbl <- sprintf("#PCA_SCALINGINFO_TBL_%s_%s", self$id, unique.id)
        tables <- list(param.tbl, loadings.tbl, loadingsinfo.tbl,
                       scores.tbl, scalinginfo.tbl)
        in.tables <- list(data, param.tbl)
        out.tables <- list(loadings.tbl, loadingsinfo.tbl,
                           scores.tbl, scalinginfo.tbl)
        tryCatch({
          errorhelper(CreateTWithConnection(conn,
                      ParameterTable$new(param.tbl)$WithData(param.data)))
          errorhelper(CallPalAutoWithConnection(conn,
                                                "PAL_PCA",
                                                in.tables,
                                                out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })
        self$loadings <- conn$table(loadings.tbl)
        self$loadings.stat <- conn$table(loadingsinfo.tbl)
        self$scores <- conn$table(scores.tbl)
        self$scaling.stat <- conn$table(scalinginfo.tbl)
        self$model <- list(self$loadings, self$scaling.stat)
      }
    }
  )
)
#' @title  Principal Component Analysis (PCA)
#' @name hanaml.PCA
#' @description hanaml.PCA is a R wrapper for SAP HANA PAL PCA.
#' @details The principal component analysis procedure to reduce the
#'  dimensionality of multivariate data using Singular Value Decomposition.
#' @seealso \code{\link{transform.PCA}}
#' @template args-data
#' @template args-key
#' @template args-feature-multiple
#' @template args-formula
#' @param scaling \code{logical, optional}\cr
#' If TRUE, scale variables to have unit variance before the analysis takes place.\cr
#' Defaults to FALSE.
#' @template args-threadratio-1
#' @param scores.output \code{logical, optional}\cr
#' If TRUE, output the scores on each principal component when fitting.\cr
#' Defaults to FALSE.
#' @return
#' Returns a "PCA" object with following values:
#' \itemize{
#'   \item{loadings : \code{DataFrame}}\cr
#'   The weights by which each standardized original variable should be\cr
#'   multiplied when computing component scores.
#'   \item{loadings.stat : \code{DataFrame}}\cr
#'   Loading statistics on each component
#'   \item{scores : \code{DataFrame}}\cr
#'   The transformed variable values corresponding to each data point.\cr
#'   Set to NULL if \emph{scores} is FALSE.
#'   \item{scaling.stat : \code{DataFrame}}\cr
#'   Mean and scale values of each variable
#'   \item{model : \code{list of DataFrame}}\cr
#'   The fitted model.
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Head(4)$Collect()
#'    ID    X1    X2    X3    X4
#' 1   1  12.0  52.0  20.0  44.0
#' 2   2  12.0  57.0  25.0  45.0
#' 3   3  12.0  54.0  21.0  45.0
#' 4   4  13.0  52.0  21.0  46.0
#' }
#' Call the function:
#' \preformatted{
#' > pca <- hanaml.PCA(data = data,
#'                     key = "ID",
#'                     scaling=TRUE,
#'                     thread.ratio=0.5,
#'                     scores.output=TRUE)
#' }
#' Output:
#' \preformatted{
#' > pca$loadings$Collect()
#'   COMPONENT_ID  LOADINGS_X1  LOADINGS_X2  LOADINGS_X3  LOADINGS_X4
#' 1        Comp1     0.541547     0.321424     0.511941     0.584235
#' 2        Comp2    -0.454280     0.728287     0.395819    -0.326429
#' 3        Comp3    -0.171426    -0.600095     0.760875    -0.177673
#' 4        Comp4    -0.686273    -0.078552    -0.048095     0.721489
#' > pca$loadings.stat$Collect()
#'   COMPONENT_ID        SD  VAR_PROP  CUM_VAR_PROP
#' 1        Comp1  1.566624  0.613577      0.613577
#' 2        Comp2  1.100453  0.302749      0.916327
#' 3        Comp3  0.536973  0.072085      0.988412
#' 4        Comp4  0.215297  0.011588      1.000000
#' > pca$scaling.stat$Collect()
#'    VARIABLE_ID       MEAN     SCALE
#' 1            1  17.000000  5.039841
#' 2            2  53.636364  1.689540
#' 3            3  23.000000  2.000000
#' 4            4  48.454545  4.655398
#' }
#' @keywords Preprocessing
#' @export
hanaml.PCA <- function(data = NULL,
                       key = NULL,
                       features = NULL,
                       formula = NULL,
                       scaling = NULL,
                       thread.ratio = NULL,
                       scores.output = NULL){
  PCA$new(data, key, features, formula, scaling, thread.ratio, scores.output)
}


#' @title Make Projection from a "PCA" Object
#' @name transform.PCA
#' @description Similar to other transform methods, this function
#' transforms values from a "PCA" object.
#' @seealso \code{\link{hanaml.PCA}}
#' @param model \code{PCA R6 model}\cr The model you want to transform
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @param n.components \code{integer, optional}\cr Number of components to be
#' retained.\cr
#' The value range is from 1 to number of features.\cr Defaults to number of
#' features.
#' @param scaling \code{logical, optional}\cr
#' If TRUE, scale variables to have unit variance before the analysis\cr
#' takes place.\cr
#' Defaults to FALSE.
#' @param     ... Reserved parameter.
#' @return
#' \code{DataFrame}\cr
#' Transformed variable values corresponding to each data point,
#' structured as follows:
#' \itemize{
#'   \item{ID column, with same name and type as \emph{data}'s ID column.}
#'   \item{Score columns, type DOUBLE, representing the component score
#'   values of each data point.}
#' }
#' @section Examples:
#' Perform the transformation on DataFrame data2 using "PCA" object pca:
#' \preformatted{
#' > data2$Collect()
#'   ID X1 X2 X3 X4 X5 X6
#' 1  1  2 32 10 54 38 20
#' 2  2  9 57 20 25 48 19
#' 3  3 12 24 28 35 30 20
#' 4  4 15 42 27 36 61 27
#' }
#' Call the function:
#' \preformatted{
#' > result <- transform(pca, data2, key="ID", n.components=4, scaling = TRUE)
#' }
#' Output:
#' \preformatted{
#' > result[[1]]$Collect()
#'   ID COMPONENT_1 COMPONENT_2 COMPONENT_3 COMPONENT_4 COMPONENT_5 COMPONENT_6
#' 1  1 -6.60374153  -12.352444   2.7068428   5.0252348          NA          NA
#' 2  2 -4.06006881    1.910325  -0.9619991  -1.2077427          NA          NA
#' 3  3 -6.33107883  -11.018845  12.5079870   2.3591360          NA          NA
#' 4  4 -0.03122317   -4.423641   6.3617901  -0.5825786          NA          NA
#' }
#' @keywords Preprocessing
#' @export
transform.PCA <- function(model,
                          data,
                          key,
                          features=NULL,
                          n.components=NULL,
                          scaling = NULL,
                          ...){
  if (is.null(model$model)){
    msg <- "Model for transform is NULL."
    flog.error(msg)
    stop(msg)
  }
  n.components <- validateInput("n.components", n.components, "integer")
  cols <- data$columns
  key <- validateInput("key", key, cols, required = TRUE, case.sensitive = TRUE)
  cols <- cols[! cols %in% key]
  features <- validateInput("features", features, cols, case.sensitive = TRUE)
  if (is.null(features)){
    features <- cols
  }
  if (!is.null(n.components)){
    if (!(0 < n.components && n.components <= length(features))){
      msg <- sprintf("n.components %s is out of bounds", n.components)
      flog.error(msg)
      stop()
    }
  }

  if (!inherits(data, "DataFrame")) {
    msg <- "If data is not omitted, it must be DataFrame."
    flog.error(msg)
    stop(msg)
  }
  conn <- data$connection.context
  CheckConnection(data)

  data <- data$Select(list(key, unlist(features)))
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_PCA_PROJECT_PARAM_TBL_%s", unique.id)
  scores.tbl <- sprintf("#PAL_PCA_SCORES_PROJECT_TBL_%s", unique.id)
  param.array <- list(
    tuple("SCALING", to.integer(scaling), NULL, NULL),
    tuple("MAX_COMPONENTS", n.components, NULL, NULL),
    tuple("THREAD_RATIO", NULL, model$thread.ratio, NULL))
  tables <- list(param.tbl, scores.tbl)
  in.tables <- list(data,
                    model$model[[1]]$name,
                    model$model[[2]]$name,
                    param.tbl)
  out.tables <- list(scores.tbl)
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
               ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_PCA_PROJECT",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return (conn$table(scores.tbl))
}
