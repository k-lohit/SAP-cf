UnifiedRegression <- R6Class(
  "UnifiedRegression",
  inherit = MlBase,
  public = list(
    params = NULL,
    func = NULL,
    model = NULL,
    statistics = NULL,
    optimal.param = NULL,
    partition = NULL,
    initialize = function(data = NULL,
                          func = NULL,
                          key = NULL,
                          features = NULL,
                          label = NULL,
                          purpose = NULL,
                          formula = NULL,
                          partition.method = NULL,
                          partition.random.state = NULL,
                          training.percent = NULL,
                          output.partition.result = NULL,
                          ...) {
      super$initialize()
      if (!is.null(data)) {
        self$func <- validateInput("func", func, private$func.list,
                                   required = TRUE)
        self$params <- list(func = self$func)
        partition.method <- validateInput("partition.method", partition.method,
                                          private$partition.map)
        self$params <- append(self$params, list(...))
        private$pal.params <- list()
        if (isTRUE(any(sapply(c("random", "expo",
                                "logar", "geo"), grepl, self$func)))) {
          func.map <- private$map.list[[private$func.list[[self$func]]]]
        } else {
          func.map <- append(private$map.list[[private$func.list[[self$func]]]],
                             private$cv.map)
        }
        if (isTRUE(any(sapply(c("expo", "logar",
                                "geo", "poly"), grepl, self$func)))) {
          func.map <- append(private$param.dict, func.map)
        }
        param.names <- names(self$params)
        valid.names <- names(func.map)
        if (length(self$params) > 1) {
          for (i in c(2:length(self$params))) {
            par.name <- param.names[i]
            if (! par.name %in% valid.names) {
              msg <- paste("Unrecognized parameter name:",
                           par.name)
              flog.error(msg)
              stop(msg)
            }
            map.value <- func.map[[par.name]]
            if (length(map.value) == 2) {
              constr <- map.value[[2]]
            } else {
              constr <- map.value[[3]]
            }
            par.val <- self$params[[i]]
            if (map.value[[2]] == "list") {
              if (typeof(self$params[[i]]) %in% c("double",
                                                  "integer",
                                                  "character")) {
                if (length(self$params[[i]]) > 1) {#nolint
                  par.val <-  as.list(self$params[[i]])
                }
              }
            }
            if (map.value[[2]] == "list" &&
                (is.character(par.val) || is.numeric(par.val))) {
              par.val <- as.list(par.val)
            }
            par.val <- validateInput(par.name, par.val, constr)
            if (length(map.value) == 3) {
              par.val <-  map.value[[3]][[par.val]]
            }
            private$pal.params[[map.value[[1]]]] <- list(par.val,
                                                         map.value[[2]])
          }
        }
        cols <- data$columns
        key <- validateInput("key", key, cols,
                             case.sensitive = TRUE)
        cols <- cols[! cols %in% key]
        if (is.null(formula)) {
          purpose <- validateInput("purpose", purpose, cols,
                                   case.sensitive = TRUE,
                                   required = isTRUE(grepl("user",
                                                           partition.method)))
          cols <- cols[! cols %in% purpose]
          label <- validateInput("label", label, cols,
                                 case.sensitive = TRUE)
          if (is.null(label)) {
            label <- cols[[length(cols)]]
          }
          cols <- cols[! cols %in% label]
          features <- validateInput("features", features, cols,
                                    case.sensitive = TRUE)
          if (is.null(features)) {
            features <- cols
          }
        } else {
          FeatureLabels <- ParseFormula(data, formula)
          label <- FeatureLabels[[1]]
          label <- validateInput("label", label, cols,
                                 case.sensitive = TRUE)
          cols <- cols[! cols %in% label]
          features <- FeatureLabels[[2]]
          features <- features[! features %in% c(key, purpose)]
          features <- validateInput("features", features, cols,
                                    case.sensitive = TRUE)
        }
        partition.random.state <- validateInput("partition.random.state",
                                                partition.random.state,
                                                "integer")
        training.percent <- validateInput("training.percent",
                                          training.percent,
                                          "numeric")
        output.partition.result <- validateInput("output.partition.result",
                                                 output.partition.result,
                                                 "logical")
        param.rows <- list(tuple("FUNCTION", NULL, NULL,
                                 private$func.list[[self$func]]),
                           tuple("KEY", as.integer(!is.null(key)),
                                 NULL, NULL))
        param.rows <-
          append(param.rows,
                 list(tuple("PARTITION_METHOD", map.null(partition.method,
                                                         private$partition.map),
                            NULL, NULL),
                      tuple("PARTITION_RANDOM_SEED", partition.random.state,
                            NULL, NULL),
                      tuple("PARTITION_TRAINING_PERCENT", NULL,
                            training.percent, NULL),
                      tuple("OUTPUT_PARTITION_RESULT",
                            to.integer(output.partition.result),
                            NULL, NULL)))
        pal.names <- names(private$pal.params)
        for (i in seq_len(length(private$pal.params))) {
          var.name <- pal.names[i]
          var.info <- private$pal.params[[var.name]]
          if (var.info[[2]] == "integer") {
            param.rows <- append(param.rows,
                                 list(tuple(var.name,
                                            var.info[[1]],
                                            NULL, NULL)))
          } else if (var.info[[2]] == "logical") {
            if (var.name == "INTERCEPT") {
              param.rows <- append(param.rows,
                                   list(tuple(var.name,
                                              to.integer(!var.info[[1]]),
                                              NULL, NULL)))
            } else {
              param.rows <- append(param.rows,
                                   list(tuple(var.name,
                                              to.integer(var.info[[1]]),
                                              NULL, NULL)))
            }
          } else if (var.info[[2]] == "numeric") {
            param.rows <- append(param.rows,
                                 list(tuple(var.name,
                                            NULL,
                                            var.info[[1]],
                                            NULL)))
          } else if (var.info[[2]] == "character") {
            param.rows <- append(param.rows,
                                 list(tuple(var.name,
                                            NULL, NULL,
                                            var.info[[1]])))
          } else if (var.name %in% c("CATEGORICAL_VARIABLE",
                                     "REF_METRIC",
                                     "MANDATORY_FEATRUE")) {
            for (val in var.info[[1]]) {
              val <- ifelse(grepl(var.name,
                                  "REF_"),
                            toupper(val),
                            val)
              param.rows <- append(param.rows,
                                   list(tuple(var.name,
                                              NULL, NULL,
                                              val)))
            }
          } else if (grepl("HIDDEN_LAYER", var.name)) {
            str.val <- paste0("\"", paste(var.info[[1]],
                                          collapse = ","),
                              "\"")
            param.rows <-
              append(param.rows,
                     list(tuple("HIDDEN_LAYER_SIZE",
                                NULL, NULL,
                                str.val)))
          } else if (var.name == "_VALUES") {
            for (j in seq(length(var.info[[1]]))) {
              cv.var.name <- names(var.info[[1]][j])
              if (! cv.var.name %in% names(func.map)) {
                msg <- paste0("Invalid parameter name: ",
                              cv.var.name,
                              ", for values specification.")
                flog.error(msg)
                stop(msg)
              }
              if (isTRUE(grepl("activation", cv.var.name))) {
                actv.map <- private$map.list[["MLP"]]$activation[[3]]
                val.vec <- c()
                for (actv in var.info[[1]][[j]]) {
                  if (! actv %in% names(actv.map)) {
                    msg <- paste0("Invalid activation \'", actv,
                                  "\' in parameter.values.")
                    flog.error(msg)
                    stop(msg)
                  }
                  val.vec <- append(val.vec,
                                    actv.map[[actv]])
                }
                param.rows <-
                  append(param.rows,
                         list(tuple(paste0(func.map[[cv.var.name]][[1]],
                                           "_OPTIONS"),
                                    NULL, NULL,
                                    paste0("{",
                                           paste(val.vec, collapse = ", "),
                                           "}"))))
              } else if (isTRUE(grepl("hidden", cv.var.name))) {
                layer.str <- c()
                for (sz in var.info[[1]][[j]]) {
                  layer.str <- c(layer.str,
                                 paste0("\"",
                                        paste(sz, collapse = ","),
                                        "\""))
                }
                layer.str <- paste0("{",
                                    paste(layer.str,
                                          collapse = ", "),
                                    "}")
                param.rows <-
                  append(param.rows,
                         list(tuple("HIDDEN_LAYER_SIZE_OPTIONS",
                                    NULL, NULL, layer.str)))
              } else {
                param.rows <-
                  append(param.rows,
                         list(tuple(paste0(func.map[[cv.var.name]][[1]],
                                           "_VALUES"),
                                    NULL, NULL,
                                    paste0("{",
                                           paste(var.info[[1]][[j]],
                                                 collapse = ", "),
                                           "}"))))
              }
            }
          } else if (var.name == "_RANGE") {
            for (j in seq(length(var.info[[1]]))) {
              cv.var.name <- names(var.info[[1]][j])
              if (! cv.var.name %in% names(func.map)) {
                msg <- paste0("Invalid parameter name: ",
                              cv.var.name,
                              ", for range specification.")
                flog.error(msg)
                stop(msg)
              }
              pal.var.name <- paste0(func.map[[cv.var.name]][[1]],
                                     "_RANGE")
              sep <- ifelse(length(var.info[[1]][[j]]) == 2,
                            ",, ", ", ")
              param.rows <-
                append(param.rows,
                       list(tuple(pal.var.name,
                                  NULL, NULL,
                                  paste0("[",
                                         paste(var.info[[1]][[j]],
                                               collapse = sep),
                                         "]"))))
            }
          }
        }
        if (!inherits(data, "DataFrame")) {
          msg <- "Data for Unified Regression model fitting must be a DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn.context <- data$connection.context
        input.df <- data$Select(c(key, features, label, purpose))
        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#UNIFIED_REGRESSION_PARAM_%s_%s",
                             self$id, unique.id)
        model.tbl <- sprintf("#UNIFIED_REGRESSION_MODEL_%s_%s",
                             self$id, unique.id)
        stats.tbl <- sprintf("#UNIFIED_REGRESSION_STATS_%s_%s",
                           self$id, unique.id)
        optimal.param.tbl <- sprintf("#UNIFIED_REGRESSION_OPT_PARAM_%s_%s",
                                     self$id, unique.id)
        partition.tbl <- sprintf("#UNIFIED_REGRESSION_PARTITION_%s_%s",
                                 self$id, unique.id)
        ph1.tbl <- sprintf("#UNIFIED_REGRESSION_PH1_%s_%s",
                           self$id, unique.id)
        ph2.tbl <- sprintf("#UNIFIED_REGRESSION_PH2_%s_%s",
                           self$id, unique.id)
        out.tables <- list(model.tbl, stats.tbl,
                           optimal.param.tbl,
                           partition.tbl,
                           ph1.tbl, ph2.tbl)
        in.tables <- list(input.df, param.tbl)
        tables <- c(param.tbl, out.tables)
        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
                                            (ParameterTable$new(param.tbl))$WithData(param.rows)))
          errorhelper(CallPalAutoWithConnection(conn.context,
                                                "PAL_UNIFIED_REGRESSION",
                                                in.tables, out.tables))
        },
        error = function(err) {
          msg <- paste("Error:", err$message)
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        self$model <- conn.context$table(model.tbl)
        self$statistics <- conn.context$table(stats.tbl)
        self$optimal.param <- conn.context$table(optimal.param.tbl)
        self$partition <- conn.context$table(partition.tbl)
      }
    },
    predict = function(data, key,
                       features = NULL,
                       thread.ratio = NULL,
                       func = NULL,
                       prediction.type = NULL,
                       significance.level = NULL,
                       handle.missing = NULL,
                       block.size = NULL) {
      if (is.null(self$model)) {
        msg <- "Model for prediction is NULL!"
        flog.error(msg)
        stop(msg)
      }
      if (is.null(self$func)) {
        func <- validateInput("func", func, private$func.list,
                              required = TRUE)
        real.func <- func
      } else {
        real.func <- self$func
      }
      prediction.type <- validateInput("prediction.type", prediction.type,
                                       list(response = "response",
                                            link = "link"))
      significance.level <- validateInput("significance.level",
                                          significance.level,
                                          "numeric")
      handle.missing <- validateInput("handle.missing", handle.missing,
                                      list(skip = 1, remove = 1,
                                           fill_zero = 2))
      block.size <- validateInput("block.size", block.size, "integer")
      conn.context <- data$connection.context
      if (!inherits(data, "DataFrame")) {
        msg <- "Data for prediction must be a DataFrame."
        flog.error(msg)
        stop(msg)
      }
      CheckConnection(data)
      thread.ratio <- validateInput("thread.ratio", thread.ratio,
                                    "numeric")
      cols <- data$columns
      key <- validateInput("key", key, cols, required = TRUE,
                           case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      features <- validateInput("features", features, cols,
                                case.sensitive = TRUE)
      if (is.null(features)) {
        features <- cols
      }
      data <- data$Select(c(key, features))
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      param.tbl <- sprintf("#UNIFIED_REGRESSION_PREDICT_PARAMS_%s_%s",
                           self$id, unique.id)
      result.tbl <- sprintf(paste0("#UNIFIED_REGRESSION_PREDICT",
                                   "_RESULT_TBL_%s_%s"),
                            self$id, unique.id)
      ph.tbl <- sprintf(paste0("#UNIFIED_REGRESSION_PREDICT",
                                 "_PH_TBL_%s_%s"),
                          self$id, unique.id)
      tables <- list(param.tbl, result.tbl, ph.tbl)
      in.tables <- list(data, self$model$name, param.tbl)
      out.tables <- list(result.tbl, ph.tbl)
      param.data <- list(
        tuple("FUNCTION", NULL, NULL,
              private$func.list[[real.func]]),
        tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
        tuple("TYPE", map.null(prediction.type,
                               list(response = "response",
                                    link = "link")),
              NULL, NULL),
        tuple("SIGNIFICANCE_LEVEL", NULL, significance.level, NULL),
        tuple("HANDLE_MISSING", map.null(handle.missing,
                                         list(remove = 1, skip = 1,
                                              fill_zero = 2)),
              NULL, NULL),
        tuple("BLOCK_SIZE", block.size, NULL, NULL)
      )
      tryCatch({
        errorhelper(CreateTWithConnection(conn.context,
                                          (ParameterTable$new(param.tbl))$WithData(param.data))) #nolint
        errorhelper(CallPalAutoWithConnection(conn.context,
                                              "PAL_UNIFIED_REGRESSION_PREDICT",#nolint
                                              in.tables, out.tables))
      },
      error = function(err) {
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn.context, tables)
        stop(msg)
      })
      result <- conn.context$table(result.tbl)
      return(result)
    },
    score = function(data, key,
                     features = NULL,
                     label = NULL,
                     thread.ratio = NULL,
                     func = NULL,
                     prediction.type = NULL,
                     significance.level = NULL,
                     handle.missing = NULL,
                     block.size = NULL) {
      if (is.null(self$model)) {
        msg <- "Model for scoring is NULL!"
        flog.error(msg)
        stop(msg)
      }
      conn.context <- data$connection.context
      if (!inherits(data, "DataFrame")) {
        msg <- "Data for scoring must be a DataFrame."
        flog.error(msg)
        stop(msg)
      }
      if (is.null(self$func)) {
        func <- validateInput("func", func, private$func.list,
                              required = TRUE)
        real.func <- func
      } else {
        real.func <- self$func
      }
      prediction.type <- validateInput("prediction.type", prediction.type,
                                       list(response = "response",
                                            link = "link"))
      significance.level <- validateInput("significance.level",
                                          significance.level,
                                          "numeric")
      handle.missing <- validateInput("handle.missing", handle.missing,
                                      list(remove = 1, skip = 1,
                                           fill_zero = 2))
      thread.ratio <- validateInput("thread.ratio", thread.ratio,
                                    "numeric")
      block.size <- validateInput("block.size", block.size, "integer")
      cols <- data$columns
      key <- validateInput("key", key, cols, required = TRUE,
                           case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      label <- validateInput("label", label, cols, case.sensitive = TRUE)
      if (is.null(label)) {
        label <- cols[[length(cols)]]
      }
      cols <- cols[! cols %in% label]
      features <- validateInput("features", features, cols,
                                case.sensitive = TRUE)
      if (is.null(features)) {
        features <- cols
      }
      CheckConnection(data)
      data <- data$Select(c(key, features, label))
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      param.tbl <- sprintf("#UNIFIED_REGRESSION_SCORE_PARAMS_%s_%s",
                           self$id, unique.id)
      result.tbl <-
        sprintf(paste0("#UNIFIED_REGRESSION_SCORE",
                       "_RESULT_TBL_%s_%s"),
                self$id, unique.id)
      stats.tbl <-
        sprintf(paste0("#UNIFIED_REGRESSION_SCORE",
                       "_STAT_TBL_%s_%s"),
                self$id, unique.id)
      tables <- list(param.tbl, result.tbl)
      in.tables <- list(data, self$model$name, param.tbl)
      out.tables <- list(result.tbl, stats.tbl)
      param.data <- list(
        tuple("FUNCTION", NULL, NULL,
              private$func.list[[real.func]]),
        tuple("TYPE",
              map.null(prediction.type,
                       list(response = "response",
                            link = "link")),
              NULL, NULL),
        tuple("SIGNIFICANCE_LEVEL", NULL, significance.level, NULL),
        tuple("HANDLE_MISSING", map.null(handle.missing,
                                         list(remove = 1, skip = 1,
                                              fill_zero = 2)),
              NULL, NULL),
        tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
        tuple("BLOCK_SIZE", block.size, NULL, NULL))
      tryCatch({
        errorhelper(CreateTWithConnection(conn.context,
                                          (ParameterTable$new(param.tbl))$WithData(param.data))) #nolint
        errorhelper(CallPalAutoWithConnection(conn.context,
                                              "PAL_UNIFIED_REGRESSION_SCORE",
                                              in.tables, out.tables))
      },
      error = function(err) {
        msg <- paste("Error:", err$message)
        flog.error(msg)
        TryDropWithConnection(conn.context, tables)
        stop(msg)
      })
      result <- conn.context$table(result.tbl)
      statistics <- conn.context$table(stats.tbl)
      return(list(result, statistics))
    }
  ),
  private = list(
    real.func = NULL,
    pal.params = list(),
    func.list = list(decisiontree = "DT",
                     hgbt = "HGBT",
                     svm = "SVM",
                     logarithmicregression = "LOG",
                     linearregression = "MLR",
                     randomforest = "RDT",
                     randomdecisiontrees = "RDT",
                     mlp = "MLP",
                     exponentialregression = "EXP",
                     polynomialregression = "POL",
                     geometricregression = "GEO",
                     glm = "GLM"),
    family.link.values = list(gaussian = list("identity", "log",
                                              "reciprocal",
                                              "inverse"),
                              poisson = list("identity", "log"),
                              binomial = list("logit", "probit",
                                              "comploglog", "log"),
                              gamma = list("identity", "reciprocal",
                                           "inverse", "log"),
                              inversegaussian = list("inversesquare",
                                                     "identity",
                                                     "reciprocal",
                                                     "inverse", "log"),
                              negativebinomial = list("identity",
                                                      "log",
                                                      "sqrt"),
                              ordinal = list("logit", "probit",
                                             "comploglog")),
    partition.map = list(no = 0, predefined = 1, random = 2),
    param.dict = list(
      "adjusted.r2" = list("ADJUSTED_R2", "logical"),
      "decomposition" = list("DECOMPOSITION", "integer", list("lu" = 0,
                                                              "qr" = 1,
                                                              "svd" = 2,
                                                              "cholesky" = 5)),
      "pmml.export" = list("PMML_EXPORT", "integer",
                           list("no" = 0, "single-row" = 1,
                                "multi-row" = 2))),
    cv.map = list(resampling.method = list("RESAMPLING_METHOD",
                                           "character",
                                           list(cv = "cv",
                                                bootstrap = "bootstrap")),#nolint
                  param.search.strategy = list("PARAM_SEARCH_STRATEGY",
                                               "character",
                                               list(grid = "grid",
                                                    random = "random")),
                  random.state = list("SEED", "integer"),
                  fold.num = list("FOLD_NUM", "integer"),
                  repeat.times = list("REPEAT_TIMES", "integer"),
                  random.search.times = list("RANDOM_SEARCH_TIMES",
                                             "integer"),
                  timeout = list("TIMEOUT", "integer"),
                  progress.indicator.id = list("PROGRESS_INDICATOR_ID",
                                               "character"),
                  parameter.values = list("_VALUES", "list"),
                  parameter.range = list("_RANGE", "list")),
    map.list = list(
      "DT" = list(
        "algorithm" = list("ALGORITHM", "integer",
                           list(c45 = 1, chaid = 2, cart = 3)),
        "allow.missing.dependent" = list("ALLOW_MISSING_LABEL", "logical"),
        "percentage" = list("PERCENTAGE", "numeric"),
        "min.records.of.parent" = list("MIN_RECORDS_PARENT", "integer"),
        "min.records.of.leaf" = list("MIN_RECORDS_LEAF", "integer"),
        "max.depth" = list("MAX_DEPTH", "integer"),
        "split.threshold" = list("SPLIT_THRESHOLD", "numeric"),
        "discretization.type" = list("DISCRETIZATION_TYPE", "integer",
                                     list("mdlpc" = 0, "equal.freq" = 1)),
        "max.branch" = list("MAX_BRANCH", "integer"),
        "merge.threshold" = list("MERGE_THRESHOLD", "numeric"),
        "use.surrogate" = list("USE_SURROGATE", "logical"),
        "model.format" = list("MODEL_FORMAT", "integer",
                              list("json" = 1, "pmml" = 2)),
        "thread.ratio" = list("THREAD_RATIO", "numeric"),
        "categorical.variable" = list("CATEGORICAL_VARIABLE", "list"),
        "evaluation.metric" = list("EVALUATION_METRIC", "character",
                                   list(rmse = "RMSE"))),
      "RDT" = list(
        "n.estimators" = list("N_ESTIMATORS", "integer"),
        "max.features" = list("MAX_FEATURES", "integer"),
        "min.samples.leaf" = list("MIN_SAMPLES_LEAF", "integer"),
        "max.depth" = list("MAX_DEPTH", "integer"),
        "split.threshold" = list("SPLIT_THRESHOLD", "numeric"),
        "random.state" = list("SEED", "integer"),
        "thread.ratio" = list("THREAD_RATIO", "numeric"),
        "allow.missing.dependent" = list("ALLOW_MISSING_LABEL", "logical"),
        "sample.fraction" = list("SAMPLE_FRACTION", "numeric"),
        "categorical.variable" = list("CATEGORICAL_VARIABLE", "list"),
        "compression" = list("COMPRESSION", "logical"),
        "max.bits" = list("MAX_BITS", "integer"),
        "quantize.rate" = list("QUANTIZE_RATE", "numeric"),
        "fittings.quantization" = list("FITTINGS_QUANTIZATION", "logical"),
        "evaluation.metric" = list("EVALUATION_METRIC", "character",
                                   list(rmse = "RMSE"))),
      "HGBT" = list(
        "n.estimators" = list("N_ESTIMATORS", "integer"),
        "random.state" = list("SEED", "integer"),
        "subsample" = list("SUBSAMPLE", "numeric"),
        "max.depth" = list("MAX_DEPTH", "integer"),
        "split.threshold" = list("SPLIT_THRESHOLD", "numeric"),
        "learning.rate" = list("LEARNING_RATE", "numeric"),
        "split.method" = list("SPLIT_METHOD", "character",
                              list(exact = "exact",
                                   sketch = "sketch",
                                   sampling = "sampling")),
        "sketch.eps" = list("SKETCH_ESP", "numeric"),
        "min.sample.weight.leaf" = list("MIN_SAMPLES_WEIGHT_LEAF",
                                        "numeric"),
        "reference.metric" = list("REF_METRIC", "list"),
        "min.samples.leaf" = list("MIN_SAMPLES_LEAF", "integer"),
        "max.w.in.split" = list("MAX_W_IN_SPLIT", "numeric"),
        "col.subsample.split" = list("COL_SUBSAMPLE_SPLIT", "numeric"),
        "col.subsample.tree" = list("COL_SUBSAMPLE_TREE", "numeric"),
        "lambda" = list("LAMBDA", "numeric"),
        "alpha" = list("ALPHA", "numeric"),
        "base.score" = list("BASE_SCORE", "numeric"),
        "categorical.variable" = list("CATEGORICAL_VARIABLE", "list"),
        "adopt.prior" = list("START_FROM_AVERAGE", "logical"),
        "thread.ratio" = list("THREAD_RATIO", "list"),
        "evaluation.metric" = list("EVALUATION_METRIC", "character",
                                   list(rmse = "RMSE"))),
      "MLP" = list(
        "activation" = list("ACTIVATION",
                            "integer",
                            list("tanh" = 1,
                                 "linear" = 2,
                                 "sigmoid-asymmetric" = 3,
                                 "sigmoid-symmetric" = 4,
                                 "gaussian-asymmetric" = 5,
                                 "gaussian-symmetric" = 6,
                                 "elliot-asymmetric" = 7,
                                 "elliot-symmetric" = 8,
                                 "sin-asymmetric" = 9,
                                 "sin-symmetric" = 10,
                                 "cos-asymmetric" = 11,
                                 "cos-symmetric" = 12,
                                 "relu" = 13)),
        "output.activation" = list("OUTPUT_ACTIVATION",
                                   "integer",
                                   list("tanh" = 1,
                                        "linear" = 2,
                                        "sigmoid-asymmetric" = 3,
                                        "sigmoid-symmetric" = 4,
                                        "gaussian-asymmetric" = 5,
                                        "gaussian-symmetric" = 6,
                                        "elliot-asymmetric" = 7,
                                        "elliot-symmetric" = 8,
                                        "sin-asymmetric" = 9,
                                        "sin-symmetric" = 10,
                                        "cos-asymmetric" = 11,
                                        "cos-symmetric" = 12,
                                        "relu" = 13)),
        "hidden.layer.size" = list("HIDDEN_LAYER_SIZE", "list"),
        "max.iter" = list("MAX_ITER", "integer"),
        "training.style" = list("TRAINING_STYLE", "integer",
                                list("batch" = 0,
                                     "stochastic" = 1)),
        "learning.rate" = list("LEARNING_RATE", "numeric"),
        "momentum" = list("MOMENTUM", "numeric"),
        "batch.size" = list("BATCH_SIZE", "integer"),
        "normalization" = list("NORMALIZATION", "integer",
                               list("no" = 0,
                                    "z-transform" = 1,
                                    "scalar" = 2)),
        "weight.init" = list("WEIGHT_INIT",
                             "integer",
                             list("all-zeros" = 0,
                                  "normal" = 1,
                                  "uniform" = 2,
                                  "variance-scale-normal" = 3,
                                  "variance-scale-uniform" = 4)),
        "thread.ratio" = list("THREAD_RATIO", "numeric"),
        "categorical.variable" = list("CATEGORICAL_VARIABLE", "list"),
        "evaluation.metric" = list("EVALUATION_METRIC", "character",
                                   list(rmse = "RMSE"))),
      "SVM" = list(
        "c" = list("SVM_C", "numeric"),
        "kernel" = list("KERNEL_TYPE", "integer",
                        list("linear" = 0,
                             "poly" = 1,
                             "rbf" = 2,
                             "sigmoid" = 3)),
        "degree" = list("POLY_DEGREE", "integer"),
        "gamma" = list("RBF_GAMMA", "numeric"),
        "coef.lin" = list("COEF_LIN", "numeric"),
        "coef.const" = list("COEF_CONST", "numeric"),
        "shrink" = list("SHRINK", "logical"),
        "tol" = list("TOL", "numeric"),
        "evaluation.seed" = list("EVALUATION_SEED", "integer"),
        "scale.info" = list("SCALE_INFO", "integer",
                            list("no" = 0,
                                 "standardization" = 1,
                                 "rescale" = 2)),
        "scale.label" = list("SCALE_LABEL", "logical"),
        "regression.eps" = list("REGRESSION_EPS", "numeric"),
        "handle.missing" = list("HANDLE_MISSING", "logical"),
        "category.weight" = list("CATEGORY_WEIGHT", "numeric"),
        "categorical.variable" = list("CATEGORICAL_VARIABLE", "list"),
        "compression" = list("COMPRESSION", "logical"),
        "max.bits" = list("MAX_BITS", "integer"),
        "max.quantization.iter" = list("MAX_QUANTIZATION_ITER", "integer"),
        "evaluation.metric" = list("EVALUATION_METRIC", "character",
                                   list(rmse = "RMSE"))),
      "GEO" = list(),
      "LOG" = list(),
      "EXP" = list(),
      "POL" = list("degree" = list("DEGREE", "integer")),
      "GLM" = list(
        "family" = list("FAMILY",
                        "character",
                        list(gaussian = "gaussian",
                             normal = "gaussian",
                             poisson = "poisson",
                             binomial = "binomial",
                             gamma = "gamma",
                             inversegaussin = "inversegaussian",
                             negativebinomial = "negativebinomial",
                             ordinal = "ordinal")),
        "link" = list("LINK",
                      "character",
                      list(identity = "identity",
                           log = "log",
                           logit = "logit",
                           probit = "probit",
                           comploglog = "comploglog",
                           reciprocal = "inverse",
                           inverse = "inverse",
                           inversesquare = "inversesquare",
                           sqrt = "sqrt")),
        "solver" = list("SOLVER", "character",
                        list(irls = "irls",
                             nr = "nr",
                             cd = "cd")),
        "quasilikelihood" = list("QUASILIKELIHOOD", "logical"),
        "group.response" = list("GROUP_RESPONSE", "logical"),
        "handle.missing.fit" = list("HANDLE_MISSING_FIT",
                                      "integer",
                                      list(abort = 0,
                                           skip = 1,
                                           fill_zero = 2)),
        "max.iter" =  list("MAX_ITER", "integer"),
        "tol" = list("TOL", "numeric"),
        "enet.alpha" = list("ALPHA", "numeric"),
        "enet.lambda" = list("LAMBDA", "numeric"),
        "num.lambda" = list("NUM_LAMBDA", "numeric"),
        "ordering" = list("ORDERING", "list"),
        "evaluation.metric" = list("EVALUATION_METRIC",
                                   "character",
                                   list(rmse = "RMSE",
                                        mae = "MAE",
                                        error_rate = "ERROR_RATE"))),
      "MLR" = list(
        "adjusted.r2" = list("ADJUSTED_R2", "logical"),
        "solver" = list("SOLVER", "integer",
                        list("qr" = 1, "svd" = 2,
                             "cyclical" = 4, "cholesky" = 5,
                             "admm" = 6)),
        "alpha.to.enter" = list("ALPHA_TO_ENTER", "numeric"),
        "alpha.to.remove" = list("ALPHA_TO_REMOVE", "numeric"),
        "bp.test" = list("BP_TEST", "logical"),
        "dw.test" = list("DW_TEST", "logical"),
        "enet.alpha" = list("ALPHA", "numeric"),
        "enet.lambda" = list("LAMBDA", "numeric"),
        "handle.missing" = list("HANDLE_MISSING", "logical"),
        "mandatory.feature" = list("MANDATORY_FEATURE", "list"),
        "ks.test" = list("KS_TEST", "logical"),
        "max.iter" = list("MAX_ITER", "integer"),
        "intercept" = list("INTERCEPT", "logical"),
        "pho" = list("PHO", "numeric"),
        "reset.test" = list("RESET_TEST", "integer"),
        "stat.inf" = list("STAT_INF", "logical"),
        "tol" = list("TOL", "numeric"),
        "thread.ratio" = list("THREAD_RATIO", "numeric"),
        "var.select" = list("VAR_SELECT",
                            list("no" = 0, "forward" = 1,
                                 "backward" = 2,
                                 "stepwise" = 3)),
        "evaluation.metric" = list("EVALUATION_METRIC", "character",
                                   list(rmse = "RMSE")))
    )
  )
)

#' @title Unified Regression
#' @name hanaml.UnifiedRegression
#' @description hanaml.UnifiedRegression is an R wrapper for SAP HANA PAL Unified Regression.
#' Note that this is a new function in SAP HANA SPS05 and Cloud.
#' @seealso \code{\link{predict.UnifiedRegression}}
#' @param func \code{character}\cr
#'   The functionality for unified regression.\cr
#'   Valid values are as follows:\cr
#'   "DecisionTree", "RandomDecisionTrees", "HGBT", "LinearRegression",
#'   "SVM", "MLP", "PolynomialRegression", "LogarithmicRegression",
#'   "ExponentialRegression", "GeometricRegression",
#'   "GLM".
#' @template args-data
#' @template args-key-optional
#' @template args-feature-multiple
#' @param label \code{character, optional}\cr
#'   Name of the column which specifies the dependent variable.\cr
#'   If not specified, defaults to the last non-purpose column.
#' @param purpose \code{character, optional}\cr
#'   Name of the column which specified user-defined data partition.\cr
#'   Mandatory if \emph{partition.method} is "predefined".
#' @template args-formula
#' @param partition.method \code{character, optional}\cr
#'   Specified the method for partitioning the training data.\cr
#'   Valid options include: "no", "predefined", "random".\cr
#'   Defaults to "no" if not specified (i.e. no data partition).
#' @param partition.random.state \code{character, optional}\cr
#'   Specifies the random seed for stratified partition.\cr
#'   Valid only when \code{partition.method} is set to "random".\cr
#'   Defaults to 0(system time).
#' @param training.percent \code{numeric, optional}\cr
#'   Specifies the percentage of data used for training.\cr
#'   Valid only when \code{partition.method} is set to "random".\cr
#'   Defaults to 0.8.
#' @param output.partition.result \code{logical, optional}\cr
#'   Specifies whether or not to output the partition result of the training data.\cr
#'   Defaults to FALSE.
#' @param ... \cr
#'   Specifies other parameters for training a regression model with the functionality
#'   specified in \emph{func}.\cr
#'   Please see the documentation of corresponding functionalities for more detail.\cr
#'   \code{\link{hanaml.DecisionTreeRegressor},
#'         \link{hanaml.RDTRegressor},
#'         \link{hanaml.MLPRegressor},
#'         \link{hanaml.HGBTRegressor},
#'         \link{hanaml.SVR},
#'         \link{hanaml.ExponentialRegression},
#'         \link{hanaml.LogarithmicRegression},
#'         \link{hanaml.PolynomialRegression},
#'         \link{hanaml.GeometricRegression},
#'         \link{hanaml.LinearRegression},
#'         \link{hanaml.GLM}}\cr
#'   However, some parameters will be disabled. The disable parameters are listed as follows:\cr
#'   \itemize{
#'   \item{\bold{DecisionTreeRegressor:}  \code{output.rules}}
#'   \item{\bold{RDTRegressor:}  \code{calculate.oob}}
#'   \item{\bold{HGBTRegressor:}  \code{calculate.importance}}
#'   }
#' @return
#' Returns a "UnifiedRegression" object with the following attributes and methods:\cr
#' \cr
#'      \bold{model}  \code{DataFrame}\cr
#'          \itemize{
#'             \item{\code{ROW_INDEX} - model row index}
#'             \item{\code{PART_INDEX} -  data partition index}
#'             \item{\code{MODEL_CONTENT} - model content}}
#'
#'      \bold{importance}  \code{DataFrame}\cr
#'          \itemize{
#'             \item{\code{VARIABLE_NAME} - Independent variable name}
#'             \item{\code{IMPORTANCE} - Variable importance}}
#'      \bold{optimal.param}  \code{DataFrame}\cr
#'          \itemize{
#'             \item{\code{PARM_NAME} - parameter name}
#'             \item{\code{INT_VALUE} -  integer value}
#'             \item{\code{DOUBLE_VALUE} - double value}
#'             \item{\code{STRING_VALUE} - character value}
#'         }
#'      \bold{statistics}   \code{DataFrame}\cr
#'          \itemize{
#'             \item{\code{STAT_NAME} - Statistics name}
#'             \item{\code{STAT_VALUE} -  Statistics value}
#'         }
#'      \bold{confusion.matrix}  \code{DataFrame}\cr
#'          \itemize{
#'             \item{\code{ACTUAL_CLASS} - The actual class name}
#'             \item{\code{PREDICTED_CLASS} -  The predicted class name}
#'             \item{\code{COUNT} - Number of records}}
#'      \bold{metrics}  \code{DataFrame}\cr
#'          \itemize{
#'            \item{\code{NAME} - Metric name}
#'            \item{\code{X} - X value}
#'            \item{\code{Y} - Y value}}
#'      \bold{score()}  \code{Function}\cr
#'      Parameters:
#'      \itemize{
#'      \item{data \code{DataFrame}\cr Input data for calculating score metrics.}
#'      \item{key \code{character}\cr Specifies name of the ID column for input data.}
#'      \item{features \code{list/vector of characters, optional}\cr Specifies names of the feature columns, i.e.
#'            independent columns.\cr Defaults to all non-key, non-label columns if not provided.}
#'      \item{label \code{character, optional}\cr Specifies name of dependent column in the input data.\cr
#'            Defaults to the last non-key column if not provided.}
#'      \item{thread.ratio \code{numeric, optional}\cr Specifies the ratio of total number of threads that
#'            can be used by the score function.\cr
#'            Defaults to 1.0.}
#'      \item{func \code{character, optional}\cr The functionality for unified regression model.\cr
#'            Mandatory only when the \emph{func} attribute of \emph{model} is NULL.\cr
#'            Valid values are as follows:\cr
#'            "DecisionTree", "RandomDecisionTrees", "HGBT", "LinearRegression",
#'            "SVM", "MLP", "PolynomialRegression", "LogarithmicRegression",
#'            "ExponentialRegression", "GeometricRegression", "GLM".}
#'      \item{prediction.type \code{character, optional}\cr Specifies the type of prediction in the result table.\cr
#'            Available options include:
#'            \itemize{
#'              \item{response} : direct response (with link function applied)
#'              \item{link} : linear response (w.o. link function applied)
#'            }
#'            Valid only for GLM models.}
#'      \item{significance.level \code{numeric, optional}\cr
#'           Specifies significance level for the confidence interval and prediction interval.\cr
#'           Valid only for GLM models where IRLS method is applied.
#'           Defaults to 0.05.}
#'      \item{handle.missing \code{character, optional}\cr
#'            Specifies the way to handling missing values in \code{data}.
#'            \itemize{
#'              \item{"skip"}: Skip rows with missing values
#'              \item{"fill_zero"}: Replace missing values with 0 before prediction
#'            }
#'            Valid only for GLM models.\cr
#'            Defaults to "fill_zero".}
#'      \item{block.size \code{integer, optional}\cr
#'            Specifies the number of data loaded per time during scoring.
#'            \itemize{
#'              \item{0}: load all data once
#'              \item{Others}: the specified number
#'            }
#'            This parameter is for reducing memory consumption, especially as the predict data is huge, \cr
#'            or it consists of a large number of missing independent variables.\cr
#'            However, you might lose some efficiency.
#'            Valid only for Random Decision Trees models.\cr
#'            Defaults to 0.}
#'      }
#' @section Examples:\cr
#' The training data:
#' \preformatted{
#' > data.fit
#'    ID   X1 X2 X3      Y
#' 1   0 0.00  A  1 -6.879
#' 2   1 0.50  A  1 -3.449
#' 3   2 0.54  B  1  6.635
#' 4   3 1.04  B  1 11.844
#' 5   4 1.50  A  1  2.786
#' 6   5 0.04  B  2  2.389
#' 7   6 2.00  A  2 -0.011
#' 8   7 2.04  B  2  8.839
#' 9   8 1.54  B  1  4.689
#' 10  9 1.00  A  2 -5.507
#' }
#'
#' Create a UnifiedRegression model for linear regression:
#' \preformatted{
#' umlr <- hanaml.UnifiedRegression(data = data.fit,
#'                                  key = 'ID',
#'                                  label = 'Y',
#'                                  solver = 'qr',
#'                                  adjusted.r2 = FALSE,
#'                                  func='LinearRegression',
#'                                  thread.ratio=0.5,
#'                                  partition.method='random',
#'                                  training.percent=0.7,
#'                                  partition.random.state=2,
#'                                  output.partition.result=TRUE)
#' }
#' Check the resulting statistics:
#' \preformatted{
#' > umlr$statistics
#'        STAT_NAME         STAT_VALUE
#' 1      TEST_EVAR  0.871459247598903
#' 2       TEST_MAE 2.0088082000000003
#' 3      TEST_MAPE 12.260003987804756
#' 4 TEST_MAX_ERROR  5.329849599999999
#' 5       TEST_MSE  9.551661310681718
#' 6        TEST_R2 0.7774293644548433
#' 7      TEST_RMSE   3.09057621013974
#' 8     TEST_WMAPE 0.7188006440839695
#' }
#'
#' Data for model scoring:
#' \preformatted{
#' > df.score
#'   ID      X1 X2 X3   Y
#' 1  0   1.690  B  1 1.2
#' 2  1   0.054  B  2 2.1
#' 3  2 980.123  A  2 2.4
#' 4  3   1.000  A  1 1.8
#' 5  4   0.563  A  1 1.0
#' }
#'
#' Apply the obtained linear regression model to the scoring data:
#' \preformatted{
#' score.res <- umlr$score(data = df.score, key = "ID", label = "Y")
#' }
#' Check the statistics on scoring data:
#' \preformatted{
#' > score.res[[2]]$Collect()
#'   STAT_NAME         STAT_VALUE
#' 1      EVAR -6284768.906191169
#' 2       MAE  666.5116459919999
#' 3      MAPE  278.9837795885635
#' 4 MAX_ERROR 3315.9714402299996
#' 5       MSE  2199151.795823181
#' 6        R2  -7854112.55651136
#' 7      RMSE 1482.9537402842952
#' 8     WMAPE  392.0656741129411
#' }
#' @keywords Unified Interface
#' @export
hanaml.UnifiedRegression <- function(data = NULL,
                                     func = NULL,
                                     key = NULL,
                                     features = NULL,
                                     label = NULL,
                                     purpose = NULL,
                                     formula = NULL,
                                     partition.method = NULL,
                                     partition.random.state = NULL,
                                     training.percent = NULL,
                                     output.partition.result = NULL,
                                     ...) {
  UnifiedRegression$new(data = data, func = func, key = key,
                        features = features, label = label,
                        purpose = purpose, formula = formula,
                        partition.method = partition.method,
                        partition.random.state = partition.random.state,
                        training.percent = training.percent,
                        output.partition.result = output.partition.result,
                        ...)
}

#' @title Make Predictions from a "UnifiedRegression" Object
#' @name predict.UnifiedRegression
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "UnifiedRegression" object.
#' @seealso \code{\link{hanaml.UnifiedRegression}}
#' @format \code{\link{S3}} methods
#' @param  model \code{R6Class}\cr
#'  A "UnifiedRegression" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @template args-threadratio-1
#' @param func \code{character, optional}\cr
#'   The functionality for unified regression model.\cr
#'   Mandatory only when the \emph{func} attribute of \emph{model} is NULL.\cr
#'   Valid values are as follows:\cr
#'      "DecisionTree", "RandomDecisionTrees", "HGBT", "LinearRegression",
#'      "SVM", "MLP", "PolynomialRegression", "LogarithmicRegression",
#'      "ExponentialRegression", "GeometricRegression", "GLM".
#' @param prediction.type \code{character, optinoal}\cr
#'   Specifies the prediction type in the result table.
#'   \itemize{
#'     \item{"response"}: direct response (with link applied)
#'     \item{"link"}: linear response (without link)
#'   }
#'   Valid only for GLM models.\cr
#'   Defaults to "response".
#' @param handle.missing \code{character, optional}\cr
#'   Specifies the way to handling missing values in \code{data}.
#'   \itemize{
#'     \item{"skip"}: Skip rows with missing values
#'     \item{"fill_zero"}: Replace missing values with 0 before prediction
#'   }
#'   Valid only for GLM models.\cr
#'   Defaults to "fill_zero".
#' @param significance.level \code{numeric, optional}\cr
#'   Specifies the significance level for the confidence interval and prediction interval.\cr
#'   Valid only for GLM models when \code{irls} solver is applied.\cr
#'   Defaults to 0.05.
#' @param block.size \code{integer, optional}\cr
#'   Specifies the number of data loaded per time during scoring.
#'   \itemize{
#'     \item{0}: load all data once
#'     \item{Others}: the specified number
#'    }
#'   This parameter is for reducing memory consumption, especially as the predict data is huge, \cr
#'   or it consists of a large number of missing independent variables.\cr
#'   However, you might lose some efficiency.
#'   Valid only for Random Decision Trees models.\cr
#'   Defaults to 0.
#'
#' @return
#' Predicted values are returned as a DataFrame, structured as follows.
#' \itemize{
#'   \item{ID column name}
#'   \item{SCORE}
#'   \item{UPPER_BOUND}
#'   \item{LOWER_BoUND}
#'   \item{REASON}
#' }
#' @section Examples:\cr
#' Input data for prediction:
#' \preformatted{
#' > df.predict
#'   ID      X1 X2 X3
#' 1  0   1.690  B  1
#' 2  1   0.054  B  2
#' 3  2 980.123  A  2
#' 4  3   1.000  A  1
#' 5  4   0.563  A  1
#' }
#' Call the predict() function:
#' \preformatted{
#' > res <- predict(model = umlr,
#'                  data = df.predict,
#'                  key = "ID")
#' }
#' Check the result:
#' \preformatted{
#' > res$Collect()
#'   ID       SCORE UPPER_BOUND LOWER_BOUND REASON
#' 1  0    8.719607          NA          NA   <NA>
#' 2  1    1.416343          NA          NA   <NA>
#' 3  2 3318.371440          NA          NA   <NA>
#' 4  3   -2.050390          NA          NA   <NA>
#' 5  4   -3.533135          NA          NA   <NA>
#' }
#' @keywords Unified Interface
#' @export
predict.UnifiedRegression <- function(model,
                                      data,
                                      key,
                                      features = NULL,
                                      thread.ratio = NULL,
                                      func = NULL,
                                      prediction.type = NULL,
                                      significance.level = NULL,
                                      handle.missing = NULL,
                                      block.size = NULL) {
  model$predict(data = data,
                key = key,
                features = features,
                thread.ratio = thread.ratio,
                func = func,
                prediction.type = prediction.type,
                significance.level = significance.level,
                handle.missing = handle.missing,
                block.size = block.size)
}
