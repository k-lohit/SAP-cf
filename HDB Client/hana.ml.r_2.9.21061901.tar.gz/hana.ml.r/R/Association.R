#Base class for association rule mining.
AssociationBase <- R6Class(
  "AssociationBase",
  inherit = MlBase,
  public = list(
    min.support = NULL,
    min.confidence = NULL,
    min.lift = NULL,
    max.item.length = NULL,
    max.consequent = NULL,
    ubiquitous = NULL,
    lhs.restrict = NULL,
    rhs.restrict = NULL,
    lhs.complement.rhs = NULL,
    rhs.complement.lhs = NULL,
    timeout = NULL,
    thread.ratio = NULL,
    relational = NULL,
    result = NULL,
    antecedent = NULL,
    consequent = NULL,
    statistics = NULL,
    initialize = function(data,
                          min.support = NULL,
                          min.confidence = NULL,
                          min.lift = NULL,
                          relational = NULL,
                          max.item.length = NULL,
                          max.consequent = NULL,
                          ubiquitous = NULL,
                          lhs.restrict = NULL,
                          rhs.complement.lhs = NULL,
                          rhs.restrict = NULL,
                          lhs.complement.rhs = NULL,
                          timeout = NULL,
                          thread.ratio = NULL){
      super$initialize()
      if (!is.null(data)){
        self$min.support <- validateInput("min.support", min.support, "numeric")
        self$min.confidence <- validateInput("min.confidence",
                                             min.confidence,
                                             "numeric")
        self$min.lift <- validateInput("min.lift", min.lift, "numeric")
        self$relational <- validateInput("relational", relational, "logical")
        self$max.item.length <- validateInput("max.item.length",
                                              max.item.length,
                                              "integer")
        self$max.consequent <- validateInput("max.consequent",
                                             max.consequent,
                                             "integer")
        self$ubiquitous <- validateInput("ubiquitous", ubiquitous, "numeric")
        if (!is.null(lhs.restrict)) {
          if (!(all(sapply(lhs.restrict,
                           inherits,
                           what = "character")) || all(sapply(lhs.restrict,
                                                              inherits,
                                                              what = c("numeric",
                                                                       "integer"))))){#nolint
            msg <- paste("Antecedent restricted items",
                         "must be list/vector of integers or",
                         "characters.")
            flog.error(msg)
            stop(msg)
          }
          self$lhs.restrict <- as.list(lhs.restrict)
        } else {
          self$lhs.restrict <- NULL
        }
        if (!is.null(rhs.restrict)) {
          if (!all(sapply(rhs.restrict,
                          inherits,
                          what = "character")) || !all(sapply(rhs.restrict,
                                                              inherits,
                                                              what = c("numeric",
                                                                       "integer")))){
            msg <- paste("Consequent restricted items",
                         "must be list/vector of integers or",
                         "characters.")
            flog.error(msg)
            stop(msg)
          }
          self$rhs.restrict <- as.list(rhs.restrict)
        } else {
          self$rhs.restrict <- NULL
        }
        self$lhs.complement.rhs <- validateInput("lhs.complement.rhs",
                                                 lhs.complement.rhs,
                                                 "logical")
        self$rhs.complement.lhs <- validateInput("rhs.complement.lhs",
                                                 rhs.complement.lhs,
                                                 "logical")
        self$timeout <- validateInput("timeout", timeout, "integer")
        self$thread.ratio <- validateInput("thread.ratio",
                                           thread.ratio,
                                           "numeric")
      }
    }
  )
)

Apriori <- R6Class(
  "Apriori",
  inherit = AssociationBase,
  public = list(
    model = NULL,
    use.prefix.tree = NULL,
    pmml.export = NULL,
    pmml.export.map = list("no" = 0, "single-row" = 1, "multi-row" = 2),
    initialize = function(data,
                          used.cols = NULL,
                          min.support,
                          min.confidence,
                          min.lift = NULL,
                          relational = NULL,
                          max.item.length = NULL,
                          max.consequent = NULL,
                          use.prefix.tree = NULL,
                          ubiquitous = NULL,
                          lhs.restrict = NULL,
                          rhs.complement.lhs = NULL,
                          rhs.restrict = NULL,
                          lhs.complement.rhs = NULL,
                          timeout = NULL,
                          thread.ratio = NULL,
                          pmml.export = NULL) {
      super$initialize(data, min.support, min.confidence,
                       min.lift, relational, max.item.length,
                       max.consequent, ubiquitous, lhs.restrict,
                       rhs.complement.lhs, rhs.restrict,
                       lhs.complement.rhs, timeout, thread.ratio)
      conn <- data$connection.context
      if (!is.null(data)) {
         self$use.prefix.tree <- validateInput("use.prefix.tree",
                                               use.prefix.tree,
                                               "logical")#nolint
        self$pmml.export <- validateInput("pmml.export",
                                          pmml.export,
                                          self$pmml.export.map)
      }
      cols <- data$columns
      if (length(cols) < 2) {
        msg <- paste("Input data should contain at least two columns:",
                     "one for transactions and another for items.")
        flog.error(msg)
        stop(msg)
      }
      used.cols <- validateInput("used.cols",
                                 used.cols,
                                 cols,
                                 case.sensitive = TRUE)
      if (!is.null(used.cols)) {
        if (length(used.cols) != 2 || !all(names(used.cols) %in% c("transaction",#nolint
                                                           "item"))) {
          msg <- paste("`used.cols` should be of length 2:",
                       "one for transactions, the other",
                       "for items.")
          flog.error(msg)
          stop(msg)
        }
      } else {
        used.cols <- list("transaction" = cols[[1]],
                          "item" = cols[[2]])
      }
      if (inherits(data, "DataFrame")){
        CheckConnection(data)
        mdata <- data$Select(list(used.cols[["transaction"]],
                                  used.cols[["item"]]))
        param.rows <- list(
          tuple("MIN_SUPPORT", NULL, self$min.support, NULL),
          tuple("MIN_CONFIDENCE", NULL, self$min.confidence, NULL),
          tuple("MIN_LIFT", NULL, self$min.lift, NULL),#nolint
          tuple("MAX_CONSEQUENT", self$max.consequent, NULL, NULL),
          tuple("MAXITEMLENGTH", self$max.item.length, NULL, NULL),
          tuple("UBIQUITOUS", NULL, self$ubiquitous, NULL),
          tuple("IS_USE_PREFIX_TREE",
                to.integer(isTRUE(self$use.prefix.tree)),
                NULL, NULL),#nolint
          tuple("LHS_IS_COMPLEMENTARY_RHS",
                to.integer(isTRUE(self$lhs.complement.rhs)),
                NULL, NULL),
          tuple("RHS_IS_COMPLEMENTARY_LHS",
                to.integer(isTRUE(self$rhs.complement.lhs)),
                NULL, NULL),
          tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
          tuple("TIMEOUT", self$timeout, NULL, NULL)#nolint
        )
        if (!is.null(self$pmml.export)) {
          val <- self$pmml.export.map[self$pmml.export][[1]]
          param.rows <- append(param.rows,
                               list(tuple("PMML_EXPORT", val,
                                          NULL, NULL)))
        }
        if (!is.null(self$lhs.restrict)){
          for (item in self$lhs.restrict){
            param.rows <- append(param.rows,
                                 list(tuple("LHS_RESTRICT", NULL, NULL,
                                            as.character(item))))#nolint
          }
        }
        if (!is.null(self$rhs.restrict)){
          for (item in self$rhs.restrict){
            param.rows <- append(param.rows,
                                 list(tuple("LHS_RESTRICT", NULL, NULL,
                                            as.character(item))))
          }
        }
        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_APRIORI_PARAM_TBL_%s_%s", self$id, unique.id)
        pmml.tbl <- sprintf("#PAL_APRIORI_PMML_TBL_%s_%s", self$id, unique.id)
        if (isFALSE(relational)) {
          result.tbl <- sprintf("#PAL_APIORI_RESULT_TBL_%s_%s", self$id, unique.id)
          tables <- list(param.tbl, result.tbl, pmml.tbl)
          in.tables <- list(mdata, param.tbl)
          out.tables <- list(result.tbl, pmml.tbl)
          proc.name <- "PAL_APRIORI"
        } else {
          unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
          antec.tbl <- sprintf("#PAL_APRIORI_ANTEC_TBL_%s_%s", self$id, unique.id)
          conseq.tbl <- sprintf("#PAL_APRIORI_CONSEQ_TBL_%s_%s", self$id, unique.id)
          stats.tbl <- sprintf("#PAL_APRIORI_STATS_TBL_%s_%s", self$id, unique.id)
          tables <- list(param.tbl, antec.tbl, conseq.tbl,
                         stats.tbl, pmml.tbl)
          in.tables <- list(mdata, param.tbl)
          out.tables <- list(antec.tbl, conseq.tbl, stats.tbl, pmml.tbl)
          proc.name <- "PAL_APRIORI_RELATIONAL"
        }
        tryCatch({
          errorhelper(CreateTWithConnection(conn,
            (ParameterTable$new(param.tbl))$WithData(param.rows)))#nolint
          errorhelper(CallPalAutoWithConnection(conn,
                                                proc.name,
                                                in.tables,
                                                out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })
        if (isFALSE(self$relational)) {
          self$result <- conn$table(result.tbl)
        } else {
          self$antecedent <- conn$table(antec.tbl)
          self$consequent <- conn$table(conseq.tbl)
          self$statistics <- conn$table(stats.tbl)
        }
        if (!(is.null(self$pmml.export) || self$pmml.export == "no")) {
          self$model <- conn$table(pmml.tbl)
        }
      }
    }
  )
)
#' @title Apriori
#' @name hanaml.Apriori
#' @description hanaml.Apriori is a R wrapper for SAP HANA PAL APRIORI and PAL APRIORI_RELATIONAL.
#' @template args-data
#' @param     min.support \code{numeric}\cr
#'            User-specified minimum support value for rule generation.\cr
#' @param     min.confidence \code{numeric}\cr
#'            User-specified minimum confidence value for rule generation.\cr
#' @param     used.cols \code{list of characters, optional}\cr
#'            Specified the columns in \emph{data} that specify transaction IDs and item IDs.
#'            For example, consider that the transaction ID column for \emph{data} is "CUSTOMER",
#'            while the item ID column for \emph{data} is "ITEM", then the correct way to set up
#'            this parameter is
#'            \itemize{\item{used.cols = list(transaction = "CUSTOMER", item = "ITEM")}.}
#'            Transaction ID column defaults to the 1st column of \emph{data} while item ID column
#'            defaults to the 2nd column of \emph{data}.
#' @param     relational \code{logical, optional}\cr
#'            Whether or not to apply relational logic for association rule mining.
#'            This will affect the format view of mined association rules.\cr
#'            Defaults to FALSE.
#' @param     min.lift \code{numeric, optional}\cr
#'            User-specified minimum lift value for rule generation.\cr
#'            Defaults to 0.
#' @param     max.item.length \code{integer, optional}\cr
#'            User-specified maximum length of items, inclusive of both antecedent and consequent items
#'            for association rule generation.\cr
#'            Defaults to 5.
#' @param     max.consequent \code{double, optional}\cr
#'            Maximum length of consequent items for association rule generation.\cr
#'            Defaults to 100.
#' @param     use.prefix.tree \code{logical, optional}\cr
#'            Indicates whether or not to use prefix tree data structure when generating association rules
#'            for the purpose of memory-saving.\cr
#'            Defaults to FALSe.
#' @param     ubiquitous \code{double, optional}\cr
#'            User-specified maximum support value during the frequent items mining phase, i.e.
#'            if an item has support value above \emph{ubiquitous}, it shall be ignored.\cr
#'            Defaults to 1.0.
#' @param     lhs.restrict \code{list of characters, optional}\cr
#'            Specifies the items are only allowed to be antecedent items, i.e. they can only
#'            appear on the left-hand side of association rules.\cr
#'            No default value.
#' @param     rhs.complement.lhs \code{logical, optional}\cr
#'            If \emph{lhs.restrict} is not NULL, you can set this parameter to TRUE to restrict rest
#'            of items so that they can only appear on the right-hand-side of association rules.\cr
#'            Defaults to 0.
#' @param     rhs.restrict \code{list of characters, optional}\cr
#'            Specifies the items are only allowed to be consequent items, i.e. they can only
#'            appear on the right-hand-side of association rules.
#'            No default value.
#' @param     lhs.complement.rhs \code{logical, optional}\cr
#'            If \emph{rhs.restrict} is not NULL, you can set this parameter to TRUE to restrict rest
#'            of items so that they can only appear on the left-hand-side of association rules.
#'            Defaults to 0.
#' @template args-threadratio
#' @param     timeout \code{integer, optional}\cr
#'            Specifies the maximum run time in seconds for association rule mining.
#'            The algorithm will stop running when the specified timeout is reached.\cr
#'            Defaults to 3600
#' @template args-pmmlexport
#' @return
#' An "Apriori" object with the following attributes:
#' \itemize{
#'  \item{\code{result:  DataFrame}}\cr
#'         Mined association rules as a whole.
#'         Each rule has its antecedent/consequent items and support/confidence/lift values.
#'         Available only when \code{relatiional} is FALSE.
#'  \item{\code{antecedent:  DataFrame}}\cr
#'         Antecedent item information of mined association rules.
#'         Available only when \emph{relational} is TRUE.
#'  \item{\code{consequent: DataFrame}}\cr
#'        Consequent item information of mined association rules.
#'        Available only when \emph{relational} is TRUE.
#'  \item{\code{statistics: DataFrame}}\cr
#'        Support/confidence/lift values of mined association rules.
#'        Available only when \emph{relational} is TRUE.
#'  \item{\code{model: DataFrame}}\cr
#'       Mined association rules in PMML format.
#'       Available only when \emph{pmml.export} is 'single-row' or 'multi-row'.
#'}
#'
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    CUSTOMER  ITEM
#' 1         2 item2
#' 2         2 item3
#' 3         3 item1
#' 4         3 item2
#' 5         3 item4
#' 6         4 item1
#' 7         4 item3
#' 8         5 item2
#' 9         5 item3
#' 10        6 item1
#' 11        6 item3
#' 12        0 item1
#' 13        0 item2
#' 14        0 item5
#' 15        1 item2
#' 16        1 item4
#' 17        7 item1
#' 18        7 item2
#' 19        7 item3
#' 20        7 item5
#' 21        8 item1
#' 22        8 item2
#' 23        8 item3
#' }
#' Call the function:
#' \preformatted{
#' > apr <- hanaml.Apriori(data = data, min.support = 0.1, min.confidence = 0.3,
#'                         min.lift = 1.10, max.consequent = 1, pmml.export = 'single-row')
#' }
#' Output:
#' \preformatted{
#' > apr$result
#'           ANTECEDENT CONSEQUENT   SUPPORT CONFIDENCE     LIFT
#' 1              item5      item2 0.2222222  1.0000000 1.285714
#' 2              item1      item5 0.2222222  0.3333333 1.500000
#' 3              item5      item1 0.2222222  1.0000000 1.500000
#' 4              item4      item2 0.2222222  1.0000000 1.285714
#' 5        item2&item1      item5 0.2222222  0.5000000 2.250000
#' 6        item5&item1      item2 0.2222222  1.0000000 1.285714
#' 7        item5&item2      item1 0.2222222  1.0000000 1.500000
#' 8        item5&item3      item2 0.1111111  1.0000000 1.285714
#' 9        item5&item3      item1 0.1111111  1.0000000 1.500000
#' 10       item1&item4      item2 0.1111111  1.0000000 1.285714
#' 11 item2&item1&item3      item5 0.1111111  0.5000000 2.250000
#' 12 item5&item1&item3      item2 0.1111111  1.0000000 1.285714
#' 13 item5&item2&item3      item1 0.1111111  1.0000000 1.500000
#' }
#' @keywords Association
#' @export
hanaml.Apriori <- function(data, used.cols = NULL,
                           min.support, min.confidence, min.lift = NULL,
                           relational = FALSE, max.item.length = NULL,
                           max.consequent = NULL, use.prefix.tree = NULL,
                           ubiquitous = NULL,
                           lhs.restrict = NULL, rhs.complement.lhs = NULL,
                           rhs.restrict = NULL, lhs.complement.rhs = NULL,
                           timeout = NULL, thread.ratio = NULL,
                           pmml.export = NULL) {
  Apriori$new(data, used.cols,
              min.support, min.confidence, min.lift,
              relational, max.item.length, max.consequent,
              use.prefix.tree, ubiquitous,
              lhs.restrict, rhs.complement.lhs,
              rhs.restrict, lhs.complement.rhs,
              timeout, thread.ratio, pmml.export)
}


AprioriLite <- R6Class(
  "AprioriLite",
  inherit = MlBase,
  public = list(
    min.support = NULL,
    min.confidence = NULL,
    thread.ratio = NULL,
    subsample = NULL,
    recalculate = NULL,
    timeout = NULL,
    pmml.export = NULL,
    model = NULL,
    result = NULL,
    pmml.export.map = list("no" = 0, "single-row" = 1, "multi-row" = 2),
    initialize = function(data,
                          used.cols = NULL,
                          min.support = NULL,
                          min.confidence = NULL,
                          thread.ratio = NULL,
                          subsample = NULL,
                          recalculate = NULL,
                          timeout = NULL,
                          pmml.export = NULL) {
      super$initialize()
      conn <- data$connection.context
      self$min.support <- validateInput("min.support", min.support, "numeric")
      self$min.confidence <- validateInput("min.confidence", min.confidence,
                                           "numeric")
      self$thread.ratio <- validateInput("thread.ratio", thread.ratio, "numeric")
      self$subsample <- validateInput("subsample", subsample, "numeric")
      self$recalculate <- validateInput("recalculate", recalculate, "logical")
      self$timeout <- validateInput("timeout", timeout, "integer")
      self$pmml.export <- validateInput("pmml.export", pmml.export,
                                        self$pmml.export.map)
      cols <- data$columns
      if (length(cols) < 2) {
        msg <- paste("Input data should contain at least two columns:",
                     "one for transactions and another for items.")
        flog.error(msg)
        stop(msg)
      }
      use.cols <- validateInput("used.cols",
                                used.cols,
                                cols,
                                case.sensitive = TRUE)
      if (!is.null(used.cols)) {
        if (length(used.cols) != 2 || !all(names(used.cols) %in% c("transaction",#nolint
                                                                   "item"))) {
          msg <- paste("`used.cols` should be of length 2:",
                       "one for transactions, the other",
                       "for items.")
          flog.error(msg)
          stop(msg)
        }
      } else {
        used.cols <- list("transaction" = cols[[1]],
                          "item" = cols[[2]])
      }
      if (inherits(data, "DataFrame")){
        CheckConnection(data)
        mdata <- data$Select(list(used.cols[["transaction"]],
                                  used.cols[["item"]]))
        param.rows <- list(
          tuple("MIN_SUPPORT", NULL, self$min.support, NULL),
          tuple("MIN_CONFIDENCE", NULL, self$min.confidence, NULL),
          tuple("SAMPLE_PROPORTION", NULL, self$subsample, NULL),
          tuple("IS_RECALCULATE",
                to.integer(isTRUE(self$recalculate) || is.null(self$recalculate)),#nolint
                NULL, NULL),
          tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),#nolint
          tuple("TIMEOUT", self$timeout, NULL, NULL)#nolint
        )
        if (!is.null(self$pmml.export)) {
          val <- self$pmml.export.map[self$pmml.export][[1]]
          param.rows <- append(param.rows, list(tuple("PMML_EXPORT",
                                                      val, NULL, NULL)))#nolint
        }
        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_APRIORI_LITE_PARAM_TBL_%s_%s", self$id, unique.id)
        pmml.tbl <- sprintf("#PAL_APRIORI_LITE_PMML_TBL_%s_%s", self$id, unique.id)
        result.tbl <- sprintf("#PAL_APIORI_LITE_RESULT_TBL_%s_%s", self$id, unique.id)
        tables <- list(param.tbl, result.tbl, pmml.tbl)
        in.tables <- list(mdata, param.tbl)
        out.tables <- list(result.tbl, pmml.tbl)
        proc.name <- "PAL_LITE_APRIORI"
        tryCatch({
          errorhelper(CreateTWithConnection(conn,
            (ParameterTable$new(param.tbl))$WithData(param.rows)))#nolint
          errorhelper(CallPalAutoWithConnection(conn,
            proc.name, in.tables, out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })
        self$result <- conn$table(result.tbl)
        if (!(is.null(self$pmml.export) || self$pmml.export == "no")) {
          self$model <- conn$table(pmml.tbl)
        }
      }
    }
  )
)
#' @title Lite Apriori
#' @name hanaml.AprioriLite
#' @description Lite Apriori is a R wrapper for SAP HANA PAL LITE_APRIORI.
#' @template args-data
#' @param    min.support \code{numeric}\cr
#'           User-specified minimum support value for rule generation.\cr
#' @param    min.confidence \code{numeric}\cr
#'           User-specified minimum confidence value for rule generation.\cr
#' @param    used.cols \code{list of characters, optional}\cr
#'           Specified the columns in \emph{data} that specify transaction IDs and item IDs.
#'           For example, consider that the transaction ID column for \emph{data} is "CUSTOMER",
#'           while the item ID column for \emph{data} is "ITEM", then the correct way to set up
#'           this parameter is
#'           \itemize{\item{used.cols = list("transaction" = "CUSTOMER", "item" = "ITEM")}.}\cr
#'           Transaction ID column defaults to the 1st column of \emph{data}, while item ID column
#'           defaults to the 2nd column of \emph{data}.
#' @param    subsample \code{double, optional}\cr
#'           User specified subsampling rate of \emph{data} used for rule mining, ranging from 0 to 1.
#'           Set to 1 if you want to used the entire input data.\cr
#'           Defaults to 1.
#' @param    recalculate \code{logical, optional}\cr
#'           If subsampled, this parameter controls whether or not to use the remaining data to
#'           update the computed support, confidence and lift values.\cr
#'           Vaild only when \emph{subsample} is not 1.\cr
#'           Defaults TRUE.
#' @param    timeout \code{integer, optional}\cr
#'           Specifies the maximum run time in seconds for association rule mining.
#'           The algorithm will stop running when the specified timeout is reached.\cr
#'           Defaults to 3600.
#' @template args-threadratio
#' @template args-pmmlexport
#' @return
#' An "AprioriLite" object with the following attributes:
#' \itemize{
#'   \item{result: \code{DataFrame}}\cr
#' Mined association rules as a whole.
#' Each rule has its antecedent/consequent items and support/confidence/lift values.
#'
#'}
#'
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    CUSTOMER  ITEM
#' 1         2 item2
#' 2         2 item3
#' 3         3 item1
#' 4         3 item2
#' 5         3 item4
#' 6         4 item1
#' 7         4 item3
#' 8         5 item2
#' 9         5 item3
#' 10        6 item1
#' 11        6 item3
#' 12        0 item1
#' 13        0 item2
#' 14        0 item5
#' 15        1 item2
#' 16        1 item4
#' 17        7 item1
#' 18        7 item2
#' 19        7 item3
#' 20        7 item5
#' 21        8 item1
#' 22        8 item2
#' 23        8 item3
#' }
#' Call the function:
#' \preformatted{
#' > apl <- hanaml.AprioriLite(data = data,
#'                             used.cols = c("transaction" = "CUSTOMER", "item" = "ITEM"),
#'                             min.support = 0.1, min.confidence = 0.3,
#'                             pmml.export = 'single-row')
#' }
#' Output:
#' \preformatted{
#' > apl$result$Collect()
#'    ANTECEDENT CONSEQUENT   SUPPORT CONFIDENCE      LIFT
#' 1       item5      item2 0.2222222  1.0000000 1.2857143
#' 2       item1      item5 0.2222222  0.3333333 1.5000000
#' 3       item5      item1 0.2222222  1.0000000 1.5000000
#' 4       item5      item3 0.1111111  0.5000000 0.7500000
#' 5       item1      item2 0.4444444  0.6666667 0.8571429
#' 6       item2      item1 0.4444444  0.5714286 0.8571429
#' 7       item4      item2 0.2222222  1.0000000 1.2857143
#' 8       item3      item2 0.4444444  0.6666667 0.8571429
#' 9       item2      item3 0.4444444  0.5714286 0.8571429
#' 10      item4      item1 0.1111111  0.5000000 0.7500000
#' 11      item3      item1 0.4444444  0.6666667 1.0000000
#' 12      item1      item3 0.4444444  0.6666667 1.0000000
#' }
#' @keywords Association
#' @export
hanaml.AprioriLite <- function(data, used.cols = NULL,
                               min.support, min.confidence,
                               thread.ratio = NULL, subsample = NULL,
                               recalculate = NULL, timeout = NULL,
                               pmml.export = NULL) {
  AprioriLite$new(data, used.cols, min.support,
                  min.confidence, thread.ratio, subsample, recalculate,
                  timeout, pmml.export)
}

FPGrowth <- R6Class(
  "FPGrowth",
  inherit = AssociationBase,
  public = list(
    initialize = function(data,
                          used.cols = NULL,
                          min.support = NULL,
                          min.confidence = NULL,
                          min.lift = NULL,
                          relational = NULL,
                          max.item.length = NULL,
                          max.consequent = NULL,
                          ubiquitous = NULL,
                          lhs.restrict = NULL,
                          rhs.complement.lhs = NULL,
                          rhs.restrict = NULL,
                          lhs.complement.rhs = NULL,
                          timeout = NULL,
                          thread.ratio = NULL) {
      super$initialize(data, min.support, min.confidence,
                       min.lift, relational, max.item.length,
                       max.consequent, ubiquitous, lhs.restrict,
                       rhs.complement.lhs, rhs.restrict,
                       lhs.complement.rhs, timeout, thread.ratio)
      conn <- data$connection.context
      cols <- data$columns
      if (length(cols) < 2) {
        msg <- paste("Input data should contain at least two columns:",
                     "one for transactions and another for items.")
        flog.error(msg)
        stop(msg)
      }
      used.cols <- validateInput("used.cols",
                                 used.cols,
                                 cols,
                                 case.sensitive = TRUE)
      if (!is.null(used.cols)) {
        if (length(used.cols) != 2 || !all(names(used.cols) %in% c("transaction",#nolint
                                                                   "item"))) {
          msg <- paste("`used.cols` should be of length 2:",
                       "one for transactions, the other",
                       "for items.")
          flog.error(msg)
          stop(msg)
        }
      } else {
        used.cols <- list("transaction" = cols[[1]],
                          "item" = cols[[2]])
      }
      if (inherits(data, "DataFrame")){
        CheckConnection(data)
        mdata <- data$Select(list(used.cols[["transaction"]],
                                  used.cols[["item"]]))
        param.rows <- list(
          tuple("MIN_SUPPORT", NULL, self$min.support, NULL),
          tuple("MIN_CONFIDENCE", NULL, self$min.confidence, NULL),
          tuple("MIN_LIFT", NULL, self$min.lift, NULL),#nolint
          tuple("MAX_CONSEQUENT", self$max.consequent, NULL, NULL),
          tuple("MAXITEMLENGTH", self$max.item.length, NULL, NULL),
          tuple("UBIQUITOUS", NULL, self$ubiquitous, NULL),
          tuple("LHS_IS_COMPLEMENTARY_RHS",
                to.integer(isTRUE(self$lhs.complement.rhs)),
                NULL, NULL),
          tuple("RHS_IS_COMPLEMENTARY_LHS",
                to.integer(isTRUE(self$rhs.complement.lhs)),
                NULL, NULL),
          tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
          tuple("TIMEOUT", self$timeout, NULL, NULL)#nolint
        )
        if (!is.null(self$lhs.restrict)){
          for (it in self$lhs.restrict){
            param.rows <- append(param.rows,
                                 list(tuple("LHS_RESTRICT",
                                            NULL, NULL,
                                            as.character(it))))
          }
        }
        if (!is.null(self$rhs.restrict)){
          for (it in self$rhs.restrict){
            param.rows <- append(param.rows,
                                 list(tuple("RHS_RESTRICT",
                                            NULL, NULL,
                                            as.character(it))))
          }
        }
        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_FPGROWTH_PARAM_TBL_%s_%s", self$id, unique.id)
        if (isFALSE(relational)) {
          result.tbl <- sprintf("#PAL_FPGROWTH_RESULT_TBL_%s_%s", self$id, unique.id)
          tables <- list(param.tbl, result.tbl)
          in.tables <- list(mdata, param.tbl)
          out.tables <- list(result.tbl)
          proc.name <- "PAL_FPGROWTH"

        } else {
          antec.tbl <- sprintf("#PAL_FPGROWTH_ANTEC_TBL_%s_%s", self$id, unique.id)
          conseq.tbl <- sprintf("#PAL_FPGROWTH_CONSEQ_TBL_%s_%s", self$id, unique.id)
          stats.tbl <- sprintf("#PAL_FPGROWTH_STATS_TBL_%s_%s", self$id, unique.id)
          tables <- list(param.tbl, antec.tbl, conseq.tbl,
                         stats.tbl)
          in.tables <- list(mdata, param.tbl)
          out.tables <- list(antec.tbl, conseq.tbl, stats.tbl)
          proc.name <- "PAL_FPGROWTH_RELATIONAL"
        }
        tryCatch({
          errorhelper(CreateTWithConnection(conn,
            (ParameterTable$new(param.tbl))$WithData(param.rows)))#nolint
          errorhelper(CallPalAutoWithConnection(conn,
            proc.name, in.tables, out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })
        if (isFALSE(self$relational)) {
          self$result <- conn$table(result.tbl)
        } else {
          self$antecedent <- conn$table(antec.tbl)
          self$consequent <- conn$table(conseq.tbl)
          self$statistics <- conn$table(stats.tbl)
        }
      }
    }
  )
)
#' @title FP-Growth
#' @name hanaml.FPGrowth
#' @description hanaml.FPGrowth is a R wrapper for SAP HANA PAL FPGROWTH and FPGROWTH_RELATIONAL.
#' @template args-data
#' @param     min.support \code{numeric, optional}\cr
#'            User-specified minimum support value for rule generation.\cr
#'            Defaults to 0.
#' @param     min.confidence \code{numeric, optional}\cr
#'            User-specified minimum confidence value for rule generation.\cr
#'            Defaults to 0.
#' @param     used.cols \code{list of characters, optional}\cr
#'            Specified the columns in \emph{data} that specify transaction IDs and item IDs.
#'            For example, consider that the transaction ID column for \emph{data} is "CUSTOMER",
#'            while the item ID column for \emph{data} is "ITEM", then the correct way to set up
#'            this parameter is
#'            \itemize{\item{used.cols = list("transaction" = "CUSTOMER", "item" = "ITEM")}.}
#'            Transaction ID column defaults to the 1st column of \emph{data}, while item ID column
#'            defaults to the 2nd column of \emph{data}.
#' @param     relational \code{logical, optional}\cr
#'            Whether or not to apply relational logic for association rule mining.
#'            This will affect the format view of mined association rules.\cr
#'            Defaults to FALSE.
#' @param     min.lift \code{numeric, optional}\cr
#'            User-specified minimum lift value for rule generation.\cr
#'            Defaults to 0.
#' @param     max.item.length \code{integer, optional}\cr
#'            User-specified maximum length of items, inclusive of both antecedent and consequent items
#'            for association rule generation.\cr
#'            Defaults to 10.
#' @param     max.consequent \code{double, optional}\cr
#'            Maximum length of consequent items for association rule generation.\cr
#'            Defaults to 100.
#' @param     ubiquitous \code{double, optional}\cr
#'            User-specified maximum support value during the frequent items mining phase, i.e.
#'            if an item has support value above \emph{ubiquitous}, it shall be ignored.\cr
#'            Defaults to 1.0.
#' @param     lhs.restrict \code{list of characters, optional}\cr
#'            Specifies the items are only allowed to be antecedent items, i.e. they can only
#'            appear on the left-hand side of association rules.\cr
#'            No default value.
#' @param     rhs.complement.lhs \code{logical, optional}\cr
#'            If \emph{lhs.restrict} is not NULL, you can set this parameter to TRUE to restrict rest
#'            of items so that they can only appear on the right-hand-side of association rules.\cr
#'            Defaults to 0.
#' @param     rhs.restrict \code{list of characters, optional}\cr
#'            Specifies the items are only allowed to be consequent items, i.e. they can only
#'            appear on the right-hand-side of association rules.\cr
#'            No default value.
#' @param     lhs.complement.rhs \code{logical, optional}\cr
#'            If \emph{rhs.restrict} is not NULL, you can set this parameter to TRUE to restrict rest
#'            of items so that they can only appear on the left-hand-side of association rules.\cr
#'            Defaults to 0.
#' @param     timeout \code{integer, optional}\cr
#'            Specifies the maximum run time in seconds for association rule mining.
#'            The algorithm will stop running when the specified timeout is reached.\cr
#'            Defaults to 3600.
#' @template args-threadratio
#'
#' @return
#' A "FPGrowth" object with the following attributes:
#'\itemize{
#'   \item{result: \code{ DataFrame}}\cr
#'         Mined association rules as a whole.
#'         Each rule has its antecedent/consequent items and support/confidence/lift values.
#'         Available only when \code{relatiional} is FALSE.
#'  \item{antecedent: \code{DataFrame}}\cr
#'         Antecedent item information of mined association rules.
#'         Available only when \emph{relational} is TRUE.
#'  \item{consequent: \code{DataFrame}}\cr
#'         Consequent item information of mined association rules.
#'         Available only when \emph{relational} is TRUE.
#'  \item{statistics: \code{DataFrame}}\cr
#'         Support/confidence/lift values of mined association rules.
#'         Available only when \emph{relational} is TRUE.
#'  \item{model: \code{DataFrame}}\cr
#'         Mined association rules in PMML format.\cr
#'         Available only when \emph{pmml.export} is 'single-row' or 'multi-row'.
#'}
#'
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    TRANS ITEM
#' 1      1    1
#' 2      1    2
#' 3      2    2
#' 4      2    3
#' 5      2    4
#' 6      3    1
#' 7      3    3
#' 8      3    4
#' 9      3    5
#' 10     4    1
#' 11     4    4
#' 12     4    5
#' 13     5    1
#' 14     5    2
#' 15     6    1
#' 16     6    2
#' 17     6    3
#' 18     6    4
#' 19     7    1
#' 20     8    1
#' 21     8    2
#' 22     8    3
#' 23     9    1
#' 24     9    2
#' 25     9    3
#' 26    10    2
#' 27    10    3
#' 28    10    5
#' }
#' Call the function:
#' \preformatted{
#' > fpg <- hanaml.FPGrowth(data = data,
#'                         used.cols = c(transaction = "TRANS",
#'                                       item = "ITEM"),
#'                         min.support = 0.2, min.confidence = 0.5,
#'                         max.item.length = 5, min.lift = 1,
#'                         max.consequent = 1, lhs.restrict = c(1,2,3),
#'                         timeout = 60)
#' }
#' Output:
#' \preformatted{
#' > fpg$result$Collect()
#'   ANTECEDENT CONSEQUENT SUPPORT CONFIDENCE     LIFT
#' 1          2          3     0.5  0.7142857 1.190476
#' 2          3          2     0.5  0.8333333 1.190476
#' 3          3          4     0.3  0.5000000 1.250000
#' 4        1&3          4     0.2  0.5000000 1.250000
#' 5        1&2          3     0.3  0.6000000 1.000000
#' 6        1&3          2     0.3  0.7500000 1.071429
#' }
#' @keywords Association
#' @export
hanaml.FPGrowth <- function(data, used.cols = NULL,
                            min.support = NULL, min.confidence = NULL,
                            min.lift = NULL,
                            relational = FALSE, max.item.length = NULL,
                            max.consequent = NULL, ubiquitous = NULL,
                            lhs.restrict = NULL, rhs.complement.lhs = NULL,
                            rhs.restrict = NULL, lhs.complement.rhs = NULL,
                            timeout = NULL, thread.ratio = NULL) {
  FPGrowth$new(data, used.cols,
               min.support, min.confidence, min.lift,
               relational, max.item.length,
               max.consequent, ubiquitous,
               lhs.restrict, rhs.complement.lhs,
               rhs.restrict, lhs.complement.rhs,
               timeout, thread.ratio)
}

KORD <- R6Class(
  "KORD",
  inherit = MlBase,
  public = list(
    k = NULL,
    max.antecedent = NULL,
    measure = NULL,
    min.support = NULL,
    min.confidence = NULL,
    min.coverage = NULL,
    min.measure = NULL,
    epsilon = NULL,
    antecedent = NULL,
    consequent = NULL,
    statistics = NULL,
    max.consequent = NULL,
    measure.map = list("leverage" = 0, "lift" = 1,
                      "support" = 2, "confidence" = 3),
    initialize = function(data,
                          used.cols = NULL,
                          k = NULL,
                          max.antecedent = NULL,
                          min.support = NULL,
                          min.confidence = NULL,
                          min.coverage = NULL,
                          measure = NULL,
                          epsilon = NULL,
                          max.consequent = NULL,
                          min.measure = NULL){
      super$initialize()
      conn <- data$connection.context
      self$k <- validateInput("k", k, "integer")
      self$max.antecedent <- validateInput("max.antecedent", max.antecedent,
                                           "integer")
      self$min.support <- validateInput("min.support", min.support,
                                        "numeric")
      self$min.confidence <- validateInput("min.confidence", min.confidence,
                                      "numeric")
      self$min.coverage <- validateInput("min.coverage", min.coverage,
                                    "numeric")
      self$measure <- validateInput("measure", measure, self$measure.map)
      self$min.measure <- validateInput("min.measure", min.measure,
                                        "numeric")
      self$epsilon <- validateInput("epsilon", epsilon, "numeric")
      self$max.consequent <- validateInput("max.consequent",
                                           max.consequent,
                                           "integer")
      if (!is.null(self$max.consequent)) {
        if (self$max.consequent > 3) {
          msg <- "The value of `max.consequent` should not be greater than 3."
          flog.error(msg)
          stop(msg)
        }
      }
      cols <- data$columns
      if (length(cols) < 2) {
        msg <- paste("Input data should contain at least two columns:",
                     "one for transactions and another for items.")
        flog.error(msg)
        stop(msg)
      }
      used.cols <- validateInput("used.cols",
                                 used.cols,
                                 cols,
                                 case.sensitive = TRUE)
      if (!is.null(used.cols)) {
        if (length(used.cols) != 2 || !all(names(used.cols) %in% c("transaction",#nolint
                                                                   "item"))) {
          msg <- paste("`used.cols` should be of length 2:",
                       "one for transactions, the other",
                       "for items.")
          flog.error(msg)
          stop(msg)
        }
      } else {
        used.cols <- list("transaction" = cols[[1]],
                          "item" = cols[[2]])
      }
      if (inherits(data, "DataFrame")){
        mdata <- data$Select(list(used.cols[["transaction"]],
                                  used.cols[["item"]]))
        param.rows <- list(
          tuple("TOPK", self$k, NULL, NULL),
          tuple("MIN_SUPPORT", NULL, self$min.support, NULL),
          tuple("MIN_CONFIDENCE", NULL, self$min.confidence, NULL),
          tuple("MIN_COVERAGE", NULL, self$min.coverage, NULL),#nolint
          tuple("MAX_ANTECEDENT", self$max.antecedent, NULL, NULL),
          tuple("MIN_MEASURE", NULL, self$min.measure, NULL),
          tuple("IS_USE_EPSILON", to.integer(is.null(self$epsilon)),
                NULL, NULL),
          tuple("EPSILON", NULL, self$epsilon, NULL),
          tuple("MAX_CONSEQUENT", self$max.consequent, NULL, NULL)
        )
        if (!is.null(self$measure)){
          temp <- tuple("MEASURE_TYPE",
                        self$measure.map[[self$measure]],
                        NULL, NULL)
          param.rows <- append(param.rows, list(temp))
        }
        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_KORD_PARAM_TBL_%s_%s", self$id, unique.id)
        antec.tbl <- sprintf("#PAL_KORD_ANTEC_TBL_%s_%s", self$id, unique.id)
        conseq.tbl <- sprintf("#PAL_KORD_CONSEQ_TBL_%s_%s", self$id, unique.id)
        stats.tbl <- sprintf("#PAL_KORD_STATS_TBL_%s_%s", self$id, unique.id)
        tables <- list(param.tbl, antec.tbl, conseq.tbl,
                       stats.tbl)
        in.tables <- list(mdata, param.tbl)
        out.tables <- list(antec.tbl, conseq.tbl, stats.tbl)
        tryCatch({
          errorhelper(CreateTWithConnection(conn,
            (ParameterTable$new(param.tbl))$WithData(param.rows)))#nolint
          errorhelper(CallPalAutoWithConnection(conn,
            "PAL_KORD", in.tables, out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })
        self$antecedent <- conn$table(antec.tbl)
        self$consequent <- conn$table(conseq.tbl)
        self$statistics <- conn$table(stats.tbl)
      }
    }
  )
)
#' @title K-Optimal Rule Discovery (KORD)
#' @name hanaml.KORD
#' @description hanaml.KORD is a R wrapper for SAP HANA PAL KORD.
#' @template args-data
#' @param     used.cols \code{list of characters, optional}\cr
#'            Specified the columns in \emph{data} that specify transaction IDs and item IDs.
#'            For example, consider that the transaction ID column for \emph{data} is "CUSTOMER",
#'            while the item ID column for \emph{data} is "ITEM", then the correct way to set up
#'            this parameter is
#'            \itemize{\item{used.cols = list("transaction" = "CUSTOMER", "item" = "ITEM")}.}
#'            Transaction ID column defaults to the 1st column of \emph{data} and item ID column
#'            defaults to the 2nd column of \emph{data}.
#' @param     k \code{integer, optional}\cr
#'            Specifies the number (k) of top rules.\cr
#'            Defaults to 10.
#' @param     max.antecedent \code{integer, optional}\cr
#'            Maximum length of antecedent items for association rule generation.\cr
#'            Defaults to 4.
#' @param     min.support \code{double, optional}\cr
#'            User-specified minimum support value for rule generation.\cr
#'            Defaults to 0.
#' @param     min.confidence \code{double, optional}\cr
#'            User-specified minimum confidence value for rule generation.\cr
#'            Defaults to 0.
#' @param     min.coverage \code{double, optional}\cr
#'            User-specified minimum lift value for rule generation.\cr
#'            Defaults to the value of \emph{min.support}.
#' @param     measure \code{("leverage", "lift", "support", "confidence"), optional}\cr
#'            User-specified measure that defines the priority of generated association rules.\cr
#'            Defaults to "leverage".
#' @param     epsilon \code{double, optional}\cr
#'            User-specified maximum support value during the frequent items mining phase, i.e.
#'            if an item has support value above \emph{ubiquitous}, it shall be ignored.\cr
#'            Defaults to 1.0.
#' @param     max.consequent \code{integer, optional}\cr
#'            User-specified maximum length of consequent items for association rule generation.\cr
#'            Should not be greater than 3.\cr
#'            New parameter added in SAP HANA Cloud.\cr
#'            Defaults to 1.
#' @param     min.measure \code{double, optional}\cr
#'            Specifies the minimum measure value for leverage or lift, whichever dependents on
#'            the setting of \emph{measure}.\cr
#'            Defaults to 0.0.
#' @return
#' A "KORD" object with the following attributes.
#' \itemize{
#'  \item{antecedent:  \code{DataFrame}}\cr
#'        Antecedent item information of mined association rules.
#'  \item{consequent: \code{DataFrame}}\cr
#'        Consequent item information of mined association rules.
#'  \item{statistics: \code{DataFrame}}\cr
#'        Support/confidence/lift values of mined association rules.
#'}
#'
#' @section Examples:
#' Input transaction DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    CUSTOMER  ITEM
#' 1         2 item2
#' 2         2 item3
#' 3         3 item1
#' 4         3 item2
#' 5         3 item4
#' 6         4 item1
#' 7         4 item3
#' 8         5 item2
#' 9         5 item3
#' 10        6 item1
#' 11        6 item3
#' 12        0 item1
#' 13        0 item2
#' 14        0 item5
#' 15        1 item2
#' 16        1 item4
#' 17        7 item1
#' 18        7 item2
#' 19        7 item3
#' 20        7 item5
#' 21        8 item1
#' 22        8 item2
#' 23        8 item3
#' }
#'
#' Creating an KORD object for mining association rules from the input data:
#' \preformatted{
#' > kd <- hanaml.KORD(data = data,
#'                     used.cols = c(transaction = "CUSTOMER",
#'                                   item = "ITEM"),
#'                     min.support = 0.1, min.confidence = 0.2,
#'                     measure = "Lift", k = 5)
#' }
#' Check the mined association rules from the attributes of above KORD object:
#' \preformatted{
#' > kd$antecedent
#'   RULE_ID ANTECEDENT
#' 1       0      item2
#' 2       1      item1
#' 3       2      item2
#' 4       2      item1
#' 5       3      item5
#' 6       4      item2
#' > kd$consequent
#'   RULE_ID CONSEQUENT
#' 1       0      item5
#' 2       1      item5
#' 3       2      item5
#' 4       3      item1
#' 5       4      item4
#' > kd$statistics
#'   RULE_ID   SUPPORT CONFIDENCE     LIFT   LEVERAGE  MEASURE
#' 1       0 0.2222222  0.2857143 1.285714 0.04938272 1.285714
#' 2       1 0.2222222  0.3333333 1.500000 0.07407407 1.500000
#' 3       2 0.2222222  0.5000000 2.250000 0.12345679 2.250000
#' 4       3 0.2222222  1.0000000 1.500000 0.07407407 1.500000
#' 5       4 0.2222222  0.2857143 1.285714 0.04938272 1.285714
#' }
#' @keywords Association
#' @export
hanaml.KORD <- function(data, used.cols = NULL,
                        k = NULL, max.antecedent = NULL,
                        min.support = NULL, min.confidence = NULL,
                        min.coverage = NULL, measure = NULL,
                        epsilon = NULL, max.consequent = NULL,
                        min.measure = NULL) {
  KORD$new(data, used.cols,
           k, max.antecedent, min.support,
           min.confidence, min.coverage,
           measure, epsilon, max.consequent,
           min.measure)
}

SPM <- R6Class(
  "SPM",
  inherit = MlBase,
  public = list(
    min.support = NULL,
    ubiquitous = NULL,
    min.event.size = NULL,
    max.event.size = NULL,
    min.event.length = NULL,
    max.event.length = NULL,
    item.restrict = NULL,
    min.gap = NULL,
    calculate.lift = NULL,
    timeout = NULL,
    pattern = NULL,
    statistics = NULL,
    result = NULL,
    initialize = function(data,
                          used.cols = NULL,
                          relational = NULL,
                          min.support = NULL,
                          ubiquitous = NULL,
                          min.event.size = NULL,
                          max.event.size = NULL,
                          min.event.length = NULL,
                          max.event.length = NULL,
                          item.restrict = NULL,
                          min.gap = NULL,
                          calculate.lift = NULL,
                          timeout = NULL){
      super$initialize()
      conn <- data$connection.context
      if (!is.null(data)){
        self$min.support <- validateInput("min.support", min.support,
                                          "double")
        self$ubiquitous <- validateInput("ubiquitous", ubiquitous,
                                         "double")
        self$min.event.size <- validateInput("min.event.size", min.event.size,
                                             "integer")
        self$max.event.size <- validateInput("max.event.size", max.event.size,
                                             "integer")
        self$min.event.length <- validateInput("min.event.length",
                                               min.event.length, "integer")
        self$max.event.length <- validateInput("max.event.length",
                                               max.event.length, "integer")
        self$min.gap <- validateInput("min.gap", min.gap, "integer")
        self$calculate.lift <- validateInput("calculate.lift",
                                             calculate.lift,
                                             "logical")
        self$timeout <- validateInput("timeout", timeout, "integer")
        if (!is.null(item.restrict)){
          item.restrict <- unlist(item.restrict)
          if (is.integer(item.restrict) || is.character(item.restrict)){
            flag <- TRUE
          } else if (is.numeric(item.restrict) && all(sapply(item.restrict,
                                                             round) == item.restrict)){#nolint
            flag <- TRUE
          } else {
            flag <- FALSE
          }
          if (flag == TRUE){
            self$item.restrict <- item.restrict
          } else {
            msg <- paste("`item.restrict` must be",
                         "list/vector of integers",
                         "or characters.")
            flog.error(msg)
            stop(msg)
          }
        }
        cols <- data$columns
        if (length(cols) < 3) {
          msg <- paste("Input data should contain at least three columns:",
                       "one for customers, one for transactions and",
                       "one for items.")
          flog.error(msg)
          stop(msg)
        }
        used.cols <- validateInput("used.cols",
                                   used.cols,
                                   cols,
                                   case.sensitive = TRUE)
        if (!is.null(used.cols)) {
          if (length(used.cols) != 3 || !all(names(used.cols) %in% c("customer",#nolint
                                                                     "transaction",#nolint
                                                                     "item"))) {
            msg <- paste("`used.cols` should be of length 3:",
                         "one for customers, one for transactions,",
                         "and one for items.")
            flog.error(msg)
            stop(msg)
          }
        } else {
          used.cols <- list("customer" = cols[[1]],
                            "transaction" = cols[[2]],
                            "item" = cols[[3]])
        }
        if (inherits(data, "DataFrame")){
          CheckConnection(data)
          mdata <- data$Select(list(used.cols[["customer"]],
                                    used.cols[["transaction"]],
                                    used.cols[["item"]]))
          param.rows <- list(
            tuple("MIN_SUPPORT", NULL, self$min.support, NULL),
            tuple("UBIQUITOUS", NULL, self$ubiquitous, NULL),
            tuple("MIN_EVENT_SIZE", self$min.event.size, NULL, NULL),
            tuple("MAX_EVENT_SIZE", self$min.event.size, NULL, NULL),
            tuple("MIN_EVENT_LENGTH", self$min.event.length, NULL, NULL),
            tuple("MAX_EVENT_LENGTH", self$max.event.length, NULL, NULL),
            tuple("MIN_GAP", self$min.gap, NULL, NULL),
            tuple("TIMEOUT", self$timeout, NULL, NULL)
          )
          if (!is.null(self$calculate.lift)){
            param.rows <- append(param.rows,
                                 list(tuple("CALCULATE_LIFT",
                                            to.integer(self$calculate.lift),
                                            NULL,
                                            NULL)))
          }
          if (!is.null(self$item.restrict)){
            param.rows <- append(param.rows,
                                 list(tuple("ITEM_RESTRICT",
                                            NULL,
                                            NULL,
                                            paste(self$item.restrict,
                                                  collapse = ", "))))
          }
          unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
          param.tbl <- sprintf("#PAL_SPM_PARAM_TBL_%s_%s", self$id, unique.id)
          in.tables <- list(mdata, param.tbl)
          if (isTRUE(relational)){
            proc.name <- "PAL_SPM_RELATIONAL"
            pattern.tbl <- sprintf("#PAL_SPM_PATTERN_TBL_%s_%s", self$id, unique.id)
            stats.tbl <- sprintf("#PAL_SPM_STATS_TBL_%s_%s", self$id, unique.id)
            out.tables <- list(pattern.tbl, stats.tbl)
          } else {
            proc.name <- "PAL_SPM"
            result.tbl <- sprintf("#PAL_SPM_RESULT_TBL_%s_%s", self$id, unique.id)
            out.tables <- list(result.tbl)
          }
          tables <- c(param.tbl, out.tables)
          tryCatch({
            errorhelper(CreateTWithConnection(conn,
              (ParameterTable$new(param.tbl))$WithData(param.rows)))#nolint
            errorhelper(CallPalAutoWithConnection(conn,
                                                  proc.name,
                                                  in.tables,
                                                  out.tables))
          },
          error = function(err){
            msg <- paste("Error:", err[["message"]])
            flog.error(msg)
            TryDropWithConnection(conn, tables)
            stop(msg)
          })
          if (isTRUE(relational)){
            self$pattern <- conn$table(pattern.tbl)
            self$statistics <- conn$table(stats.tbl)
          } else {
            self$result <- conn$table(result.tbl)
          }
        }
      }
    }
  )
)
#' @title Sequential Pattern Mining (SPM)
#' @name hanaml.SPM
#' @description hanaml.SPM is a R wrapper for SAP HANA PAL SPM.
#' @details  The sequential pattern mining (SPM) algorithm, which searches for frequent patterns in
#'  sequence databases.
#' @template args-data
#' @param     used.cols \code{list of characters, optional}\cr
#'            Specified the columns in \emph{data} that specify customer IDs, transaction IDs and
#'            item IDs.
#'            For example, considering that the customer ID column for \emph{data} is "CUSTID",
#'            the transaction ID column of \emph{data} is "TRANSID",
#'            while the item ID column for \emph{data} is "ITEMS", then the correct way to set up
#'            this parameter is
#'            \itemize{\item{used.cols = list("customer" = "CUSTID",
#'                                   "transaction" = "TRANSID",
#'                                   "item" = "ITEMS")}.}
#'            If not set, customer ID column defaults to the 1st column of \emph{data},
#'            transaction ID column defaults to the 2nd column of \emph{data}, and item ID column
#'            defaults to the 3rd column of \emph{data}.
#' @param     relational \code{logical, optional}\cr
#'            Specifies whether or not to apply relational logic to the output of SPM algorithm.
#'            This only affects the view of the sequential mining result.\cr
#'            Defaults to FALSE.
#' @param     min.support \code{double}\cr
#'            User-specified minimum support value for rule generation.\cr
#' @param     ubiquitous \code{double, optional}\cr
#'            User-specified maximum support value during the frequent items mining phase, i.e.
#'            if an item has support value above \emph{ubiquitous}, it shall be ignored.\cr
#'            Defaults to 1.0.
#' @param     min.event.size \code{integer, optional}\cr
#'            User-specified minimum number of items in an event.\cr
#'            Defaults to 1.
#' @param     max.event.size \code{integer, optional}\cr
#'            User-specified maximum number of items in an event.\cr
#'            Defaults to 10.
#' @param     min.event.length \code{integer, optional}\cr
#'            User-specified minimum length of events in the output.\cr
#'            Defaults to 1.
#' @param     max.event.length \code{integer, optional}\cr
#'            User-specified maximum length of events in the output.\cr
#'            Defaults to 10.
#' @param     item.restrict \code{list of strings/integers, optional}\cr
#'            Specifies which items are allowed in the association rule.\cr
#'            No default value.
#' @param     min.gap \code{integer, optional}\cr
#'            Specifies The minimum time difference between consecutive events of a sequence.\cr
#'            If the data type of the input transaction ID is timestamp, the unit of this parameter is second.\cr
#'            No default value.
#' @param     calculate.lift \code{logical, optional}\cr
#'            - FALSE: Only calculates lift values for the cases that the last event contains only one item.\cr
#'            - TRUE: Calculates lift values for all applicable cases. This will take extra time.\cr
#'            Defaults to FALSE.
#' @param     timeout \code{integer, optional}\cr
#'            Specifies the maximum run time in seconds for association rule mining.
#'            The algorithm will stop running when the specified timeout is reached.\cr
#'            Defautls to 3600.
#'
#' @return
#' A "SPM" object with the following attributes:
#' \itemize{
#'    \item{result: \code{DataFrame}}\cr
#'        Mined frequent patterns with transaction IDs, item IDs
#'        as well as support, confindence and lift values in all.\cr
#'        Available only when \emph{relational} is FALSE.
#'  \item{pattern: \code{DataFrame}}\cr
#'        Mined frequent patterns with transaction IDs and item IDs.
#'        Available only when \emph{relational} is TRUE.
#'  \item{statistics: \code{DataFrame}}\cr
#'        Support/confidence/lift values of mined frequent patterns.
#'        Available only when \emph{relational} is TRUE.
#'}
#'
#' @section Examples:
#' Input transaction DataFrame data:
#' \preformatted{
#' > data$CollecT()
#'    CUSTID TRANSID     ITEMS
#' 1       A       1     Apple
#' 2       A       1 Blueberry
#' 3       A       2     Apple
#' 4       A       2    Cherry
#' 5       A       3   Dessert
#' 6       B       1    Cherry
#' 7       B       1 Blueberry
#' 8       B       1     Apple
#' 9       B       2   Dessert
#' 10      B       3 Blueberry
#' 11      C       1     Apple
#' 12      C       2 Blueberry
#' 13      C       3   Dessert
#' }
#'
#' Creating an SPM object for mining association rules from the input data:
#' \preformatted{
#' > sp <- hanaml.SPM(data = df, relational = TRUE,
#'                    used.cols = c("customer" = "CUSTID",
#'                                  "transaction" = "TRANSID",
#'                                  "item" = "ITEMS"),
#'                    min.support = 0.5, calculate.lift = TRUE)
#' }
#' Check the mined frequent patterns from the attributes of above SPM object:
#' \preformatted{
#' > sp$pattern$CollecT()
#'    PATTERN_ID EVENT_ID              ITEM
#' 1           1        1           {Apple}
#' 2           2        1           {Apple}
#' 3           2        2       {Blueberry}
#' 4           3        1           {Apple}
#' 5           3        2         {Dessert}
#' 6           4        1 {Apple,Blueberry}
#' 7           5        1 {Apple,Blueberry}
#' 8           5        2         {Dessert}
#' 9           6        1    {Apple,Cherry}
#' 10          7        1    {Apple,Cherry}
#' 11          7        2         {Dessert}
#' 12          8        1       {Blueberry}
#' 13          9        1       {Blueberry}
#' 14          9        2         {Dessert}
#' 15         10        1          {Cherry}
#' 16         11        1          {Cherry}
#' 17         11        2         {Dessert}
#' 18         12        1         {Dessert}
#'
#' > sp$statistics$CollecT()
#'    PATTERN_ID   SUPPORT CONFIDENCE      LIFT
#' 1           1 1.0000000  0.0000000 0.0000000
#' 2           2 0.6666667  0.6666667 0.6666667
#' 3           3 1.0000000  1.0000000 1.0000000
#' 4           4 0.6666667  0.0000000 0.0000000
#' 5           5 0.6666667  1.0000000 1.0000000
#' 6           6 0.6666667  0.0000000 0.0000000
#' 7           7 0.6666667  1.0000000 1.0000000
#' 8           8 1.0000000  0.0000000 0.0000000
#' 9           9 1.0000000  1.0000000 1.0000000
#' 10         10 0.6666667  0.0000000 0.0000000
#' 11         11 0.6666667  1.0000000 1.0000000
#' 12         12 1.0000000  0.0000000 0.0000000
#' }
#' @keywords Association
#' @export
hanaml.SPM <- function(data, used.cols = NULL,
                       relational = NULL, min.support,
                       ubiquitous = NULL, min.event.size = NULL,
                       max.event.size = NULL, min.event.length = NULL,
                       max.event.length = NULL, item.restrict = NULL,
                       min.gap = NULL, calculate.lift = NULL,
                       timeout = NULL){
  SPM$new(data, used.cols, relational, min.support, ubiquitous,
          min.event.size, max.event.size, min.event.length,
          max.event.length, item.restrict, min.gap,
          calculate.lift, timeout)
}
