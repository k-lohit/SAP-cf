ARIMA <- R6Class(
  "ARIMA",
  inherit = MlBase,
  public = list(
    method.map = list(
      "css" = 0,
      "mle" = 1,
      "css-mle" = 2
    ),
    forecast.method.map = list(
      "formula.forecast" = 0,
      "innovations.algorithm" = 1
    ),
    order = NULL,
    order.p = NULL,
    order.q = NULL,
    order.d = NULL,
    seasonal.order = NULL,
    seasonal.order.p = NULL,
    seasonal.order.d = NULL,
    seasonal.order.q = NULL,
    seasonal.order.s = NULL,
    method = NULL,
    include.mean = NULL,
    forecast.method = NULL,
    forecast.length = NULL,
    output.fitted = NULL,
    thread.ratio = NULL,
    fitted = NULL,
    model = NULL,
    conn.context = NULL,
    initialize = function(data = NULL,
                          key = NULL,
                          endog = NULL,
                          exog = NULL,
                          order = NULL,
                          order.p = NULL,
                          order.q = NULL,
                          order.d = NULL,
                          seasonal.order = NULL,
                          seasonal.order.p = NULL,
                          seasonal.order.d = NULL,
                          seasonal.order.q = NULL,
                          seasonal.order.s = NULL,
                          method = NULL,
                          include.mean = NULL,
                          forecast.method = NULL,
                          output.fitted = NULL,
                          thread.ratio = NULL) {
      super$initialize()
      if (!is.null(data)) {
        self$order <- validateInput("order", unlist(order), c("integer","numeric"))
        if (!is.null(order) && length(order)!= 3){
          msg <- "order must contain exactly 3 integers for regression order, differentiation order and moving average order!"
          flog.error(msg)
          stop(msg)
        }
        #seasonal.order check
        self$seasonal.order <- validateInput("seasonal.order", unlist(seasonal.order), c("integer","numeric"))
        if (!is.null(seasonal.order) && length(seasonal.order)!= 4){
          msg <- "seasonal.order must contain exactly 4 integers for regression, differentiation order, moving average order for seasonal part and seasonal period!"
          flog.error(msg)
          stop(msg)
        }
        self$order.p <- validateInput("order.p", order.p, "integer")
        self$order.q <- validateInput("order.q", order.q, "integer")
        self$order.d <- validateInput("order.d", order.d, "integer")
        self$seasonal.order.p <- validateInput("seasonal.order.p",
                                               seasonal.order.p,
                                               "integer")
        self$seasonal.order.d <- validateInput("seasonal.order.d",
                                               seasonal.order.d,
                                               "integer")
        self$seasonal.order.q <- validateInput("seasonal.order.q",
                                               seasonal.order.q,
                                               "integer")
        self$seasonal.order.s <- validateInput("seasonal.order.s",
                                               seasonal.order.s,
                                               "integer")
        self$include.mean <- validateInput("include.mean",
                                           include.mean,
                                           "logical")

        self$method <- validateInput("method", method, self$method.map)

        self$forecast.method <- validateInput("forecast.method",
                                              forecast.method,
                                              self$forecast.method.map)
        self$output.fitted <- validateInput("output.fitted",
                                            output.fitted,
                                            "logical")
        self$thread.ratio <- validateInput("thread.ratio",
                                           thread.ratio,
                                           "double")
        cols <- data$columns

        if (is.null(key)){
          key <- cols[[1]]
        }
        key <- validateInput("key", key, cols, case.sensitive = TRUE)
        cols <- cols[! cols %in% key]

        if (is.null(endog)){
          endog <- cols[[1]]
        }
        endog <- validateInput("endog", endog, cols, case.sensitive = TRUE)
        cols <- cols[! cols %in% endog]

        exog <- validateInput("exog", exog, cols, case.sensitive = TRUE)

        if (!inherits(data, "DataFrame")) {
          msg <- "data must be given as DataFrame."
          flog.error(msg)
          stop(msg)
        }

        CheckConnection(data)
        conn.context <- data$connection.context
        self$conn.context <- conn.context

        selected <- list(key, endog)
        data <- data$Select(append(selected, exog))

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_ARIMA_PARAM_TBL_%s_%s",
                             self$id, unique.id)
        model.tbl <- sprintf("#PAL_ARIMA_MODEL_TBL_%s_%s",
                             self$id, unique.id)
        fitted.tbl <- sprintf("#PAL_ARIMA_FITTED_TBL_%s_%s",
                              self$id, unique.id)
        in.tables <- list(data, param.tbl)
        tables <- list(param.tbl, model.tbl, fitted.tbl)
        out.tables <- list(model.tbl, fitted.tbl)
        if (length(self$order) == 3) {
          if (is.null(self$order[[1]])) {
            self$order.p <- self$order[[1]]
          }
          if (is.null(self$order[[2]])) {
            self$order.q <- self$order[[2]]
          }
          if (is.null(self$order[[3]])) {
            self$order.d <- self$order[[3]]
          }
        }
        if (length(self$seasonal.order) == 4) {
          if (is.null(self$seasonal.order[[1]])) {
            self$seasonal.order.p <- self$seasonal.order[[1]]
          }
          if (is.null(self$seasonal.order[[2]])) {
            self$seasonal.order.q <- self$seasonal.order[[2]]
          }
          if (is.null(self$seasonal.order[[3]])) {
            self$seasonal.order.d <- self$seasonal.order[[3]]
          }
          if (is.null(self$seasonal.order[[4]])) {
            self$seasonal.order.s <- self$seasonal.order[[4]]
          }
        }
        param.rows <- list(
          tuple("P", self$order.p, NULL, NULL),
          tuple("D", self$order.d, NULL, NULL),
          tuple("Q", self$order.q, NULL, NULL),
          tuple("SEASONAL_PERIOD", self$seasonal.order.s, NULL, NULL),
          tuple("SEASONAL_P", self$seasonal.order.p, NULL, NULL),
          tuple("SEASONAL_D", self$seasonal.order.d, NULL, NULL),
          tuple("SEASONAL_Q", self$seasonal.order.q, NULL, NULL),
          tuple("METHOD",
                map.null(self$method,
                         self$method.map),
                NULL, NULL),
          tuple(
            "FORECAST_METHOD",
            map.null(self$forecast.method,
                     self$forecast.method.map),
            NULL,
            NULL
          ),
          tuple("OUTPUT_FITTED", to.integer(self$output.fitted),
                NULL, NULL),
          tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
          tuple("INCLUDE_MEAN", to.integer(self$include.mean), NULL, NULL),
          tuple("DEPENDENT_VARIABLE", NULL, NULL, endog)
        )

        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
            (ParameterTable$new(param.tbl))$WithData(param.rows))) #nolint
          errorhelper(CallPalAutoWithConnection(conn.context,
                                                "PAL_ARIMA",
                                                in.tables,
                                                out.tables))
        },
        error = function(err) {
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        self$model <- conn.context$table(model.tbl)
        self$fitted <- conn.context$table(fitted.tbl)
      }
    }
  )
)
#' @title Autoregressive Integrated Moving Average
#' @name hanaml.ARIMA
#' @description hanaml.ARIMA is a R wrapper for SAP HANA PAL ARIMA algorithm.
#' @details Autoregressive Integrated Moving Average ARIMA(p, d, q) model.
#' @seealso \code{\link{predict.ARIMA}}
#' @template args-data
#' @param     key \code{character, optional}\cr
#'            Name of the key. The type of key column is integer.\cr
#'            If not provide, defaults to the first column.
#' @template args-endog
#' @param     exog \code{character or list of character, optional}\cr
#'            An optional array of exogenous variables.
#'            Valid only for ARIMAX; cannot be the first ID column
#'            and the name of endog column.\cr
#'            Defaults to NULL, i.e. no exogenous columns in \code{data}.
#' @param     order \code{list/vector of integers, optional}\cr
#'            (p, q, d) values of the auto regression, moving average and differentiation order.\cr
#'            Defaults to c(0,0,0).
#' @param     order.p \code{integer, optional}\cr
#'            value of the auto regression order.\cr
#'            Defaults to 0.
#' @param     order.q \code{integer, optional}\cr
#'            value of the differentiation order.\cr
#'            Defaults to 0.
#' @param     order.d \code{integer, optional}\cr
#'            Value of the differentiation order.\cr
#'            Defaults to 0.
#' @param     seasonal.order \code{list of integer, optional}\cr
#'            (P, Q, D, S) values of the auto regression, differentiation, moving average order
#'            and seasonal period for the seasonal part.
#'            Defaults to (0,0,0,0).\cr
#' @param     seasonal.order.p \code{integer, optional}\cr
#'            value of the auto regression order for the seasonal part.\cr
#'            Defaults to 0.
#' @param     seasonal.order.d \code{integer, optional}\cr
#'            value of the differentiation order for the seasonal part.\cr
#'            Defaults to 0.
#' @param     seasonal.order.q \code{integer, optional}\cr
#'            value of the moving average order for the seasonal part.\cr
#'            Defaults to 0.
#' @param     seasonal.order.s \code{integer, optional}\cr
#'            value of the seasonal period.\cr
#'            Defaults to 0.
#' @param     method \code{c("css", "mle", "css-mle"), optional}\cr
#'            The object function for integer optimization.
#'            \itemize{
#'              \item{\code{"css":} use the conditional sum of squares. }
#'              \item{\code{"mle":} use the maximized likelihood estimation.}
#'              \item{\code{"css-mle":} use css to approximate starting values and mle to fit.}
#'            }\cr
#'            Defaults to "css-mle".
#' @param     include.mean \code{logical, optional}\cr
#'            ARIMA model includes a constant part if TRUE.\cr
#'            Valid only when d + D <= 1.
#'            if d + D = 0, TRUE.
#'            else FALSE\cr
#' @param     forecast.method \code{{"formula.forecast", "innovations.algorithm"}, optional}\cr
#' Store information for the subsequent forecast method.
#' \itemize{
#'         \item{\code{"formula.forecast":} compute future series via formula. }
#'         \item{\code{"innovations.algorithm":} apply innovations algorithm to compute future
#'               series, which requires more original information to be stored}
#' }
#' Defaults to "innovations.algorithm".
#' @param     output.fitted \code{logical, optional}\cr
#'            Output fitted result and residuals if TRUE.\cr
#'            Defaults to TRUE.
#' @template args-threadratio
#' @return
#' Returns an "ARIMA" object with the following attributes:
#' \itemize{
#' \item{model: \code{DataFrame}}\cr
#'      Fitted model.
#' \item{fitted: \code{DataFrame}}\cr
#'      Predicted dependent variable values for training data.
#'      Set to NULL if the training data has no row IDs.
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    TIMESTAMP           Y
#' 1          1 -0.63612643
#' 2          2  3.09250865
#' 3          3 -0.73733556
#' 4          4 -3.14219098
#' 5          5  2.08881981
#' .......
#' }
#' Invoke the function:
#' \preformatted{
#' > arm <- hanaml.ARIMA(data = data,
#'                       order.p = 0,
#'                       order.d = 0,
#'                       order.q = 1,
#'                       seasonal.order.p = 1,
#'                       seasonal.order.s = 4,
#'                       method = "mle",
#'                       thread.ratio = 1.0,
#'                       output.fitted = TRUE)
#' }
#' Output:
#' \preformatted{
#' > arm$fitted$Collect()
#'    TIMESTAMP      FITTED  RESIDUALS
#' 1          1  0.02337363 -0.6595001
#' 2          2  0.11459591  2.9779127
#' 3          3 -0.39656680 -0.3407688
#' 4          4  0.10108234 -3.2432733
#' 5          5 -0.43702717  2.5258470
#' 6          6  2.34169970  0.8376030
#' ......
#' }
#' @keywords TimeSeries
#' @export
hanaml.ARIMA <- function(data = NULL,
                         key = NULL,
                         endog = NULL,
                         exog = NULL,
                         order = NULL,
                         order.p = NULL,
                         order.q = NULL,
                         order.d = NULL,
                         seasonal.order = NULL,
                         seasonal.order.p = NULL,
                         seasonal.order.d = NULL,
                         seasonal.order.q = NULL,
                         seasonal.order.s = NULL,
                         method = NULL,
                         include.mean = NULL,
                         forecast.method = NULL,
                         output.fitted = NULL,
                         thread.ratio = NULL) {
  ARIMA$new(data,
            key,
            endog,
            exog,
            order,
            order.p,
            order.q,
            order.d,
            seasonal.order,
            seasonal.order.p,
            seasonal.order.d,
            seasonal.order.q,
            seasonal.order.s,
            method,
            include.mean,
            forecast.method,
            output.fitted,
            thread.ratio)
}

#' @export
print.ARIMA <- function(x, ...) {
  writeLines("ARIMA Model ID:")
  print(x$id)
  writeLines("\n")

  writeLines("ARIMA Model:")
  print(x$model)
  writeLines("\n")

  writeLines("ARIMA fitted:")
  print(x$fitted)
  writeLines("\n")
}

#' @title Make Predictions from a "ARIMA" Object
#' @name predict.ARIMA
#' @description Similar to other predict methods, this function
#' predicts fitted values from a fitted "ARIMA" object.
#' @seealso \code{\link{hanaml.ARIMA}}
#' @format \code{\link{S3}} methods
#' @param      model \code{R6Class object}\cr
#'             An "ARIMA" object for prediction.
#' @param      data \code{DataFrame, optional}\cr
#'             Includes the ID column and external Data (exogeneous variables) for prediction.\cr
#'             Defaults to NULL.
#' @param      key \code{character, optional}\cr
#'             Name of the key in the data. \cr
#'             Defaults to NULL and if data is not NULL and key is not provided, defaults to the first column.
#' @param      forecast.method \code{{"formula.forecast", "innovations.algorithm"}, optional}\cr
#'             Store information for the subsequent forecast method.
#'             \itemize{
#'                    \item{\code{"formula.forecast":} compute future series via formula. }
#'                    \item{\code{"innovations.algorithm":} apply innovations algorithm to compute future
#'                          series, which requires more original information to be stored}
#'            }\cr
#'            Defaults to "innovations.algorithm".
#' @param     forecast.length \code{integer, optional}\cr
#'            Number of points to forecast.\cr
#'            Defaults to 1.
#' @param     ... Reserved parameter.
#' @return
#' Predicted values are returned as a DataFrame, structured as follows:
#' \itemize{
#'  \item{\code{ID}: with same name and type the ID column of \code{data}.}
#'  \item{\code{FORECAST}: type DOUBLE, representing predicted values.}
#'  \item{\code{SE}: type DOUBLE, standard error.}
#'  \item{\code{LO80}: type DOUBLE, low 80\% values.}
#'  \item{\code{HI80}: type DOUBLE, high 80\% values.}
#'  \item{\code{LO95}: type DOUBLE, low 95\% values.}
#'  \item{\code{HI95}: type DOUBLE, high 95\% values.}
#' }
#' @section Examples:
#' Apply predict on an 'arima' object arm and obtain the result:
#' \preformatted{
#' > res <- predict(arm,
#'                  forecast.method='innovations.algorithm',
#'                  forecast.length = 10)
#'
#'    TIMESTAMP   FORECAST       SE       LO80       HI80       LO95       HI95
#' 1          0  1.5577828 1.302436 -0.1113569  3.2269225 -0.9949452  4.1105108
#' 2          1  3.7659871 1.315333  2.0803200  5.4516542  1.1879826  6.3439917
#' 3          2 -0.5655989 1.315333 -2.2512660  1.1200682 -3.1436035  2.0124056
#' 4          3 -3.6198158 1.315333 -5.3054829 -1.9341487 -6.1978203 -1.0418112
#' ......
#' }
#' @keywords TimeSeries
#' @export
predict.ARIMA <- function(model,
                          data = NULL,
                          key = NULL,
                          forecast.method = NULL,
                          forecast.length = NULL,
                          ...) {
  if (is.null(model$model)) {
    msg <- "model of object is empty."
    flog.error(msg)
    stop(msg)
  }
  forecast.method <- validateInput("forecast.method",
                                   forecast.method,
                                   model$forecast.method.map)
  forcast.length <- validateInput("forecast.length",
                                  forecast.length,
                                  "integer")
  if (is.null(data)){
    conn.context <- model$conn.context
  } else {
    conn.context <- data$connection.context
  }

  if (!is.null(data))
  {
    cols <- data$columns
    if (is.null(key)){
      key <- cols[[1]]
    }
    key <- validateInput("key", key, cols, case.sensitive = TRUE)
    cols <- cols[! cols %in% key]
    exog <- cols
    data <- data$Select(append(key, exog))
  }

  conn <- conn.context$connection
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_AUTO_ARIMA_PARAM_TBL_%s_%s",
                       model$id, unique.id)#nolint
  fitted.tbl <- sprintf("#PAL_AUTO_ARIMA_FITTED_TBL_%s_%s",
                        model$id, unique.id)#nolint
  data.flag <- is.null(data)
  if (data.flag){
    data.tbl <- sprintf("PAL_ARIMA_DATA_TBL_%s", unique.id)
    tryCatch({
      ExecuteLogged(conn, paste("CREATE COLUMN TABLE",
                              data.tbl,
                              "(\"TIMESTAMP\" INTEGER,",
                              "\"Y\" DOUBLE)"))
    },
    error = function(err){
      msg <- paste("Error:", err[["message"]])
      flog.error(msg)
      ExecuteLogged(conn,
                  sprintf("drop table %s", data.tbl))
      stop(msg)
    }
    )
    data <- conn.context$table(data.tbl)
  }
  in.tables <- list(data, model$model$name, param.tbl)
  tables <- list(param.tbl, fitted.tbl)
  out.tables <- list(fitted.tbl)
  param.rows <- list(tuple("FORECAST_METHOD",
                           map.null(forecast.method,
                                    model$forecast.method.map),
                           NULL, NULL),
                     tuple("FORECAST_LENGTH", forecast.length,
                           NULL, NULL))

  tryCatch({
    errorhelper(CreateTWithConnection(conn.context,
      (ParameterTable$new(param.tbl))$WithData(param.rows))) #nolint
    errorhelper(CallPalAutoWithConnection(conn.context,
      "PAL_ARIMA_FORECAST", in.tables, out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn.context, tables)
    if (data.flag){
      sqlQueryMix(conn, paste("drop table", data.tbl))
    }
    stop(msg)
  })
  if (data.flag){
    ExecuteLogged(conn, paste("drop table", data.tbl))
  }
  return(conn.context$table(fitted.tbl))
}


AutoARIMA <- R6Class(
  "AutoARIMA",
  inherit = MlBase,
  public = list(
    method.map = list("css" = 0, "mle" = 1, "css-mle" = 2),
    forecast.method.map = list("formula.forecast" = 0, "innovations.algorithm" = 1),
    fitted = NULL,
    model = NULL,
    seasonal.period = NULL,
    seasonality.criterion = NULL,
    d = NULL,
    kpss.significance.level = NULL,
    max.d = NULL,
    seasonal.d = NULL,
    ch.significance.level = NULL,
    max.seasonal.d = NULL,
    max.p = NULL,
    max.q = NULL,
    max.seasonal.p = NULL,
    max.seasonal.q = NULL,
    information.criterion = NULL,
    search.strategy = NULL,
    max.order = NULL,
    initial.p = NULL,
    initial.q = NULL,
    initial.seasonal.p = NULL,
    initial.seasonal.q = NULL,
    guess.states = NULL,
    max.search.iterations = NULL,
    method = NULL,
    allow.linear = NULL,
    forecast.method = NULL,
    output.fitted = NULL,
    thread.ratio = NULL,
    conn.context = NULL,
    initialize = function(data = NULL,
                          key = NULL,
                          endog = NULL,
                          exog = NULL,
                          seasonal.period = NULL,
                          seasonality.criterion = NULL,
                          d = NULL,
                          kpss.significance.level = NULL,
                          max.d = NULL,
                          seasonal.d = NULL,
                          ch.significance.level = NULL,
                          max.seasonal.d = NULL,
                          max.p = NULL,
                          max.q = NULL,
                          max.seasonal.p = NULL,
                          max.seasonal.q = NULL,
                          information.criterion = NULL,
                          search.strategy = NULL,
                          max.order = NULL,
                          initial.p = NULL,
                          initial.q = NULL,
                          initial.seasonal.p = NULL,
                          initial.seasonal.q = NULL,
                          guess.states = NULL,
                          max.search.iterations = NULL,
                          method = NULL,
                          allow.linear = NULL,
                          forecast.method = NULL,
                          output.fitted = NULL,
                          thread.ratio = NULL){
      super$initialize()
      if (!is.null(data)){
        self$seasonal.period <-
          validateInput("seasonal.period", seasonal.period, "integer")
        self$seasonality.criterion <-
          validateInput("seasonality.criterion", seasonality.criterion, "double")
        self$d <- validateInput("d", d, "integer")
        self$kpss.significance.level <-
          validateInput("kpss.significance.level", kpss.significance.level, "double")
        self$max.d <- validateInput("max.d", max.d, "integer")
        self$seasonal.d <- validateInput("seasonal.d", seasonal.d, "integer")
        self$ch.significance.level <-
          validateInput("ch.significance.level", ch.significance.level, "double")
        self$max.seasonal.d <- validateInput("max.seasonal.d", max.seasonal.d, "integer")
        self$max.p <- validateInput("max.p", max.p, "integer")
        self$max.q <- validateInput("max.q", max.q, "integer")
        self$max.seasonal.p <- validateInput("max.seasonal.p", max.seasonal.p, "integer")
        self$max.seasonal.q <- validateInput("max.seasonal.q", max.seasonal.q, "integer")
        self$information.criterion <-
          validateInput("information.criterion", information.criterion, "integer")
        self$search.strategy <-
          validateInput("search.strategy", search.strategy, "integer")
        self$max.order <- validateInput("max.order", max.order, "integer")
        self$initial.p <- validateInput("initial.p", initial.p, "integer")
        self$initial.q <- validateInput("initial.q", initial.q, "integer")
        self$initial.seasonal.p <-
          validateInput("initial.seasonal.p", initial.seasonal.p, "integer")
        self$initial.seasonal.q <-
          validateInput("initial.seasonal.q", initial.seasonal.q, "integer")
        self$guess.states <- validateInput("guess.states", guess.states, "integer")
        self$max.search.iterations <-
          validateInput("max.search.iterations", max.search.iterations, "integer")
        self$method <- validateInput("method", method, self$method.map)
        self$allow.linear <- validateInput("allow.linear", allow.linear, c("numeric",
                                                                           "integer",
                                                                           "logical"))
        if (is.logical(self$allow.linear)) {
          self$allow.linear <- as.integer(self$allow.linear)
        }
        self$forecast.method <-
          validateInput("forecast.method", forecast.method, self$forecast.method.map)
        self$output.fitted <- validateInput("output.fitted", output.fitted, "logical")
        self$thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <-
          sprintf("#PAL_AUTO_ARIMA_PARAM_TBL_%s_%s", self$id, unique.id)#nolint
        model.tbl <-
          sprintf("#PAL_AUTO_ARIMA_MODEL_TBL_%s_%s", self$id, unique.id)#nolint
        fitted.tbl <-
          sprintf("#PAL_AUTO_ARIMA_TBL_%s_%s", self$id, unique.id)#nolint

        cols <- data$columns
        if (is.null(key)){
          key <- cols[[1]]
        }
        key <- validateInput("key", key, cols, case.sensitive = TRUE)

        cols <- cols[! cols %in% key]
        if (is.null(endog)){
          endog <- cols[[1]]
        }
        endog <- validateInput("endog", endog, cols, case.sensitive = TRUE)
        cols <- cols[! cols %in% endog]

        exog <- validateInput("exog", exog, cols, case.sensitive = TRUE)

        if (!inherits(data, "DataFrame") ) {
          msg <- "If training data is not omitted, it must be DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn.context <- data$connection.context
        self$conn.context <- conn.context
        selected <- list(key, endog)
        data <- data$Select(append(selected, exog))

        param.rows <- list(
          tuple("SEASONAL_PERIOD", self$seasonal.period, NULL, NULL),
          tuple("SEASONALITY_CRITERION", NULL, self$seasonality.criterion, NULL),
          tuple("D", self$d, NULL, NULL),
          tuple("KPSS_SIGNIFICANCE_LEVEL", NULL, self$kpss.significance.level, NULL),
          tuple("MAX_D", self$max.d, NULL, NULL),
          tuple("SEASONAL_D", self$seasonal.d, NULL, NULL),
          tuple("CH_SIGNIFICANCE_LEVEL", NULL, self$ch.significance.level, NULL),
          tuple("MAX_SEASONAL_D", self$max.seasonal.d, NULL, NULL),
          tuple("MAX_P", self$max.p, NULL, NULL),
          tuple("MAX_Q", self$max.q, NULL, NULL),
          tuple("MAX_SEASONAL_P", self$max.seasonal.p, NULL, NULL),
          tuple("MAX_SEASONAL_Q", self$max.seasonal.q, NULL, NULL),
          tuple("INFORMATION_CRITERION", self$information.criterion, NULL, NULL),
          tuple("SEARCH_STRATEGY", self$search.strategy, NULL, NULL),
          tuple("MAX_ORDER", self$max.order, NULL, NULL),
          tuple("INITIAL_P", self$initial.p, NULL, NULL),
          tuple("INITIAL_Q", self$initial.q, NULL, NULL),
          tuple("INITIAL_SEASONAL_P", self$initial.seasonal.p, NULL, NULL),
          tuple("INITIAL_SEASONAL_Q", self$initial.seasonal.q, NULL, NULL),
          tuple("GUESS_STATES", self$guess.states, NULL, NULL),
          tuple("MAX_SEARCH_ITERATIONS", self$max.search.iterations, NULL, NULL),
          tuple("METHOD", map.null(self$method, self$method.map), NULL, NULL),
          tuple("ALLOW_LINEAR", self$allow.linear, NULL, NULL),
          tuple("FORECAST_METHOD", map.null(self$forecast.method, self$forecast.method.map), NULL, NULL),
          tuple("OUTPUT_FITTED", to.integer(self$output.fitted), NULL, NULL),
          tuple("DEPENDENT_VARIABLE", NULL, NULL, endog)
        )

        tables <- list(param.tbl, model.tbl, fitted.tbl)
        in.tables <- list(data, param.tbl)
        out.tables <- list(model.tbl, fitted.tbl)
        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
                                            (ParameterTable$new(param.tbl))$WithData(param.rows))) #nolint
          errorhelper(CallPalAutoWithConnection(conn.context,
                                                "PAL_AUTOARIMA", in.tables, out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        self$model <- conn.context$table(model.tbl)
        self$fitted <- conn.context$table(fitted.tbl)
      }
    }
  )
)

#' @title Auto Autoregressive Integrated Moving Average
#' @name hanaml.AutoARIMA
#' @description hanaml.AutoARIMA is a R wrapper
#' for SAP HANA PAL Auto ARIMA algorithm.
#' @details The AUTO ARIMA function identifies the orders of an ARIMA model (p, d, q)(P, D, Q)m,
#' where m is the seasonal period according to some information criterion such as AICc,
#' AIC, and BIC. If order selection succeeds, the function gives the optimal model as in
#' the ARIMATRAIN function.
#' @seealso \code{\link{predict.AutoARIMA}}
#' @template args-data
#' @param     key \code{character, optional}\cr
#'            Name of the key. The type of key column is integer.\cr
#'            If not provide, defaults to the first column.
#' @template args-endog
#' @param     exog \code{list of character, optional}\cr
#'            An optional array of exogenous variables.
#'            Valid only for ARIMAX; cannot be the ID column's name
#'            and the name of \code{endog} column.\cr
#'            Defaults to NULL.
#' @param     seasonal.period \code{integer, optional}\cr
#'            Value of the seasonal period.\cr
#'            Negative: Automatically identify seasonality by means of auto-correlation scheme.\cr
#'            0 or 1: Non-seasonal.\cr
#'            Others: Seasonal period.\cr
#'            Defaults to -1.
#' @param     seasonality.criterion \code{double, optional}\cr
#'            The criterion of the auto-correlation coefficient for accepting seasonality,
#'            in the range of (0, 1). The larger it is, the less probable a time series is
#'            regarded to be seasonal.\cr
#'            Valid only when \code{seasonal.period} is negative.\cr
#'            Defaults to 0.2.
#' @param     d \code{integer, optional}\cr
#'            Order of first-differencing.\cr
#'            Others: Uses the specified value as the first-differencing order.\cr
#'            Negative: Automatically identifies first-differencing order with KPSS test.\cr
#'            Defaults to -1.
#' @param     kpss.significance.level \code{double, optional}\cr
#'            The significance level for KPSS test. Supported values are 0.01, 0.025, 0.05, and 0.1.
#'            The smaller it is, the larger probable a time series is considered as first-stationary,
#'            that is, the less probable it needs first-differencing.
#'            Valid only when \code{d} is negative.\cr
#'            Defaults to 0.05.
#' @param     max.d     \code{integer, optional}\cr
#'            The maximum value of d when KPSS test is applied.
#'            Defaults to 2.
#' @param     seasonal.d \code{integer, optional}\cr
#'            Order of seasonal-differencing.
#'            Negative: Automatically identifies seasonal-differencing order Canova-Hansen test.
#'            Others: Uses the specified value as the seasonal-differencing order.
#'            Defaults to -1.
#' @param     ch.significance.level \code{double, optional}\cr
#'            The significance level for Canova-Hansen test. Supported values are 0.01, 0.025,
#'            0.05, 0.1, and 0.2. The smaller it is, the larger probable a time series
#'            is considered seasonal-stationary,that is, the less probable it needs
#'            seasonal-differencing.\cr
#'            Valid only when \code{seasonal.d} is negative.\cr
#'            Defaults to 0.05.
#' @param     max.seasonal.d \code{integer, optional}\cr
#'            The maximum value of \code{seasonal.d} when Canova-Hansen test is applied.\cr
#'            Defaults to 1.
#' @param     max.p \code{integer, optional}\cr
#'            The maximum value of AR order p.\cr
#'            Defaults to 5.
#' @param     max.q \code{integer, optional}\cr
#'            The maximum value of MA order q.\cr
#'            Defaults to 5.
#' @param     max.seasonal.p \code{integer, optional}\cr
#'            The maximum value of SAR order P.\cr
#'            Defaults to 2.
#' @param     max.seasonal.q \code{integer, optional}\cr
#'            The maximum value of SMA order Q.\cr
#'            Defaults to 2.
#' @param     information.criterion \code{integer, optional}\cr
#'            The information criterion for order selection:\cr
#'            0: AICC\cr
#'            1: AIC\cr
#'            2: BIC.\cr
#'            Defaults to 0.
#' @param     search.strategy \code{integer, optional}\cr
#'            The search strategy for optimal ARMA model.\cr
#'            0: Exhaustive traverse\cr
#'            1: Stepwise traverse.\cr
#'            Defaults to 1.
#' @param     max.order \code{integer, optional}\cr
#'            The maximum value of \code{max.p} + \code{max.q} + \code{max.seasonal.p} +
#'            \code{max.seasonal.q}. Valid only when \code{search.strategy} is 0.\cr
#'            Defaults to 15.
#' @param     initial.p \code{integer, optional}\cr
#'            Initial value of \code{p}. Valid only when \code{search.strategy} is 1.\cr
#'            Defaults to 0.
#' @param     initial.q \code{integer, optional}\cr
#'            Initial value of \code{q}. Valid only when \code{search.strategy} is 1.\cr
#'            Defaults to 0.
#' @param     initial.seasonal.p \code{integer, optional}\cr
#'            Initial value of \code{seasonal.p}.\cr
#'            Valid only when \code{search.strategy} is 1.\cr
#'            Defaults to 0.
#' @param     initial.seasonal.q \code{integer, optional}\cr
#'            Initial value of \code{seasonal.q}.\cr
#'            Valid only when \code{search.strategy} is 1.\cr
#'            Defaults to 0.
#' @param     guess.states \code{integer, optional}\cr
#'            If employing ACF/PACF to guess initial ARMA models, besides user-defined model:\cr
#'            0: No guess. Besides user-defined model, uses states (2, 2) (1, 1)m, (1, 0) (1, 0)m,
#'               and (0, 1) (0, 1)m meanwhile as starting states.\cr
#'            1: Guesses starting states taking advantage of ACF/PACF.\cr
#'            Valid only when \code{search.strategy} is 1.\cr
#'            Defaults to 1.
#' @param     max.search.iterations \code{integer, optional}\cr
#'            The maximum iterations for searching optimal ARMA states.\cr
#'            Valid only when \code{search.strategy} is 1.\cr
#'            Defaults to (\code{max.p} + 1) * (\code{max.q} + 1) *
#'            (\code{max.seasonal.p} + 1) * (\code{max.seasonal.q} + 1).
#' @param     method \code{{"css", "mle", "css-mle"}, optional}\cr
#'            The object function for numeric optimization.
#'            \itemize{
#'                    \item{\code{"css":} use the conditional sum of squares. }
#'                    \item{\code{"mle":} use the maximized likelihood estimation.}
#'                    \item{\code{"css-mle":} use css to approximate starting values and mle to fit.}
#'            }\cr
#'            Defaults to "css-mle".
#' @param     allow.linear \code{integer or logical, optional}\cr
#'            Controls whether to check linear model ARMA (0, 0) (0, 0)m.\cr
#'            0 or FALSE: No\cr
#'            1 or TRUE: Yes\cr
#'            Defaults to 1.
#' @param     forecast.method \code{{"formula.forecast", "innovations.algorithm"}, optional}\cr
#'            Store information for the subsequent forecast method.
#'            \itemize{
#'                    \item{\code{"formula.forecast":} compute future series via formula. }
#'                    \item{\code{"innovations.algorithm":} apply innovations algorithm to compute future
#'                          series, which requires more original information to be stored}
#'            }\cr
#'            Defaults to "innovations.algorithm".
#' @param     output.fitted \code{logical, optional}\cr
#'            Output fitted result and residuals if TRUE.\cr
#'            Defaults to TRUE.
#' @template args-threadratio
#' @return
#' Returns an "AutoARIMA" object with the following attributes:
#' \itemize{
#' \item{model: \code{DataFrame}}\cr
#'      Fitted model.
#' \item{fitted: \code{DataFrame}}\cr
#'      Predicted dependent variable values for training data.
#'      Set to NULL if the training data has no row IDs.
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'   TIMESTAMP       Y
#' 1         1 -24.525
#' 2         2  34.720
#' 3         3  57.325
#' 4         4  10.340
#' 5         5 -12.890
#' ......
#' }
#' Invoke the function:
#' \preformatted{
#' > autoarima <- hanaml.AutoARIMA(data = data, search.strategy = 1)
#' }
#' Output:
#' \preformatted{
#' > autoarima$fitted
#'     TIMESTAMP      FITTED   RESIDUALS
#' 1           1          NA          NA
#' 2           2          NA          NA
#' 3           3          NA          NA
#' 4           4          NA          NA
#' 5           5 -24.5250000 11.63500000
#' 6           6  37.5839311  1.46106885
#' 7           7  57.9926243 -0.69262431
#' 8           8   8.6228706 -1.88787060
#' 9           9 -20.3259208  0.96092077
#  .......
#' }
#' @keywords TimeSeries
#' @export
hanaml.AutoARIMA <- function(data = NULL,
                             key = NULL,
                             endog = NULL,
                             exog = NULL,
                             seasonal.period = NULL,
                             seasonality.criterion = NULL,
                             d = NULL,
                             kpss.significance.level = NULL,
                             max.d = NULL,
                             seasonal.d = NULL,
                             ch.significance.level = NULL,
                             max.seasonal.d = NULL,
                             max.p = NULL,
                             max.q = NULL,
                             max.seasonal.p = NULL,
                             max.seasonal.q = NULL,
                             information.criterion = NULL,
                             search.strategy = NULL,
                             max.order = NULL,
                             initial.p = NULL,
                             initial.q = NULL,
                             initial.seasonal.p = NULL,
                             initial.seasonal.q = NULL,
                             guess.states = NULL,
                             max.search.iterations = NULL,
                             method = NULL,
                             allow.linear = NULL,
                             forecast.method = NULL,
                             output.fitted = NULL,
                             thread.ratio = NULL) {
  AutoARIMA$new(data,
                key,
                endog,
                exog,
                seasonal.period,
                seasonality.criterion,
                d,
                kpss.significance.level,
                max.d,
                seasonal.d,
                ch.significance.level,
                max.seasonal.d,
                max.p,
                max.q,
                max.seasonal.p,
                max.seasonal.q,
                information.criterion,
                search.strategy,
                max.order,
                initial.p,
                initial.q,
                initial.seasonal.p,
                initial.seasonal.q,
                guess.states,
                max.search.iterations,
                method,
                allow.linear,
                forecast.method,
                output.fitted,
                thread.ratio)
}


#' @title Make Predictions from a "AutoARIMA" Object
#' @name predict.AutoARIMA
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "AutoARIMA" object.
#' @seealso \code{\link{hanaml.AutoARIMA}}
#' @format \code{\link{S3}} methods
#' @param     model \code{R6Class object}\cr
#'            An "AutoARIMA" object for prediction.
#' @param     data \code{DataFrame, optional}\cr
#'            Includes the ID column and external Data (exogeneous variables) for prediction.\cr
#'            Defaults to NULL.
#' @param     key \code{character, optional}\cr
#'            Name of the key in the data. \cr
#'            Defaults to NULL and if data is not NULL and key is not provided, defaults to the first column.
#' @param     forecast.method \code{c("formula.forecast", "innovations.algorithm"), optional}\cr
#' Store information for the subsequent forecast method.
#' \itemize{
#'   \item{\code{"formula.forecast":} compute future series via formula. }
#'   \item{\code{"innovations.algorithm":} apply innovations algorithm to compute future
#'         series, which requires more original information to be stored}
#' }
#' Defaults to "innovations.algorithm".
#' @param     forecast.length \code{integer, optional}\cr
#'            Number of points to forecast. \cr
#'            Defaults to 1.
#' @param     ... Reserved parameter.
#' @return
#' Predicted values are returned as a DataFrame, structured as follows:
#' \itemize{
#'  \item{\code{ID}: with same name and type the ID column of \code{data}.}
#'  \item{\code{FORECAST}: type DOUBLE, representing predicted values.}
#'  \item{\code{SE}: type DOUBLE, standard error.}
#'  \item{\code{LO80}: type DOUBLE, low 80\% values.}
#'  \item{\code{HI80}: type DOUBLE, high 80\% values.}
#'  \item{\code{LO95}: type DOUBLE, low 95\% values.}
#'  \item{\code{HI95}: type DOUBLE, high 95\% values.}
#' }
#' @section Examples:
#' Call the function and obtain the result:
#' \preformatted{
#' > predict(model = autoarima, forecast.length = 5)
#'   TIMESTAMP   FORECAST       SE       LO80      HI80        LO95      HI95
#' 1         0 -15.544832 3.298697 -19.772283 -11.31738 -22.0101587 -9.079505
#' 2         1  35.587390 3.404891  31.223846  39.95094  28.9139269 42.260854
#' 3         2  56.498532 3.411723  52.126231  60.87083  49.8116773 63.185386
#' 4         3   7.086176 3.412170   2.713303  11.45905   0.3984467 13.773906
#' 5         4 -16.266996 3.412250 -20.639972 -11.89402 -22.9548838 -9.579108
#' }
#' @keywords TimeSeries
#' @export
predict.AutoARIMA <- function(model,
                              data = NULL,
                              key = NULL,
                              forecast.method = NULL,
                              forecast.length = NULL,
                              ...){
  return(predict.ARIMA(model,
                       data,
                       key,
                       forecast.method,
                       forecast.length,
                       ...))
}


#' @title Accuracy Measure
#' @name hanaml.AccuracyMeasure
#' @description hanaml.AccuracyMeasure is a R wrapper
#' for SAP HANA PAL accuracy measure algorithm.
#' @details Measures are used to check the accuracy of the forecast made by SAP HANA PAL algorithms.
#' @param      data \code{DataFrame}\cr
#' DataFrame containing the data for accuracy measure calculations.\cr
#' It needs to contain two columns that correspond to true
#' values and predicted values, respectively.
#' @param evaluation.metric \code{character or list of characters, optional}\cr
#' Specifies measure name.
#' \itemize{
#'    \item{\code{"mpe"}:   Mean percentage error.}
#'    \item{\code{"mse"}:   Mean squared error.}
#'    \item{\code{"rmse"}:  Root mean squared error.}
#'    \item{\code{"et"}:    Error total.}
#'    \item{\code{"mad"}:   Mean absolute deviation.}
#'    \item{\code{"mase"}:  Out-of-sample mean absolute scaled error.}
#'    \item{\code{"wmape"}: Weighted mean absolute percentage error.}
#'    \item{\code{"smape"}: Symmetric mean absolute percentage error.}
#'    \item{\code{"mape"}:  Mean absolute percentage error.}
#'    }
#' @return
#' \itemize{
#'   \item{\code{DataFrame}}\cr
#'    Results of the forecast accuracy measurement, structured as follows:\cr
#'    \itemize{
#'    \item{\code{STAT_NAME}:   name of the accuracy measures.}
#'    \item{\code{STAT_VALUE}:  values of the accuracy measures.}
#'    }
#' }
#' @section Examples:
#' Input dataFrame data:
#' \preformatted{
#' > data$Collect()
#'   ACTUALCOL FORECASTCOL
#' 1      1130        1270
#' 2      2410        2340
#' 3      2210        2310
#' 4      2500        2340
#' }
#' Invoke the function:
#' \preformatted{
#' > am <- hanaml.AccuracyMeasure(data,
#'                                evaluation.metric = list("mse","mpe"))
#' }
#' Output:
#' \preformatted{
#' > am$Collect()
#'   STAT_NAME    STAT_VALUE
#' 1       MPE -1.902426e-02
#' 2       MSE  1.502500e+04
#' }
#' @keywords TimeSeries
#' @export
hanaml.AccuracyMeasure <- function(data,
                                   evaluation.metric) {
  evaluation.metric.map <- list(
    mpe = "MPE",
    mse = "MSE",
    rmse = "RMSE",
    et = "ET",
    mad = "MAD",
    mase = "MASE",
    wmape = "WMAPE",
    smape = "SMAPE",
    mape = "MAPE"
  )
  evaluation.metric <-
    validateInput("evaluation.metric",
                  evaluation.metric,
                  evaluation.metric.map,
                  required = TRUE)

  if (!inherits(data, "DataFrame")) {
    msg <- "Input data must be DataFrame."
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn.context <- data$connection.context
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_AM_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_AM_RESULT_TBL_%s", unique.id)

  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl)
  tables <- list(param.tbl, result.tbl)
  param.array <- list()
  for (measure in evaluation.metric) {
    param.array <-
      append(param.array, list(tuple(
        "MEASURE_NAME",
        NULL, NULL,
        map.null(measure, evaluation.metric.map)
      )))
  }
  tryCatch({
    errorhelper(CreateTWithConnection(
      conn.context,
      ParameterTable$new(param.tbl)$WithData(param.array)
    ))
    errorhelper(
      CallPalAutoWithConnection(
        conn.context,
        "PAL_ACCURACY_MEASURES",
        in.tables,
        out.tables
      )
    )
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn.context, tables)
    stop(msg)
  })
  return(conn.context$table(result.tbl))
}

#' @title Linear Regression with Damped Trend and Seasonal Adjust
#' @name hanaml.LRSeasonalAdjust
#' @description hanaml.LRSeasonalAdjust is a R wrapper for SAP HANA PAL
#' Linear regression with damped trend and seasonal adjust.
#' @template args-data
#' @template args-key
#' @template args-endog
#' @param forecast.length \code{integer, optional}\cr
#' Length of the final forecast results.\cr
#' Defaults to 1.
#' @param trend \code{double, optional}\cr
#' Damped trend factor. Value range is (0,1]. \cr
#' Defaults to 1.
#' @param affect.future.only \code{logical, optional}\cr
#' Specifies whether the damped trend affects the history.
#' \itemize{
#'    \item{\code{FALSE}: Affects all.}
#'    \item{\code{TRUE}:  Affects the future only.}
#' }
#' Defaults to TRUE.
#' @param seasonality \code{integer, optional}\cr
#' Specifies whether the data represents seasonality.
#' \itemize{
#'    \item{\code{0}: Non-seasonality.}
#'    \item{\code{1}: Seasonality exists and user inputs the value of periods.}
#'    \item{\code{2}: Automatically detects seasonality.}
#' }
#' Defaults to 0.
#' @param seasonal.period \code{integer, optional}\cr
#' Length of seasonal period. \code{seasonal.period} is only valid when seasonality is 1.\cr
#' If this parameter is not specified, the seasonality value will be changed from 1 to 2,
#' that is, from user-defined to automatically-detected.\cr
#' No default value.
#' @param accuracy.measure \code{character or list of character, optional}\cr
#' Specifies accuracy measure.The criterion used for the optimization.
#' \itemize{
#'    \item{\code{mpe}:   Mean percentage error.}
#'    \item{\code{mse}:   Mean squared error.}
#'    \item{\code{rmse}:  Root mean squared error.}
#'    \item{\code{et}:    Error total.}
#'    \item{\code{mad}:   Mean absolute deviation.}
#'    \item{\code{mase}:  Out-of-sample mean absolute scaled error.}
#'    \item{\code{wmape}: Weighted mean absolute percentage error.}
#'    \item{\code{smape}: Symmetric mean absolute percentage error.}
#'    \item{\code{mape}:  Mean absolute percentage error.}
#'    }
#' No default value.
#' @param seasonal.handle.method \code{character, optional}\cr
#' Method used for calculating the index value in the seasonal_period.
#' \itemize{
#'    \item{\code{"average"}: Average method.}
#'    \item{\code{"lr"}: Fitting linear regression.}
#' }
#' Defaults to 'average'.
#' @param expost.flag \code{logical, optional}\cr
#' \itemize{
#'    \item{\code{FALSE}: Does not output the expost forecast, and just outputs the forecast values.}
#'    \item{\code{TRUE}: Outputs the expost forecast and the forecast values.}
#' }
#' Defaults to TRUE.
#' @param ignore.zero \code{logical, optional}\cr
#' \itemize{
#'    \item{\code{FALSE}: Uses zero values in the input dataset when calculating 'mpe' or 'mape'.}
#'    \item{\code{TRUE}: Ignores zero values in the input dataset when calculating 'mpe' or 'mape'.}
#' }
#' Defaults to FALSE.
#' @return
#' Returns a list of two DataFrames:
#' \itemize{
#'   \item{\code{DataFrame 1}\cr}
#'   Forecast values.
#'   \item{\code{DataFrame 2}\cr}
#'   Statistics analysis content.}
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'   TIMESTAMP         Y
#' 1         1  5328.172
#' 2         2  7701.608
#' 3         3 11248.606
#' 4         4  9478.945
#' 5         5  6138.471
#' 6         6  8829.956
#' 7         7  2838.390
#' }
#' Invoke the function:
#' \preformatted{
#' > lr <- hanaml.LRSeasonalAdjust(data,
#'                                 key = "TIMESTAMP",
#'                                 endog = "Y",
#'                                 forecast.length = 1,
#'                                 trend = 0.9,
#'                                 affect.future.only = TRUE,
#'                                 seasonality = 2,
#'                                 seasonal.handle.method = "lr",
#'                                 accuracy.measure =  list("mape","mpe"),
#'                                 expost.flag = TRUE,
#'                                 ignore.zero = TRUE)
#' }
#' Ouput:
#' \preformatted{
#' > lr[[1]]$Collect()
#'   TIMESTAMP    VALUE
#' 1         1 8472.320
#' 2         2 8103.649
#' 3         3 7734.978
#' 4         4 7366.307
#' 5         5 6997.636
#' 6         6 6628.965
#' 7         7 6260.294
#' 8         8 5928.490
#'
#' > lr[[2]]$Collect()
#'    STAT_NAME   STAT_VALUE
#' 1  Intercept 8840.9904286
#' 2      Slope -368.6708929
#' 3       MAPE    0.3960495
#' 4        MPE   -0.1719060
#' 5 HandleZero    0.0000000
#' }
#' @keywords TimeSeries
#' @export
hanaml.LRSeasonalAdjust <- function(data,
                                    key,
                                    endog = NULL,
                                    forecast.length = NULL,
                                    trend = NULL,
                                    affect.future.only = NULL,
                                    seasonality = NULL,
                                    seasonal.period = NULL,
                                    accuracy.measure = NULL,
                                    seasonal.handle.method = NULL,
                                    expost.flag = NULL,
                                    ignore.zero = NULL) {
  accuracy.measure.map  <- list(
    "mpe" = "MPE",
    "mse" = "MSE",
    "rmse" = "RMSE",
    "et" = "ET",
    "mad" = "MAD",
    "mase" = "MASE",
    "wmape" = "WMAPE",
    "smape" = "SMAPE",
    "mape" = "MAPE")
  seasonal.handle.method.map <- list("average" = 0, "lr" = 1)
  forecast.length <- validateInput("forecast.length", forecast.length, "integer")
  trend <- validateInput("trend", trend, "double")
  affect.future.only <- validateInput("affect.future.only",
                                      affect.future.only,
                                      "logical")
  seasonality <- validateInput("seasonality", seasonality, "integer")
  seasonal.period <- validateInput("seasonal.period", seasonal.period, "integer")
  accuracy.measure <-
    validateInput("accuracy.measure", accuracy.measure, accuracy.measure.map)
  seasonal.handle.method <-
    validateInput(
      "seasonal.handle.method",
      seasonal.handle.method,
      seasonal.handle.method.map
    )
  expost.flag <- validateInput("expost.flag", expost.flag, "logical")
  ignore.zero <- validateInput("ignore.zero", ignore.zero, "logical")

  measure.list <-  list("mpe", "mape")
  if ( (!is.null(ignore.zero) ) &&
       (!(accuracy.measure %in% measure.list)) ) {
    msg <- paste("Please select accuracy.measure from",
                 "'mpe' and 'mape' when ignore.zero is not NULL!")
    flog.error(msg)
    stop(msg)
  }

  if (!is.null(trend)){
    if ( (trend < 0) || (trend > 1) ) {
      error.msg <- "Trend should be in the interval [0,1]!"
      flog.error(error.msg)
      stop(error.msg)
    }
  }

  if (!is.null(seasonality)){
    if (! seasonality %in% c(0, 1, 2)){
      msg <- "seasonality must be selected from 0, 1, and 2!"
      flog.error(msg)
      stop(msg)
    }
  }

  if ( (seasonality != 1) &&
       (!is.null(seasonal.period)) ) {
    msg <- "seasonal.period is only valid when seasonality is 1!"
    flog.error(msg)
    stop(msg)
  }

  if ( (seasonality != 2) &&
       (!is.null(seasonal.handle.method)) ) {
    msg <- "seasonal.handle.method is only valid when seasonality is 2!"
    flog.error(msg)
    stop(msg)
  }

  cols <- data$columns
  key <- validateInput("key", key, cols, required = TRUE, case.sensitive = TRUE)
  cols <- cols[!cols %in% key]
  endog <- validateInput("endog", endog, cols, case.sensitive = TRUE)
  if (is.null(endog)) {
    endog <- cols[[1]]
  }

  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as DataFrame."
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn.context <- data$connection.context
  data <- data$Select(list(key, endog))
  param.array <-
    list(
      tuple("FORECAST_LENGTH", forecast.length, NULL, NULL),
      tuple("TREND", NULL, trend, NULL),
      tuple(
        "AFFECT_FUTURE_ONLY",
        to.integer(affect.future.only),
        NULL, NULL
      ),
      tuple("SEASONALITY", seasonality, NULL, NULL),
      tuple("PERIODS", seasonal.period, NULL, NULL),
      tuple(
        "SEASONAL_HANDLE_METHOD",
        map.null( seasonal.handle.method, seasonal.handle.method.map),
        NULL, NULL
      ),
      tuple("IGNORE_ZERO", to.integer(ignore.zero), NULL, NULL),
      tuple("EXPOST_FLAG", to.integer(expost.flag), NULL, NULL)
    )
  if (length(accuracy.measure) > 0){
    for (measure in accuracy.measure){
      param.array <- append(param.array,
                            list(tuple("MEASURE_NAME", NULL, NULL,
                                       accuracy.measure.map[[measure]])))
    }
  }
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_LR_SEASONAL_ADJUST_PARAM_TBL_%s", unique.id)
  forecast.tbl <- sprintf("#PAL_LR_SEASONAL_ADJUST_DETRENDED_TBL_%s", unique.id)
  statistic.tbl <- sprintf("#PAL_LR_SEASONAL_ADJUST_STATISTIC_TBL_%s", unique.id)

  in.tables <- list(data, param.tbl)
  out.tables <- list(forecast.tbl, statistic.tbl)
  tables <- list(param.tbl, forecast.tbl, statistic.tbl)

  tryCatch({
    errorhelper(CreateTWithConnection(conn.context,
      ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn.context,
                                          "PAL_LR_SEASONAL_ADJUST",
                                          in.tables, out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn.context, tables)
    stop(msg)
  })
  conn <- conn.context
  return(list(conn$table(forecast.tbl),
              conn$table(statistic.tbl)))
}

#' @title White Noise Test
#' @name hanaml.WhiteNoiseTest
#' @description hanaml.WhiteNoiseTest is a R wrapper for SAP HANA PAL white noise test.
#' @details    hanaml.WhiteNoiseTest is used to identify whether a time series is a white noise series.
#' If white noise exists in the raw time series, the algorithm returns the value of 1.
#' If not, the value of 0 will be returned.
#' @template args-data
#' @template args-key-first
#' @template args-endog
#' @param     lag \code{integer, optional} \cr
#'            Specifies the lag autocorrelation coefficient that the statistic will be based on.
#'            It corresponds to the degree of freedom of chi-square distribution.\cr
#'            Defaults to half of the sample size (n/2).
#' @param     probability \code{double, optional} \cr
#'            The confidence level used for chi-square distribution.
#'            The value is 1 - a, where a is the significance level.\cr
#'            Defaults to 0.9.
#' @template args-threadratio-1
#'
#' @return
#' \code{DataFrame}
#'    Result of the forecast accuracy measurement, structured as follows:\cr
#'    \itemize{
#'    \item{\code{STAT_NAME}}:   name of the accuracy measures.
#'    \item{\code{STAT_VALUE}}:  values of the accuracy measures
#'    \itemize{
#'      \item{WN}: 1 for white noise, 0 for not white noise.
#'      \item{Q}: Q statistics defined as above.
#'      \item{chi^2}: chi-square distribution.
#'    }
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'   TIMESTAMP    Y
#' 1         0 1474
#' 2         1 1356
#' 3         2  826
#' 4         3 1586
#' 5         4 1010
#' 6         5 1337
#' 7         6 1415
#' 8         7 1514
#' }
#' Invoke the function:
#' \preformatted{
#' > wn <- hanaml.WhiteNoiseTest(data,
#'                               key = "TIMESTAMP",
#'                               endog = "Y",
#'                               lag = 3,
#'                               probability = 0.9,
#'                               thread.ratio = 0.2)
#' }
#' Output:
#' \preformatted{
#' > wn$Collect()
#'   STAT_NAME STAT_VALUE
#' 1        WN   1.000000
#' 2         Q   2.469041
#' 3     chi^2   6.251389
#' }
#' @keywords TimeSeries
#' @export
hanaml.WhiteNoiseTest <- function(data,
                                  key = NULL,
                                  endog = NULL,
                                  lag = NULL,
                                  probability = NULL,
                                  thread.ratio = NULL) {
  lag <- validateInput("lag", lag, "integer")
  probability <- validateInput("probability", probability, "double")
  thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
  cols <- data$columns
  if (length(cols) < 2) {
    msg <- paste("Input data should contain at least 2 columns:",
                 "one for ID, another for raw data.")
    flog.error(msg)
    stop(msg)
  }
  key <- validateInput("key", key, cols, case.sensitive = TRUE)
  if (is.null(key)) {
    key <- cols[[1]]
  }
  cols <- cols[!cols %in% key]
  endog <- validateInput("endog", endog, cols, case.sensitive = TRUE)
  if (is.null(endog)) {
    endog <- cols[[1]]
  }

  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn.context <- data$connection.context
  data <- data$Select(list(key, endog))
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_WN_TEST_PARAM_TBL_%s", unique.id)
  statistic.tbl <- sprintf("#PAL_WN_TEST_STATISTIC_TBL_%s", unique.id)
  in.tables <- list(data, param.tbl)
  out.tables <- list(statistic.tbl)
  tables <- list(param.tbl, statistic.tbl)
  param.array <-
    list(
      tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
      tuple("PROBABILITY", NULL, probability, NULL),
      tuple("LAG", lag, NULL, NULL)
    )
  tryCatch({
    errorhelper(CreateTWithConnection(conn.context,
          ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn.context, "PAL_WN_TEST",
                                          in.tables, out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn.context, tables)
    stop(msg)
  })
  return(conn.context$table(statistic.tbl))
}

#' @title Trend Test
#' @name hanaml.TrendTest
#' @description hanaml.TrendTest is a R wrapper for SAP HANA PAL Trend Test.
#' @template args-data
#' @template args-key-first
#' @template args-endog
#' @param     method \code{character, optional}\cr
#'            The method used to identify trend.
#' \itemize{
#'    \item{\code{'mk'}: Mann-Kendall test.}
#'    \item{\code{'difference.sign'}:  Difference-sign test.}
#' }
#' Defaults to 'mk'.
#' @param alpha \code{double, optional}\cr
#' Significance value. The value range is (0, 0.5).\cr
#' Defaults to 0.05.
#' @return
#' Returns a list of DataFrame:
#' \itemize{
#'   \item{\code{DataFrame 1 }\cr}
#'    Statistics for time series.\cr
#'   \item{\code{DataFrame 2 }\cr}
#'    De-trended table, structured as follows:\cr
#'    \itemize{
#'        \item{\code{ID}: Time stamp that is monotonically increasing sorted.}
#'        \item{\code{DETRENDED_SERIES}: The corresponding de-trended time series.}
#'    }
#'    The first value absents if trend presents. \cr
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    TIMESTAMP    Y
#' 1          1 1500
#' 2          2 1510
#' 3          3 1550
#' 4          4 1650
#' 5          5 1620
#' 6          6 1690
#' 7          7 1695
#' 8          8 1700
#' 9          9 1710
#' 10        10 1705
#' 11        11 1708
#' 12        12 1715
#' }
#' Invoke the function:
#' \preformatted{
#' > tt <- hanaml.TrendTest(data,
#'                          method="mk",
#'                          alpha = 0.05)
#' }
#' Output:
#' \preformatted{
#' > tt[[1]]$Collect()
#'   STAT_NAME   STAT_VALUE
#' 1     TREND 1.000000e+00
#' 2         S 6.000000e+01
#' 3   P-VALUE 5.214912e-05
#'
#' > tt[[2]]$Collect()
#'    TIMESTAMP DETRENDED_SERIES
#' 1          2               10
#' 2          3               40
#' 3          4              100
#' 4          5              -30
#' 5          6               70
#' 6          7                5
#' 7          8                5
#' 8          9               10
#' 9         10               -5
#' 10        11                3
#' 11        12                7
#' }
#' @keywords TimeSeries
#' @export
hanaml.TrendTest <- function(data,
                             key = NULL,
                             endog = NULL,
                             method = NULL,
                             alpha = NULL) {
  method.map <- list("mk" = 1, "difference-sign" = 2)
  method <- validateInput("method", method, method.map)
  alpha <- validateInput("alpha", alpha, "double")

  cols <- data$columns
  if (length(cols) < 2) {
    msg <- paste("Input data should contain at least 2 columns:",
                 "one for ID, another for raw data.")
    flog.error(msg)
    stop(msg)
  }

  key <- validateInput("key", key, cols, case.sensitive = TRUE)
  if (is.null(key)) {
    key <- cols[[1]]
  }
  cols <- cols[!cols %in% key]
  endog <- validateInput("endog", endog, cols, case.sensitive = TRUE)
  if (is.null(endog)) {
    endog <- cols[[1]]
  }

  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn.context <- data$connection.context
  data <- data$Select(list(key, endog))
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_TT_PARAM_TBL_%s", unique.id)
  detrended.tbl <- sprintf("#PAL_TT_DETRENDED_TBL_%s", unique.id)
  statistic.tbl <- sprintf("#PAL_TT_STATISTIC_TBL_%s", unique.id)

  in.tables <- list(data, param.tbl)
  out.tables <- list(detrended.tbl, statistic.tbl)
  tables <- list(param.tbl, detrended.tbl, statistic.tbl)
  param.array <-
    list(tuple("METHOD", map.null(method, method.map), NULL, NULL),
         tuple("ALPHA", NULL, alpha, NULL))
  tryCatch({
    errorhelper(CreateTWithConnection(
      conn.context,
      ParameterTable$new(param.tbl)$WithData(param.array)
    ))
    errorhelper(
      CallPalAutoWithConnection(conn.context, "PAL_TREND_TEST",
                                in.tables, out.tables)
    )
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn.context, tables)
    stop(msg)
  })
  return(list(
    conn.context$table(detrended.tbl),
    conn.context$table(statistic.tbl)
  ))
}

#' @title Seasonality Test
#' @name hanaml.SeasonalDecompose
#' @description hanaml.SeasonalDecompose is a R wrapper for SAP HANA PAL seasonality test.
#' @template args-data
#' @template args-key-first
#' @template args-endog
#' @template args-threadratio-1
#' @param alpha \code{double, optional}\cr
#' The criterion for the autocorrelation coefficient.
#' The value range is (0, 1). A larger value indicates stricter requirement for seasonality.\cr
#' Defaults to 0.2.
#' @param extrapolation \code{logical, optional}\cr
#'    Specifies whether to extrapolate the endpoints.
#'    Set to 1 when there’s an end-point issue.\cr
#'    A new parameter added in SAP HANA SPS05 and Cloud.\cr
#'    Defaults to FALSE.
#' @param smooth.width \code{integer, optional}\cr
#'    Specifies the width of the moving average applied to non-seasonal data.
#'    0 indicates linear fitting to extract trends. Can not be larger than half of the data length.\cr
#'    A new parameter added in SAP HANA SPS05 and Cloud.\cr
#'    Defaults to 0.
#' @param auxiliary.normalitytest \code{logical, optional}\cr
#'    Specifies whether to use normality test to identify model types.\cr
#'    Defaults to FALSE.
#'
#' @return
#' Returns a list of DataFrame:
#' \itemize{
#'   \item{\code{DataFrame 1}}\cr
#'    Statistics for time series, structured as follows: \cr
#'    \itemize{
#'    \item{\code{STAT_NAME}: includes type (additive or multiplicative), period (number of seasonality),
#'                            acf (autocorrelation coefficient).\cr
#'    \item{\code{STAT_VALUE}:value of stats above.}
#'    }}
#'    \item{\code{DataFrame 2}}\cr
#'    Seasonal decomposition table, structured as follows::\cr
#'          \itemize{
#'          \item{\code{ID}: index/time stamp..}
#'          \item{\code{SEASONAL}: seasonality component.}
#'          \item{\code{TREND}: trend component.}
#'          \item{\code{RANDOM}: white noise component.}
#'          }
#' }
#'
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    TIMESTAMP    Y
#' 1          1   10
#' 2          2    7
#' 3          3   17
#' 4          4   34
#' 5          5    9
#' ......
#' 31        31   83
#' 32        32   55
#' 33        33  207
#' 34        34   25
#' 35        35    0
#' 36        36    0
#' }
#' Invoke the function:
#' \preformatted{
#' > sd <- hanaml.SeasonalDecompose(data,
#'                                  thread.ratio = 0.5,
#'                                  alpha = 0.2)
#' }
#' Output:
#' \preformatted{
#' > sd[[1]]$Collect()
#'   STAT_NAME     STAT_VALUE
#' 1      type multiplicative
#' 2    period              4
#' 3       acf       0.501947
#'
#' > sd[[2]]$Collect()
#'    TIMESTAMP  SEASONAL   TREND    RANDOM
#' 1          1 1.2526605  10.125 0.7884453
#' 2          2 0.3499516  14.000 1.4287688
#' 3          3 0.7488509  16.875 1.3452711
#' 4          4 1.6485370  16.750 1.2313043
#' ......
#' 33        33 1.2526605  82.125 2.0121557
#' 34        34 0.3499516  64.875 1.1011706
#' 35        35 0.7488509  32.125 0.0000000
#' 36        36 1.6485370   3.125 0.0000000
#' }
#' @keywords TimeSeries
#' @export
hanaml.SeasonalDecompose <- function(data,
                                     key = NULL,
                                     endog = NULL,
                                     alpha = NULL,
                                     thread.ratio = NULL,
                                     extrapolation = NULL,
                                     smooth.width = NULL,
                                     auxiliary.normalitytest = NULL) {
  alpha <- validateInput("alpha", alpha, "double")
  thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
  extrapolation <- validateInput("extrapolation", extrapolation, "logical")
  smooth.width <- validateInput("smooth.width", smooth.width, "integer")
  auxiliary.normalitytest <- validateInput("auxiliary.normalitytest",
                                           auxiliary.normalitytest, "logical")

  cols <- data$columns
  if (length(cols) < 2) {
    msg <- paste("Input data should contain at least 2 columns:",
                 "one for ID, another for raw data.")
    flog.error(msg)
    stop(msg)
  }

  key <- validateInput("key", key, cols, case.sensitive = TRUE)
  if (is.null(key)) {
    key <- cols[[1]]
  }
  cols <- cols[!cols %in% key]
  endog <- validateInput("endog", endog, cols, case.sensitive = TRUE)
  if (is.null(endog)) {
    endog <- cols[[1]]
  }

  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn.context <- data$connection.context
  data <- data$Select(list(key, endog))
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_SD_PARAM_TBL_%s", unique.id)
  stats.tbl <- sprintf("#PAL_SD_STATS_TBL_%s", unique.id)
  decompose.tbl <- sprintf("#PAL_SD_DECOMPOSE_TBL_%s", unique.id)

  in.tables <- list(data, param.tbl)
  out.tables <- list(stats.tbl, decompose.tbl)
  tables <- list(param.tbl, stats.tbl, decompose.tbl)
  param.array <-
    list(tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
         tuple("ALPHA", NULL, alpha, NULL),
         tuple("EXTRAPOLATION", to.integer(extrapolation), NULL, NULL),
         tuple("SMOOTH_WIDTH", smooth.width, NULL, NULL),
         tuple("AUXILIARY_NORMALITYTEST", to.integer(auxiliary.normalitytest), NULL, NULL))

  tryCatch({
    errorhelper(CreateTWithConnection(
      conn.context,
      ParameterTable$new(param.tbl)$WithData(param.array)
    ))
    errorhelper(
      CallPalAutoWithConnection(
        conn.context,
        "PAL_SEASONALITY_TEST",
        in.tables,
        out.tables
      )
    )
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn.context, tables)
    stop(msg)
  })
  return(list(conn.context$table(stats.tbl),
              conn.context$table(decompose.tbl)))
}

#' @title Correlation
#' @name hanaml.Correlation
#' @description hanaml.Correlation is a R wrapper for SAP HANA PAL correlation.
#' @template args-data
#' @template args-key
#' @param cols \code{list of character, optional}\cr
#' Specifies the columns in \code{data} for correlation calculation.
#' If only one column is specified, then the auto-correlation of that column
#' will be calculated.\cr
#' Defaults to the 1st non-ID column in \code{data}.
#' @template args-threadratio-1
#' @param method \code{("auto", "brute_force", "fft"), optional}\cr
#' Indicates the method to be used to calculate the correlation function.\cr
#' Defaults to 'auto', i.e. automatically determined.
#' @param max.lag \code{integer, optional}\cr
#' Maximum lag for the correlation function.\cr
#' Defaults to sqrt(n), where n is the data number.
#' @param calculate.pacf \code{logical, optional}\cr
#' Controls whether to calculate PACF or not.
#' Valid only when only one series is provided.\cr
#' Defaults to 1.
#' @return
#' \code{DataFrame}
#' \itemize{
#'   \item{LAG}: ID column.
#'   \item{CV}: ACV/CCV.
#'   \item{CF}: ACF/CCF.
#'   \item{PACF}: PACF. Null if cross-correlation is calculated.
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'     TIMESTAMP  Y
#'  1          1 88
#'  2          2 84
#'  3          3 85
#'  4          4 85
#'  5          5 84
#'  6          6 85
#'  7          7 83
#'  8          8 85
#'  9          9 88
#'  10         9 89
#' }
#' Invoke the function:
#' \preformatted{
#' > cr <- hanaml.Correlation(data,
#'                            key="TIMESTAMP",
#'                            cols = c("Y"),
#'                            thread.ratio = 0.4,
#'                            method = 'auto',
#'                            calculate.pacf = TRUE)
#' }
#' Output:
#' \preformatted{
#' > cr$Collect()
#'   LAG     CV          CF       PACF
#' 1   0  3.640  1.00000000  1.0000000
#' 2   1  0.924  0.25384615  0.2538462
#' 3   2 -0.292 -0.08021978 -0.1546211
#' 4   3 -0.628 -0.17252747 -0.1201993
#' }
#' @keywords TimeSeries
#' @export
hanaml.Correlation <- function(data,
                               key,
                               cols = NULL,
                               thread.ratio = NULL,
                               method = NULL,
                               max.lag = NULL,
                               calculate.pacf = NULL) {
  method.map <- list("auto" = -1,
                     "brute_force" = 0,
                     "fft" = 1)
  thread.ratio <-
    validateInput("thread.ratio", thread.ratio, "double")
  method <- validateInput("method", method, method.map)
  max.lag <- validateInput("max.lag", max.lag, "integer")
  calculate.pacf <- validateInput("calculate.pacf", calculate.pacf,
                                  "logical")
  data.cols <- data$columns
  key <- validateInput("key", key, data.cols,
                       case.sensitive = TRUE,
                       required = TRUE)
  data.cols <- data.cols[!data.cols %in% key]
  cols <- validateInput("cols", cols, data.cols,
                        case.sensitive = TRUE)
  if (length(cols) > 2){
    msg <- paste("At most two columns could be specified.")
    flog.error(msg)
    stop(msg)
  }
  if (length(cols) == 0){
    cols <- data.cols[[1]]
  }
  selected <- c(key, cols)
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as DataFrame."
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn.context <- data$connection.context
  data <- data$Select(selected)
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_CR_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_CR_RESULT_TBL_%s", unique.id)

  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl)
  tables <- list(param.tbl, result.tbl)
  param.array <-
    list(
      tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
      tuple("USE_FFT", map.null(method, method.map),
            NULL, NULL),
      tuple("MAX_LAG", max.lag, NULL, NULL),
      tuple("CALCULATE_PACF", to.integer(calculate.pacf),
            NULL, NULL)
    )
  tryCatch({
    errorhelper(CreateTWithConnection(
      conn.context,
      ParameterTable$new(param.tbl)$WithData(param.array)
    ))
    errorhelper(
      CallPalAutoWithConnection(
        conn.context,
        "PAL_CORRELATION_FUNCTION",
        in.tables,
        out.tables
      )
    )
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn.context, tables)
    stop(msg)
  })
  return(conn.context$table(result.tbl))
}

#' @title Fast Fourier Transform
#' @name hanaml.FFT
#' @description hanaml.FFT is a R wrapper for SAP HANA PAL fast-Fourier-transform.
#' @template args-data
#' @template args-key
#' @param num.type \code{list of character, optional}\cr
#' Specify the number types(i.e. real or imaginary) of columns in \code{data},\cr
#' e.g. num.type <- list(real = "COL1", imag = "COL2"),\cr
#' where "COL1" and "COL2" are assumed to be column names in \code{data}.\cr
#' If only one column is specified in \code{num.type}, only that column
#' will be applied FFT.\cr
#' If not provided, then \code{data} must contain exactly 3 columns,
#' and the two non-ID columns will be treated as real, imaginary part of \code{data} respectively.
#' @param inverse \code{logical, optional}\cr
#' If FALSE, forward FFT is applied; otherwise inverse FFT is applied.\cr
#' Defaults to FALSE.
#' @return
#' \code{DataFrame}
#' \itemize{
#'   \item{ ID: with same name and type as input data.}\cr
#'   \item{ REAL: type DOUBLE, representing real part of the transformed sequence.}\cr
#'   \item{ IMAG: type DOUBLE, representing imaginary part of the transformed sequence.}\cr
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    ID   RE   IM
#' 1   1  2.0  9.0
#' 2   2  3.0 -3.0
#' 3   3  5.0  0.0
#' 4   4  0.0  0.0
#' 5   5 -2.0 -2.0
#' 6   6 -9.0 -7.0
#' 7   7  7.0  0.0
#' }
#' Call the function:
#' \preformatted{
#' > result <-  hanaml.FFT(data, key = "ID")
#' }
#' Output:
#' \preformatted{
#' > result$Collect()
#'    ID        REAL        IMAG
#' 1   1   6.000000   -3.000000
#' 2   2   16.273688  -0.900317
#' 3   3  -5.393946    26.265112
#' 4   4  -13.883222   18.514840
#' 5   5  -4.233990   -2.947800
#' 6   6   9.657319    3.189618
#' 7   7   5.580151    21.878547
#' }
#' @keywords TimeSeries
#' @export
hanaml.FFT <- function(data,
                       key,
                       num.type = NULL,
                       inverse = NULL) {
  cols <- data$columns
  if (length(cols) < 2){
    msg <- "Input data must contain at least two columns."
    flog.error(msg)
    stop(msg)
  }
  inverse <- validateInput("inverse", inverse, "logical")
  key <- validateInput("key", key, cols, case.sensitive = TRUE,
                       required = TRUE)
  cols <- cols[! cols %in% key]
  number.type.map <- list("real" = 1, "imag" = 2)
  num.type <- validateInput("num.type", num.type, cols,
                            case.sensitive = TRUE)
  if (length(num.type) == 0) {
    if (length(cols) != 3){
      msg <- paste("If num.type is not specified, then data must contain",
                   "exactly 3 columns.")
      flog.error(msg)
      stop(msg)
    }
  }
  names(num.type) <- validateInput("Names of num.type", names(num.type),
                                   number.type.map)
  num.type <- validateInput("num.type", num.type, cols,
                            case.sensitive = TRUE)
  if (length(unique(names(num.type))) < length(num.type)){
    msg <- paste("Each column name in num.type must be specified",
                 "with a distinct number type,",
                 "i.e. either real or imag.")
    flog.error(msg)
    stop(msg)
  }
  if (length(num.type) == 0){
    num.type <- list(real = cols[[1]],
                     imag = cols[[2]])
  }
  if (!inherits(data, "DataFrame")){
    msg <- "data must be given as DataFrame."
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn.context <- data$connection.context
  data <- data$Select(c(key, num.type[["real"]],
                        num.type[["imag"]]))
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_CR_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_CR_RESULT_TBL_%s", unique.id)

  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl)
  tables <- list(param.tbl, result.tbl)
  param.array <- list(tuple("INVERSE",
                            to.integer(inverse),
                            NULL, NULL))
  if (length(num.type) == 1){
    col.type <- names(num.type)[[1]]
    param.array <- append(param.array,
                          list(tuple("NUMBER_TYPE",
                                     map.null(col.type,
                                              number.type.map),
                                     NULL,
                                     NULL)))
  }
  tryCatch({
    errorhelper(CreateTWithConnection(
      conn.context,
      ParameterTable$new(param.tbl)$WithData(param.array)
    ))
    errorhelper(CallPalAutoWithConnection(conn.context, "PAL_FFT",
                                          in.tables, out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn.context, tables)
    stop(msg)
  })
  return(conn.context$table(result.tbl))
}

ExpSmoothingBase <- function(data,
                             key = NULL,
                             endog = NULL,
                             model.selection = NULL,
                             forecast.model.name = NULL,
                             optimizer.time.budget = NULL,
                             max.iter  =  NULL,
                             optimizer.random.seed = NULL,
                             thread.ratio = NULL,
                             alpha = NULL,
                             beta = NULL,
                             gamma = NULL,
                             phi = NULL,
                             forecast.num = NULL,
                             seasonal.period = NULL,
                             seasonal = NULL,
                             initial.method = NULL,
                             training.ratio = NULL,
                             damped = NULL,
                             accuracy.measure = NULL,
                             seasonality.criterion = NULL,
                             trend.test.method = NULL,
                             trend.test.alpha = NULL,
                             alpha.min = NULL,
                             beta.min = NULL,
                             gamma.min = NULL,
                             phi.min = NULL,
                             alpha.max = NULL,
                             beta.max = NULL,
                             gamma.max = NULL,
                             phi.max = NULL,
                             prediction.confidence.1 = NULL,
                             prediction.confidence.2 = NULL,
                             level.start = NULL,
                             trend.start = NULL,
                             season.start = NULL,
                             delta = NULL,
                             adaptive.method = NULL,
                             ignore.zero = NULL,
                             expost.flag = NULL,
                             method = NULL,
                             exp.smooth.function){
      accuracy.measure.map  <-  list("mpe", "mse", "rmse", "et", "mad",
                                     "mase", "wmape", "smape", "mape")
      method.map <- list("sporadic" = 0,
                         "constant" = 1)
      model.selection <- validateInput("model.selection", model.selection, "logical")
      forecast.model.name <-
        validateInput("forecast.model.name", forecast.model.name, "character")
      max.iter <- validateInput("max.iter", max.iter, "integer")
      optimizer.random.seed <-
        validateInput("optimizer.random.seed", optimizer.random.seed, "integer")
      thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
      alpha <- validateInput("alpha", alpha, "double")
      beta <- validateInput("beta", beta, "double")
      gamma <- validateInput("gamma", gamma, "double")
      phi <- validateInput("phi", phi, "double")
      forecast.num <- validateInput("forecast.num", forecast.num, "integer")
      seasonal.period <- validateInput("seasonal.period", seasonal.period, "integer")
      seasonal <- validateInput("seasonal", seasonal, "integer")
      initial.method <- validateInput("initial.method", initial.method, "integer")
      training.ratio <- validateInput("training.ratio", training.ratio, "double")
      damped <- validateInput("damped", damped, "logical")
      accuracy.measure <-
        validateInput("accuracy.measure",
                      accuracy.measure,
                      accuracy.measure.map)
      seasonality.criterion <-
        validateInput("seasonality.criterion", seasonality.criterion, "double")
      trend.test.method <-
        validateInput("trend.test.method", trend.test.method, "integer")
      trend.test.alpha <-
        validateInput("trend.test.alpha", trend.test.alpha, "double")
      alpha.min <-
        validateInput("alpha.min", alpha.min, "double")
      beta.min <- validateInput("beta.min", beta.min, "double")
      gamma.min <-
        validateInput("gamma.min", gamma.min, "double")
      phi.min <- validateInput("phi.min", phi.min, "double")
      alpha.max <-
        validateInput("alpha.max", alpha.max, "double")
      beta.max <- validateInput("beta.max", beta.max, "double")
      gamma.max <-
        validateInput("gamma.max", gamma.max, "double")
      phi.max <- validateInput("phi.max", phi.max, "double")
      prediction.confidence.1 <-
        validateInput("prediction.confidence.1",
                      prediction.confidence.1,
                      "double")
      prediction.confidence.2 <-
        validateInput("prediction.confidence.2",
                      prediction.confidence.2,
                      "double")
      level.start <- validateInput("level.start", level.start, "double")
      trend.start <- validateInput("trend.start", trend.start, "double")
      delta <- validateInput("delta", delta, "double")
      adaptive.method <- validateInput("adaptive.method", adaptive.method, "logical")
      ignore.zero <- validateInput("ignore.zero", ignore.zero, "logical")
      expost.flag <-  validateInput("expost.flag", expost.flag, "logical")
      method <- validateInput("method", method, "character")
      optimizer.time.budget <-
        validateInput("optimizer.time.budget", optimizer.time.budget, "integer")

      #check season.start which is a list of tuples.
      #Each tuple has two elements and 1st element is int and 2nd is float
      season.start <-
        validateInput("season.start", season.start, "list")
      if (!is.null(season.start)) {
        for (i in seq_len(season.start)) {
          if (length(season.start[[i]]) != 2) {
            msg <- paste("The length of each tuple of",
                         "season.start should be 2!")
            flog.error(msg)
            stop(msg)
          } else {
            season.start[[i]][[1]] <-
              validateInput("Cycle ID in season.start",
                            season.start[[i]][[1]], "integer")
            season.start[[i]][[2]] <-
              validateInput("Initial value in season.start",
                            season.start[[i]][[2]], "double")
          }
        }
      }

      cols <- data$columns
      key <- validateInput("key", key, cols, case.sensitive = TRUE)
      if (is.null(key)) {
        key <- cols[[1]]
      }
      cols <- cols[!cols %in% key]
      endog <- validateInput("endog", endog, cols, case.sensitive = TRUE)
      if (is.null(endog)) {
        endog <- cols[[1]]
      }

      if (!inherits(data, "DataFrame")) {
        msg <- "If training data is not omitted, it must be DataFrame."
        flog.error(msg)
        stop(msg)
      }
      CheckConnection(data)
      conn.context <- data$connection.context
      data <- data$Select(list(key, endog))
      param.array <-
        list(
          tuple("MODELSELECTION", to.integer(model.selection), NULL, NULL),
          tuple("FORECAST_MODEL_NAME", NULL, NULL, forecast.model.name),
          tuple("OPTIMIZER_TIME_BUDGET", optimizer.time.budget, NULL, NULL),
          tuple("MAX_ITERATION", max.iter, NULL, NULL),
          tuple("OPTIMIZER_RANDOM_SEED", optimizer.random.seed, NULL, NULL),
          tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
          tuple("ALPHA", NULL, alpha, NULL),
          tuple("BETA", NULL, beta, NULL),
          tuple("GAMMA", NULL, gamma, NULL),
          tuple("PHI", NULL, phi, NULL),
          tuple("FORECAST_NUM", forecast.num, NULL, NULL),
          tuple("CYCLE", seasonal.period, NULL, NULL),
          tuple("SEASONAL", seasonal, NULL, NULL),
          tuple("INITIAL_METHOD", initial.method, NULL, NULL),
          tuple("TRAINING_RATIO", NULL, training.ratio, NULL),
          tuple("DAMPED", to.integer(damped), NULL, NULL),
          tuple("SEASONAL", seasonal, NULL, NULL),
          tuple("INITIAL_METHOD", initial.method, NULL, NULL),
          # S/D/T ESM
          tuple("SEASONALITY_CRITERION", NULL, seasonality.criterion, NULL),
          tuple("TREND_TEST_METHOD", trend.test.method, NULL, NULL),
          tuple("TREND_TEST_ALPHA", NULL, trend.test.alpha, NULL),
          tuple("ALPHA_MIN", NULL, alpha.min, NULL),
          tuple("BETA_MIN", NULL, beta.min, NULL),
          tuple("GAMMA_MIN", NULL, gamma.min, NULL),
          tuple("PHI_MIN", NULL, phi.min, NULL),
          tuple("ALPHA_MAX", NULL, alpha.max, NULL),
          tuple("BETA_MAX", NULL, beta.max, NULL),
          tuple("GAMMA_MAX", NULL, gamma.max, NULL),
          tuple("PHI_MAX", NULL, phi.max, NULL),
          tuple("PREDICTION_CONFIDENCE_1", NULL,
                prediction.confidence.1, NULL),
          tuple("PREDICTION_CONFIDENCE_2", NULL,
                prediction.confidence.2, NULL),
          tuple("LEVEL_START", NULL, level.start, NULL),
          tuple("TREND_START", NULL, trend.start, NULL),
          tuple("DELTA", NULL, delta, NULL),
          #SESM
          tuple("ADAPTIVE_METHOD", to.integer(adaptive.method),
                NULL, NULL),
          #SESM
          tuple("IGNORE_ZERO", to.integer(ignore.zero), NULL, NULL),
          tuple("EXPOST_FLAG", to.integer(expost.flag), NULL, NULL),
          tuple("METHOD", map.null(method, method.map), NULL, NULL)
        )
      if (!is.null(accuracy.measure)) {
        for (each in accuracy.measure) {
          temp.list <- tuple("MEASURE_NAME", NULL, NULL, each)
          param.array <- append(param.array, list(temp.list))
          temp.list <- tuple("accuracy.measure", NULL, NULL, each)
          param.array <- append(param.array, list(temp.list))
        }
      }

      if (!is.null(season.start)){
        param.array <-
          list(append(
            param.array,
            list(tuple(
              "SEASON_START",
              season.start[[1]],
              season.start[[2]],
              NULL))))
      }
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      param.tbl <- sprintf("#PAL_EXP_SMOOTHING_PARAM_TBL_%s", unique.id)
      forecast.tbl <- sprintf("#PAL_EXP_SMOOTHING_FORECAST_TBL_%s", unique.id)
      statistic.tbl <- sprintf("#PAL_EXP_SMOOTHING_STATISTIC_TBL_%s", unique.id)

      in.tables <- list(data, param.tbl)
      out.tables <- list(forecast.tbl, statistic.tbl)
      tables <- list(param.tbl, forecast.tbl, statistic.tbl)

      tryCatch({
        errorhelper(CreateTWithConnection(conn.context,
                   (ParameterTable$new(param.tbl))$WithData(param.array)))#nolint
        errorhelper(CallPalAutoWithConnection(conn.context,
                                              exp.smooth.function,
                                              in.tables,
                                              out.tables))
      },
      error  =  function(err) {
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn.context, tables)
        stop(msg)
      })
      return(list(conn.context$table(forecast.tbl),
                  conn.context$table(statistic.tbl)))

    }

#' @title Single Exponential Smoothing
#' @name hanaml.SingleExponentialSmoothing
#' @description hanaml.SingleExponentialSmoothing is a R wrapper
#' for SAP HANA PAL Single Exponential Smoothing algorithm.
#' @details Single Exponential Smoothing model is suitable to model the time series without trend and seasonality.
#' In the model, the smoothed value is the weighted sum of previous smoothed value and previous observed value.\cr
#' PAL provides two simple exponential smoothing algorithms: single exponential smoothing
#' and adaptive-response-rate simple exponential smoothing.
#' The adaptive-response-rate single exponential smoothing algorithm may have an advantage
#' over single exponential smoothing in that it allows the value of alpha to be modified.
#' @template args-data
#' @template args-key-first
#' @template args-endog
#' @param     alpha \code{double, optional}\cr
#'            Weight for smoothing. Value range: 0 < alpha < 1.\cr
#'            Defaults to 0.1 when \code{adaptive.method} is not TRUE, 0.2 otherwise.
#' @param     delta \code{double, optional}\cr
#'            Value of weight for At and Mt.
#'            Only valid when \code{adaptive.method} is TRUE.\cr
#'            Defaults to 0.2.
#' @param     forecast.num \code{integer, optional}\cr
#'            Number of values to be forecast.\cr
#'            Defaults to 0.\cr
#' @param     adaptive.method \code{logical, optional}
#'            \itemize{
#'              \item{FALSE}: Single exponential smoothing
#'              \item{TRUE}: Adaptive-response-rate single exponential smoothing}
#'            Defaults to FALSE.
#' @param     accuracy.measure \code{character or list of characters, optional}\cr
#'            Specifies measure name.
#'            \itemize{
#'              \item{\code{mpe}:   Mean percentage error.}
#'              \item{\code{mse}:   Mean squared error.}
#'              \item{\code{rmse}:  Root mean squared error.}
#'              \item{\code{et}:    Error total.}
#'              \item{\code{mad}:   Mean absolute deviation.}
#'              \item{\code{mase}:  Out-of-sample mean absolute scaled error.}
#'              \item{\code{wmape}: Weighted mean absolute percentage error.}
#'              \item{\code{smape}: Symmetric mean absolute percentage error.}
#'              \item{\code{mape}:  Mean absolute percentage error.}
#'            }
#'            No default value.
#' @param     ignore.zero \code{logical, optional}
#'            \itemize{
#'              \item{FALSE}: Uses zero values in the input dataset when calculating "mpe" or "mape".
#'              \item{TRUE}: Ignores zero values in the input dataset when calculating "mpe" or "mape".}
#'            Only valid when \code{accuracy.measure} is "mpe" or "mape".\cr
#'            Defaults to FALSE.
#' @param     expost.flag \code{logical, optional}
#'            \itemize{
#'              \item{FALSE}: Does not output the expost forecast, and just outputs the forecast values.
#'              \item{TRUE}: Outputs the expost forecast and the forecast values.}
#'            Defaults to TRUE.
#' @param     prediction.confidence.1 \code{double, optional}\cr
#'            Prediction confidence for interval 1.
#'            Only valid when the upper and lower columns are provided in the result table.\cr
#'            Defaults to 0.8.
#' @param     prediction.confidence.2 \code{double, optional}\cr
#'            Prediction confidence for interval 2.
#'            Only valid when the upper and lower columns are provided in the result table.\cr
#'            Defaults to 0.95.
#' @return
#' Return a list of two DataFrame:
#' \itemize{
#' \item{\code{DataFrame 1}}\cr
#'      Forecast values.
#' \item{\code{DataFrame 2}}\cr
#'     Statistics analysis content.
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'      ID RAWDATA
#'  1   1   200.0
#'  2   2   135.0
#'  3   3   195.0
#'  4   4   197.5
#'  5   5   310.0
#'  6   6   175.0
#'  7   7   155.0
#'  8   8   130.0
#'  9   9   220.0
#'  10 10   277.5
#'  11 11   235.0
#' }
#' Call the function:
#' \preformatted{
#' > sesm <- hanaml.SingleExponentialSmoothing(alpha = 0.1,
#'                                             delta = 0.2,
#'                                             forecast.num = 12,
#'                                             adaptive.method = FALSE,
#'                                             accuracy.measure = list('MPE', 'MSE'),
#'                                             ignore.zero = TRUE,
#'                                             expost.flag = TRUE,
#'                                             prediction.confidence.1 = 0.8,
#'                                             prediction.confidence.2 = 0.95)
#' }
#' Output:
#' \preformatted{
#' > sesm[[2]]$Collect()
#'   STAT_NAME    STAT_VALUE
#' 1       MPE   -0.05117142
#' 2       MSE 3438.33212531
#' }
#' @keywords TimeSeries
#' @export
hanaml.SingleExponentialSmoothing <- function(data,
                                              key = NULL,
                                              endog = NULL,
                                              alpha = NULL,
                                              delta = NULL,
                                              forecast.num = NULL,
                                              adaptive.method = NULL,
                                              accuracy.measure = NULL,
                                              ignore.zero = NULL,
                                              expost.flag = NULL,
                                              prediction.confidence.1 = NULL,
                                              prediction.confidence.2 = NULL) {

  ExpSmoothingBase(data = data,
                   key = key,
                   endog = endog,
                   alpha = alpha,
                   delta = delta,
                   forecast.num = forecast.num,
                   adaptive.method = adaptive.method,
                   accuracy.measure = accuracy.measure,
                   ignore.zero = ignore.zero,
                   expost.flag = expost.flag,
                   prediction.confidence.1 = prediction.confidence.1,
                   prediction.confidence.2 = prediction.confidence.2,
                   exp.smooth.function = "PAL_SINGLE_EXPSMOOTH")
    }

#' @title Double Exponential Smoothing
#' @name hanaml.DoubleExponentialSmoothing
#' @description hanaml.DoubleExponentialSmoothing is a R wrapper
#' for SAP HANA PAL Double Exponential Smoothing algorithm.
#' @details Double Exponential Smoothing model is suitable to model the time series with trend
#' but without seasonality.\cr
#' In the model there are two kinds of smoothed quantities: smoothed signal and smoothed trend.
#' @template args-data
#' @template args-key-first
#' @template args-endog
#' @param     alpha \code{double, optional}\cr
#'            Weight for smoothing. Value range: 0 < alpha < 1.\cr
#'            Defaults to 0.1.
#' @param     beta \code{double, optional}\cr
#'            Weight for the trend component. Value range: 0 <= beta < 1.\cr
#'            Defaults to 0.1.
#' @param     forecast.num \code{integer, optional}\cr
#'            Number of values to be forecast.\cr
#'            Defaults to 0.\cr
#' @param     phi \code{double, optional}\cr
#'            Value of the damped smoothing constant phi (0 < phi < 1).\cr
#'            Defaults to 0.1.
#' @param     damped \code{logical, optional}
#'            \itemize{
#'              \item{FALSE}: Uses the Holt Winter method.
#'              \item{TRUE}: Uses the additive damped seasonal Holt Winter method
#'             }
#'            Defaults to FALSE.
#' @param     accuracy.measure \code{character or list of characters, optional}\cr
#'            Specifies measure name.
#'            \itemize{
#'              \item{\code{mpe}:   Mean percentage error.}
#'              \item{\code{mse}:   Mean squared error.}
#'              \item{\code{rmse}:  Root mean squared error.}
#'              \item{\code{et}:    Error total.}
#'              \item{\code{mad}:   Mean absolute deviation.}
#'              \item{\code{mase}:  Out-of-sample mean absolute scaled error.}
#'              \item{\code{wmape}: Weighted mean absolute percentage error.}
#'              \item{\code{smape}: Symmetric mean absolute percentage error.}
#'              \item{\code{mape}:  Mean absolute percentage error.}
#'            }
#'            No default value.
#' @param     ignore.zero \code{logical, optional}
#'            \itemize{
#'              \item{FALSE}: Uses zero values in the input dataset when calculating "mpe" or "mape".
#'              \item{TRUE}: Ignores zero values in the input dataset when calculating "mpe" or "mape".
#'            }
#'            Only valid when \code{accuracy.measure} is "mpe" or "mape".\cr
#'            Defaults to FALSE.
#' @param     expost.flag \code{logical, optional}
#'            \itemize{
#'              \item{FALSE}: Does not output the expost forecast, and just outputs the forecast values.
#'              \item{TRUE}: Outputs the expost forecast and the forecast values.}
#'            Defaults to TRUE.
#' @param     prediction.confidence.1 \code{double, optional}\cr
#'            Prediction confidence for interval 1.\cr
#'            Only valid when the upper and lower columns are provided in the result table.\cr
#'            Defaults to 0.8.
#' @param     prediction.confidence.2 \code{double, optional}\cr
#'            Prediction confidence for interval 2.\cr
#'            Only valid when the upper and lower columns are provided in the result table.\cr
#'            Defaults to 0.95.
#' @return
#' Returns a list of two DataFrame:
#' \itemize{
#' \item{\code{DataFrame 1}}\cr
#'      Forecast values.
#' \item{\code{DataFrame 2}}\cr
#'     Statistics analysis content.
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    ID RAWDATA
#' 1   1     143
#' 2   2     152
#' 3   3     161
#' ......
#' 21 21     223
#' 22 22     242
#' 23 23     239
#' 24 24     266
#' }
#' Call the function:
#' \preformatted{
#' > desm <- hanaml.DoubleExponentialSmoothing(data = data,
#'                                             alpha=0.501,
#'                                             beta=0.072,
#'                                             forecast.num=6,
#'                                             phi=NULL,
#'                                             damped=NULL,
#'                                             accuracy.measure='mse',
#'                                             ignore.zero=NULL,
#'                                             expost.flag=TRUE,
#'                                             prediction.confidence.1=0.8,
#'                                             prediction.confidence.2=0.95)
#' }
#' Output:
#' \preformatted{
#' > desm[[2]]$Collect()
#'   STAT_NAME    STAT_VALUE
#' 1       MSE      274.896
#' }
#' @keywords TimeSeries
#' @export
hanaml.DoubleExponentialSmoothing <-  function(data,
                                               key = NULL,
                                               endog = NULL,
                                               alpha = NULL,
                                               beta = NULL,
                                               forecast.num = NULL,
                                               phi = NULL,
                                               damped = NULL,
                                               accuracy.measure = NULL,
                                               ignore.zero = NULL,
                                               expost.flag = NULL,
                                               prediction.confidence.1 = NULL,
                                               prediction.confidence.2 = NULL) {
  ExpSmoothingBase(data = data,
                   key = key,
                   endog = endog,
                   alpha = alpha,
                   beta = beta,
                   forecast.num = forecast.num,
                   phi = phi,
                   damped = damped,
                   accuracy.measure = accuracy.measure,
                   ignore.zero = ignore.zero,
                   expost.flag = expost.flag,
                   prediction.confidence.1 = prediction.confidence.1,
                   prediction.confidence.2 = prediction.confidence.2,
                   exp.smooth.function = "PAL_DOUBLE_EXPSMOOTH"
      )
    }

#' @title Triple Exponential Smoothing
#' @name hanaml.TripleExponentialSmoothing
#' @description hanaml.TripleExponentialSmoothing is a R wrapper
#' for SAP HANA  Triple Exponential Smoothing algorithm.
#' @details Triple Exponential smoothing is used to handle the time series data
#' containing a seasonal component.
#' @template args-data
#' @template args-key-first
#' @template args-endog
#' @param     alpha \code{double, optional}\cr
#'            Weight for smoothing. Value range: 0 < alpha < 1.\cr
#'            Defaults to 0.1.
#' @param     beta \code{double, optional}\cr
#'            Weight for the trend component. Value range: 0 <= beta < 1.\cr
#'            Defaults to 0.1.
#' @param     gamma \code{double, optional}\cr
#'            Weight for the seasonal component. Value range: 0 < gamma < 1.\cr
#'            Defaults to 0.1.
#' @param     seasonal.period \code{integer, optional}\cr
#'            Length of a seasonal.period (L > 1).\cr
#'            For example, the seasonal.period of quarterly data is 4,
#'            and the seasonal.period of monthly data is 12. \cr
#'            Defaults to 2.
#' @param     forecast.num \code{integer, optional}\cr
#'            Number of values to be forecast.\cr
#'            Defaults to 0.\cr
#' @param     seasonal \code{integer, optional}\cr
#'            \itemize{
#'              \item{0}: Multiplicative triple exponential smoothing.
#'              \item{1}: Additive triple exponential smoothing.
#'            }
#'            When \code{seasonal} is set to 1, the default value of initial.method is 1;\cr
#'            When  \code{seasonal}  is set to 0, the default value of initial.method is 0.\cr
#'            Defaults to 0.
#' @param     initial.method \code{integer, optional}\cr
#'            Initialization method for the trend and seasonal components.
#'            When \code{seasonal} is set to 1, the default value of initial.method is 1;\cr
#'            When  \code{seasonal}  is set to 0, the default value of initial.method is 0.\cr
#' @param     phi \code{double, optional}\cr
#'            Value of the damped smoothing constant phi (0 < phi < 1).\cr
#'            Defaults to 0.1.
#' @param     damped \code{logical, optional}
#'            \itemize{
#'              \item{FALSE}: Uses the Holt Winter method.
#'              \item{TRUE}: Uses the additive damped seasonal Holt Winter method.
#'            }
#'            Defaults to FALSE.
#' @param     accuracy.measure \code{character or list of characters, optional}\cr
#'            Specifies measure name.
#'            \itemize{
#'              \item{\code{mpe}:   Mean percentage error.}
#'              \item{\code{mse}:   Mean squared error.}
#'              \item{\code{rmse}:  Root mean squared error.}
#'              \item{\code{et}:    Error total.}
#'              \item{\code{mad}:   Mean absolute deviation.}
#'              \item{\code{mase}:  Out-of-sample mean absolute scaled error.}
#'              \item{\code{wmape}: Weighted mean absolute percentage error.}
#'              \item{\code{smape}: Symmetric mean absolute percentage error.}
#'              \item{\code{mape}:  Mean absolute percentage error.}
#'            }
#'            No default value.
#' @param     ignore.zero \code{logical, optional}
#'            \itemize{
#'              \item{FALSE}: Uses zero values in the input dataset when calculating "mpe" or "mape".
#'              \item{TRUE}: Ignores zero values in the input dataset when calculating "mpe" or "mape".
#'            }
#'            Only valid when \code{accuracy.measure} is "mpe" or "mape".\cr
#'            Defaults to FALSE.
#' @param     expost.flag \code{logical, optional}
#'            \itemize{
#'              \item{FALSE}: Does not output the expost forecast, and just outputs the forecast values.
#'              \item{TRUE}: Outputs the expost forecast and the forecast values.
#'            }
#'            Defaults to TRUE.
#' @param     level.start \code{double, optional}\cr
#'            The initial value for level component S. If this value is not provided,\cr
#'            it will be calculated in the way as described in Triple Exponential Smoothing.\cr
#'            \code{level.start} cannot be zero. If it is set to zero, 0.0000000001 will be used instead.\cr
#' @param     trend.start \code{double, optional}\cr
#'            The initial value for trend component B.\cr
#'            No default value.
#' @param     season.start \code{list of tuples, optional}\cr
#'            A list of initial values for seasonal component C.
#'            Two values must be provided for each cycle:
#'            \itemize{
#'              \item{Cycle ID}: An int which represents which cycle the initial value is used for.
#'              \item{Initial value}: A double precision number which represents the initial value
#'            }
#'            for the corresponding cycle. \cr
#'            For example: To give the initial value 0.5 to the 3rd cycle,
#'            insert list(tuple(3, 0.5)) into the parameter table.\cr
#'            No default value.
#' @param     prediction.confidence.1 \code{double, optional}\cr
#'            Prediction confidence for interval 1.
#'            Only valid when the upper and lower columns are provided in the result table.\cr
#'            Defaults to 0.8.
#' @param     prediction.confidence.2 \code{double, optional}\cr
#'            Prediction confidence for interval 2.
#'            Only valid when the upper and lower columns are provided in the result table.\cr
#'            Defaults to 0.95.
#' @return
#' Returns a list of two DataFrame:
#' \itemize{
#' \item{\code{DataFrame 1}}\cr
#'      Forecast values.
#' \item{\code{DataFrame 2}}\cr
#'     Statistics analysis content.
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'      ID RAWDATA
#' 1   1     362
#' 2   2     385
#' 3   3     432
#' ......
#' 22 22     725
#' 23 23     854
#' 24 24     661
#' }
#' Call the function:
#' \preformatted{
#' > tesm <- hanaml.TripleExponentialSmoothing(data = data,
#'                                             alpha=0.822,
#'                                             beta=0.055,
#'                                             gamma=0.055,
#'                                             seasonal.period=4,
#'                                             forecast.num=6,
#'                                             seasonal=0,
#'                                             initial.method=0,
#'                                             phi=NULL,
#'                                             damped=NULL,
#'                                             accuracy.measure='mse',
#'                                             ignore.zero=NULL,
#'                                             expost.flag=TRUE,
#'                                             level.start=NULL,
#'                                             trend.start=NULL,
#'                                             season.start=NULL,
#'                                             prediction.confidence.1=0.8,
#'                                             prediction.confidence.2=0.95)
#'
#' }
#' Output:
#' \preformatted{
#' > tesm[[2]]$Collect()
#'   STAT_NAME    STAT_VALUE
#' 1       MSE      616.5415
#' }
#' @keywords TimeSeries
#' @export
hanaml.TripleExponentialSmoothing <- function(
  data,
  key = NULL,
  endog = NULL,
  alpha = NULL,
  beta = NULL,
  gamma = NULL,
  seasonal.period = NULL,
  forecast.num = NULL,
  seasonal = NULL,
  initial.method = NULL,
  phi = NULL,
  damped = NULL,
  accuracy.measure = NULL,
  ignore.zero = NULL,
  expost.flag = NULL,
  level.start = NULL,
  trend.start = NULL,
  season.start = NULL,
  prediction.confidence.1 = NULL,
  prediction.confidence.2 = NULL){
  ExpSmoothingBase(data = data,
                   key = key,
                   endog = endog,
                   alpha = alpha,
                   beta = beta,
                   gamma = gamma,
                   seasonal.period = seasonal.period,
                   forecast.num = forecast.num,
                   seasonal = seasonal,
                   initial.method = initial.method,
                   phi = phi,
                   damped = damped,
                   accuracy.measure = accuracy.measure,
                   ignore.zero = ignore.zero,
                   expost.flag = expost.flag,
                   level.start = level.start,
                   trend.start = trend.start,
                   season.start = season.start,
                   prediction.confidence.1 = prediction.confidence.1,
                   prediction.confidence.2 = prediction.confidence.2,
                   exp.smooth.function = "PAL_TRIPLE_EXPSMOOTH"
      )
  }

#' @title  Auto Exponential Smoothing
#' @name hanaml.AutoExponentialSmoothing
#' @description hanaml.AutoExpSmoothing is a R wrapper
#' for SAP HANA PAL Auto Exponential Smoothing algorithm.
#' @details  Auto exponential smoothing (previously named forecast smoothing)
#' is used to calculate optimal parameters of a set of smoothing functions in PAL,
#' including Single Exponential Smoothing, Double Exponential Smoothing, and Triple Exponential Smoothing.
#' @template args-data
#' @template args-key-first
#' @template args-endog
#' @param     model.selection \code{logical, optional}
#'            \itemize{
#'              \item{TRUE}: the algorithm will select the best model among Single/Double/Triple/
#'            Damped Double/Damped Triple Exponential Smoothing models.
#'              \item{FALSE}: the algorithm will not perform the model selection.}
#'            If \code{forecast.model.name} is set, the model defined by \code{forecast.model.name} will be used.
#'            Defaults to FALSE.
#' @param     forecast.model.name \code{character, optional}\cr
#'            Name of the statistical model used for calculating the forecast.
#'            \itemize{
#'              \item{'SESM'}: Single Exponential Smoothing
#'              \item{'DESM'}: Double Exponential Smoothing
#'              \item{'TESM'}: Triple Exponential Smoothing
#'            }
#'            This parameter must be set unless \code{model.selection} is set to TRUE.
#' @param     optimizer.time.budget \code{integer, optional}\cr
#'            Time budget for Nelder-Mead optimization process. The time unit
#'            is second and the value should be larger than zero.\cr
#'            Defaults to 1.\cr
#' @param     max.iter \code{integer, optional}\cr
#'            Maximum number of iterations for simulated annealing.
#'            Defaults to 100.\cr
#' @param     optimizer.random.seed \code{integer, optional}\cr
#'            Random seed for simulated annealing. The value should be larger than zero.\cr
#'            Defaults to system time.\cr
#' @param     thread.ratio \code{double, optional}\cr
#'            Controls the proportion of available threads to use.
#'            The ratio of available threads.
#'            \itemize{
#'              \item{0}: single thread.
#'              \item{0 ~ 1}: percentage.
#'              \item{Others}: heuristically determined.
#'            }
#'            Defaults to 1.0. \cr
#' @param     alpha \code{double, optional}\cr
#'            Weight for smoothing. Value range: 0 < alpha < 1.\cr
#'            Default value is computed automatically.
#' @param     beta \code{double, optional}\cr
#'            Weight for the trend component. Value range: 0 <= beta < 1.\cr
#'            If it is not set, the optimized value will be computed automatically.
#'            Only valid when the model is set by user or identified by the algorithm as a DESM/TESM.
#'            Value 0 is allowed under TESM model only.\cr
#'            Defaults value is computed automatically.
#' @param     gamma \code{double, optional}\cr
#'            Weight for the seasonal component. Value range: 0 < gamma < 1.\cr
#'            Only valid when the model is set by user or identified by the algorithm as TESM.\cr
#'            Default value is computed automatically.
#' @param     phi \code{double, optional}\cr
#'            Value of the damped smoothing constant phi (0 < phi < 1).\cr
#'            Only valid when the model is set by user or identified by the algorithm as a damped model.\cr
#'            Default value is computed automatically.
#' @param     forecast.num \code{integer, optional}\cr
#'            Number of values to be forecast.\cr
#'            Defaults to 0.\cr
#' @param     seasonal.period \code{integer, optional}\cr
#'            Length of a seasonal.period (L > 1).\cr
#'            For example, the seasonal.period of quarterly data is 4,
#'            and the seasonal.period of monthly data is 12.\cr
#'            Only valid when the model is set by user or identified by the algorithm as a TESM.\cr
#'            Default value is computed automatically.
#' @param     seasonal \code{integer, optional}
#'            \itemize{
#'              \item{0}: Multiplicative triple exponential smoothing.
#'              \item{1}: Additive triple exponential smoothing.}
#'            Only valid when the model is set by user or identified by the algorithm as a TESM.\cr
#'            If \code{model.selection} is set to TRUE, the default value will be computed automatically.\cr
#'            Otherwise, the default value is 0.
#' @param     initial.method \code{integer, optional}\cr
#'            Initialization method for the trend and seasonal components.\cr
#'            Refer to Triple Exponential Smoothing for detailed information on initialization method.\cr
#'            Only valid when the model is set by user or identified by the algorithm as a TESM.
#'            When \code{seasonal} is set to 1, the default value of initial.method is 1;\cr
#'            When  \code{seasonal}  is set to 0, the default value of initial.method is 0.\cr
#' @param     training.ratio \code{double, optional}\cr
#'            The ratio of training data to the whole time series.\cr
#'            Assuming the size of time series is N, and the training ratio is r,
#'            the first N\ifelse{html}{\out{&times}}{\eqn{\times}}r time series is used to train,
#'            whereas only the latter N\ifelse{html}{\out{&times}}{\eqn{\times}}(1-r) one
#'            is used to test. If this parameter is set to 0.0 or 1.0, or the resulting training data
#'            (N\ifelse{html}{\out{&times}}{\eqn{\times}}r) is less than 1 or equal to the size of time series, no train-and-test procedure is
#'            carried out.\cr
#'            Defaults to 1.0.
#' @param     damped \code{logical, optional}\cr
#'            For Double ExponentialSmoothing DESM:
#'            \itemize{
#'              \item{FALSE}: Uses the Holt's linear method.
#'              \item{TRUE}: Uses the additive damped trend Holt's linear method.}
#'            For Triple Exponential Smoothing TESM:
#'            \itemize{
#'              \item{FALSE}: Uses the Holt Winter method.
#'              \item{TRUE}: Uses the additive damped seasonal Holt Winter method.}
#'            If \code{model.selection} is set to TRUE, the default value will be computed automatically.
#'            Otherwise, the default value is FALSE.
#' @param     accuracy.measure \code{list('mse', 'mape'), optional}\cr
#'            The criterion used for the optimization.
#'            Defaults to 'mse'.
#' @param     seasonality.criterion \code{double, optional}\cr
#'            The criterion of the auto-correlation coefficient for accepting seasonality,
#'            in the range of (0, 1). The larger it is, the less probable a time series is
#'            regarded to be seasonal.Only valid when \code{forecast.model.name} is 'TESM' or \code{model.selection}
#'            is set to TRUE, and \code{seasonal.period} is not defined.\cr
#'            Defaults to 0.5.
#' @param     trend.test.method \code{integer, optional}
#'            \itemize{
#'              \item{1}: MK test
#'              \item{2}: Difference-sign test
#'            }
#'            Only valid when \code{model.selection} is set to TRUE. \cr
#'            Defaults to 1.
#' @param     trend.test.alpha \code{double, optional}\cr
#'            Tolerance probability for trend test. The value range is (0, 0.5).\cr
#'            Only valid when \code{model.selection} is set to TRUE.\cr
#'            Defaults to 0.05.
#' @param     alpha.min \code{double, optional}\cr
#'            Sets the minimum value of alpha.\cr
#'            Only valid when \code{alpha} is not defined.\cr
#'            Defaults to 0.0000000001.
#' @param     beta.min \code{double, optional}\cr
#'            Sets the minimum value of beta.\cr
#'            Only valid when \code{beta} is not defined.\cr
#'            Defaults to 0.0000000001.
#' @param     gamma.min \code{double, optional}\cr
#'            Sets the minimum value of gamma.\cr
#'            Only valid when \code{gamma} is not defined.\cr
#'            Defaults to 0.0000000001.
#' @param      phi.min \code{double, optional}\cr
#'            Sets the minimum value of phi.
#'            Only valid when \code{phi} is not defined.\cr
#'            Defaults to 0.0000000001.
#' @param     alpha.max \code{double, optional}\cr
#'            Sets the maximum value of alpha.\cr
#'            Only valid when \code{alpha} is not defined.\cr
#'            Defaults to 1.0.
#' @param     beta.max \code{double, optional}\cr
#'            Sets the maximum value of beta.\cr
#'            Only valid when \code{beta} is not defined.\cr
#'            Defaults to 1.0.
#' @param     gamma.max \code{double, optional}\cr
#'            Sets the maximum value of gamma.\cr
#'            Only valid when \code{gamma} is not defined.\cr
#'            Defaults to 1.0.
#' @param     phi.max \code{double, optional}\cr
#'            Sets the maximum value of phi.\cr
#'            Only valid when \code{phi} is not defined.\cr
#'            Defaults to 1.0.
#' @param     level.start \code{double, optional}\cr
#'            The initial value for level component S. \cr If this value is not provided,
#'            it will be calculated in the way as described in Triple Exponential Smoothing.\cr
#'            Notice that \code{level.start} cannot be zero. If it is set to zero, 0.0000000001 will be used instead.
#' @param     prediction.confidence.1 \code{double, optional}\cr
#'            Prediction confidence for interval 1.
#'            Only valid when the upper and lower columns are provided in the result table.\cr
#'            Defaults to 0.8.
#' @param     prediction.confidence.2 \code{double, optional}\cr
#'            Prediction confidence for interval 2.
#'            Only valid when the upper and lower columns are provided in the result table.\cr
#'            Defaults to 0.95.
#' @param     trend.start \code{double, optional}\cr
#'            The initial value for trend component B. \cr If this value is not provided,
#'            it will be calculated in the way as described in Triple Exponential Smoothing.\cr
#'            No default value.
#' @param     season.start \code{list of tuples, optional}\cr
#'            A list of initial values for seasonal component C.
#'            Two values must be provided for each cycle:
#'            \itemize{
#'              \item{Cycle ID}: An int which represents which cycle
#'              the initial value is used for.
#'              \item{Initial value}: A double precision number which represents
#'              the initial value for the corresponding cycle.}
#'            For example: To give the initial value 0.5 to the 3rd cycle,
#'            insert list(tuple(3, 0.5)) into the parameter table.\cr
#'            No default value.
#' @return
#' Returns a list of two DataFrame:
#' \itemize{
#' \item{\code{DataFrame 1}}\cr
#'      Forecast values.
#' \item{\code{DataFrame 2}}\cr
#'     Statistics analysis content.
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'      ID RAWDATA
#' 1   1     362
#' 2   2     385
#' 3   3     432
#' 4   4     341
#' ......
#' 22 22     725
#' 23 23     854
#' 24 24     661
#' }
#' Call the function:
#' \preformatted{
#' > aesm <- hanaml.AutoExponentialSmoothing(data = data,
#'                                           forecast.model.name = 'TESM',
#'                                           alpha=0.4,
#'                                           gamma=0.4,
#'                                           forecast.num=3,
#'                                           seasonal=0,
#'                                           initial.method=1,
#'                                           training.ratio = 0.75)
#' }
#'
#' Output:
#' \preformatted{
#' > aesm[[2]]$Collect()
#'                  STAT_NAME        STAT_VALUE
#' 1                      MSE  467.811415778471
#' 2     NUMBER_OF_ITERATIONS               110
#' 3  SA_NUMBER_OF_ITERATIONS               100
#' 4  NM_NUMBER_OF_ITERATIONS                10
#' 5        NM_EXECUTION_TIME          0.000171
#' 6             SA_STOP_COND     MAX_ITERATION
#' 7             NM_STOP_COND  ERROR_DIFFERENCE
#' 8                    ALPHA               0.4
#' 9                     BETA               0.4
#' 10                   GAMMA               0.4
#' 11                   CYCLE                 4
#' 12      NUMBER_OF_TRAINING                18
#' 13       NUMBER_OF_TESTING                 6
#' 14                TEST_MSE 6353.632907713298
#' }
#' @keywords TimeSeries
#' @export
hanaml.AutoExponentialSmoothing <- function(data,
                                            key = NULL,
                                            endog = NULL,
                                            model.selection = NULL,
                                            forecast.model.name = NULL,
                                            optimizer.time.budget = NULL,
                                            max.iter = NULL,
                                            optimizer.random.seed = NULL,
                                            thread.ratio = NULL,
                                            alpha = NULL,
                                            beta = NULL,
                                            gamma = NULL,
                                            phi = NULL,
                                            forecast.num = NULL,
                                            seasonal.period = NULL,
                                            seasonal = NULL,
                                            initial.method = NULL,
                                            training.ratio = NULL,
                                            damped = NULL,
                                            accuracy.measure = NULL,
                                            seasonality.criterion = NULL,
                                            trend.test.method = NULL,
                                            trend.test.alpha = NULL,
                                            alpha.min = NULL,
                                            beta.min = NULL,
                                            gamma.min = NULL,
                                            phi.min = NULL,
                                            alpha.max = NULL,
                                            beta.max = NULL,
                                            gamma.max = NULL,
                                            phi.max = NULL,
                                            prediction.confidence.1 = NULL,
                                            prediction.confidence.2 = NULL,
                                            level.start = NULL,
                                            trend.start = NULL,
                                            season.start = NULL) {
  accuracy.measure.auto.map <- list("mse", "mape")
  accuracy.measure <- validateInput("accuracy.measure",
                                    accuracy.measure,
                                    accuracy.measure.auto.map)

  ExpSmoothingBase(data = data,
                   key = key,
                   endog = endog,
                   model.selection = model.selection,
                   forecast.model.name = forecast.model.name,
                   optimizer.time.budget = optimizer.time.budget,
                   max.iter = max.iter,
                   optimizer.random.seed = optimizer.random.seed,
                   thread.ratio = thread.ratio,
                   alpha = alpha,
                   beta = beta,
                   gamma = gamma,
                   phi = phi,
                   forecast.num = forecast.num,
                   seasonal.period = seasonal.period,
                   seasonal = seasonal,
                   initial.method = initial.method,
                   training.ratio = training.ratio,
                   damped = damped,
                   accuracy.measure = accuracy.measure,
                   seasonality.criterion = seasonality.criterion,
                   trend.test.method = trend.test.method,
                   trend.test.alpha = trend.test.alpha,
                   alpha.min = alpha.min,
                   beta.min = beta.min,
                   gamma.min = gamma.min,
                   phi.min = phi.min,
                   alpha.max = alpha.max,
                   beta.max = beta.max,
                   gamma.max = gamma.max,
                   phi.max = phi.max,
                   prediction.confidence.1 = prediction.confidence.1,
                   prediction.confidence.2 = prediction.confidence.2,
                   level.start = level.start,
                   trend.start = trend.start,
                   season.start = season.start,
                   exp.smooth.function = "PAL_AUTO_EXPSMOOTH"
      )
 }

#' @title  Brown Exponential Smoothing
#' @name hanaml.BrownExponentialSmoothing
#' @description hanaml.BrownExponentialSmoothing is a R wrapper
#' for SAP HANA PAL Brown Exponential Smoothing algorithm.
#' @details  The brown exponential smoothing model is suitable to model the time series
#' with trend but without seasonality.
#' In SAP HANA PAL, both non-adaptive and adaptive brown linear exponential smoothing are provided.
#' @template args-data
#' @template args-key-first
#' @template args-endog
#' @param     alpha \code{double, optional}\cr
#'            The smoothing constant alpha for brown exponential smoothing or
#'            the initialization value for adaptive brown exponential smoothing (0 < alpha < 1).\cr
#'            \itemize{
#'              \item{Defaults to 0.1 when Brown exponential smoothing}
#'              \item{Defaults to 0.2 when Adaptive brown exponential smoothing}
#'            }
#' @param     delta \code{double, optional}\cr
#'            Value of weighted for At and Mt.
#'            Only valid when 'adaptive_method' is TRUE.\cr
#'            Defaults to 0.2
#' @param     forecast.num \code{integer, optional}\cr
#'            Number of values to be forecast.\cr
#'            Defaults to 0.\cr
#' @param     adaptive.method \code{logical, optional}
#'            \itemize{
#'              \item{FALSE}: Brown exponential smoothing.
#'              \item{TRUE}: Adaptive brown exponential smoothing.}
#'            Defaults to FALSE.
#' @param     accuracy.measure \code{character or list of characters, optional}\cr
#'            Specifies measure name.
#'            \itemize{
#'              \item{\code{mpe}:   Mean percentage error.}
#'              \item{\code{mse}:   Mean squared error.}
#'              \item{\code{rmse}:  Root mean squared error.}
#'              \item{\code{et}:    Error total.}
#'              \item{\code{mad}:   Mean absolute deviation.}
#'              \item{\code{mase}:  Out-of-sample mean absolute scaled error.}
#'              \item{\code{wmape}: Weighted mean absolute percentage error.}
#'              \item{\code{smape}: Symmetric mean absolute percentage error.}
#'              \item{\code{mape}:  Mean absolute percentage error.}
#'            }
#'            No default value.
#' @param     ignore.zero \code{logical, optional}
#'            \itemize{
#'              \item{FALSE}: Uses zero values in the input dataset when calculating "mpe" or "mape".
#'              \item{TRUE}: Ignores zero values in the input dataset when calculating "mpe" or "mape".
#'            }
#'            Only valid when \code{accuracy.measure} is "mpe" or "mape".\cr
#'            Defaults to FALSE.
#' @param     expost.flag \code{logical, optional}
#'            \itemize{
#'              \item{FALSE}: Does not output the expost forecast, and just outputs the forecast values.
#'              \item{TRUE}: Outputs the expost forecast and the forecast values.}
#'            Defaults to TRUE.
#' @return
#'Return a list of two DataFrame:
#' \itemize{
#' \item{\code{DataFrame 1}}\cr
#'      Forecast values.
#' \item{\code{DataFrame 2}}\cr
#'     Statistics analysis content.
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    ID RAWDATA
#' 1   1     143
#' 2   2     152
#' 3   3     161
#' 4   4     139
#' ......
#' 20 20     227
#' 21 21     223
#' 22 22     242
#' 23 23     239
#' 24 24     266
#' }
#' Call the function
#' \preformatted{
#' > besm <- hanaml.BrownExponentialSmoothing(data = data,
#'                                            alpha=0.1,
#'                                            forecast.num=6,
#'                                            adaptive.method=FALSE,
#'                                            accuracy.measure='mse',
#'                                            expost.flag=TRUE)
#' }
#' Output:
#' \preformatted{
#' > besm[[2]]$Collect()
#'   STAT_NAME    STAT_VALUE
#' 1       MSE       474.142
#' }
#' @keywords TimeSeries
#' @export
hanaml.BrownExponentialSmoothing <- function(data,
                                             key = NULL,
                                             endog = NULL,
                                             alpha = NULL,
                                             delta = NULL,
                                             forecast.num = NULL,
                                             adaptive.method = NULL,
                                             accuracy.measure = NULL,
                                             ignore.zero = NULL,
                                             expost.flag = NULL){

  ExpSmoothingBase(data = data,
                   key = key,
                   endog = endog,
                   alpha = alpha,
                   delta = delta,
                   forecast.num = forecast.num,
                   adaptive.method = adaptive.method,
                   accuracy.measure = accuracy.measure,
                   ignore.zero = ignore.zero,
                   expost.flag = expost.flag,
                   exp.smooth.function = "PAL_BROWN_EXPSMOOTH")
}

#' @title  Croston
#' @name hanaml.Croston
#' @description hanaml.Croston is a R wrapper
#' for SAP HANA PAL Croston Exponential Smoothing algorithm.
#' @details  The Croston method is a forecast strategy for products with intermittent demand.\cr
#' The Croston method consists of two steps. First, separate
#' exponential smoothing estimates are made of the average size of a demand.
#' Second, the average interval between demands is calculated.
#' This is then used in a form of the constant model to predict the future demand.
#' @template args-data
#' @template args-key-first
#' @template args-endog
#' @param     alpha \code{double, optional}\cr
#'            Value of the smoothing constant alpha (0 < alpha < 1).\cr
#'            Defaults to 0.1.
#' @param     forecast.num \code{integer, optional}\cr
#'            Number of values to be forecast.\cr
#'            Defaults to 0.\cr
#' @param     method \code{character, optional}\cr
#'            \itemize{
#'              \item{'sporadic'}: Use the sporadic method.
#'              \item{'constant'}: Use the constant method.}
#'            Defaults to 'sporadic'.
#' @param     accuracy.measure \code{character or list of characters, optional}\cr
#'            Specifies measure name.
#'            \itemize{
#'              \item{\code{mpe}:   Mean percentage error.}
#'              \item{\code{mse}:   Mean squared error.}
#'              \item{\code{rmse}:  Root mean squared error.}
#'              \item{\code{et}:    Error total.}
#'              \item{\code{mad}:   Mean absolute deviation.}
#'              \item{\code{mase}:  Out-of-sample mean absolute scaled error.}
#'              \item{\code{wmape}: Weighted mean absolute percentage error.}
#'              \item{\code{smape}: Symmetric mean absolute percentage error.}
#'              \item{\code{mape}:  Mean absolute percentage error.}
#'            }
#'            No default value.
#' @param     ignore.zero \code{logical, optional}
#'            \itemize{
#'              \item{FALSE}: Uses zero values in the input dataset when calculating "mpe" or "mape".
#'              \item{TRUE}: Ignores zero values in the input dataset when calculating "mpe" or "mape".}
#'            Only valid when \code{accuracy.measure} is "mpe" or "mape".\cr
#'            Defaults to FALSE.
#' @param     expost.flag \code{logical, optional}
#'            \itemize{
#'              \item{FALSE}: Does not output the expost forecast, and just outputs the forecast values.
#'              \item{TRUE}: Outputs the expost forecast and the forecast values.}
#'            Defaults to TRUE.
#' @return
#'Return a list of two DataFrame:
#' \itemize{
#' \item{\code{DataFrame 1}}\cr
#'      Forecast values.
#' \item{\code{DataFrame 2}}\cr
#'     Statistics analysis content.
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    ID RAWDATA
#' 1   0       0
#' 2   1       1
#' 3   2       4
#' 4   3       0
#' 5   4       0
#' 6   5       0
#' 7   6       5
#' 8   7       3
#' 9   8       0
#' 10  9       0
#' 11 10       0
#' }
#' Call the function:
#' \preformatted{
#' > cesm <- hanaml.Croston(data = data,
#'                          alpha=0.1,
#'                          forecast.num=1,
#'                          method='sporadic',
#'                          accuracy.measure='mape')
#' }
#' Output:
#' \preformatted{
#' > cesm[[2]]$Collect()
#'   STAT_NAME    STAT_VALUE
#' 1      MAPE     0.2432182
#' }
#' @keywords TimeSeries
#' @export
hanaml.Croston <- function(data,
                           key = NULL,
                           endog = NULL,
                           alpha = NULL,
                           forecast.num = NULL,
                           method = NULL,
                           accuracy.measure = NULL,
                           ignore.zero = NULL,
                           expost.flag = NULL) {

  ExpSmoothingBase(data = data,
                   key = key,
                   endog = endog,
                   alpha = alpha,
                   forecast.num = forecast.num,
                   method = method,
                   accuracy.measure = accuracy.measure,
                   ignore.zero = ignore.zero,
                   expost.flag = expost.flag,
                   exp.smooth.function = "PAL_CROSTON"
 )
}

#' @title  Change-point Detection
#' @name hanaml.CPD
#' @description hanaml.CPD is a R wrapper
#'  for SAP HANA PAL change-point detection algorithm.
#' @details   Change-point detection (CPD) methods aim at detecting multiple abrupt changes such as change in mean,
#'            variance or distribution in an observed time-series data.
#' @param     data \code{DataFrame}\cr
#'            Input data for change-point detection.
#' @param     key \code{character, optional}\cr
#'            Column name for time-stamp of the input time-series data.
#' @param     features \code{character, optional}\cr
#'            Column name(s) for the value(s) of the input time-series data.
#' @param     cost \code{c("normal.mse", "normal.rbf", "normal.mhlb", "normal.mv", "linear", "gamma", "poisson",
#'            "exponential", "normal.m", "negbinomial"), optional}\cr
#'            The cost function for change-point detection.\cr
#'            Defaults to 'normal_mse'.
#' @param     penalty \code{ c("aic", "bic", "mbic", "oracle", "custom"), optional}\cr
#'            The penalty function for change-point detection.
#'            Defaults to
#'            \itemize{
#'            \item{(1)}"aic" if \code{solver} is "pruneddp", "pelt" or "opt",
#'            \item{(2)}"custom" if \code{solver} is "adppelt".
#'            }
#' @param     custom.pen \code{numeric, optional}\cr
#'            Specified the value of customized penalty.\cr
#'            Valid when \code{penalty} is "custom" or \code{solver} is "adppelt".
#' @param     solver \code{("pelt", "opt", "adpelt", "pruneddp"), optional}\cr
#'            Method for finding change-points of given data, cost and penalty.
#'            Each solver supports different cost and penalty functions.
#'            \itemize{
#'            \item{1}  For cost functions, "pelt", "opt" and "adpelt" support the following eight:\cr
#'            "normal_mse", "normal_rbf", "normal_mhlb", "normal_mv", \cr
#'            "linear", "gamma", "poisson", "exponential"; \cr
#'            while "pruneddp" supports the following four cost functions: \cr
#'            "poisson", "exponential", "normal_m", "negbinomial".
#'            \item{2}  For penalty functions, "pruneddp" supports all penalties,
#'            "pelt", "opt" and "adppelt" support the following three: \cr
#'            "aic","bic","custom", while "adppelt" only supports "custom" penalty.
#'            }
#'            Defaults to "pelt".
#' @param     lambda \code{double, optional}\cr
#'            Assigned weight of the penalty w.r.t. the cost function, i.e. penalizaion factor. \cr
#'            It can be seen as trade-off between speed and accuracy of running the detection algorithm. \cr
#'            A small values (usually less than 0.1) will dramatically improve the efficiency.\cr
#'            Defaults to 0.02, and valid only when \code{solver} is "pelt" or "adppelt".
#' @param     min.size \code{integer, optional}\cr
#'            The minimal length from the very begining within which change would not happen.\cr
#'            Defaults to 2, valid only when \code{solver} is "opt", "pelt" or "adppelt".
#' @param     min.sep \code{integer, optional}\cr
#'            The minimal length of speration between consecutive change-points.\cr
#'            Defaults to 1, valid only when \code{solver} is "opt", "pelt" or "adppelt".
#' @param     max.k \code{integer, optional}\cr
#'            The maximum number of change-points to be detected. If the given value is less
#'            than 1, this number would be determined automatically from the input data.\cr
#'            Defaults to 0, vaild only when \code{solver} is "pruneddp".
#' @param     dispersion \code{double, optional}\cr
#'            Dispersion coefficient for Gamma and negative binomial distribution.\cr
#'            Defaults to 1.0, valid only when \code{cost} is "gamma" or "negbinomial".
#' @param     lambda.range \code{two numerical values, optional(deprecated)}\cr
#'            Specifies the range for customized penalty, e.g.
#'            \itemize{
#'              lambda.range <- c(0.01, 0.1) means the range of [0.01, 0.1].
#'            }
#'            Valid when \code{solver} is "adppelt" and \code{custom.pen} is not specified.
#'            Deprecated, please use \code{range.penalty} instead.
#' @param     max.iter \code{integer, optional}\cr
#'            Maximum number of iterations for searching the best penalty.
#'            Valid only when \code{solver} is "adppelt".\cr
#'            Defaults to 40.
#' @param     range.penalty \code{list/vector of two numerical values, optional}\cr
#'            Specifies the range for customized penalty, e.g.
#'            \itemize{
#'              range.penalty <- c(0.01, 0.1) means the range of [0.01, 0.1].
#'            }
#'            Valid when \code{solver} is "adppelt" and \code{value.penalty} is not specified.
#'            Defaults to c(0.01, 100).
#' @return
#' Returns a list of two DataFrame:
#' \itemize{
#' \item{\code{DataFrame 1}}\cr
#'   Detected change-points of the input time-series.
#' \item{\code{DataFrame 2}}\cr
#'   Statistics for running change-point detection on the input data.
#' }
#' @section Examples:
#' Call the function:
#' \preformatted{
#' > res <- hanaml.CPD(data = df,
#'                     solver ="pelt",
#'                     cost ="normal.mse",
#'                     penalty = "aic",
#'                     lambda = 0.02)
#' }
#' @keywords TimeSeries
#' @export
hanaml.CPD <- function(data,
                       key,
                       features = NULL,
                       cost = NULL,
                       penalty = NULL,
                       custom.pen = NULL,
                       solver = NULL,
                       lambda = NULL,
                       min.size = NULL,
                       min.sep = NULL,
                       max.k = NULL,
                       dispersion = NULL,
                       lambda.range = NULL,
                       max.iter = NULL,
                       range.penalty = NULL) {
  solver.map <- list(
    "pelt" = "Pelt",
    "opt" = "Opt",
    "adppelt" = "AdpPelt",
    "pruneddp" = "PrunedDP"
  )
  penalty.map <- list(
    "aic" = "AIC",
    "bic" = "BIC",
    "mbic" = "mBIC",
    "oracle" = "Oracle",
    "custom" = "Custom"
  )
  cost.map <- list(
    "normal.mse" = "Normal_MSE",
    "normal.rbf" = "Normal_RBF",
    "normal.mhlb" = "Normal_MHLB",
    "normal.mv" = "Normal_MV",
    "linear" = "Linear",
    "gamma" = "Gamma",
    "poisson" = "Poisson",
    "exponential" = "Exponential",
    "normal.m" = "Normal_M",
    "negbinomial" = "NegBinomial")
  cost <- validateInput("cost", cost, cost.map)
  penalty <- validateInput("penalty", penalty, penalty.map)
  custom.pen <- validateInput("custom.pen", custom.pen, "numeric")
  solver <- validateInput("solver", solver, solver.map)
  lambda <-  validateInput("lambda", lambda, "double")
  min.size <- validateInput("min.size", min.size, "integer")
  min.sep <- validateInput("min.sep", min.sep, "integer")
  max.k <- validateInput("max.k", max.k, "integer")
  dispersion <- validateInput("dispersion", dispersion,
                              "double")
  if (isTRUE(is.list(lambda.range))) {
    lambda.range <- unlist(lambda.range)
  }
  lambda.range <- validateInput("lambda.range", lambda.range, "numeric")
  if (!is.null(range.penalty)) {
      if (isTRUE(is.list(range.penalty))) {
        range.penalty <- unlist(range.penalty)
      }
      range.penalty <- validateInput("range.penalty", range.penalty, "numeric")
  }
  max.iter <- validateInput("max.iter", max.iter, "integer")
  if (is.null(solver)){
    solver <- "pelt"
  }
  if (is.null(penalty)){
    penalty <- "aic"
  }
  if (!(isTRUE(penalty  == "custom") || isTRUE(solver == "adppelt"))) {
      custom.pen <- NULL
  }
  if (!is.null(penalty)) {
    if (solver %in% c("pelt", "opt")) {
      if (!penalty %in% c("aic", "bic", "custom")) {
        msg <-
          paste(
            "Wrong setting for parameter 'penalty',",
            "pelt and opt solvers only support penalty",
            "type aic, bic and custom.")
        flog.error(msg)
        stop(msg)
      }
    }
    if (solver == "adppelt") {
      if (penalty != "custom") {
        msg <-
          paste(
            "Wrong setting for parameter 'penalty',",
            "adppelt solver only supports custom penelty.")
        flog.error(msg)
        stop(msg)
      }
    }
  }
  if (!is.null(cost)) {
    if (map.null(cost, cost.map) %in% cost.map[1:6]) {
      if (solver == "pruneddp") {
        msg <-
          paste(
            "Wrong setting for parameter 'cost',",
            "pruneddp solver does not support the specified cost function."
          )
        flog.error(msg)
        stop(msg)
      }
    } else if (map.null(cost, cost.map) %in% cost.map[9:10]) {
      if (solver %in% c("pelt", "opt", "adppelt")) {
        msg <-
          paste(
            "Wrong setting for parameter 'cost',",
            "pelt, opt, adppelt solvers do not support",
            "the specified cost function.")
        flog.error(msg)
        stop(msg)
      }
    }
  }
  if (!is.null(lambda)) {
    if (!solver %in% c("pelt", "adppelt")) {
      msg <-
        paste(
          "Parameter 'lambda' is only valid for",
          "pelt and adppelt solver."
        )
      flog.error(msg)
      stop(msg)
    }
  }
  if (!is.null(min.size)) {
    if (!solver %in% c("opt", "pelt", "adppelt")) {
      msg <-
        paste(
          "Parameter 'min.size' is only valid",
          "for opt, pelt and adppelt solvers."
        )
      flog.error(msg)
      stop(msg)
    }
  }
  if (!is.null(min.sep)) {
    if (!solver %in% c("opt", "pelt", "adppelt")) {
      msg <-
        paste(
          "Parameter 'min.sep' is only valid for",
          "opt, pelt and adppelt solvers."
        )
      flog.error(msg)
      stop(msg)
    }
  }
  if (!is.null(max.k)) {
    if (solver != "pruneddp") {
      msg <-
        paste(
          "Parameter 'max.k' is only valid",
          "for pruneddp solver."
        )
      flog.error(msg)
      stop(msg)
    }
  }
  if (!is.null(lambda.range) && is.null(range.penalty)) {
    if (solver != "adppelt") {
      msg <-
        paste(
          "Parameter 'lambda.range' is only valid for",
          "adppelt solver.")
      flog.error(msg)
      stop(msg)
    }
  }
  if (!is.null(range.penalty)) {
    if (solver != "adppelt") {
      msg <-
        paste(
          "Parameter 'range.penalty' is only valid for",
          "adppelt solver.")
      flog.error(msg)
      stop(msg)
    }
  }
  if (!is.null(max.iter)) {
    if (solver != "adppelt") {
      msg <-
        paste(
          "Parameter 'max.iter' is only valid for",
          "adppelt solver.")
      flog.error(msg)
      stop(msg)
    }
  }
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as DataFrame."
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn.context <- data$connection.context
  cols.left <- data$columns
  key <- validateInput("key", key, cols.left,
                       case.sensitive = TRUE)
  cols.left <- cols.left[!cols.left %in% key]
  features <- validateInput("features", features,
                            cols.left,
                            case.sensitive = TRUE)
  if (is.null(features)) {
    features <- cols.left
  }
  selected.cols <- append(key, features)
  data <- data$Select(selected.cols)
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <-
    sprintf("#PAL_CPD_PARAM_TBL_%s", unique.id)#nolint
  result.tbl <-
    sprintf("#PAL_CPD_MODEL_TBL_%s", unique.id)#nolint
  stats.tbl <-
    sprintf("#PAL_CPD_TBL_%s", unique.id)#nolint

  param.rows <- list(
    tuple(
      "COSTFUNCTION",
      NULL,
      NULL,
      map.null(cost, cost.map)
    ),
    tuple(
      "PENALTY",
      NULL,
      custom.pen,
      map.null(penalty, penalty.map)
    ),
    tuple(
      "SOLVER",
      NULL,
      NULL,
      map.null(solver, solver.map)
    ),
    tuple("PENALIZATION_FACTOR",  NULL, lambda, NULL),
    tuple("MIN_SIZE", min.size, NULL, NULL),
    tuple("MIN_SEP", min.sep, NULL, NULL),
    tuple("MaxK", max.k, NULL, NULL),
    tuple("DISPERSION", NULL, dispersion, NULL),
    tuple("MAX_ITERATION", max.iter, NULL, NULL)
  )
  if (!is.null(range.penalty)) {
    lambda.range <- range.penalty
  }
  if (!is.null(lambda.range)){
    param.rows <- append(param.rows, list(
      tuple("RANGE_PENALTIES", NULL, NULL,
            sprintf("[%s]",
                    paste(lambda.range,
                          collapse = ",")))))
  }
  tables <- list(param.tbl, result.tbl, stats.tbl)
  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl, stats.tbl)
  tryCatch({
    errorhelper(CreateTWithConnection(conn.context,
                                      ParameterTable$new(param.tbl)$WithData(param.rows))) #nolint
    errorhelper(CallPalAutoWithConnection(conn.context,
                                          "PAL_CPDETECTION", in.tables, out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn.context,
                          tables)
    stop(msg)
  })
  conn <- conn.context
  return(list(conn$table(result.tbl), conn$table(stats.tbl)))
}

#' @title Hierarchical Forecast
#' @name hanaml.HierarchicalForecast
#' @description hanaml.HierarchicalForecast is a R wrapper
#' for SAP HANA PAL hierarchy forecast algorithm.
#' @details   Hierarchical forecast algorithm forecast across the hierarchy
#'            (that is, ensuring the forecasts sum appropriately across the levels).
#' @param     orig.data \code{DataFrame}\cr
#'            DataFrame of original data.\cr
#'            By default, it is assumed that \code{orig.data} is organized as follows:\cr
#'            1st column for names of time-series, 2nd column for time stamp, 3rd column for raw data,
#'            4th column for residuals of base forecasts.
#' @param     pred.data \code{DataFrame}\cr
#'            DataFrame of predictive data.\cr
#'            By default, it is assumed that \code{pred.data} is organized as follows:\cr
#'            1st column for names of time-series, 2nd column for time stamp,
#'            3rd column for predictive raw data.
#' @param     stru.data \code{DataFrame}\cr
#'            DataFrame of structure data.\cr
#'            It must be structured as follows:
#'            1st column for ID,
#'            2nd column for time-series names,
#'            3rd column for hierarchical tree structure of time-series,
#'            which is the number of nodes at each level.
#' @param     orig.cols \code{list of character, optional}\cr
#'            If the input \code{orig.data} is not organized by its default setting, then we can use \code{orig.cols}
#'            to set up the correct assignment of columns for \code{orig.data} as follows:\cr
#'            \itemize{
#'            orig.cols = (name = [time-series names column],
#'                         key = [time stamp column],
#'                         endog = [raw data column],
#'                         residual = [residual column])
#'            }
#'            Note that you need to specify \code{all four} columns for making this parameter
#'            effective, otherwise an error message shall be issued.
#' @param     pred.cols \code{list of character, optional}\cr
#'            If the input \code{pred.data} is not organized by its default setting, then we can use \code{pred.cols}
#'            to set up the correct assignment of columns for \code{pred.data} as follows:\cr
#'            \itemize{
#'            pred.cols = (name = [time-series names column],
#'                         key = [time stamp column],
#'                         endog = [predictive raw data column])
#'            }
#'            Note that you need to specify \code{all three} columns for making this parameter
#'            effective, otherwise an error message shall be issued.
#' @param     method \code{('optimal.combination', 'bottom.up', 'top.down'), optional}\cr
#'            Method for reconciling forecasts across hierarchy.\cr
#'            Default to 'optimal_combination'.
#' @param     weights \code{('ordinary.least.squares', 'minimum.trace', 'weighted.least.squares'), optional}\cr
#'            Specifies the method to assign weights to base forecasts in different hierarchies.\cr
#'            Only valid when parameter method is 'optimal.combination'.\cr
#'            Default to 'ordinary.least.squares'.
#' @return
#' Returns a list of two DataFrames:
#' \itemize{
#' \item{\code{DataFrame 1} result: DataFrame for Forecast result.}\cr
#' \item{\code{DataFrame 2} stats: DataFrame for Statistics analysis content.}\cr
#' }
#' @section Examples:
#' Input DataFrame data.orig:
#' \preformatted{
#' > data.orig$Collect()
#'    Series TimeStamp  Original     Residual
#' 1   Total      1992 48.748080  0.058251736
#' 2   Total      1993 49.480469  0.236069215
#' 3   Total      1994 49.932384 -0.044404927
#' 4   Total      1995 50.240702 -0.188001523
#' 5   Total      1996 50.608464 -0.128557779
#' 6   Total      1997 50.848506 -0.256277857
#' 7   Total      1998 51.709220  0.364393685
#' 8   Total      1999 51.943298 -0.262241472
#' 9   Total      2000 52.577956  0.138337958
#' 10  Total      2001 53.214959  0.140682700
#' 11      A      1992 27.211338  0.026941198
#' 12      A      1993 27.838827  0.357361180
#' 13      A      1994 28.145348  0.036394576
#' 14      A      1995 28.277125 -0.138351039
#' 15      A      1996 28.478001 -0.069250754
#' 16      A      1997 28.564466 -0.183661771
#' 17      A      1998 28.907533  0.072939797
#' 18      A      1999 29.021548 -0.156112852
#' 19      A      2000 29.403080  0.111405265
#' 20      A      2001 29.642483 -0.030724402
#' 21      B      1992 21.536742  0.021310538
#' 22      B      1993 21.641642 -0.121291965
#' ......
#' }
#' Input DataFrame data.pred:
#' \preformatted{
#' > data.pred$Collect()
#'    Series TimeStamp     Value
#' 1   Total      1993 54.711279
#' 2   Total      1994 54.207598
#' 3   Total      1995 54.703918
#' 4   Total      1996 55.200238
#' 5   Total      1997 55.696558
#' 6   Total      1998 56.192878
#' 7       A      1993 29.912610
#' 8       A      1994 30.182737
#' 9       A      1995 30.452864
#' 10      A      1996 30.722991
#' 11      A      1997 30.993119
#' 12      A      1998 31.263246
#' 13      B      1993 23.798669
#' 14      B      1994 24.024861
#' 15      B      1995 24.251054
#' 16      B      1996 24.477247
#' ......
#' }
#' Invoke the function:
#' \preformatted{
#' > res <- hanaml.HierarchicalForecast(orig.data = data.orig,
#'                                      pred.data = data.pred,
#'                                      orig.cols = list(key = "TimeStamp",
#'                                                       name = "Series",
#'                                                       endog = "Original",
#'                                                       residual = "Residual"),
#'                                      stru.data = struct.df,
#'                                      method = "optimal.combination",
#'                                      weights = "minimum.trace")
#' }
#' Ouput:
#' \preformatted{
#' > res[[1]]$Collect()
#'    Series TimeStamp     Value
#' 1   Total      1993 48.862705
#' 2   Total      1994 54.255631
#' 3   Total      1995 54.663688
#' 4   Total      1996 55.192436
#' 5   Total      1997 55.719965
#' 6   Total      1998 56.434261
#' 7       A      1993 27.204558
#' 8       A      1994 30.215278
#' 9       A      1995 30.424968
#' 10      A      1996 30.718347
#' 11      A      1997 31.007053
#'
#' }
#' @keywords TimeSeries
#' @export
hanaml.HierarchicalForecast <- function(orig.data,
                                        pred.data,
                                        stru.data,
                                        orig.cols = NULL,
                                        pred.cols = NULL,
                                        method = NULL,
                                        weights = NULL){
  method.list <- list(
    "optimal.combination" = 0,
    "bottom.up" = 1,
    "top.down" = 2
  )
  weights.list <- list(
    "ordinary.least.squares" = 0,
    "minimum.trace" = 1,
    "weighted.least.squares" = 2
  )
  col.names <- c("name", "key", "endog", "residual")
  method <- validateInput("method", method, method.list)
  weights <- validateInput("weights", weights, weights.list)
  if (!is.null(weights) &&
      isTRUE(!is.null(method) && method != "optimal.combination")){
    msg <- paste("The weight parameter is valid only when",
                 "method is set to 'optimal.combination'.")
    flog.error(msg)
    stop(msg)
  }

  orig.columns <- orig.data$columns
  orig.cols <- validateInput("orig.cols", orig.cols, orig.columns,
                             case.sensitive = TRUE)
  if (!is.null(orig.cols)){
    if (length(unique(orig.cols)) != 4 ||
        length(setdiff(names(orig.cols),
                       col.names)) != 0){
      msg <- paste("Exactly four different columns from original",
                   "data need to be specified and assigned to name",
                   "key, endog and residual, respectively.")
      flog.error(msg)
      stop(msg)
    }
  } else {
    orig.cols <- list(name = orig.columns[[1]],
                      key = orig.columns[[2]],
                      endog = orig.columns[[3]],
                      residual = orig.columns[[4]])
  }
  pred.columns <- pred.data$columns
  pred.cols <- validateInput("pred.cols", pred.cols, pred.columns,
                             case.sensitive = TRUE)
  if (!is.null(pred.cols)){
    if (length(unique(pred.cols)) != 3 ||
        length(setdiff(names(pred.cols),
                       col.names[1:3])) != 0){
      msg <- paste("Exactly three different columns from predictive",
                   "data need to be specified and assigned to name",
                   "key and endog, respectively.")
      flog.error(msg)
      stop(msg)
    }
  } else {
    pred.cols <- list(name = pred.columns[[1]],
                      key = pred.columns[[2]],
                      endog = pred.columns[[3]])
  }
  if (!all(sapply(list(orig.data,
                       pred.data,
                       stru.data),
                  inherits,
                  what = "DataFrame"))){
    msg <- paste("Original data, predictive data",
                 "and structure data must all be DataFrames.")
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(orig.data)
  conn.context <- orig.data$connection.context
  orig.data <- orig.data$Select(list(orig.cols[["name"]],
                                     orig.cols[["key"]],
                                     orig.cols[["endog"]],
                                     orig.cols[["residual"]]))
  pred.data <- pred.data$Select(list(pred.cols[["name"]],
                                     pred.cols[["key"]],
                                     pred.cols[["endog"]]))
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <-
    sprintf("#PAL_HF_PARAM_TBL_%s", unique.id)
  result.tbl <-
    sprintf("#PAL_HF_MODEL_TBL_%s", unique.id)
  stats.tbl <-
    sprintf("#PAL_HF_TBL_%s", unique.id)

  param.rows <- list(tuple(
    "METHOD",
    map.null(method, method.list),
    NULL,
    NULL
  ),
  tuple(
    "WEIGHTS",
    map.null(weights, weights.list),
    NULL,
    NULL
  ))

  tables <- list(param.tbl, result.tbl, stats.tbl)
  in.tables <- list(orig.data, pred.data, stru.data, param.tbl)
  out.tables <- list(result.tbl, stats.tbl)
  tryCatch({
    errorhelper(CreateTWithConnection(conn.context,
                                      ParameterTable$new(param.tbl)$WithData(param.rows))) #nolint
    errorhelper(CallPalAutoWithConnection(conn.context,
                                          "PAL_HIERARCHICAL_FORECAST",
                                          in.tables, out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn.context,
                          tables)
    stop(msg)
  })
  conn <- conn.context
  return(list(conn$table(result.tbl), conn$table(stats.tbl)))
}
