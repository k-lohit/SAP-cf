FeatureNormalizer <- R6Class(
  "FeatureNormalizer",
  inherit = MlBase,
  public = list(
    method = NULL,
    z.score.method = NULL,
    new.max = NULL,
    new.min = NULL,
    thread.ratio = NULL,
    division.by.zero.handler = NULL,
    result = NULL,
    model = NULL,
    stats = NULL,
    method.map = list(
      "min.max" = 0,
      "z.score" = 1,
      "decimal" = 2
    ),
    z.score.method.map = list(
      "mean.standard" = 0,
      "mean.mean" = 1,
      "median.median" = 2
    ),
    zero.handle.map = list(ignore = 0, throw.error = 1),
    initialize = function(method = NULL,
                          data = NULL,
                          features = NULL,
                          key = NULL,
                          z.score.method = NULL,
                          new.max = NULL,
                          new.min = NULL,
                          thread.ratio = NULL,
                          division.by.zero.handler = NULL) {
      super$initialize()
      if (!is.null(data)){
        self$method <- validateInput("method", method,
                                      self$method.map, required = TRUE)
        self$z.score.method <-
          validateInput("z.score.method", z.score.method,
                        self$z.score.method.map,
                        required = isTRUE(grepl("score", self$method)))
        self$new.max <-
          validateInput("new.max", new.max, "double",
                        required = grepl("min", self$method))
        self$new.min <-
          validateInput("new.min", new.min, "double",
                        required = grepl("min", self$method))

        if (isTRUE(self$method  !=  "min.max")) {
          if (!(is.null(new.min) && is.null(new.max))) {
            msg <- paste("new.min and new.max is not applicable",
                         "when scale method is not min.max!")
            flog.warn(msg)
          }
        }
         self$division.by.zero.handler <-
           validateInput("division.by.zero.handler",
                         division.by.zero.handler,
                         self$zero.handle.map)
        self$thread.ratio <-
          validateInput("thread.ratio", thread.ratio, "numeric")

        if (!is.null(thread.ratio)) {
          if (!(thread.ratio >= 0 && thread.ratio <= 1)) {
            msg <- sprintf("thread.ratio %s is out of bounds", thread.ratio)
            flog.error(msg)
            stop(msg)
          }
        }
        cols <- data$columns
        key <- validateInput("key", key, cols, case.sensitive = TRUE)
        if (is.null(key)) {
          key <- cols[[1]]
        }
        cols <- cols[!cols %in% key]
        features <-
          validateInput("features", features, cols, case.sensitive = TRUE)
        if (is.null(features)) {
          features <- cols
        }
        if (!inherits(data, "DataFrame")) {
          msg <- "If training data is not omitted, it must be DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn.context <- data$connection.context
        selected <- append(key, features)
        data <- data$Select(selected)

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <-
          sprintf("#PAL_FN_PARAM_TBL_%s_%s", self$id, unique.id)
        result.tbl <-
          sprintf("#PAL_FN_RESULT_TBL_%s_%s", self$id, unique.id)
        model.tbl <-
          sprintf("#PAL_FN_MODEL_TBL_%s_%s", self$id, unique.id)
        statistic.tbl <-
          sprintf("#PAL_FN_STATISTIC_TBL_%s_%s", self$id, unique.id)
        placeholder.tbl <-
          sprintf("#PAL_FN_PLACEHOLDER_TBL_%s_%s", self$id, unique.id)
        tables <- list(param.tbl, result.tbl, model.tbl, statistic.tbl,
                       placeholder.tbl)
        in.tables <- list(data, param.tbl)
        out.tables <- list(result.tbl, model.tbl, statistic.tbl,
                           placeholder.tbl)

        param.rows <- list(tuple("SCALING_METHOD",
                                 map.null(self$method, self$method.map),#nolint
                                 NULL, NULL),
                           tuple("Z-SCORE_METHOD",
                                 map.null(self$z.score.method,
                                          self$z.score.method.map),#nolint
                                 NULL, NULL),
                           tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
                           tuple("NEW_MAX", NULL, self$new.max, NULL),
                           tuple("NEW_MIN", NULL, self$new.min, NULL),
                           tuple("DIVISION_BY_ZERO_HANDLER",
                                 map.null(self$division.by.zero.handler,
                                          self$zero.handle.map),
                                 NULL, NULL))
        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
            (ParameterTable$new(param.tbl))$WithData(param.rows))) #nolint
          errorhelper(CallPalAutoWithConnection(conn.context,
            "PAL_SCALE", in.tables, out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        self$result <- conn.context$table(result.tbl)
        self$model <- conn.context$table(model.tbl)
        self$stats <- conn.context$table(statistic.tbl)
      }
    }
  )
)
#' @title Feature Normalizer
#' @name hanaml.FeatureNormalizer
#' @description hanaml.FeatureNormalizer is a R wrapper for SAP HANA PAL scale algorithm.
#' @details Class to Normalize input data and generate a scaling model
#'  using one of the three scaling methods:
#'  min.max normalization, z.score normalization and normalization in decimal scaling.
#'  The transform function can be used to perform transform on the given DataFrame.
#' @seealso \code{\link{transform.FeatureNormalizer}}
#' @template args-data
#' @template args-key
#' @template args-feature-multiple
#' @param   method \code{{'min.max', 'z.score', 'decimal'}, optional}\cr
#'          Invokes one of the following scaling methods:
#'          \itemize{
#'          \item{\code{'min.max'} - min.max normalization.}
#'          \item{\code{'z.score'} - z.score normalization.}
#'          \item{\code{'decimal'} - Decimal scaling normalization.}
#'          }
#' @param   z.score.method \code{{'mean.standard', 'mean.mean', 'median.median'}, optional}\cr
#'          Only valid when \code{method} is 'z.score'.
#'          \itemize{
#'          \item{\code{'mean.standard'} - Mean-Standard deviation.}
#'          \item{\code{'mean.mean'} - mean.mean deviation.}
#'          \item{\code{'median.median'} - median.median absolute deviation.}
#'          }
#' @param   new.max \code{double, optional}\cr
#'          The new maximum value for min.max normalization.
#'          Mandatory and valid only when \code{method} is 'min.max'.
#' @param   new.min \code{double, optional}\cr
#'          The new minimum value for min.max normalization.
#'          Mandatory and valid Only when \code{method} is 'min.max'.
#' @template args-threadratio
#' @param   division.by.zero.handler \code{c("ignore", "throw.error"), optional} \cr
#'          Specifies what to do when encountering a division by zero.
#'          \itemize{
#'          \item{"ignore":} ignores the column when encountering a division by zero.
#'          \item{"throw.error":} throws an error when encountering a division by zero.
#'          }
#' @return
#' Returns a "FeatureNormalizer" object with following values:
#' \itemize{
#' \item{result : \code{DataFrame}}\cr
#' Scaled dataset from fit and fit_transform methods.
#'   \itemize{
#'     \item{DATA_ID}: name as shown in input DataFrame.
#'     \item{DATA_FEATURES}: name as shown in input table column name.
#'   }
#' \item{model : \code{DataFrame}}\cr
#'  Trained model content., structured as follows:
#'  \itemize{
#'    \item{ID} :  Scaling model ID
#'    \item{MODEL_CONTENT} : Binning model saved as JSON string.
#'       The table must be a column table. The minimum length of each
#'       unit (row) is 5000.
#'  }
#' \item{statistics : \code{DataFrame}}\cr
#'  Statistic results, structured as follows:
#'  \itemize{
#'    \item{STAT_NAME} :  statistic name.
#'    \item{STAT_VALUE} : statistic value.
#'  }
#'}
#'
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#'  > data$Collect()
#'      ID   X1   X2
#'    1  0  6.0  9.0
#'    2  1 12.1  8.3
#'    3  2 13.5 15.3
#'    4  3 15.4 18.7
#'    5  4 10.2 19.8
#'    }
#' Call the function:
#' \preformatted{
#' fn <- hanaml.FeatureNormalizer(data = data,
#'                                key = "ID",
#'                                method="min.max",
#'                                new.max=1.0,
#'                                new.min=0.0)
#' }
#' Output:
#' \preformatted{
#' > fn$result$Collect()
#'      ID        X1         X2
#'   1   0 0.0000000 0.03317536
#'   2   1 0.1865443 0.00000000
#'   3   2 0.2293578 0.33175355
#'   4   3 0.2874618 0.49289100
#'   5   4 0.1284404 0.54502370
#'   6   5 0.5290520 0.58293839
#'   7   6 0.5626911 0.75829384
#'   8   7 0.7522936 0.80568720
#'   9   8 0.8103976 0.91469194
#'   10  9 0.5993884 0.95734597
#'   11 10 1.0000000 1.00000000
#'   12 11 1.0000000 1.00000000
#'
#'}
#' @keywords Preprocessing
#' @export
hanaml.FeatureNormalizer <- function(method = NULL, data = NULL, features= NULL,
                                     key = NULL, z.score.method = NULL, new.max = NULL,
                                     new.min = NULL, thread.ratio = NULL,
                                     division.by.zero.handler = NULL){
  FeatureNormalizer$new(method, data, features, key,
                        z.score.method, new.max, new.min,
                        thread.ratio, division.by.zero.handler)
}

#' @title Make Transform from a "FeatureNormalizer" Object
#' @name transform.FeatureNormalizer
#' @description Similar to other transform methods, this function
#' transformed values from a fitted "FeatureNormalizer" object.
#' @seealso \code{\link{hanaml.FeatureNormalizer}}
#' @param model \code{R6Class object}\cr A "FeatureNormalizer" Object.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @template args-threadratio
#' @param    division.by.zero.handler \code{logical, optional}\cr
#'          If TRUE, Throws an error when encountering a division by zero. If FALSE,
#'          ignores the column when encountering a division by zero. The column is not scaled.
#' @return \code{Dataframe}\cr
#' Transformed variable values corresponding to each data point,
#' structured as follows:
#' \itemize{
#'   \item{ID column, with same name and type as \emph{data}'s ID column.}
#'   \item{Score columns, type DOUBLE, representing the component score
#'   values of each data point.}
#' }
#' @section Examples:
#' Input DataFrame data2 for transform:
#' \preformatted{
#' > data2$Collect()
#'      ID S_X1 S_X2
#'    1  0    6    9
#'    2  1    6    7
#'    3  2    4    4
#'    4  3    1    2
#'    5  4    9   -2
#' }
#'
#' Perform transform() on the given data2 and "FeatureNormalizer" Object fn:
#' \preformatted{
#' > result <- transform(fn, data = data2, key = "ID")
#' }
#' Output:
#' \preformatted{
#' > result$Collect()
#'     ID        S_X1        S_X2
#'   1  0  0.00000000  0.03317536
#'   2  1  0.00000000 -0.06161137
#'   3  2 -0.06116208 -0.20379147
#'   4  3 -0.15290520 -0.29857820
#'   5  4  0.09174312 -0.48815166
#'   6  5 -0.06116208 -0.15639810
#'
#' }
#' @export
#' @keywords Preprocessing
transform.FeatureNormalizer <- function(model,
                                        data,
                                        key,
                                        features=NULL,
                                        thread.ratio = NULL,
                                        division.by.zero.handler = NULL){
  if (is.null(model$model)) {
    msg <- "Model is not initialized!"
    flog.error(msg)
    stop(msg)
  }

  division.by.zero.handler <-
    validateInput("division.by.zero.handler",
                  division.by.zero.handler, "logical")
  thread.ratio <-
    validateInput("thread.ratio", thread.ratio, "numeric")

  cols <- data$columns
  key <- validateInput("key", key, cols, required = TRUE, case.sensitive = TRUE)
  cols <- cols[!cols %in% key]
  features <-
    validateInput("features", features, cols, case.sensitive = TRUE)
  if (is.null(features)) {
    features <- cols
  }
  CheckConnection(data)
  conn.context <- data$connection.context
  selected <- append(key, features)
  data <- data$Select(selected)
  unique.id <-
    toupper(gsub("-", "_", UUIDgenerate()))  #require UUID package
  param.tbl <-
    sprintf("#PAL_FN_PARAM_TBL_%s_%s", model$id, unique.id)
  result.tbl <-
    sprintf("#PAL_FN_RESULT_TBL_%s_%s", model$id, unique.id)
  param.rows <- list( tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
                      tuple("DIVISION_BY_ZERO_HANDLER",
                            map.null(division.by.zero.handler,
                                     model$zero.handle.map),
                            NULL, NULL))
  tables <- list(param.tbl, result.tbl)
  in.tables <- list(data, model$model$name, param.tbl)
  out.tables <- list(result.tbl)
  tryCatch({
    errorhelper(CreateTWithConnection(conn.context,
      (ParameterTable$new(param.tbl))$WithData(param.rows))) #nolint
    errorhelper(CallPalAutoWithConnection(conn.context,
      "PAL_SCALE_WITH_MODEL", in.tables, out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn.context, tables)
    stop(msg)
  })
  return(conn.context$table(result.tbl))
}
