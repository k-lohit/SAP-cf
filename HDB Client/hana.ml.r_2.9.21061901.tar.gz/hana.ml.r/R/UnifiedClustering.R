UnifiedClustering <- R6Class(
  "UnifiedClustering",
  inherit = MlBase,
  public = list(
    params = NULL,
    func = NULL,
    labels = NULL,
    centers = NULL,
    model = NULL,
    statistics = NULL,
    optimal.param = NULL,

    initialize = function(data = NULL,
                          func = NULL,
                          key = NULL,
                          features = NULL,
                          ...) {
      super$initialize()

      if (!is.null(data)) {
        func <- tolower(func)
        self$func <- validateInput("func", func, private$func.list, required = TRUE)
        self$params <- list(func = self$func)
        self$params <- append(self$params, list(...))
        private$pal.params <- list()
        param.names <- names(self$params)

        func.map <- private$map.list[[private$func.list[[self$func]]]]
        valid.names <- names(func.map)

        # GMM mandatory parameter checks
        if (self$func == "gaussianmixture") {
          if (! "init.param" %in% param.names) {
             msg <- "init.param is a madantory parameter for gaussianmixture!"
             flog.error(msg)
             stop(msg)
          }
          method <- self$params[["init.param"]]
          if (method == "manual") {
            msg <- "init.centers is a madantory parameter when init.param is 'manual' of gaussianmixture!"
            if (("init.centers" %in% param.names) && (is.null(self$params[["init.centers"]]))) {
              flog.error(msg)
              stop(msg)
            }
            if (!"init.centers" %in% param.names) {
              flog.error(msg)
              stop(msg)
            }
          }
          if (method %in% c("farthest.first.traversal", "random.means", "k.means++")) {
            msg <- "n.components is a madantory parameter when init.param is not 'manual' of gaussianmixture!"
            if ((! "n.components" %in% param.names) || (is.null(self$params[["n.components"]]))) {
              flog.error(msg)
              stop(msg)
            }
          }
        }

        # AHC parameter checks， distance.level and affinity
        if (self$func == "agglomeratehierarchicalclustering") {
          if (("affinity" %in% param.names) && ("distance.level" %in% param.names) &&
              (self$params[["affinity"]] != self$params[["distance.level"]])){
            self$params <- self$params[names(self$params) != "affinity"]
            param.names <- param.names[param.names != "affinity"]
            msg <-"when affinity and distance.level are both entered in AgglomerateHierarchicalClustering, distance.level takes precedence over affinity!"
            flog.warn(msg)
          }
        }
        # DBSCAN parameter checks， distance.level and metric
        if (self$func == "dbscan") {
          if (("metric" %in% param.names) && ("distance.level" %in% param.names) &&
              (self$params[["metric"]] != self$params[["distance.level"]])){
            self$params <- self$params[names(self$params) != "metric"]
            param.names <- param.names[param.names != "metric"]
            msg <- "when metric and distance.level are both entered in DBSCAN, distance.level takes precedence over affinity!"
            flog.warn(msg)
          }
        }

        if (length(self$params) > 1) {
          for (i in c(2:length(self$params))) {
            par.name <- param.names[i]

            if (! par.name %in% valid.names) {
              msg <- paste("Unrecognized parameter name:", par.name)
              flog.error(msg)
              stop(msg)
              }

            if (par.name %in% c("n.components", "init.centers")) {
              next
            }

            map.value <- func.map[[par.name]]
            if (length(map.value) == 2) {
              constr <- map.value[[2]]
            } else {
              constr <- map.value[[3]]
            }
            par.val <- self$params[[i]]
            if (map.value[[2]] == "list") {
              if (typeof(self$params[[i]]) %in% c("double",
                                                  "integer",
                                                  "character")) {
                if (length(self$params[[i]]) > 1) {#nolint
                  par.val <- as.list(self$params[[i]])
                }
              }
            }
            if (map.value[[2]] == "list" &&
                (is.character(par.val) || is.numeric(par.val))) {
              par.val <- as.list(par.val)
            }
            par.val <- validateInput(par.name, par.val, constr)
            if (length(map.value) == 3) {
              par.val <-  map.value[[3]][[par.val]]
            }
            private$pal.params[[map.value[[1]]]] <- list(par.val,
                                                         map.value[[2]])
          }
        }

        cols <- data$columns
        key <- validateInput("key", key, cols, case.sensitive = TRUE, required=TRUE)
        cols <- cols[! cols %in% key]
        features <- validateInput("features", features, cols, case.sensitive = TRUE)
        if (is.null(features)) {
          features <- cols
        }

        if (("categorical.variable" %in% param.names) && (!is.null(self$params[["categorical.variable"]]))) {
          validateInput("categorical.variable", self$params[["categorical.variable"]],
                        cols, case.sensitive = TRUE)
        }

        if (("string.variable" %in% param.names) && (!is.null(self$params[["string.variable"]]))) {
          validateInput("string.variable", self$params[["string.variable"]],
                        cols, case.sensitive = TRUE)
        }

        if (("variable.weight" %in% param.names) && (!is.null(self$params[["variable.weight"]]))) {
          validateInput("variable.weight", names(self$params[["variable.weight"]]),
                         cols, case.sensitive = TRUE)
          var.weight <- self$params[["variable.weight"]]
          for (i in 1:length(var.weight)) {
            if (!is.numeric(var.weight[[i]])) {
              msg <- "The value of variable.weight should be numeric!"
              flog.error(msg)
              stop(msg)
            }
          }
        }

        param.rows <- list(tuple("FUNCTION", NULL, NULL,
                                 private$func.list[[self$func]]))

        pal.names <- names(private$pal.params)
        for (i in seq_len(length(private$pal.params))) {
          var.name <- pal.names[i]
          var.info <- private$pal.params[[var.name]]
          if (var.info[[2]] == "integer") {
            param.rows <- append(param.rows,
                                 list(tuple(var.name,
                                            var.info[[1]],
                                            NULL, NULL)))
          } else if (var.info[[2]] == "logical") {
            param.rows <- append(param.rows,
                                 list(tuple(var.name,
                                            to.integer(var.info[[1]]),
                                            NULL, NULL)))
          } else if (var.info[[2]] == "numeric") {
            param.rows <- append(param.rows,
                                 list(tuple(var.name,
                                            NULL,
                                            var.info[[1]],
                                            NULL)))
          } else if (var.info[[2]] == "character") {
            param.rows <- append(param.rows,
                                 list(tuple(var.name,
                                            NULL, NULL,
                                            var.info[[1]])))
          } else if (var.name %in% c("CATEGORICAL_VARIABLE",
                                     "STRING_VARIABLE")) {
            for (val in var.info[[1]]) {
              param.rows <- append(param.rows,
                                   list(tuple(var.name,
                                              NULL, NULL,
                                              val)))
            }
          }
         }

        # dbscan AUTO_PARAM handling
        if (self$func == "dbscan") {
          auto.param <- list(tuple("AUTO_PARAM", NULL, NULL, "true"))
          if (("minpts" %in% param.names) && ("eps" %in% param.names)) {
            if ((!is.null(self$params[["minpts"]])) && (!is.null(self$params[["eps"]]))) {
              auto.param <- list(tuple("AUTO_PARAM", NULL, NULL, "false"))
            }
        }
        param.rows <- append(param.rows, auto.param)

        if (("variable.weight" %in% param.names) && (!is.null(self$params[["variable.weight"]]))) {
          weight.name <- names(self$params[["variable.weight"]])

        for (i in seq_len(weight.name)) {
          each.name <- weight.name[[i]]
          param.rows <- append(param.rows,
                               list(tuple("VARIABLE_WEIGHT",
                                          NULL, self$params[["variable.weight"]][[i]], each.name)))
            }
          }
        }

        #gaussianmixture INITIALIZE_PARAMETER handling
        if (self$func == "gaussianmixture") {
          if (self$params[["init.param"]] == "manual") {
            init.centers <- self$params[["init.centers"]]
            if (inherits(init.centers, c("integer", "numeric", "character"))) {
              init.centers <- as.list(init.centers)
            }
            init.centers <- validateInput("init.centers", init.centers, "list")
            for (val in init.centers) {
              param.rows <- append(param.rows,
                                   list(tuple("INITIALIZE_PARAMETER",
                                              NULL, NULL, as.character(val))))
              }
          } else {
            n.components <- self$params[["n.components"]]
            n.components <- validateInput("n.components", n.components, "integer")
            param.rows <- append(param.rows,
                                 list(tuple("INITIALIZE_PARAMETER",
                                            NULL, NULL,
                                            as.character(n.components))))
          }
        }

        if (!inherits(data, "DataFrame")) {
          msg <- "Data for Unified Clustering model fitting must be a DataFrame."
          flog.error(msg)
          stop(msg)
        }

        CheckConnection(data)
        conn.context <- data$connection.context
        input.df <- data$Select(c(key, features))
        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#UNIFIED_CLUSTERING_PARAM_%s_%s",
                             self$id, unique.id)
        labels.tbl <- sprintf("#UNIFIED_CLUSTERING_LABELS_%s_%s",
                             self$id, unique.id)
        centers.tbl <- sprintf("#UNIFIED_CLUSTERING_CENTERS_%s_%s",
                             self$id, unique.id)
        model.tbl <- sprintf("#UNIFIED_CLUSTERING_MODEL_%s_%s",
                             self$id, unique.id)
        stats.tbl <- sprintf("#UNIFIED_CLUSTERING_STATS_%s_%s",
                           self$id, unique.id)
        optimal.param.tbl <- sprintf("#UNIFIED_CLUSTERING_OPT_PARAM_%s_%s",
                                     self$id, unique.id)
        ph1.tbl <- sprintf("#UNIFIED_CLUSTERING_PH1_%s_%s",
                           self$id, unique.id)
        ph2.tbl <- sprintf("#UNIFIED_CLUSTERING_PH2_%s_%s",
                           self$id, unique.id)
        out.tables <- list(labels.tbl, centers.tbl, model.tbl, stats.tbl,
                           optimal.param.tbl, ph1.tbl, ph2.tbl)
        in.tables <- list(input.df, param.tbl)
        tables <- c(param.tbl, out.tables)
        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
                                            (ParameterTable$new(param.tbl))$WithData(param.rows)))
          errorhelper(CallPalAutoWithConnection(conn.context,
                                                "PAL_UNIFIED_CLUSTERING",
                                                in.tables, out.tables))
        },
        error = function(err) {
          msg <- paste("Error:", err$message)
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        self$labels <- conn.context$table(labels.tbl)
        self$centers <- conn.context$table(centers.tbl)
        self$model <- conn.context$table(model.tbl)
        self$statistics <- conn.context$table(stats.tbl)
        self$optimal.param <- conn.context$table(optimal.param.tbl)
        }

    },
    predict = function(data, key, features = NULL, func = NULL) {

      if (is.null(self$func)) {
        func <- validateInput("func", func, private$func.list, required = TRUE)
        real.func <- func
      } else {
        real.func <- self$func
      }

      if (real.func == "agglomeratehierarchicalclustering") {
        msg <- "AgglomerateHierarchicalClustering does not provide predict function!"
        flog.error(msg)
        stop(msg)
      }

      if (is.null(self$model)) {
        msg <- "Model for prediction is NULL!"
        flog.error(msg)
        stop(msg)
      }

      conn.context <- data$connection.context
      if (!inherits(data, "DataFrame")) {
        msg <- "Data for prediction must be a DataFrame."
        flog.error(msg)
        stop(msg)
      }
      CheckConnection(data)

      cols <- data$columns
      key <- validateInput("key", key, cols, required = TRUE,
                           case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      features <- validateInput("features", features, cols,
                                case.sensitive = TRUE)
      if (is.null(features)) {
        features <- cols
      }
      data <- data$Select(c(key, features))
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      param.tbl <- sprintf("#UNIFIED_CLUSTERING_PREDICT_PARAMS_%s_%s",
                           self$id, unique.id)
      assignment.tbl <- sprintf(paste0("#UNIFIED_CLUSTERING_PREDICT",
                                "_ASSIGNMENT_TBL_%s_%s"),
                                self$id, unique.id)
      ph.tbl <- sprintf(paste0("#UNIFIED_CLUSTERING_PREDICT",
                                "_PH_TBL_%s_%s"),
                          self$id, unique.id)
      tables <- list(param.tbl, assignment.tbl, ph.tbl)
      in.tables <- list(data, self$model$name, param.tbl)
      out.tables <- list(assignment.tbl, ph.tbl)
      tryCatch({
        errorhelper(CreateTWithConnection(conn.context,
                                          (ParameterTable$new(param.tbl)))) #nolint
        errorhelper(CallPalAutoWithConnection(conn.context,
                                              "PAL_UNIFIED_CLUSTERING_ASSIGNMENT",#nolint
                                              in.tables, out.tables))
      },
      error = function(err) {
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn.context, tables)
        stop(msg)
      })
      assignment <- conn.context$table(assignment.tbl)
      return(assignment)
    }),
  private = list(
    real.func = NULL,
    pal.params = list(),
    func.list = list(
        agglomeratehierarchicalclustering = "AHC",
        dbscan = "DBSCAN",
        gaussianmixture = "GMM",
        acceleratedkmeans = "AKMEANS",
        kmeans = "KMEANS",
        kmedians = "KMEDIANS",
        kmedoids = "KMEDOIDS",
        som = "SOM"),
    map.list = list(
      "AHC" = list(
        "n.clusters" = list("N_CLUSTERS", "integer"),
        "affinity" = list("AFFINITY", "integer", list("manhattan" = 1, "euclidean" = 2,
                                                      "minkowski" = 3, "chebyshev" = 4,
                                                      "cosine" = 6, "pearson.correlation" = 7,
                                                      "squared.euclidean" = 8,
                                                      "jaccard" = 9, "gower" = 10)),
        "distance.level" = list("DISTANCE_LEVEL", "integer", list("manhattan" = 1, "euclidean" = 2,
                                                                  "minkowski" = 3, "chebyshev" = 4,
                                                                  "cosine" = 6, "pearson.correlation" = 7,
                                                                  "squared.euclidean" = 8,
                                                                  "jaccard" = 9, "gower" = 10)),
        "linkage" = list("LINKAGE", "integer", list("nearest.neighbor" = 1,
                                                    "furthest.neighbor" = 2,
                                                    "group.average" = 3,
                                                    "weighted.average" = 4,
                                                    "centroid.clustering" = 5,
                                                    "median.clustering" = 6,
                                                    "ward" = 7)),
        "thread.ratio" = list("THREAD_RATIO", "numeric"),
        "distance.dimension" = list("DISTANCE_DIMENSION", "numeric"),
        "normalization" = list("NORMALIZATION", "integer", list("no" = 0, "z.score" = 1,
                                                                "symmetric.min.max" = 2,
                                                                "min.max" = 3)),
        "category.weights" = list("CATEGORY_WEIGHTS", "numeric"),
        "categorical.variable" = list("CATEGORICAL_VARIABLE", "list")),
      "DBSCAN" = list(
        "minpts" = list("MINPTS", "integer"),
        "eps" = list("EPS", "numeric"),
        "thread.ratio" = list("THREAD_RATIO", "numeric"),
        "metric" = list("METRIC", "integer", list("manhattan" = 1, "euclidean" = 2,
                                                  "minkowski" = 3, "chebyshev" = 4,
                                                  "standardized.euclidean" = 5, "cosine" = 6)),
        "distance.level" = list("DISTANCE_LEVEL", "integer", list("manhattan" = 1, "euclidean" = 2,
                                                                  "minkowski" = 3, "chebyshev" = 4,
                                                                  "standardized.euclidean" = 5, "cosine" = 6)),
        "minkowski.power" = list("MINKOWSKI_POWER", "integer"),
        "category.weights" = list("CATEGORY_WEIGHTS", "numeric"),
        "algorithm" = list("ALGORITHM", "integer", list("brute.force" = 0, "kd.tree" = 1)),
        "save.model" = list("SAVE_MODEL", "logical"),
        "categorical.variable" = list("CATEGORICAL_VARIABLE", "list"),
        "string.variable" = list("STRING_VARIABLE", "list"),
        "variable.weight" = list("VARIABLE_WEIGHT", "list")),
      "GMM" = list(
        "init.param" = list("INIT_MODE", "integer", list("farthest.first.traversal" = 0,
                                                         "manual" = 1,
                                                         "random.means" = 2,
                                                         "k.means++" = 3)),
        "n.components" = list("INITIALIZE_PARAMETER", "integer"),
        "init.centers" = list("INITIALIZE_PARAMETER", c("list", "integer", "character")),
        "covariance.type" = list("COVARIANCE_TYPE", "integer", list("full" = 0,
                                                                    "diag" = 1,
                                                                    "tied.diag" = 2)),
        "shared.covariance" = list("SHARED_COVARIANCE", "logical"),
        "category.weight" = list("CATEGORY_WEIGHT", "numeric"),
        "max.iter" = list("MAX_ITER", "integer"),
        "thread.ratio" = list("THREAD_RATIO", "numeric"),
        "error.tol" = list("ERROR_TOL", "numeric"),
        "regularization" = list("REGULARIZATION", "numeric"),
        "random.seed" = list("SEED", "integer"),
        "categorical.variable" = list("CATEGORICAL_VARIABLE", "list")),
      "AKMEANS" = list(
        "n.clusters" = list("N_CLUSTERS", "integer"),
        "n.clusters.min" = list("N_CLUSTERS_MIN", "integer"),
        "n.clusters.max" = list("N_CLUSTERS_MAX", "integer"),
        "distance.level" = list("DISTANCE_LEVEL", "integer", list("manhattan" = 1,
                                                                  "euclidean" = 2,
                                                                  "minkowski" = 3,
                                                                  "chebyshev" = 4)),
        "minkowski.power" = list("MINKOWSKI_POWER", "numeric"),
        "category.weights" = list("CATEGORY_WEIGHTS", "numeric"),
        "max.iter" = list("MAX_ITER", "integer"),
        "init" = list("INIT", "integer", list("first.k" = 1, "first_k" = 1, "replace" = 2,
                                              "no_replace" = 3, "no.replace" = 3, "patent" = 4)),
        "normalization" = list("NORMALIZATION", "integer", list("no" = 0, "l1.norm" = 1,
                                                                "min.max" = 2)),
        "thread.ratio" = list("THREAD_RATIO", "numeric"),
        "memory.mode" = list("MEMORY_MODE", "integer", list("auto" = 0, "optimize.speed" = 1,
                                                            "optimize.space" = 2,
                                                            "optimize-speed" = 1,
                                                            "optimize-space" = 2)),
        "tol" = list("TOL", "numeric"),
        "categorical.variable" = list("CATEGORICAL_VARIABLE", "list")),
      "KMEANS" = list(
        "n.clusters" = list("N_CLUSTERS", "integer"),
        "n.clusters.min" = list("N_CLUSTERS_MIN", "integer"),
        "n.clusters.max" = list("N_CLUSTERS_MAX", "integer"),
        "distance.level" = list("DISTANCE_LEVEL", "integer", list("manhattan" = 1, "euclidean" = 2,
                                                                  "minkowski" = 3, "chebyshev" = 4,
                                                                  "cosine" = 6)),
        "minkowski.power" = list("MINKOWSKI_POWER", "numeric"),
        "category.weights" = list("CATEGORY_WEIGHTS", "numeric"),
        "max.iter" = list("MAX_ITER", "integer"),
        "init" = list("INIT", "integer", list("first.k" = 1, "first_k" = 1, "replace" = 2,
                                              "no_replace" = 3, "no.replace" = 3, "patent" = 4)),
        "normalization" = list("NORMALIZATION", "integer", list("no" = 0, "l1.norm" = 1, "min.max" = 2)),
        "thread.ratio" = list("THREAD_RATIO", "numeric"),
        "tol" = list("TOL", "numeric"),
        "categorical.variable" = list("CATEGORICAL_VARIABLE", "list")),
      "KMEDIANS" = list(
        "n.clusters" = list("N_CLUSTERS", "integer"),
        "init" = list("INIT", "integer", list("first.k" = 1, "first_k" = 1, "replace" = 2,
                                              "no_replace" = 3, "no.replace" = 3, "patent" = 4)),
        "max.iter" = list("MAX_ITER", "integer"),
        "tol" = list("TOL", "numeric"),
        "thread.ratio" = list("THREAD_RATIO", "numeric"),
        "distance.level" = list("DISTANCE_LEVEL", "integer", list("manhattan" = 1, "euclidean" = 2,
                                                                  "minkowski" = 3, "chebyshev" = 4, "cosine" = 6)),
        "minkowski.power" = list("MINKOWSKI_POWER", "numeric"),
        "category.weights" = list("CATEGORY_WEIGHTS", "numeric"),
        "normalization" = list("NORMALIZATION", "integer", list("no" = 0, "l1.norm" = 1, "min.max" = 2)),
        "categorical.variable" = list("CATEGORICAL_VARIABLE", "list")),
      "KMEDOIDS" = list(
        "n.clusters" = list("N_CLUSTERS", "integer"),
        "init" = list("INIT", "integer", list("first.k" = 1, "first_k" = 1, "replace" = 2,
                                              "no_replace" = 3, "no.replace" = 3, "patent" = 4)),
        "max.iter" = list("MAX_ITER", "integer"),
        "tol" = list("TOL", "numeric"),
        "thread.ratio" = list("THREAD_RATIO", "numeric"),
        "distance.level" = list("DISTANCE_LEVEL", "integer", list("manhattan" = 1, "euclidean" = 2,
                                                                  "minkowski" = 3, "chebyshev" = 4,
                                                                  "jaccard" = 5, "cosine" = 6)),
        "minkowski.power" = list("MINKOWSKI_POWER", "numeric"),
        "category.weights" = list("CATEGORY_WEIGHTS", "numeric"),
        "normalization" = list("NORMALIZATION", "integer", list("no" = 0, "l1.norm" = 1, "min.max" = 2)),
        "categorical.variable" = list("CATEGORICAL_VARIABLE", "list")),
      "SOM" = list(
        "covergence.criterion" = list("COVERGENCE_CRITERION", "numeric"),
        "normalization" = list("NORMALIZATION", "integer", list("no" = 0, "min.max" = 1, "z.score" = 2)),
        "n.clusters" = list("N_CLUSTERS", "integer"),
        "random.seed" = list("RANDOM_SEED", "integer"),
        "height.of.map" = list("HEIGHT_OF_MAP", "integer"),
        "width.of.map" = list("WIDTH_OF_MAP", "integer"),
        "kernel.function" = list("KERNEL_FUNCTION", "integer", list("gaussian" = 1, "flat" = 2)),
        "alpha" = list("ALPHA", "numeric"),
        "learning.rate" = list("LEARNING_RATE", "integer", list("exponential" = 1, "linear" = 2)),
        "shape.of.grid" = list("SHAPE_OF_GRID", "integer", list("rectangle" = 1, "hexagon" = 2)),
        "radius" = list("RADIUS", "numeric"),
        "batch.som" = list("BATCH_SOM", "integer", list("classical" = 0, "batch" = 1)),
        "max.iter" = list("MAX_ITER", "integer"),
        "categorical.variable" = list("CATEGORICAL_VARIABLE", "list")))
  )
)

#' @title Unified Clustering
#' @name hanaml.UnifiedClustering
#' @description hanaml.UnifiedClustering is an R wrapper for SAP HANA PAL Unified Clustering.
#' Note that this is a new function in SAP HANA SPS05 and Cloud.
#' @seealso \code{\link{predict.UnifiedClustering}}
#' @param func \code{character}\cr
#'   The functionality for unified Clustering.\cr
#'   Valid values are as follows:\cr
#'   'AgglomerateHierarchicalClustering',
#'   'DBSCAN',
#'   'GaussianMixture',
#'   'AcceleratedKMeans',
#'   'KMeans',
#'   'KMedians',
#'   'KMedoids',
#'   'SOM'.
#' @template args-data
#' @template args-key
#' @template args-feature-clustering
#' @param ... \cr
#'   Specifies other parameters for training a clustering model with the functionality
#'   specified in \emph{func}.\cr
#'   Please see the documentation of corresponding functionalities for more detail.\cr
#'   \code{\link{hanaml.AgglomerateHierarchical},
#'         \link{hanaml.DBSCAN},
#'         \link{hanaml.GaussianMixture},
#'         \link{hanaml.KMeans},
#'         \link{hanaml.KMedian},
#'         \link{hanaml.KMedoid},
#'         \link{hanaml.SOM}}
#' @return
#' Returns a "UnifiedClustering" object with the following attributes and methods:\cr
#' \cr
#'      \bold{labels}  \code{DataFrame}\cr
#'          \itemize{
#'             \item{\code{DATA_ID} - ID column in the input data.}
#'             \item{\code{CLUSTER_ID} -  The assigned cluster ID.}
#'             \item{\code{DISTANCE} - Distance between a given point and the cluster center (k-means)
#'               nearest core object (DBSCAN) weight vector (SOM) Or probability
#'               of a given point belonging to the corresponding cluster (GMM).}
#'             \item{\code{SLIGHT_SILHOUETTE} - Estimated value (slight silhouette).}}
#'      \bold{centers}  \code{DataFrame}\cr
#'          \itemize{
#'             \item{\code{CLUSTER_ID}}
#'             \item{\code{VARIABLE_NAME} -  The name of variable.}
#'             \item{\code{VALUE} - The value of variable.}}
#'      \bold{model}  \code{DataFrame}\cr
#'          \itemize{
#'             \item{\code{ROW_INDEX} - model row index.}
#'             \item{\code{PART_INDEX} -  Specifically for GMM's CLUSTER_ID.}
#'             \item{\code{MODEL_CONTENT} - model content.}}
#'      \bold{statistics}   \code{DataFrame}\cr
#'          \itemize{
#'             \item{\code{STAT_NAME} - Statistics name.}
#'             \item{\code{STAT_VALUE} -  Statistics value.}
#'         }
#'      \bold{optimal.param}  \code{DataFrame}\cr
#'          \itemize{
#'             \item{\code{PARM_NAME} - parameter name.}
#'             \item{\code{INT_VALUE} -  integer value.}
#'             \item{\code{DOUBLE_VALUE} - double value.}
#'             \item{\code{STRING_VALUE} - character value.}
#'         }
#' @section Examples:\cr
#' The training data:
#' \preformatted{
#'  > data.fit$Collect()
#'      ID  V000 V001  V002
#'  1    0   0.5    A   0.5
#'  2    1   1.5    A   0.5
#'  3    2   1.5    A   1.5
#'  4    3   0.5    A   1.5
#'  5    4   1.1    B   1.2
#'  6    5   0.5    B  15.5
#'  7    6   1.5    B  15.5
#'  8    7   1.5    B  16.5
#'  9    8   0.5    B  16.5
#'  10   9   1.2    C  16.1
#'  11  10  15.5    C  15.5
#'  12  11  16.5    C  15.5
#'  13  12  16.5    C  16.5
#'  14  13  15.5    C  16.5
#'  15  14  15.6    D  16.2
#'  16  15  15.5    D   0.5
#'  17  16  16.5    D   0.5
#'  18  17  16.5    D   1.5
#'  19  18  15.5    D   1.5
#'  20  19  15.7    A   1.6
#' }
#'
#' Create a UnifiedClustering model for Kmeans:
#' \preformatted{
#' ukmeans <- hanaml.UnifiedClustering(data = data.fit,
#'                                     n.clusters=4,
#'                                     init='first.k',
#'                                     max.iter=100,
#'                                     tol=1.0E-6,
#'                                     thread.ratio=1.0,
#'                                     distance.level='Euclidean',
#'                                     category.weights=0.5)
#' }
#' Check the labels:
#' \preformatted{
#' > ukmeans$labels$Collect()
#'     ID  CLUSTER_ID  DISTANCE  SLIGHT_SILHOUETE
#' 1    0           0  0.891088          0.944370
#' 2    1           0  0.863917          0.942478
#' 3    2           0  0.806252          0.946288
#' 4    3           0  0.835684          0.944942
#' ......
#' 17  16           1  0.976885          0.939386
#' 18  17           1  0.818178          0.945878
#' 19  18           1  0.722799          0.952170
#' 20  19           1  1.102342          0.925679
#' }
#' @keywords Unified Interface
#' @export
hanaml.UnifiedClustering <- function(data = NULL,
                                     func = NULL,
                                     key = NULL,
                                     features = NULL,
                                     ...) {
  UnifiedClustering$new(data = data, func = func, key = key, features = features, ...)
}

#' @title Make Predictions from a "UnifiedClustering" Object
#' @name predict.UnifiedClustering
#' @description Similar to other predict methods, this function
#' Cluster assignment is a unified interface to call a cluster assignment algorithm
#' to assign data to clusters that are previously generated by some clustering methods,
#' including K-Means, Accelerated K-Means, K-Medians, K-Medoids, DBSCAN, SOM, and
#' GMM. AgglomerateHierarchicalClustering does not provide predict function!
#' @seealso \code{\link{hanaml.UnifiedClustering}}
#' @format \code{\link{S3}} methods
#' @param  model \code{R6Class}\cr
#'  A "UnifiedClustering" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @param func \code{character, optional}\cr
#'   The functionality for unified Clustering model.\cr
#'   Mandatory only when the \emph{func} attribute of \emph{model} is NULL.\cr
#'   Valid values are as follows:\cr
#'   'AgglomerateHierarchicalClustering',
#'   'DBSCAN',
#'   'GaussianMixture',
#'   'AcceleratedKMeans',
#'   'KMeans',
#'   'KMedians',
#'   'KMedoids',
#'   'SOM'.
#'
#' @return
#' Predicted values are returned as a DataFrame, structured as follows.
#' \itemize{
#'   \item{ID column name.}
#'   \item{CLUSTER_ID: Assigned cluster ID.}
#'   \item{DISTANCE: Distance metric between a given point and the assigned cluster.}
#' }
#' @section Examples:\cr
#' Input data for prediction:
#' \preformatted{
#' > df.predict$Collect()
#'    ID  CLUSTER_ID  DISTANCE
#' 1  88           3  0.981659
#' 2  89           3  0.826454
#' 3  90           2  1.990205
#' 4  91           2  0.325812
#' }
#' Call the predict() function:
#' \preformatted{
#' > res <- predict(model = ukmeans,
#'                  data = df.predict,
#'                  key = "ID",
#'                  func = 'KMeans')
#' }
#' Check the result:
#' \preformatted{
#' > res$Collect()
#'    ID  CLUSTER_ID  DISTANCE
#' 1  88           3  0.981659
#' 2  89           3  0.826454
#' 3  90           2  1.990205
#' 4  91           2  0.325812
#' }
#' @keywords Unified Interface
#' @export
predict.UnifiedClustering <- function(model,
                                      data,
                                      key,
                                      features = NULL,
                                      func = NULL) {
  model$predict(data = data,
                key = key,
                features = features,
                func = func)
}
