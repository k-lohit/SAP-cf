#' @title Variance Test
#' @name hanaml.VarianceTest
#' @description hanaml.VarianceTest is a R wrapper
#'  for SAP HANA PAL Variance Test.
#' @details Variance Test is a method to identify the outliers of n number
#' of numeric data \ifelse{html}{\out{x<sub>i</sub>}}{\eqn{x_i}}
#' where 0 < i < n+1, using the mean and the standard
#' deviation(sigma) of n number of numeric data.
#' @template args-data
#' @template args-key
#' @param sigma.num \code{double}\cr
#' Multiplier for sigma.\cr
#' @template args-threadratio
#' @param data.col {character, optional}\cr
#' Name of the raw data column in the \emph{data}.\cr
#' If not specified, the first non-ID column is taken as data.col.
#' @return
#' Returns a list of two DataFrame:
#' \itemize{
#'   \item{\code{DataFrame 1}}\cr
#'    Sampling results, structured as follows:
#'    \itemize{
#'    \item{DATA_ID}: name as shown in input DataFrame.
#'    \item{IS_OUT_OF_RANGE}: 0 -> in bounds, 1 -> out of bounds.
#'    }
#'  \item{\code{DataFrame 2}}\cr
#'    Statistic results, structured as follows:
#'    \itemize{
#'      \item{STAT_NAME}:  statistic name.
#'      \item{STAT_VALUE}: statistic value.
#'    }
#'  }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'     ID  X
#' 1   0  25
#' 2   1  20
#' 3   2  23
#' 4   3  29
#' 5   4  26
#' ...
#' 18 17  23
#' 19 18  25
#' 20 19 103
#' }
#' Call the function:
#' \preformatted{
#' > vt <- hanaml.VarianceTest(data, key = "ID", sigma.num = 3.0)
#' }
#' Output:
#' \preformatted{
#' > vt[[2]]$Collect()
#'    ID IS_OUT_OF_RANGE
#' 1   0               0
#' 2   1               0
#' 3   2               0
#' ...
#' 18 17               0
#' 19 18               0
#' 20 19               1
#' }
#' @keywords Preprocessing
#' @export
hanaml.VarianceTest <- function(data,
                                key,
                                sigma.num,
                                thread.ratio = NULL,
                                data.col = NULL) {

  sigma.num <- validateInput("sigma.num", sigma.num, "double", required = TRUE)
  if (!is.null(thread.ratio)) {
    thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
    if (thread.ratio < 0 || thread.ratio > 1) {
      msg <- "The thread.ratio value range is from 0 to 1!"
      flog.error(msg)
      stop(msg)
    }
  }
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  conn <- data$connection.context
  CheckConnection(data)
  cols <- data$columns
  key <- validateInput("key", key, cols, required = TRUE,
                       case.sensitive = TRUE)
  cols <- cols[! cols %in% key]
  data.col <- validateInput("data.col", data.col, cols,
                            case.sensitive = TRUE)
  if (is.null(data.col)) {
    data.col <- cols[[1]]
  }

  data <- data$Select(c(key, data.col))

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_VT_PARAMETER_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_VT_RESULT_TBL_%s", unique.id)
  statistic.tbl <- sprintf("#PAL_VT_STATISTIC_TBL_%s", unique.id)
  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl, statistic.tbl)
  tables <- list(param.tbl, result.tbl, statistic.tbl)

  param.array <- list(
    tuple("SIGMA_NUM", NULL, sigma.num, NULL),
    tuple("THREAD_RATIO", NULL, thread.ratio, NULL)
  )
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_VARIANCE_TEST",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(list(conn$table(result.tbl),
              conn$table(statistic.tbl)))
 }
