#' @title ABC Analysis
#' @name hanaml.ABC
#' @description hanaml.ABC is an R wrapper
#' for SAP HANA PAL ABC analysis.
#' @details
#' ABC analysis is a method that ranks the importance of different items
#' based on a particular measurement (such as revenue or profit).
#' Based on the measurement, items are then grouped in
#' three different classes.
#' The items in the A-class are the most valuable,
#' while the items in the C-class are
#' the least valuable.
#' An example of ABC classification is as follows:
#' \itemize{
#'        \item "A" items: 20 \% of the items (customers) accounts
#'        for 70% of the revenue.
#'        \item "B" items: 30 \% of the items (customers) accounts
#'        for 20% of the revenue.
#'        \item "C" items: 50 \% of the items (customers) accounts
#'        for 10% of the revenue.
#'        }
#' @template args-data
#' @template args-key-first
#' @param     col  \code{character, optional}\cr
#'            Name of the measurement column.\cr
#'            If not provided, it defaults the first non-ID
#'            column of \emph{data}.
#' @param     percent.a  \code{double}\cr
#'            Specifies the interval for A class
#' @param     percent.b  \code{double}\cr
#'            Specifies the interval for B class
#' @param     percent.c  \code{double}\cr
#'            Specifies the interval for C class
#' @template args-threadratio
#' @return
#'   \code{DataFrame}, structured as follows:
#'   \itemize{
#'      \item{ABC_CLASS} ABC class.
#'      \item{ID} record ID (correspond to input table).
#'      }
#'
#' @section Examples:
#'\preformatted{
#'  > data$Collect()
#'      ITEM  VALUE
#' 1   item1  15.40
#' 2   item2 200.40
#' 3   item3 280.40
#' 4   item4 100.90
#' 5   item5  40.40
#' 6   item6  25.60
#' 7   item7  18.40
#' 8   item8  10.50
#' 9   item9  96.15
#' 10 item10   9.40
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.ABC(data = data, percent.a = 0.7,
#'                        percent.b = 0.2, percent.c = 0.1, thread.ratio = 0.5)
#' }
#' Results:
#' \preformatted{
#' > result$Collect()
#'    ABC_CLASS   ITEM
#' 1          A  item3
#' 2          A  item2
#' 3          A  item4
#' 4          B  item9
#' 5          B  item5
#' 6          B  item6
#' 7          C  item7
#' 8          C  item1
#' 9          C  item8
#' 10         C item10
#' }
#' @keywords Miscellaneous
#' @export

hanaml.ABC <-  function(
  data,
  key = NULL,
  col = NULL,
  percent.a,
  percent.b,
  percent.c,
  thread.ratio = NULL) {
  if (is.null(data)) {
    msg <- "data is NULL, please provide data to proceed!"
    flog.error(msg)
    stop(msg)
  }
  thread.ratio <- validateInput("thread.ratio", thread.ratio, "numeric")
  if (!is.null(thread.ratio)) {
    if (thread.ratio < 0 || thread.ratio > 1) {
      msg <- "The thread.ratio value range is from 0 to 1!"
      flog.error(msg)
      stop(msg)
    }
  }
  percent.a <- validateInput("percent.a", percent.a,
                             "numeric", required = TRUE)
  percent.b <- validateInput("percent.b", percent.b,
                             "numeric", required = TRUE)
  percent.c <- validateInput("percent.c", percent.c,
                             "numeric", required = TRUE)
  if (round(percent.a + percent.b + percent.c,
            digits = 4) != 1) {
    msg <- "Sum of the percentage of A, B, and C is not equal to 100%!"
    flog.error(msg)
    stop(msg)
  }
  if (percent.a < 0 || percent.a >= 1) {
    msg <- "percent.a is invalid!"
    flog.error(msg)
    stop(msg)
  }
  if (percent.b < 0 || percent.b >= 1) {
    msg <- "percent.b is invalid!"
    flog.error(msg)
    stop(msg)
  }
  if (percent.c < 0 || percent.c >= 1) {
    msg <-  "percent.c is invalid!"
    flog.error(msg)
    stop(msg)
  }
  cols <- data$columns
  key <- validateInput("key", key, cols,
                       case.sensitive = TRUE)
  if (is.null(key)) {
    key <- cols[[1]]
  }
  cols <- cols[! cols %in% key]
  col <- validateInput("col", col, cols,
                       case.sensitive = TRUE)
  if (is.null(col)) {
    col <- cols[[1]]
  }
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  conn <- data$connection.context
  CheckConnection(data)
  data <- data$Select(c(key, col))
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_ABC_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_ABC_RESULT_TBL_%s", unique.id)
  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl)
  tables <- c(param.tbl, out.tables)
  param.array <- list(tuple("PERCENT_A", NULL, percent.a, NULL),
                      tuple("PERCENT_B", NULL, percent.b, NULL),
                      tuple("PERCENT_C", NULL, percent.c, NULL),
                      tuple("THREAD_RATIO", NULL, thread.ratio,
                            NULL))
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
      ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_ABC",
                                          in.tables,
                                          out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err$message)
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(conn$table(result.tbl))
}
