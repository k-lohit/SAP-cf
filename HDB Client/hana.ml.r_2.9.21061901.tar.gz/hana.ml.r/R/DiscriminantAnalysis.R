DiscriminantAnalysis <- R6Class(
  "DiscriminantAnalysis",
  inherit = MlBase,
  public = list(
    regularization.map = list("mixing" = 0,
                              "diag" = 1,
                              "pseudo" = 2),
    regularization.type = NULL,
    regularization.amount = NULL,
    projection = NULL,
    basic.info = NULL,
    priors = NULL,
    coef = NULL,
    proj.info  = NULL,
    proj.model = NULL,
    initialize = function(data = NULL,
                          key = NULL,
                          features = NULL,
                          label = NULL,
                          regularization.type = NULL,
                          regularization.amount = NULL,
                          projection = NULL) {
      super$initialize()
      if (!is.null(data)){
        self$regularization.type <-
          validateInput("regularization.type", regularization.type,
                        self$regularization.map)
        self$regularization.amount <-
          validateInput("regularization.amount",
                        regularization.amount, "double")
        self$projection <- validateInput("projection", projection, "logical")
        cols <- data$columns
        key <- validateInput("key", key, cols, case.sensitive = TRUE)
        cols <- cols[! cols %in% key]
        label <- validateInput("label", label, cols, case.sensitive = TRUE)
        if (is.null(label)){
          label <- cols[[length(cols)]]
        }
        cols <- cols[! cols %in% label]
        features <- validateInput("features", features,
                                  cols,
                                  case.sensitive = TRUE)
        if (is.null(features)){
          features <- cols
        }
        selected.cols <- append(features, label)
        if (!inherits(data, "DataFrame")){
          msg <- "If training data is not omitted, it must be DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn.context <- data$connection.context
        data <- data$Select(selected.cols)
        param.rows <- private$prepParam()
        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <-  sprintf("#PAL_LDA_PARAM_TBL_%s_%s", self$id, unique.id)
        basic.info.tbl <- sprintf("#PAL_LDA_BASIC_INFO_TBL_%s_%s", self$id,  unique.id)
        priors.tbl <- sprintf("#PAL_LDA_PRIORS_TBL_%s_%s", self$id, unique.id)
        coef.tbl <- sprintf("#PAL_LDA_COEF_TBL_%s_%s", self$id, unique.id)
        proj.info.tbl <- sprintf("#PAL_LDA_PROJECTION_INFO_TBL_%s_%s", self$id, unique.id)
        proj.model.tbl <- sprintf("#PAL_LDA_PROJECTION_MODEL_TBL_%s_%s", self$id, unique.id)
        tables <- list(param.tbl, basic.info.tbl, priors.tbl,
                       coef.tbl, proj.info.tbl, proj.model.tbl)
        in.tables <- list(data, param.tbl)
        out.tables <- list(basic.info.tbl, priors.tbl, coef.tbl,
                           proj.info.tbl, proj.model.tbl)
        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
                     ParameterTable$new(param.tbl)$WithData(param.rows)))
          errorhelper(CallPalAutoWithConnection(conn.context,
            "PAL_LINEAR_DISCRIMINANT_ANALYSIS", in.tables, out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        self$basic.info <- conn.context$table(basic.info.tbl)
        self$priors     <- conn.context$table(priors.tbl)
        self$coef       <- conn.context$table(coef.tbl)
        self$proj.info  <- conn.context$table(proj.info.tbl)
        self$proj.model <- conn.context$table(proj.model.tbl)
        self$model <- list(self$priors, self$coef)
       }
      },
    score = function(data,
                     key,
                     features = NULL,
                     label = NULL){
      if (!inherits(data, "DataFrame")){
        msg <- "If training data is not omitted, it must be DataFrame."
        flog.error(msg)
        stop(msg)
      }
      cols <- data$columns
      key <- validateInput("key", key, cols, required = TRUE, case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      label <- validateInput("label", label, cols, case.sensitive = TRUE)
      if (is.null(label)){
        label <- cols[[length(cols)]]
      }
      cols <- cols[! cols %in% label]
      features <- validateInput("features", features,
                                cols,
                                case.sensitive = TRUE)
      if (is.null(features)){
        features <- cols
      }
      selected.cols <- append(features, label)
      data <- data$Select(c(key, selected.cols))

      prediction <- predict(self, data, key, features)
      prediction <- prediction$Select(list(key, label))
      prediction <- prediction$rename.columns(list("ID_P", "PREDICTION"))
      actual <- data$Select(list(key, label))
      actual <- actual$rename.columns(list("ID_A", "ACTUAL"))
      joined <- actual$Join(prediction, "ID_P=ID_A")
      joined <- joined$Select(list("ACTUAL", "PREDICTION"))
      return(accuracy.score(data$connection.context,
                            joined,
                            label.true = "ACTUAL",
                            label.pred = "PREDICTION"))
    }),
  private = list(
    prepParam = function() {
      param.array <- list(
        tuple("DO_PROJECTION", to.integer(self$projection), NULL, NULL),
        tuple("REGULARIZATION_TYPE",
              map.null(self$regularization.type, self$regularization.type.map), NULL, NULL),
        tuple("REGULARIZATION_AMOUNT", NULL, self$regularization.amount, NULL)
      )
      return (param.array)
    }
  )
)
#' @title  Linear Discriminant Analysis
#' @name hanaml.DiscriminantAnalysis
#' @description hanaml.DiscriminantAnalysis is a R wrapper
#'  for SAP HANA PAL Linear Discriminant Analysis.
#' @details Linear discriminant analysis for classification and data reduction.
#' @seealso \code{\link{predict.DiscriminantAnalysis}}
#' @seealso \code{\link{transform.DiscriminantAnalysis}}
#' @keywords Classification
#' @template args-data
#' @template args-key
#' @template args-feature-multiple
#' @template args-label
#' @param     regularization.type  \code{character, optional}\cr
#'            The strategy for handling ill-conditioning or rank-deficiency
#'            of the empirical covariance matrix.
#'            \itemize{
#'            \item{\code{'mixing'}: uses regularized covariance estimate.}
#'            \item{\code{'diag'}:   uses diagonal covariance estimate.}
#'            \item{\code{'pseudo'}: uses pseudo inverse covariance estimate.}
#'             }
#'            Defaults to 'mixing'.
#' @param     regularization.amount  \code{float, optional}\cr
#'            The convex mixing weight assigned to the diagonal matrix
#'            obtained from diagonal of the empirical covriance matrix.
#'            Valid range for this parameter is (0,1)
#'            Valid only when \emph{regularization.type|} is 'mixing'.\cr
#'            Defaults to the smallest number in (0,1) that makes the
#'            regularized emprical covariance matrix invertible.
#' @param     projection  \code{logical, optional}\cr
#'            Whether or not to compute the projection model.\cr
#'            Defaults to TRUE.
#'
#' @return
#' Returns a "DiscriminantAnalysis" object with the following attributes:
#' \itemize{
#'  \item{basic.info  \code{DataFrame}}\cr
#'        Basic information of the training Data
#'        for linear discriminant analysis.
#'  \item{priors  \code{DataFrame}}\cr
#'        The empirical priors for each class in the training data.
#'  \item{coef \code{DataFrame}}\cr
#'        Projection related info, such as standard deviations of the discriminants,
#'        variance proportion to the total variance explained by each discriminant, etc.
#'  \item{proj.info \code{DataFrame}}\cr
#'        Projection related info, such as standard deviations of the discriminants,
#'        variance proportion to the total variance explained by each discriminant, etc.
#'  \item{proj.model \code{DataFrame}}\cr
#'        The projection matrix and overall means for features.
#'
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#     ID    X1   X2   X3   X4            CLASS
#' 1   0   5.1  3.5  1.4  0.2      Iris-setosa
#' 2   1   4.9  3.0  1.4  0.2      Iris-setosa
#' 3   2   4.7  3.2  1.3  0.2      Iris-setosa
#' 4   3   4.6  3.1  1.5  0.2      Iris-setosa
#' 5   4   5.0  3.6  1.4  0.2      Iris-setosa
#' 6   5   5.4  3.9  1.7  0.4      Iris-setosa
#'     ......
#' 25 24   6.5  3.0  5.8  2.2   Iris-virginica
#' 26 25   7.6  3.0  6.6  2.1   Iris-virginica
#' 27 26   4.9  2.5  4.5  1.7   Iris-virginica
#' 28 28   7.3  2.9  6.3  1.8   Iris-virginica
#' 29 29   6.7  2.5  5.8  1.8   Iris-virginica
#' 30 29   7.2  3.6  6.1  2.5   Iris-virginica
#' }
#' Call the function:
#' \preformatted{
#' > lda <- hanaml.DiscriminantAnalysis(data
#'                                      key = 'ID',
#'                                      label = 'CLASS',
#'                                      regularization.type = "mixing",
#'                                      regularization.amount = 0.5,
#'                                      projection = TRUE)
#' }
#' Output:
#' \preformatted{
#' > lda$coef$Collect()
#'               CLASS   COEFF_X1   COEFF_X2   COEFF_X3   COEFF_X4   INTERCEPT
#'  1      Iris-setosa  23.907391  51.754001 -34.641902 -49.063407 -113.235478
#'  2  Iris-versicolor   0.511034  15.652078  15.209568  -4.861018  -53.898190
#'  3   Iris-virginica -14.729636   4.981955  42.511486  12.315007  -94.143564
#'
#' > lda$proj.model$Collect()
#'               NAME        X1        X2        X3        X4
#'  1  DISCRIMINANT_1  1.907978  2.399516 -3.846154 -3.112216
#'  2  DISCRIMINANT_2  3.046794 -4.575496 -2.757271  2.633037
#'  3    OVERALL_MEAN  5.843333  3.040000  3.863333  1.213333
#'
#' }
#' @export
hanaml.DiscriminantAnalysis <- function(data = NULL,
                                        key = NULL,
                                        features = NULL,
                                        label = NULL,
                                        regularization.type = NULL,
                                        regularization.amount = NULL,
                                        projection = NULL){
  DiscriminantAnalysis$new(data, key, features, label,
                           regularization.type, regularization.amount,
                           projection)
}

#' @export
print.DiscriminantAnalysis <- function(x, ...){
  writeLines("\n")
  writeLines("DiscriminantAnalysis attributes:")
  writeLines("\n")
  cat(sprintf("regularization.type : %s", to.null(x$regularization.type)))
  writeLines("\n")
  cat(sprintf("regularization.amount : %s", to.null(x$regularization.amount)))
  writeLines("\n")
  cat(sprintf("projection : %s", to.null(x$projection)))
  writeLines("\n")
}
#' @export
summary.DiscriminantAnalysis <- function(object, ...){
  writeLines("\n")
  writeLines("Linear Discriminant Analysis Model Basic Information:")
  print(object$basic.info$Collect())
  writeLines("\n")
  writeLines("Linear Discriminant Analysis Model Priors:")
  print(object$priors$Collect())
  writeLines("\n")
  writeLines("Linear Discriminant Analysis Model Classifiers:")
  print(object$coef$Collect())
  writeLines("\n")
  writeLines("Linear Discriminant Analysis Model Projection Information:")
  print(object$proj.info$Collect())
  writeLines("\n")
  writeLines("Linear Discriminant Analysis Model Projection Model:")
  print(object$proj.model$Collect())
}

#' @title Make Projections from a "DiscriminantAnalysis" Object
#' @name transform.DiscriminantAnalysis
#' @description Similar to other transform methods, this function
#' transforms values from a fitted "DiscriminantAnalysis" object.
#' @seealso \code{\link{predict.DiscriminantAnalysis}}
#' @seealso \code{\link{hanaml.DiscriminantAnalysis}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#'  A 'DiscriminantAnalysis' object for projection.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @param proj.dim \code{integer, optional}\cr
#' Dimension of the projected space, equivalent to the number of discriminant
#' used for projection. \cr
#' Defaults to the number of obtained discriminants.
#' @return
#' \code{DataFrame}\cr
#' Projected result, structured as follows:
#' \itemize{
#'   \item{1st column, ID, with the same name and data type as \emph{data} for projection.}
#'   \item{other columns with name DISCRIMINANT_i, where i iterates from 1 to the number
#' of elements in \emph{features}, data type DOUBLE.}
#' }
#'
#' @section Examples:
#'  Perform transform with a 'DiscriminantAnalysis' object 'lda':
#' \preformatted{
#'  > result <- transform(lda,
#'                        test.set,
#'                        key = "ID"
#'                        features=list("ID","X1","X2","X3","X4"))
#'  }
#'  Output:
#' \preformatted{
#'  > result$Collect()
#'      ID  DISCRIMINANT_1  DISCRIMINANT_2  DISCRIMINANT_3 DISCRIMINANT_4
#'  1    1       12.313584       -0.245578              NA             NA
#'  2    2       10.732231        1.432811              NA             NA
#'  3    3       11.215154        0.184080              NA             NA
#'  4    4       10.015174       -0.214504              NA             NA
#'  ...
#'  27  27       -7.058927       -0.877426              NA             NA
#'  28  28       -8.754272       -0.095103              NA             NA
#'  29  29       -8.935789        1.285655              NA             NA
#'  30  30       -8.674729       -1.208049              NA             NA
#' }
#' @keywords Classification
#' @export
transform.DiscriminantAnalysis <- function(model,
                                           data,
                                           key,
                                           features = NULL,
                                           proj.dim = NULL){
    if (is.null(model$proj.model)){
      msg <- paste("Please provide a proj.model in Linear",
                   "Discriminant Analysis object!")
      flog.error(msg)
      stop(msg)
    }
    if (!inherits(data, "DataFrame")){
      msg <- "If training data is not omitted, it must be DataFrame."
      flog.error(msg)
      stop(msg)
    }
    conn.context <- data$connection.context
    CheckConnection(data)
    proj.dim <- validateInput("proj.dim", proj.dim, "integer")
    cols <- data$columns
    key <- validateInput("key", key, cols,
                         required = TRUE, case.sensitive = TRUE)
    cols <- cols[! cols %in% key]
    features <- validateInput("features", features,
                              cols, case.sensitive = TRUE)
    if (is.null(features)){
      features <- cols
    }
    data <- data$Select(c(key, features))
    unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
    param.tbl <-  sprintf("#PAL_LDA_PARAM_TBL_%s", unique.id)
    result.tbl <- sprintf("#PAL_LDA_RESULT_TBL_%s", unique.id)
    param.rows <- list(
      tuple("DISCRIMINANT_NUMBER", proj.dim, NULL, NULL))
    tables <- list(param.tbl, result.tbl )
    in.tables <- list(data, model$proj.model$name, param.tbl)
    out.tables <- list(result.tbl)
    tryCatch({
      errorhelper(CreateTWithConnection(conn.context,
        (ParameterTable$new(param.tbl))$WithData(param.rows)))
      errorhelper(CallPalAutoWithConnection(conn.context,
        "PAL_LINEAR_DISCRIMINANT_ANALYSIS_PROJECT", in.tables, out.tables))
    },
    error = function(err){
      msg <- paste("Error:", err[["message"]])
      flog.error(msg)
      TryDropWithConnection(conn.context,
                            tables)
      stop()
    })
    return(conn.context$table(result.tbl))
}

#' @title Make Predictions from a "DiscriminantAnalysis" Object
#' @name predict.DiscriminantAnalysis
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "DiscriminantAnalysis" object.
#' @seealso \code{\link{transform.DiscriminantAnalysis}}
#' @seealso \code{\link{hanaml.DiscriminantAnalysis}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#'  A 'DiscriminantAnalysis' object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @param verbose \code{logical, optional}\cr
#' Whether or not outputs scores of all classes.
#' If FALSE, only score of the predicted class will be outputed.\cr
#' Defaults to FALSE.
#' @return
#' Predicted values are returned as a DataFrame, structured as follows.
#' \itemize{
#'   \item{ID column, with same name and type as \emph{data}'s ID column.}
#'   \item{Label column, with same name and type as training data's labelcolumn.}
#'   \item{SCORE column, score of each of the class.}
#' }
#'
#' @section Examples:
#' Perform the prediction on a 'DiscriminantAnalysis' object lda:
#' \preformatted{
#' > result <- predict(lda,
#'                     data,
#'                     key = "ID")
#' }
#' @keywords Classification
#' @export
predict.DiscriminantAnalysis <- function(model,
                                         data,
                                         key,
                                         features = NULL,
                                         verbose =NULL){
  if (is.null(model$model)){
    msg <- "Please provide a model in Linear Discriminant Analysis object!"
    flog.error(msg)
    stop(msg)
  }
  conn.context <- data$connection.context
  CheckConnection(data)
  cols <- data$columns
  key <- validateInput("key", key, cols, required = TRUE,
                       case.sensitive = TRUE)
  cols <- cols[! cols %in% key]
  features <- validateInput("features", features,
                            cols,
                            case.sensitive = TRUE)
  if (is.null(features)){
    features <- cols
  }

  data <- data$Select(c(key, features))
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.rows <- list(
    tuple("VERBOSE_OUTPUT", to.integer(verbose), NULL, NULL))

  model$priors <- model$model[[1]]
  model$coef <- model$model[[2]]
  param.tbl <-  sprintf("#PAL_LDA_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_LDA_RESULT_TBL_%s",  unique.id)

  tables <- list(param.tbl, result.tbl)
  in.tables <- list(data, model$priors$name, model$coef$name, param.tbl)
  out.tables <- list(result.tbl)

  tryCatch({
    errorhelper(CreateTWithConnection(conn.context,
      (ParameterTable$new(param.tbl))$WithData(param.rows)))
    errorhelper(CallPalAutoWithConnection(conn.context,
      "PAL_LINEAR_DISCRIMINANT_ANALYSIS_CLASSIFY", in.tables, out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn.context, tables)
    stop()
  })
  return(conn.context$table(result.tbl))
}
