LinearRegression <- R6Class(
  "LinearRegression",
  inherit = MlBase,
  public = list(
    solver.map = list(qr = 1, svd = 2, cd = 4, cholesky = 5, admm = 6),#nolint
    var.select.map = list(all = 0, forward = 1, backward = 2, stepwise = 3),
    pmml.export.map = list("no" = 0, "multi-row" = 2),
    model.format.map = list("coefficients" = 0, "pmml" = 1),
    solver = NULL,
    var.select = NULL,
    features.must.select = NULL,
    intercept = NULL,
    alpha.to.enter = NULL,
    alpha.to.remove = NULL,
    enet.lambda = NULL,
    enet.alpha = NULL,
    max.iter = NULL,
    tol = NULL,
    pho = NULL,
    stat.inf = NULL,
    adjusted.r2 = NULL,
    dw.test = NULL,
    reset.test = NULL,
    bp.test = NULL,
    ks.test = NULL,
    thread.ratio = NULL,
    categorical.variable = NULL,
    pmml.export = NULL,
    coefficients = NULL,
    pmml = NULL,
    fitted = NULL,
    statistics = NULL,
    model = NULL,
    optim.param = NULL,
    resampling.method = NULL,
    evaluation.metric = NULL,
    fold.num = NULL,
    repeat.times = NULL,
    param.search.strategy = NULL,
    random.search.times = NULL,
    random.state = NULL,
    timeout = NULL,
    progress.indicator.id = NULL,
    parameter.range = NULL,
    parameter.values = NULL,
    initialize = function(data = NULL,
                          key = NULL,
                          features = NULL,
                          label = NULL,
                          formula = NULL,
                          solver = NULL,
                          var.select = NULL,
                          features.must.select = NULL,
                          intercept = NULL,
                          alpha.to.enter = NULL,
                          alpha.to.remove = NULL,
                          enet.lambda = NULL,
                          enet.alpha = NULL,
                          max.iter = NULL,
                          tol = NULL,
                          pho = NULL,
                          stat.inf = NULL,
                          adjusted.r2 = NULL,
                          dw.test = NULL,
                          reset.test = NULL,
                          bp.test = NULL,
                          ks.test = NULL,
                          thread.ratio = NULL,
                          categorical.variable = NULL,
                          pmml.export = NULL,
                          resampling.method = NULL,
                          evaluation.metric = NULL,
                          fold.num = NULL,
                          repeat.times = NULL,
                          param.search.strategy = NULL,
                          random.search.times = NULL,
                          random.state = NULL,
                          timeout = NULL,
                          progress.indicator.id = NULL,
                          parameter.range = NULL,
                          parameter.values = NULL){
      super$initialize()
      if (!is.null(data)){
        self$solver <- validateInput("solver", solver,
                                     self$solver.map)
        self$var.select <- validateInput("var.select", var.select,
                                         self$var.select.map)
        self$intercept <- validateInput("intercept", intercept, "logical")
        self$alpha.to.enter <- validateInput("alpha.to.enter", alpha.to.enter, "double")
        self$alpha.to.remove <- validateInput("alpha.to.remove", alpha.to.remove, "double")
        self$enet.lambda <- validateInput("enet.lambda", enet.lambda, "double")
        self$enet.alpha <- validateInput("enet.alpha", enet.alpha, "double")
        self$max.iter <- validateInput("max.iter", max.iter, "integer")
        self$tol <- validateInput("tol", tol, "double")
        self$pho <- validateInput("pho", pho, "double")
        self$stat.inf <- validateInput("stat.inf", stat.inf, "logical")
        self$adjusted.r2 <- validateInput("adjusted.r2", adjusted.r2, "logical")
        self$dw.test <- validateInput("dw.test", dw.test, "logical")
        self$reset.test <- validateInput("reset.test", reset.test, "integer")
        self$bp.test <- validateInput("bp.test", bp.test, "logical")
        self$ks.test <- validateInput("ks.test", ks.test, "logical")
        self$thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
        self$categorical.variable <- validateInput("categorical.variable",
                                                   categorical.variable,
                                                   data$columns,
                                                   case.sensitive = TRUE)
        self$features.must.select <- validateInput("features.must.select",
                                                   features.must.select,
                                                   data$columns,
                                                   case.sensitive = TRUE)
        self$pmml.export <- validateInput("pmml.export", pmml.export,
                                          self$pmml.export.map)
        if (!is.null(self$solver)){
          if (self$solver %in% c("cd", "admm")){#nolint
            if (!is.null(self$var.select) && self$var.select != "all"){#nolint
              msg <- sprintf("var.select cannot be %s when solver is %s.",
                             self$var.select, self$solver)
              flog.error(msg)
              stop(msg)
            }
          }
        }
        if (is.null(self$solver) || !self$solver %in% c("cd", "admm")){#nolint
          if (!is.null(enet.lambda)){
            msg <- paste("enet.lambda is applicable only when solver",
                         "is coordinate descent or admm.")
            flog.error(msg)
            stop(msg)
          }
          if (!is.null(self$enet.alpha)){
            msg <- paste("enet.alpha is applicable only when solver",
                         "is coordinate descent or admm.")
            flog.error(msg)
            stop(msg)
          }
          if (!is.null(self$max.iter)){
            msg <- paste("max.iter is applicable only when solver",
                         "is coordinate descent or admm.")
            flog.error(msg)
            stop(msg)
          }
        }
        if ((is.null(self$solver) || (self$solver != "cd")) &&#nolint
            (!is.null(self$tol))){
          msg <- "tol is applicable only when solver is coordinate descent."
          flog.error(msg)
          stop(msg)
        }
        if ((is.null(self$solver) || self$solver != "admm") &&#nolint
            (!is.null(self$pho))){
          msg <- "pho is applicable only when solver is admm."
          flog.error(msg)
          stop(msg)
        }
        if (is.null(self$var.select) || self$var.select != "forward"){#nolint
          if (!is.null(self$alpha.to.enter)){
            msg <- paste("alpha.to.enter is applicable only when",
                         "var.select is forward.")
            flog.error(msg)
            stop(msg)
          }
        }
        if (is.null(self$var.select) || self$var.select != "backward"){#nolint
          if (!is.null(self$alpha.to.remove)){
            msg <- paste("alpha.to.remove is applicable",
                         "only when var.select is backward")
            flog.error(msg)
            stop(msg)
          }
        }
        if (!is.null(self$enet.lambda) || !is.null(self$enet.alpha) ||
            isFALSE(self$intercept)){
          if (isTRUE(self$dw.test)){
            msg <- paste("dw.test is applicable only when elastic net",
                         "regularization is disabled and the model",
                         "includes an intercept.")
            flog.error(msg)
            stop(msg)
          }
          if (!is.null(self$reset.test) && self$reset.test != 1){
            msg <- paste("reset.test is applicable only when elastic",
                         "net regularization is disabled and the",
                         "model includes an intercept.")
            flog.error(msg)
            stop(msg)
          }
          if (isTRUE(self$bp.test)){
            msg <- paste("bp.test is applicable only when elastic net",
                         "regularization is disabled and the model",
                         "includes an intercept.")
            flog.error(msg)
            stop(msg)
          }
          if (isTRUE(self$ks.test)){
            msg <- paste("ks.test is applicable only when elastic",
                         "net regularization is disabled and the",
                         "model includes an intercept.")
            flog.error(msg)
            stop(msg)
          }
        }
        if (!is.null(self$reset.test)){
          if (inherits(self$reset.test, "logical")){
            msg <- paste("reset.test should be an integer, not a",
                         "boolean indicating whether or not to conduct",
                         "the Ramsey RESET test.")
            flog.error(msg)
            stop(msg)
          }
        }
        if (!is.null(self$enet.alpha)){
          if ((0 > self$enet.alpha) || self$enet.alpha > 1){#nolint
            msg <- sprintf("enet.alpha %s is out of bounds.", enet.alpha)
            flog.error(msg)
            stop(msg)
          }
        }
        self$resampling.method <- validateInput("resampling.method",
                                                resampling.method,
                                                list(cv = "cv",
                                                     bootstrap = "bootstrap"))
        if (!is.null(evaluation.metric)){
          if (!is.character(evaluation.metric) ||
              tolower(evaluation.metric) != "rmse"){
            msg <- "Only 'rmse' is valid for evaluation.metric."
            flog.warn(msg)
          } else {
            self$evaluation.metric <- tolower(evaluation.metric)
          }
        }
        self$repeat.times <- validateInput("repeat.times",
                                           repeat.times,
                                           "integer")
        self$fold.num <-
          validateInput("fold.num", fold.num, "integer",
            required = isTRUE(self$resampling.method == "cv"))
        self$param.search.strategy <-
          validateInput("param.search.strategy",
                        param.search.strategy,
                        list(grid = "grid",
                             random = "random"))
        self$random.search.times <-
          validateInput("random.search.times", random.search.times, "integer",
            required = isTRUE(self$param.search.strategy == "random"))
        self$random.state <- validateInput("random.state",
                                           random.state,
                                           "integer")
        self$timeout <- validateInput("timeout", timeout, "integer")
        self$progress.indicator.id <- validateInput("progress.indicator.id",
                                                    progress.indicator.id,
                                                    "character")
        if (length(parameter.values) != 0){
          validateInput("Parameters for value specification",
                        names(parameter.values),
                        list("enet.lambda", "enet.alpha"),
                        case.sensitive = TRUE)
        }
        if (length(parameter.range) != 0){
          validateInput("Parameters for range specification",
                        names(parameter.range),
                        list("enet.lambda", "enet.alpha"),
                        case.sensitive = TRUE)
        }
        self$parameter.range <- parameter.range
        self$parameter.values <- parameter.values
        cols <- data$columns
        key <- validateInput("key", key, cols,
                             case.sensitive = TRUE)
        cols <- cols[!cols %in% key]
        if (inherits(formula, "formula")){
          parseformula <- ParseFormula(data, formula)
          label <- parseformula[[1]]
          features <- parseformula[[2]]
          features <- features[! features %in% key]
        }
        label <- validateInput("label", label, cols,
                               case.sensitive = TRUE)
        categorical.variable <- validateInput("categorical.variable",
                                              categorical.variable,
                                              cols,
                                              case.sensitive = TRUE)
        if (is.null(label)){
          label <- cols[[length(cols)]]
        }
        cols <- cols[! cols %in% label]
        features <- validateInput("features", features, cols,
                                  case.sensitive = TRUE)
        if (is.null(features)){
          features <- cols
        }
        if (!is.null(key)){
          id.col <- list(key)
          cols <- cols[! cols %in% key]
        } else {
          id.col <- list()
        }

        id.col <- append(id.col, label)
        id.col <- append(id.col, features)

        if (!inherits(data, "DataFrame")) {
          msg <- "data must be given as a DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn <- data$connection.context

        data <- data$Select(id.col)

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_LINEAR_REGRESSION_PARAM_TBL_%s_%s", self$id, unique.id)
        coef.tbl <- sprintf("#PAL_LINEAR_REGRESSION_COEF_TBL_%s_%s", self$id, unique.id)
        pmml.tbl <- sprintf("#PAL_LINEAR_REGRESSION_PMML_TBL_%s_%s", self$id, unique.id)
        fit.tbl <- sprintf("#PAL_LINEAR_REGRESSION_FITTED_TBL_%s_%s", self$id, unique.id)
        stat.tbl <- sprintf("#PAL_LINEAR_REGRESSION_STATS_TBL_%s_%s", self$id, unique.id)
        opt.param.tbl <- sprintf("#PAL_LINEAR_REGRESSION_OPTIMAL_PARAM_TBL_%s",#nolintlib
                                 self$id)
        param.rows <- list(
          tuple("ALG", map.null(self$solver,
                                self$solver.map),
                NULL, NULL),
          tuple("VARIABLE_SELECTION",
                map.null(self$var.select, self$var.select.map),
                NULL, NULL),
          tuple("NO_INTERCEPT", to.integer(self$intercept), NULL, NULL),#nolint
          tuple("ALPHA_TO_ENTER", NULL, self$alpha.to.enter, NULL),
          tuple("ALPHA_TO_REMOVE", NULL, self$alpha.to.remove, NULL),
          tuple("ENET_LAMBDA", NULL, self$enet.lambda, NULL),
          tuple("ENET_ALPHA", NULL, self$enet.alpha, NULL),
          tuple("MAX_ITERATION", self$max.iter, NULL, NULL),
          tuple("THRESHOLD", NULL, self$tol, NULL),
          tuple("PHO", NULL, self$pho, NULL),
          tuple("STAT_INF", to.integer(self$stat.inf), NULL, NULL),#nolint
          tuple("ADJUSTED_R2", to.integer(self$adjusted.r2), NULL, NULL),#nolint
          tuple("DW_TEST", to.integer(self$dw.test), NULL, NULL),#nolint
          tuple("RESET_TEST", self$reset.test, NULL, NULL),
          tuple("BP_TEST", to.integer(self$bp.test), NULL, NULL),
          tuple("KS_TEST", to.integer(self$ks.test), NULL, NULL),
          tuple("PMML_EXPORT",
                map.null(self$pmml.export, self$pmml.export.map),
                NULL, NULL),
          tuple("HAS_ID", as.integer(!is.null(key)), NULL, NULL),
          tuple("RESAMPLING_METHOD", NULL, NULL, self$resampling.method),
          tuple("PARAM_SEARCH_STRATEGY", NULL, NULL,
                self$param.search.strategy),
          tuple("FOLD_NUM", self$fold.num, NULL, NULL),
          tuple("REPEAT_TIMES", self$repeat.times, NULL, NULL),
          tuple("EVALUATION_METRIC", NULL, NULL, "RMSE"),
          tuple("TIMEOUT", self$timeout, NULL, NULL),
          tuple("RANDOM_SEARCH_TIMES", self$random.search.times, NULL, NULL),
          tuple("SEED", self$random.state, NULL, NULL),
          tuple("PROGRESS_INDICATOR_ID", NULL, NULL,
                self$progress.indicator.id))
        if (is.null(self$solver) || self$solver != "svd"){
          param.rows <- append(param.rows,
                               tuple(tuple("THREAD_RATIO", NULL,
                                           self$thread.ratio, NULL)))#nolint
        }
        if (!is.null(self$categorical.variable)) {
          for (each in self$categorical.variable) {
            temp.list <- tuple("CATEGORICAL_VARIABLE", NULL, NULL, each)
            param.rows <- append(param.rows, tuple(temp.list))
          }
        }
        if (!is.null(self$features.must.select)) {
          for (each in self$features.must.select) {
            temp.list <- tuple("MANDATORY_FEATURE", NULL, NULL, each)
            param.rows <- append(param.rows, tuple(temp.list))
          }
        }

        if (length(self$parameter.values) > 0){
          for (i in 1:length(self$parameter.values)){
            param.name <- gsub("\\.", "_",
                               toupper(names(self$parameter.values[i])))
            str.values <- paste("{",
                                paste0(self$parameter.values[[i]],
                                       collapse = ","),
                                "}", sep = "")
            temp.tup <- tuple(paste0(param.name, "_VALUES"),
                              NULL, NULL, str.values)
            param.rows <-
              append(param.rows,  list(temp.tup))
          }
        }
        if (length(self$parameter.range) > 0){
          for (i in 1:length(self$parameter.range)){
            param.name <- gsub("\\.", "_",
                               toupper(names(self$parameter.range[i])))
            range.temp <- self$parameter.range[[i]]
            cps <- ifelse(length(range.temp) == 2, ",,", ",")
            str.range <- paste("[",
                               paste0(range.temp,
                                      collapse = cps),
                               "]", sep = "")
            temp.tup <- tuple(paste0(param.name, "_RANGE"),
                              NULL, NULL, str.range)
            param.rows <-
              append(param.rows, list(temp.tup))
          }
        }
        tables <- list(param.tbl, coef.tbl, pmml.tbl,
                       fit.tbl, stat.tbl, opt.param.tbl)
        in.tables <- list(data, param.tbl)
        out.tables <- list(coef.tbl, pmml.tbl,
                           fit.tbl, stat.tbl, opt.param.tbl)
        tryCatch({
          errorhelper(CreateTWithConnection(conn,(ParameterTable$new(param.tbl))$WithData(param.rows))) #nolint
          errorhelper(CallPalAutoWithConnection(conn, "PAL_LINEAR_REGRESSION", in.tables, out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })

        self$coefficients <- conn$table(coef.tbl)
        self$model <- self$coefficients
        if (!is.null(self$pmml.export)){
          self$pmml <- conn$table(pmml.tbl)
          self$model <- self$pmml
        } else {
          self$pmml <- NULL
        }
        if (!is.null(key)){
          self$fitted <- conn$table(fit.tbl)
        } else {
          self$fitted <- NULL
        }
        self$statistics <- conn$table(stat.tbl)
        self$optim.param <- conn$table(opt.param.tbl)
      }
    },
    score = function(data, key, features=NULL, label=NULL, model.format=NULL){
      if (is.null(self$model)) {
        msg <- "Model not initialized. Perform a fit first."
        flog.error(msg = msg)
        stop(msg)
      }

      if (!inherits(data, "DataFrame")) {
        msg <- "data must be given as a DataFrame"
        flog.error(msg)
        stop(msg)
      }
      CheckConnection(data)
      conn <- data$connection.context

      key <- validateInput("key", key, "character")
      label <- validateInput("label", label, "character")
      cols <- data$columns
      key <- validateInput("key", key, cols, required = TRUE,
                           case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      if (is.null(label)){
        label <- cols[[length(cols)]]
      }
      cols <- cols[! cols %in% label]
      features <- validateInput("features", features, cols,
                                case.sensitive = TRUE)
      if (is.null(features))
        features <- cols
      prediction <- predict(self, data, key = key, features = features, model.format = model.format)
      prediction <- prediction$rename.columns(list("ID_P", "PREDICTION"))
      actual <- data$Select(list(key, label))
      actual <- actual$rename.columns(list("ID_A", "ACTUAL"))
      joined <- actual$Join(prediction, "ID_P=ID_A")
      joined <- joined$Select(list("ACTUAL", "PREDICTION"))
      r2.score <- r2.score(conn,
                           joined,
                           label.true = "ACTUAL",
                           label.pred = "PREDICTION")
      return(r2.score)
    }
  )
)
#' @title Linear Regression
#' @name hanaml.LinearRegression
#' @description hanaml.LinearRegression is a R wrapper
#' for SAP HANA PAL linear regression algorithm.
#' @details Linear regression is an approach to model the linear relationship
#' between a variable, usually referred to as dependent variable,
#' and one or more variables, usually referred to as
#' independent variables, denoted as predictor vector.
#' @seealso \code{\link{predict.LinearRegression}}
#' @template args-data
#' @template args-key-optional
#' @template args-feature-multiple
#' @template args-label
#' @template args-formula
#' @param    solver \code{{"QR", "SVD", "CD", "Cholesky", "ADMM"}, optional}\cr
#'           Algorithms to use to solve the least square problem.\cr
#' \itemize{
#'   \item{"QR":} QR decomposition.
#'   \item{"SVD":} singular value decomposition.
#'   \item{"CD"}: cyclical coordinate descent method.
#'   \item{"Cholesky":} Cholesky decomposition.
#'   \item{"ADMM":} alternating direction method of multipliers.
#' }
#' Defaults to "QR".
#' @param    var.select \code{c("all", "forward", "backward", "stepwise"), optional}\cr
#'           Method to perform variable selection.
#' \itemize{
#'   \item{"all":} all variables are included.
#'   \item{"forward":} forward selection.
#'   \item{"backward":} backward selection.
#'   \item{"stepwise":} stepwise selection.}
#' 'forward', 'backward' and 'stepwise' are supported only when \emph{solver}
#'  is 'QR', 'SVD' or 'Cholesky'.\cr
#'  Note that 'stepwise' is a new option in SAP HANA SPS05 and Cloud.
#' Defaults to 'all'.
#' @param  features.must.select \code{character or list/vector of characters, optional}\cr
#' Specifies the column names of \emph{data} that needs to be included in the final
#' training model when executing variable selection.\cr
#' Note that this is a new parameter in SAP HANA SPS05 and Cloud.\cr
#' Only valid when \emph{varselect} is not 'all'.\cr
#' \strong{Note}: This parameter is a hint.
#' There are exceptional cases that a specified mandatory feature is excluded in the final model.
#' For instance, some mandatory features can be represented as a linear combination
#' of other features, among which some are also mandatory features.\cr
#' New parameter added in SAP HANA Cloud and SPS05.\cr
#' No default value.
#' @param     intercept \code{logical, optional}\cr
#'            If TRUE, include the intercept in the model.\cr
#'            Defaults to TRUE.
#' @param     alpha.to.enter \code{double, optional}\cr
#'            P-value for forward selection.
#'            When \emph{var.select} is 'forward', default value is 0.05; when \emph{var.select} is 'stepwise', default value is 0.15.
#' @param     alpha.to.remove \code{double, optional}\cr
#'            P-value for backward selection.
#'            When \emph{var.select} is 'backward', default value is 0.1; when \emph{var.select} is 'stepwise', default value is 0.15.
#' @param     enet.lambda \code{double, optional}\cr
#'            Penalized weight. Value should be greater than or equal to 0.\cr
#'            Valid only when \emph{solver} is 'CD' or 'ADMM'.
#' @param     enet.alpha \code{double, optional}\cr
#'            Elastic net mixing parameter.
#'            Ranges from 0 (Ridge penalty) to 1 (LASSO penalty) inclusively.
#'            Valid only when \emph{solver} is 'CD' or 'ADMM'.\cr
#'            Defaults to 1.0.
#' @param     max.iter \code{integer, optional}\cr
#'            Maximum number of passes over training data.
#'            If convergence is not reached after the specified number of
#'            iterations, an error will be generated.
#'            Valid only when \emph{solver} is 'CD' or 'ADMM'.\cr
#'            Defaults to 1e5.
#' @param     tol \code{double, optional}\cr
#'            Convergence threshold for coordinate descent.
#'            Valid only when \emph{solver} is 'CD'.\cr
#'            Defaults to 1.0e-7.
#' @param     pho \code{double, optional}\cr
#'            Step size for ADMM. Generally, it should be greater than 1.
#'            Valid only when \emph{solver} is 'ADMM'.\cr
#'            Defaults to 1.8.
#' @param     stat.inf \code{logical, optional}\cr
#'            If TRUE, output t-value and Pr(>|t|) of coefficients.\cr
#'            Defaults to FALSE.
#' @param     adjusted.r2 \code{logical, optional}\cr
#'            If TRUE, include the adjusted R^2 value in statistics.\cr
#'            Defaults to FALSE.
#' @param     dw.test \code{logical, optional}\cr
#'            If TRUE, conduct Durbin-Watson test under null hypothesis that
#'            errors do not follow a first order autoregressive process.
#'            Not available if elastic net regularization is enabled or
#'            intercept is ignored.\cr
#'            Defaults to FALSE.
#' @param     reset.test \code{integer, optional}\cr
#'            Specifies the order of Ramsey RESET test.
#'            Ramsey RESET test with power of variables ranging from 2
#'            to this value (greater than 1) will be conducted.
#'            Value 1 means RESET test will not be conducted.
#'            Not available if elastic net regularization is enabled or
#'            intercept is ignored.\cr
#'            Defaults to 1.
#' @param     bp.test \code{logical, optional}\cr
#'            If TRUE, conduct Breusch-Pagan test under null hypothesis that
#'            homoscedasticity is satisfied.
#'            Not available if elastic net regularization is enabled or
#'            intercept is ignored.\cr
#'            Defaults to FALSE.
#' @param     ks.test \code{logical, optional}\cr
#'            If TRUE, conduct Kolmogorov-Smirnov normality test under
#'            null hypothesis that errors follow a normal distribution.
#'            Not available if elastic net regularization is enabled or
#'            intercept is ignored.\cr
#'            Defaults to FALSE.
#' @template args-threadratio
#' @template args-cate-var
#' @template args-pmmlexport
#' @param  resampling.method   \code{c("cv", "bootstrap"), optional}\cr
#'         Specifies the resampling values form below list.\cr
#'         If no value is specifier, neither model evaluation
#'         nor parameter selection is activated.
#' @param   evaluation.metric   \code{character, optional}\cr
#'   Specifies the evaluation metric for model evaluation or parameter selection.\cr
#'   Currently the only valid option(also the default value) is "rmse".
#' @param  fold.num \code{integer, optional}\cr
#'         Specifies the fold number for the cross-validation(cv).
#'         Mandatory and valid only when \code{resampling.method} is 'cv'.
#' @template args-crossvalidation-group
#' @param parameter.range   \code{list, optional}\cr
#'      Specifies range of the following parameters for parameter selection:\cr
#'      \code{enet.lambda, enet.alpha}.\cr
#'      Parameter range should be specified by 3 numbers in the form of c(start, step, end).\cr
#'      Examples:\cr
#'      parameter.range <- list(enet.lambda = c(0.01, 0.01, 0.1)), which means taking
#'      \code{enet.lambda} values from 0.01 to 0.1 with 0.01 being the step size, i.e.
#'      0.01, 0.02, 0.03, ..., 0.09, 0.1.\cr
#'      If \code{param.search.strategy} is 'random', then the middle term,
#'      i.e. step has no effect and thus can be omitted.
#' @param parameter.values   \code{list, optional}\cr
#'       Specifies values of the following parameters for parameter selection:\cr
#'       \code{enet.lambda, enet.alpha}.\cr
#'       Example: parameter.values <- list(enet.lambda = c(0.001, 0.003, 0.007, 0.01))
#'
#' @return
#' Returns a "LinearRegression" object with following values:
#' \itemize{
#'    \item{coefficients : \code{DataFrame}}\cr
#'         Fitted regression coefficients.
#'    \item{pmml : \code{DataFrame}}\cr
#'         PMML model. Set to NULL if no PMML model was requested.
#'    \item{fitted : \code{DataFrame}}\cr
#'        Predicted dependent variable values for training data.
#'        Set to NULL if the training data has no row IDs.
#'    \item{statistics : \code{DataFrame}}\cr
#'        Regression-related statistics, such as mean squared error.
#'    \item{optim.param : \code{DataFrame}}\cr
#'        Optimal parameters selected. Available only when parameter selection
#'        is activated.
#' }
#'
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    ID      Y    X1 X2  X3
#' 1  0  -6.879  0.00  A   1
#' 2  1  -3.449  0.50  A   1
#' 3  2   6.635  0.54  B   1
#' 4  3  11.844  1.04  B   1
#' 5  4   2.786  1.50  A   1
#' 6  5   2.389  0.04  B   2
#' 7  6  -0.011  2.00  A   2
#' 8  7   8.839  2.04  B   2
#' 9  8   4.689  1.54  B   1
#' 10 9  -5.507  1.00  A   2
#' }
#' Model traning and a "LinearRegression" object lr is returned:
#' \preformatted{
#' >lr <- LinearRegression(data = data, key = "ID",
#'                         label = "Y", thread.ratio = 0.5,
#'                         categorical.variable = list("X3"))
#' }
#' Output:
#' \preformatted{
#' > lr$coefficients$Select(c("VARIABLE_NAME",
#'                            "COEFFICIENT_VALUE"))
#'         VARIABLE_NAME COEFFICIENT_VALUE
#' 1   __PAL_INTERCEPT__           -5.7045
#' 2                  X1            3.0925
#' 3  X2__PAL_DELIMIT__A            0.0000
#' 4  X2__PAL_DELIMIT__B            9.3675
#' 5  X3__PAL_DELIMIT__1            0.0000
#' 6  X3__PAL_DELIMIT__2           -2.6895
#' }
#' @keywords Regression
#' @export
hanaml.LinearRegression <- function(data = NULL, key = NULL, features = NULL,
                                    label = NULL, formula = NULL,
                                    solver = NULL, var.select = NULL,
                                    features.must.select = NULL,
                                    intercept = NULL, alpha.to.enter = NULL,
                                    alpha.to.remove = NULL, enet.lambda = NULL,
                                    enet.alpha = NULL, max.iter = NULL,
                                    tol = NULL, pho = NULL, stat.inf = NULL,
                                    adjusted.r2 = NULL,
                                    dw.test = NULL, reset.test = NULL,
                                    bp.test = NULL, ks.test = NULL,
                                    thread.ratio = NULL,
                                    categorical.variable = NULL,
                                    pmml.export = NULL,
                                    resampling.method = NULL,
                                    evaluation.metric = NULL,
                                    fold.num = NULL, repeat.times = NULL,
                                    param.search.strategy = NULL,
                                    random.search.times = NULL,
                                    random.state = NULL,
                                    timeout = NULL,
                                    progress.indicator.id = NULL,
                                    parameter.range = NULL,
                                    parameter.values = NULL){
  LinearRegression$new(data, key, features, label, formula,
                       solver, var.select, features.must.select,
                       intercept, alpha.to.enter,
                       alpha.to.remove, enet.lambda, enet.alpha,
                       max.iter, tol, pho, stat.inf,
                       adjusted.r2, dw.test, reset.test, bp.test,
                       ks.test, thread.ratio, categorical.variable,
                       pmml.export, resampling.method,
                       evaluation.metric,
                       fold.num, repeat.times,
                       param.search.strategy,
                       random.search.times,
                       random.state,
                       timeout, progress.indicator.id,
                       parameter.range,
                       parameter.values)
}


#' @title Make Predictions from a "LinearRegression" Object
#' @name predict.LinearRegression
#' @description Similar to other predict methods, this function
#' predicts fitted values from a fitted "LinearRegression" object.
#' @seealso \code{\link{hanaml.LinearRegression}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#' A "LinearRegression" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @param model.format \code{character, optional}\cr
#' Choose the format of mdoel. 'coefficients' or 'pmml'.\cr
#' Defaults to 'coefficients'.
#' @param     ... Reserved parameter.
#' @return
#' Predicted values are returned as a DataFrame, structured as follows.
#' \itemize{
#'   \item{ID column, with same name and type as \emph{data}'s ID column.}
#'   \item{VALUE, type DOUBLE, representing predicted values.}
#' }
#'
#' @section Examples:
#' Perform the predict on DataFrame data2 using "LinearRegression" object lr:
#' \preformatted{
#' >data2$Collect()
#'    ID     X1 X2  X3
#' 1   0  1.690  B   1
#' 2   1  0.054  B   2
#' 3   2  0.123  A   2
#' 4   3  1.980  A   1
#' 5   4  0.563  A   1
#' }
#' Call the function and obtain the result:
#' \preformatted{
#' >fitted <- predict(model = lr, data = data2, key = "ID")$Collect()
#'    ID      VALUE
#' 1   0  10.314760
#' 2   1   1.685926
#' 3   2  -7.409561
#' 4   3   2.021592
#' 5   4  -3.122685
#' }
#' @keywords Regression
#' @export
predict.LinearRegression <- function(model,
                                     data,
                                     key,
                                     features = NULL,
                                     model.format = NULL, ...){
  model.format <-
    validateInput("model.format", model.format, model$model.format.map)
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn <- data$connection.context

  if (!is.null(model$model)){
    predict.model <- model$model
  } else if (!is.null(model$coefficients)){
    predict.model <- model$coefficients
  } else if (!is.null(model$pmml)){
    predict.model <- model$pmml
  } else{
    msg <- "Model is NULL. Perform a fit first."
    flog.error(msg = msg)
    stop(msg)
  }
  cols <- data$columns
  key <- validateInput("key", key, cols, required = TRUE, case.sensitive = TRUE)
  cols <- cols[! cols %in% key]
  features <- validateInput("features", features, cols, case.sensitive = TRUE)
  if (is.null(features)){
    features <- cols
  }
  data.list <- list(key)
  data.list <- append(data.list, features)
  data <- data$Select(data.list)
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_LINEAR_REGRESSION_PARAM_TBL_%s_%s", model$id, unique.id)
  fitted.tbl <- sprintf("#PAL_LINEAR_REGRESSION_FITTED_TBL_%s_%s", model$id, unique.id)
  param.rows <- list(tuple("THREAD_RATIO", NULL, model$thread.ratio, NULL),
                     tuple("MODEL_FORMAT",
                           map.null(model.format, model$model.format.map), NULL, NULL))

  tables <- list(param.tbl, fitted.tbl)
  in.tables <- list(data, model$coefficients$name, param.tbl)
  out.tables <- list(fitted.tbl)
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                ParameterTable$new(param.tbl)$WithData(param.rows)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_LINEAR_REGRESSION_PREDICT",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return (conn$table(fitted.tbl))
}

#' @export
print.LinearRegression <- function(x, ...){
  writeLines("Linear Model Attributes::")
  cat(sprintf("Adjusted r2 : %s", to.null(x$adjusted.r2)))
  writeLines("\n")
  cat(sprintf("Alpha to enter : %s", to.null(x$alpha.to.enter)))
  writeLines("\n")
  cat(sprintf("Alpha to enter :%s", to.null(x$alpha.to.remove)))
  writeLines("\n")
  cat(sprintf("BP Test :%s", to.null(x$bp.test)))
  writeLines("\n")
  cat(sprintf("DW Test :%s", to.null(x$dw.test)))
  writeLines("\n")
  cat(sprintf("Enet Alpha :%s", to.null(x$enet.alpha)))
  writeLines("\n")
  cat(sprintf("Enet Lambda :%s", to.null(x$enet.lambda)))
  writeLines("\n")
  cat(sprintf("Intercept :%s", to.null(x$intercept)))
  writeLines("\n")
  cat(sprintf("KS Test :%s", to.null(x$ks.test)))
  writeLines("\n")
  cat(sprintf("Max Iter :%s", to.null(x$max.iter)))
  writeLines("\n")
  cat(sprintf("Pho :%s", to.null(x$pho)))
  writeLines("\n")
  cat(sprintf("Pmml Export :%s", to.null(x$pmml.export)))
  writeLines("\n")
  cat(sprintf("Reset Test :%s", to.null(x$reset.test)))
  writeLines("\n")
  cat(sprintf("Solver :%s", to.null(x$solver)))
  writeLines("\n")
  cat(sprintf("Stat Inf :%s", to.null(x$stat.inf)))
  writeLines("\n")
  cat(sprintf("Thread Ratio :%s", to.null(x$thread.ratio)))
  writeLines("\n")
  cat(sprintf("Tol :%s", to.null(x$tol)))
  writeLines("\n")
  cat(sprintf("Var Select :%s", to.null(x$var.select)))
}

#' @export
summary.LinearRegression  <- function(object, ...){
  writeLines("Linear Regression Coeffecient table::")
  print(to.null(object$coefficients$Collect()))
  writeLines("\n")
  writeLines("Linear Fitted table::")
  print(to.null(object$fitted$Collect()))
  writeLines("\n")
  writeLines("Linear Statistics table::")
  print(to.null(object$statistics$Collect()))
}
