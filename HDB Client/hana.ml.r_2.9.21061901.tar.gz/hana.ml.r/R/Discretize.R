Discretize <- R6Class(
  "Discretize",
  inherit = MlBase,
  public = list(
    binning.variable = NULL,
    strategy = NULL, #BINNING METHOD
    smoothing = NULL, # DEFAULT_SMOOTHING_METHOD
    col.smoothing = NULL,
    n.bins = NULL, #BIN_NUMBER
    bin.size = NULL, #BIN_DISTANCE
    n.sd = NULL, #SD
    categorical.variable = NULL,
    save.model = NULL,
    result = NULL,
    statistics = NULL,
    model = NULL,
    assignment = NULL,
    strategy.map =
      list(uniform.number = 0, uniform.size = 1, quantile = 2, sd = 3),
    smooth.map =
      list(no = 0, bin.means = 1, bin.medians = 2, bin.boundaries = 3),
    initialize = function(data = NULL,
                          key = NULL,
                          features = NULL,
                          binning.variable = NULL,
                          strategy  = NULL, #BINNING METHOD
                          smoothing = NULL, # DEFAULT_SMOOTHING_METHOD
                          col.smoothing = NULL,
                          n.bins = NULL, #BIN_NUMBER
                          bin.size = NULL, #BIN_DISTANCE
                          n.sd = NULL, #SD
                          categorical.variable = NULL,
                          save.model = NULL) {
      super$initialize()
      if (!is.null(data)) {
        binning.variable <-
          validateInput("binning.variable", binning.variable, "character",
                        required = TRUE)
        self$strategy <-
            validateInput("strategy", strategy, self$strategy.map, required = TRUE)
        self$smoothing <-
          validateInput("smoothing", smoothing, self$smooth.map)
        self$n.bins <- validateInput("n.bins", n.bins, "integer")
        self$bin.size <- validateInput("bin.size", bin.size, "double")
        self$n.sd <- validateInput("n.sd", n.sd, "integer")
        if (!is.null(self$n.bins) &&
            (!self$strategy %in% c("uniform.number", "quantile"))) {
          msg <- paste("Bin number `n.bins` only valid when `strategy`",
          "is 'uniform.number' or 'quantile'!")
          flog.error(msg)
          stop(msg)
        }
        if (!is.null(bin.size) && self$strategy != "uniform.size") {
          msg <- paste("`bin.size` only valid when `method` is 'uniform.size'!")
          flog.error(msg)
          stop(msg)
        }
        if (!is.null(n.sd) && self$strategy != "sd") {
          msg <- paste("`n.sd` only valid when `method` is 'sd'!")
          flog.error(msg)
          stop(msg)
        }
        types <- data$dtypes()
        tp.list <- list()
        for (tp in types){
          tp.list <- c(tp.list, tp[[2]])
        }
        cols <- data$columns
        key <- validateInput("key", key, cols, case.sensitive = TRUE,
                             required = TRUE)
        tp.list <- tp.list[! cols %in% key]
        cols <- cols[! cols %in% key]
        features <- validateInput("features", features, cols,
                                  case.sensitive = TRUE)
        self$categorical.variable <- validateInput("categorical.variable",
                                                   categorical.variable,
                                                   cols,
                                                   case.sensitive = TRUE)
        if (is.null(features)) {
          features <- cols
        }
        cols <- cols[tp.list %in% c("INTEGER", "DOUBLE")]
        cols <- cols[cols %in% features]
        cols <- cols[! cols %in% self$categorical.variable]#exclude categorical variables
        self$binning.variable <-
          validateInput("binning.variable", binning.variable, cols,
                        required = TRUE, case.sensitive = TRUE)
        if (length(col.smoothing) != 0){
          if ((length(names(col.smoothing)) != length(col.smoothing))) {#nolint
            msg <- paste("Each element in `col.smoothing` must be",
                         "named by a valid column name in `data`.")
            flog.error(msg)
            stop(msg)
          } else {
            col.names <- names(col.smoothing)
            validateInput("Names of `col.smoothing`",
                          col.names,
                          cols,
                          case.sensitive = TRUE)
            self$col.smoothing <- validateInput("col.smoothing",
                                                col.smoothing,
                                                self$smooth.map)
            names(self$col.smoothing) <- col.names
          }
        }
        if (!inherits(data, "DataFrame")) {
          msg <- "data must be given as a DataFrame"
          flog.error(msg)
          stop(msg)
        } else {
          CheckConnection(data)
          conn.context <- data$connection.context
          data <- data$Select(c(key, features))

          unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
          param.tbl <- sprintf("#PAL_PARAMETER_TBL_%s_%s", self$id, unique.id)
          result.tbl <- sprintf("#PAL_DISC_RESULT_TBL_%s_%s", self$id, unique.id)
          assignment.tbl <- sprintf("#PAL_DISC_ASSIGNMENT_TBL_%s_%s", self$id, unique.id)
          model.tbl <- sprintf("#PAL_DISC_MODEL_TBL_%s_%s", self$id, unique.id)
          statistics.tbl <- sprintf("#PAL_DISC_STATISTIC_TBL_%s_%s", self$id, unique.id)
          tables <- list(
            param.tbl,
            result.tbl,
            assignment.tbl,
            model.tbl,
            statistics.tbl
          )
          in.tables <- list(data, param.tbl)
          out.tables <- list(result.tbl,
                             assignment.tbl,
                             model.tbl,
                             statistics.tbl)
          param.rows <- list(
            tuple("METHOD",
                  map.null(self$strategy, self$strategy.map), NULL, NULL),
            tuple("BIN_NUMBER", self$n.bins, NULL, NULL),
            tuple("BIN_DISTANCE", NULL, self$bin.size, NULL),
            tuple("DEFAULT_SMOOTHING_METHOD",
                  map.null(self$smoothing, self$smooth.map), NULL, NULL),
            tuple("SD", self$n.sd, NULL, NULL),
            tuple("BINNING_VARIABLE", NULL, NULL, self$binning.variable)
          )
          if (!is.null(self$categorical.variable)) {
            for (each in self$categorical.variable) {
              temp.list <- tuple("CATEGORICAL_VARIABLE", NULL, NULL, each)
              param.rows <-
                append(param.rows, tuple(temp.list))
            }
          }
          if (length(self$col.smoothing) != 0){
            for (i in 1:length(self$col.smoothing)) {
              temp.list <-
                tuple("SMOOTHING_METHOD",
                      map.null(self$col.smoothing[[i]],
                               self$smooth.map),
                      NULL, names(self$col.smoothing[i]))
                param.rows <-
                  append(param.rows, list(temp.list))
            }
          }
          tryCatch({
            errorhelper(CreateTWithConnection(conn.context,
              (ParameterTable$new(param.tbl))$WithData(param.rows)))
            errorhelper(CallPalAutoWithConnection(conn.context,
              "PAL_DISCRETIZE", in.tables, out.tables))
          },
          error = function(err){
            msg <- paste("Error:", err[["message"]])
            flog.error(msg)
            TryDropWithConnection(conn.context, tables)
            stop(msg)
          })
          self$result <- conn.context$table(result.tbl)
          self$assignment <- conn.context$table(assignment.tbl)
          self$model <- conn.context$table(model.tbl)
          self$statistics <- conn.context$table(statistics.tbl)
        }
      }
    }
  )
)

#' @title Discretize
#' @name hanaml.Discretize
#' @description hanaml.Discretize is a R wrapper for SAP HANA PAL Discretize.
#' @details
#' It is an enhanced version of binning function which can be applied to table
#' with multiple columns. This function partitions table rows into multiple
#' segments called bins, then applies smoothing methods in each bin of each
#' column respectively.
#' @seealso \code{\link{transform.Discretize}}
#' @template args-data
#' @template args-key
#' @template args-feature-multiple
#' @param binning.variable \code{list of character}\cr
#' Attribute name, to which binning operation is applied.
#' @param strategy \code{character}\cr
#' \itemize{Binning methods:
#'    \item{\code{"uniform.number"}: equal widths based on the number of bins}
#'    \item{\code{"uniform.size"}: equal widths based on the bin width}
#'    \item{\code{"quantile"}: equal number of records per bin}
#'    \item{\code{"sd"}: mean/ standard deviation bin boundaries}}
#' @param smoothing \code{character, optional}\cr
#' \itemize{Default overall smoothing methods:
#'     \item{\code{"no"}: no smoothing}
#'     \item{\code{"bin.means"}: smoothing by bin means}
#'     \item{\code{"bin.medians"}: smoothing by bin medians}
#'     \item{\code{"bin.boundaries"}: smoothing by bin boundaries}}
#' Only applies for none-categorical attributes that do not get specified
#' smoothing method by parameter \emph{col.smoothing}.\cr
#' No default value.
#' @param col.smoothing : \code{list of characters, optional}\cr
#'  Specifies smoothing method for columns, which overwrites the default smoothing method.
#'  Each element must be a valid smoothing method, and a name which specifies a column in
#'  \emph{data}.\cr
#'  Suppose \emph{data} has two columns: ATT1 and ATT2, then we can set the smoothing method
#'  for these two columns as follows:\cr
#'  \itemize{
#'    col.smoothing = list("ATT1" = "bin.means", "ATT2" = "bin.boundaries")
#'  } or
#'  equivalently
#'  \itemize{
#'    col.smoothing = c(ATT1 = "bin.means", ATT2 = "bin.boundaries")
#'  }
#'  Only applies for numerical attributes. \cr
#'  No default value.
#' @param n.bins \code{integer, optional}\cr
#' Number of needed bins.\cr
#' 	Only valid when \emph{strategy} is "uniform.number" or "quantile".\cr
#' Defaults to 2.
#' @param bin.size \code{double, optional}\cr
#' 	Specifies the distance for binning. \cr
#' 	Only valid when \emph{strategy} is 'uniform.size'.\cr
#' 	Defaults to 10.
#' @param n.sd \code{integer, optional}\cr
#' Specifies the number of standard deviation at each side of the mean.\cr
#' Only valid when \emph{strategy} is 'sd'.\cr
#' Defaults to 1.
#' @template args-cate-var
#' @param save.model \code{logical, optional}\cr
#' \itemize{Indicates whether the model is saved.
#'         \item{\code{FALSE}: not save}
#'         \item{\code{TRUE}: save}}
#' @return
#' A "Discretize" object with the following attributes:
#' \itemize{
#'   \item{result: \code{DataFrame}}\cr
#'    Discretize results, structured as follows:
#'    \itemize{
#'      \item{ID} : name as shown in input DataFrame
#'      \item{FEATURES} : data smoothed respectively in each bins
#'    }
#'    \item{assignment: \code{DataFrame}}\cr
#'    Assignment results, structured as follows:
#'    \itemize{
#'      \item{ID} : data ID, name as shown in input DataFrame.
#'      \item{BIN_INDEX} : bin index.
#'    }
#'  \item{model: \code{DataFrame}}\cr
#'    Model results, structured as follows:
#'    \itemize{
#'      \item{ROW_INDEX} : row index.
#'      \item{MODEL_CONTENT} : model contents.
#'  }
#'  \item{statistics: \code{DataFrame}}\cr
#'    Statistic results, structured as follows:
#'    \itemize{
#'      \item{STAT_NAME} :  statistic name.
#'      \item{STAT_VALUE} : statistic value.
#'    }
#' }
#'
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#'    ID ATT1 ATT2 ATT3 ATT4
#' 1   1 10.0  100    1    A
#' 2   2 10.1  101    1    A
#' 3   3 10.2  100    1    A
#' 4   4 10.4  103    1    A
#' 5   5 10.3  100    1    A
#' 6   6 40.0  400    4    C
#' 7   7 40.1  402    4    B
#' 8   8 40.2  400    4    B
#' 9   9 40.4  402    4    B
#' 10 10 40.3  400    4    A
#' 11 11 90.0  900    2    C
#' 12 12 90.1  903    1    B
#' 13 13 90.2  901    2    B
#' 14 14 90.4  900    1    B
#' 15 15 90.3  900    1    B
#' }
#' Call the function and a "Discretize" object discretize is returned:
#' \preformatted{
#' > discretize <- hanaml.Discretize(data,
#'                                   key = "ID",
#'                                   features = c("ATT1", "ATT2",  "ATT3", "ATT4"),
#'                                   binning.variable = "ATT1",
#'                                   strategy = "uniform.number",
#'                                   smoothing = "bin.boundaries",
#'                                   col.smoothing = list(ATT2  = "bin.means"),
#'                                   n.bins = 3,
#'                                   categorical.variable = "ATT3")
#' }
#' Expected output:
#' \preformatted{
#' > discretize$result$Collect()
#'    ID ATT1  ATT2 ATT3 ATT4
#' 1   1 10.2 100.8    1    A
#' 2   2 10.2 100.8    1    A
#' 3   3 10.2 100.8    1    A
#' 4   4 10.2 100.8    1    A
#' 5   5 10.2 100.8    1    A
#' 6   6 40.2 400.8    4    C
#' 7   7 40.2 400.8    4    B
#' 8   8 40.2 400.8    4    B
#' 9   9 40.2 400.8    4    B
#' 10 10 40.2 400.8    4    A
#' 11 11 90.2 900.8    2    C
#' 12 12 90.2 900.8    1    B
#' 13 13 90.2 900.8    2    B
#' 14 14 90.2 900.8    1    B
#' 15 15 90.2 900.8    1    B
#' }
#' @keywords Preprocessing
#' @export
hanaml.Discretize <- function(data = NULL,
                              key = NULL,
                              features = NULL,
                              binning.variable = NULL,
                              strategy = NULL,
                              smoothing = NULL,
                              col.smoothing = NULL,
                              n.bins = NULL,
                              bin.size = NULL,
                              n.sd = NULL,
                              categorical.variable = NULL,
                              save.model = NULL) {
  Discretize$new(data, key, features, binning.variable, strategy,
                 smoothing, col.smoothing, n.bins, bin.size, n.sd,
                 categorical.variable, save.model)
}

#' @title Make Transformation from a "Discretize" Object
#' @name transform.Discretize
#' @description Similar to other transform methods, this function
#' transforms values from a fitted "Kmeans" object.
#' @seealso \code{\link{hanaml.Discretize}}
#' @param model \code{R6Class object}\cr A "Discretize" Object.
#' @template args-data
#' @template args-key
#' @template args-feature-multiple
#' @return
#' Transformed values are returned as a DataFrame, structured as follows.
#' \itemize{
#'   \item{ID column, with same name and type as \emph{data} 's ID column.}
#'   \item{Cluster_ID, type INTEGER, the assigned cluster ID.}
#'   \item{DISTANCE, type DOUBLE, Distance between a given point and the cluster
#'    center.}
#' }
#'
#' @section Examples:
#'Perform the transformation on DataFrame data2 using "Discretize" object discretize:
#' \preformatted{
#' > data2$Collect()
#'   ID ATT1 ATT2 ATT3 ATT4
#' 1  1 20.0  120    1    A
#' 2  2 30.0  101    1    A
#' 3  3 10.7  143    1    B
#' 4  4 15.8  256    1    C
#' 5  5 88.9  100    1    A
#' 6  6 76.5  402    4    A
#' 7  7 55.3  905    4    B
#' }
#' Call the function:
#' \preformatted{
#' > result <- transform(discretize, discretize.df.apply, key = "ID",
#'                      features = list("ATT1", "ATT2", "ATT3", "ATT4"))
#' }
#' Output:
#' \preformatted{
#' > result[[1]]$Collect()
#'    ID ATT1  ATT2 ATT3 ATT4
#' 1  1 10.2 100.8    1    A
#' 2  2 10.2 100.8    1    A
#' 3  3 10.2 100.8    1    B
#' 4  4 10.2 100.8    1    C
#' 5  5 90.2 900.8    1    A
#' 6  6 90.2 900.8    4    A
#' 7  7 40.2 400.8    4    B
#'}
#' @keywords Preprocessing
#' @export
transform.Discretize <- function(model,
                                 data,
                                 key,
                                 features = NULL) {
  if (is.null(model$model) ){
    msg <- "Model is not initialized!"
    flog.error(msg)
    stop(msg)
  }
  conn.context <- data$connection.context
  cols <- data$columns
  key <- validateInput("key", key, cols, required = TRUE,
                       case.sensitive = TRUE)
  cols <- cols[! cols %in% key]
  feature <- validateInput("features", features, cols,
                           case.sensitive = TRUE)
  if (is.null(features)) {
    features <- cols
  }
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_DISC_APPLY_PARAMETER_TBL_%s_%s", model$id,
                       unique.id)
  result.tbl <- sprintf("#PAL_DISC_APPLY_RESULT_TBL_%s_%s", model$id,
                        unique.id)
  assignment.tbl <- sprintf("#PAL_DISC_APPLY_ASSIGNMENT_TBL_%s_%s",
                            model$id, unique.id)
  statistics.tbl <- sprintf("#PAL_DISC_APPLY_STATISTIC_TBL_%s_%s",
                            model$id, unique.id)

  tables <- list(param.tbl,  result.tbl, assignment.tbl, statistics.tbl)
  in.tables <- list(data, model$model$name, param.tbl)
  out.tables <- list(result.tbl, assignment.tbl, statistics.tbl)
  param.rows <- list()
  tryCatch({
    errorhelper(CreateTWithConnection(conn.context,
                                      (ParameterTable$new(param.tbl))$WithData(param.rows)))
    errorhelper(CallPalAutoWithConnection(conn.context,
                                          "PAL_DISCRETIZE_APPLY", in.tables, out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn.context, tables)
    stop(msg)
  })
  statistics <- conn.context$table(statistics.tbl)
  assignment <- conn.context$table(assignment.tbl)
  result <- conn.context$table(result.tbl)
  return (list(result, assignment, statistics))
}
