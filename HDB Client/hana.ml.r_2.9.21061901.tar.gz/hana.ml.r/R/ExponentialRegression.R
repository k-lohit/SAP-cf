ExponentialRegression <- R6Class(
  "ExponentialRegression",
  inherit = RegressionBase,
  public = list(
    initialize = function(data = NULL,
                          key = NULL,
                          features = NULL,
                          label = NULL,
                          formula = NULL,
                          decomposition = NULL,
                          adjusted.r2 = NULL,
                          pmml.export = NULL){
      super$initialize(data,
                       key,
                       features,
                       label,
                       formula,
                       NULL,
                       decomposition,
                       adjusted.r2,
                       pmml.export,
                       "PAL_EXPONENTIAL_REGRESSION")
   }))
#' @title  Exponential Regression
#' @name hanaml.ExponentialRegression
#' @description hanaml.ExponentialRegression is a R wrapper
#' for SAP HANA PAL Exponential Regression algorithm.
#' @details Exponential regression is an approach to modeling the relationship
#' between a scalar variable y and one or more variables denoted X.
#' In exponential regression, data is modeled using exponential functions,
#' and unknown model parameters are estimated from the data.
#' Such models are called exponential models.

#' @seealso \code{\link{predict.ExponentialRegression}}
#' @template args-data
#' @template args-key-optional
#' @template args-feature-multiple
#' @template args-label
#' @template args-formula
#' @template args-decompostion
#' @template args-adjustedr2
#' @template args-pmmlexport
#' @return
#' Return a "ExponentialRegression" object with following values:
#'
#' \itemize{
#' \item{coefficients: \code{DataFrame}}\cr
#'       Fitted regression coefficients.
#' \item{pmml: \code{DataFrame}}\cr
#'       Regression model content in PMML format.
#'       Set to NULL  if no PMML model was requested.
#' \item{model: \code{DataFrame}}\cr
#'       Model is used to save coefficients or PMML model.
#'       If PMML model is requested,
#'       model defaults to PMML model. Otherwise, it is coefficients.
#' \item{fitted: \code{DataFrame}}\cr
#'       Predicted dependent variable values for training data.
#'       Set to NULL if the training data has no row IDs.
#' \item{statistics: \code{DataFrame}}\cr
#'       Regression-related statistics, like mean square error, F-statistics, etc.
#' }
#' @section Examples:
#'  Input DataFrame data:
#' \preformatted{
#'  > data$Collect()
#'        ID    Y   X1   X2
#'     1   0 0.50 0.13 0.33
#'     2   1 0.15 0.14 0.34
#'     3   2 0.25 0.15 0.36
#'     4   3 0.35 0.16 0.35
#'     5   4 0.45 0.17 0.37
#'     6   5 0.55 0.18 0.38
#'     7   6 0.65 0.19 0.39
#'     8   7 0.75 0.19 0.31
#'     9   8 0.85 0.11 0.32
#'     10  9 0.95 0.12 0.33
#' }
#' Call the function:
#' \preformatted{
#' er <-  hanaml.ExponentialRegression(data = data,
#'                                     key = 'ID',
#'                                     label = 'Y',
#'                                     features = list('X1','X2'),
#'                                     pmml.export='multi-row')
#' }
#' Output:
#' \preformatted{
#' > er$coefficients$Collect()
#'       VARIABLE_NAME COEFFICIENT_VALUE
#' 1 __PAL_INTERCEPT__          2.727731
#' 2                X1          2.674141
#' 3                X2         -6.180427
#'
#' }
#' @keywords Regression
#' @export
hanaml.ExponentialRegression <- function(data = NULL,
                                         key = NULL,
                                         features = NULL,
                                         label = NULL,
                                         formula = NULL,
                                         decomposition = NULL,
                                         adjusted.r2 = NULL,
                                         pmml.export = NULL){
  ExponentialRegression$new(data, key, features, label, formula,
                            decomposition, adjusted.r2, pmml.export)
}

#' @title Make Predictions from a "ExponentialRegression" Object
#' @name predict.ExponentialRegression
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "ExponentialRegression" object.
#' @seealso \code{\link{hanaml.ExponentialRegression}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#'  A "ExponentialRegression" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @template args-threadratio
#' @template args-modelformat
#' @return
#' Predicted values are returned as a DataFrame, structured as follows.
#' \itemize{
#'    \item{ID: with same name and type as \emph{data}'s ID column.}
#'    \item{VALUE: type DOUBLE, representing predicted values.}
#' }
#'
#' @section Examples:
#'  DataFrame data.predict for prediction:
#' \preformatted{
#'  > data.predict$Collect()
#'    ID  X1   X2
#'  1  0 0.5 0.30
#'  2  1 4.0 0.40
#'  3  2 0.0 1.60
#'  4  3 0.3 0.45
#'  5  4 0.4 1.70
#' }
#'  Fitted values of the prediction data using a "ExponentialRegression" Object er:
#' \preformatted{
#'   > predict(model = er, data = data.predict, key = "ID")
#'     ID       VALUE
#'   1  0 0.690059893
#'   2  1 1.234150232
#'   3  2 0.006630664
#'   4  3 0.388797021
#'   5  4 0.005210654
#' }
#' @export
#' @keywords Regression
predict.ExponentialRegression <- function(model,
                                          data,
                                          key,
                                          features = NULL,
                                          thread.ratio = NULL,
                                          model.format = NULL){
  model$predict(data,
                key,
                features,
                thread.ratio,
                model.format,
                "PAL_EXPONENTIAL_REGRESSION_PREDICT")
}

#' @export
print.ExponentialRegression <- function(x, ...){
  writeLines("\n")
  writeLines("ExponentialRegression attributes:")
  writeLines("\n")
  cat(sprintf("decomposition : %s", to.null(x$decomposition)))
  writeLines("\n")
  cat(sprintf("adjusted.r2 : %s", to.null(x$adjusted.r2)))
  writeLines("\n")
  cat(sprintf("pmml.export : %s", to.null(x$poly.pmml.export)))
  writeLines("\n")
}

#' @export
summary.ExponentialRegression <- function(object, ...){
    writeLines("ExponentialRegression coefficients DataFrame:")
    print(object$coefficients$Collect())
    writeLines("\n")
    writeLines("ExponentialRegression fitted DataFrame:")
    print(object$fitted$Collect())
    writeLines("\n")
    writeLines("ExponentialRegression model DataFrame:")
    print(object$model$Collect())
    writeLines("\n")
    writeLines("ExponentialRegression statistics DataFrame:")
    print(object$statistics$Collect())
    writeLines("\n")
    writeLines("ExponentialRegression pmml DataFrame:")
    print(object$pmml$Collect())
    writeLines("\n")
}
