NaiveBayes <- R6Class(
  "NaiveBayes",
  inherit = MlBase,
  public = list(
    model.format.map = list("json" = 0, "pmml" = 1),
    discretization.map = list("no" = 0, "supervised" = 1),
    alpha = NULL,
    discretization = NULL,
    model.format = NULL,
    model = NULL,
    statistics = NULL,
    optim.param = NULL,
    categorical.variable = NULL,
    thread.ratio = NULL,
    resampling.method = NULL,
    evaluation.metric = NULL,
    fold.num = NULL,
    repeat.times = NULL,
    param.search.strategy = NULL,
    random.search.times = NULL,
    random.state = NULL,
    timeout = NULL,
    progress.indicator.id = NULL,
    parameter.range = NULL,
    parameter.values = NULL,
    initialize = function(data = NULL,
                          key = NULL,
                          features = NULL,
                          label = NULL,
                          formula = NULL,
                          alpha = NULL,
                          discretization = NULL,
                          model.format = NULL,
                          categorical.variable = NULL,
                          thread.ratio = NULL,
                          resampling.method = NULL,
                          evaluation.metric = NULL,
                          fold.num = NULL, repeat.times = NULL,
                          param.search.strategy = NULL,
                          random.search.times = NULL,
                          random.state = NULL,
                          timeout = NULL,
                          progress.indicator.id = NULL,
                          parameter.range = NULL,
                          parameter.values = NULL){
      super$initialize()
      if (!is.null(data)){
         self$alpha <- validateInput ("alpha", alpha, "double")
        self$discretization <-
          validateInput("discretization", discretization, self$discretization.map)
        self$model.format <-
          validateInput("model.format", model.format, self$model.format.map)
        self$thread.ratio <- validateInput("thread.ratio", thread.ratio, "numeric")
        cols <- data$columns
        key <- validateInput("key", key, cols, case.sensitive = TRUE)
        if (inherits(formula, "formula")){
          parseformula <- ParseFormula(data, formula)
          label <- parseformula[[1]]
          features <- parseformula[[2]]
          features <- features[! features %in% key]
        }
        if (!is.null(key)){
          id.col <- list(key)
          cols <- cols[! cols %in% key]
        } else {
          id.col <- list()
        }
        self$categorical.variable <- validateInput("categorical.variable",
                                                   categorical.variable,
                                                   cols,
                                                   case.sensitive = TRUE)
        self$resampling.method <-
          validateInput("resampling.method",
                        resampling.method,
                        list(cv = "cv",
                             stratified_cv = "stratified_cv",
                             bootstrap = "bootstrap",
                             stratified_bootstrap = "stratified_bootstrap"
                        ))
        self$evaluation.metric <-
          validateInput("evaluation.metric",
                        evaluation.metric,
                        list(accuracy = "ACCURACY",
                             f1_score = "F1_SCORE",
                             auc = "AUC",
                             nll = "NLL"),
                        required = isTRUE(!is.null(resampling.method)))
        self$repeat.times <- validateInput("repeat.times",
                                           repeat.times,
                                           "integer")
        self$fold.num <-
          validateInput("fold.num", fold.num, "integer",
                        required = isTRUE(grepl("cv",
                                                self$resampling.method)))
        self$param.search.strategy <-
          validateInput("param.search.strategy",
                        param.search.strategy,
                        list(grid = "grid",
                             random = "random"))
        self$random.search.times <-
          validateInput("random.search.times", random.search.times, "integer",
                        required = isTRUE(grepl("rand",
                                                self$param.search.strategy)))
        self$random.state <- validateInput("random.state",
                                           random.state,
                                           "integer")
        self$timeout <- validateInput("timeout", timeout, "integer")
        self$progress.indicator.id <- validateInput("progress.indicator.id",
                                                    progress.indicator.id,
                                                    "character")
        if (length(parameter.values) > 0){
          validateInput("Parameters for value specification",
                        names(parameter.values),
                        list("alpha"),
                        case.sensitive = TRUE)
        }
        if (length(parameter.range) > 0){
          validateInput("Parameters for range specification",
                        names(parameter.range),
                        list("alpha"),
                        case.sensitive = TRUE)
        }
        self$parameter.range <- parameter.range
        self$parameter.values <- parameter.values
        label <- validateInput("label", label, cols, case.sensitive = TRUE)
        if (is.null(label)){
          label <- cols[[length(cols)]]
        }
        cols <- cols[! cols %in% label]
        features <- validateInput("features", features, cols, case.sensitive = TRUE)
        if (is.null(features)){
          features <- cols
        }
        id.col <- append(append(id.col, features), label)
        if (!inherits(data, "DataFrame")) {
          msg <- "If training data is not omitted, it must be DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn <- data$connection.context
        df <- data$Select(id.col)

        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#NAIVE_BAYES_PARAMS_TBL_%s_%s", self$id, unique.id)
        model.tbl <- sprintf("#NAIVE_BAYES_MODEL_TBL_%s_%s", self$id, unique.id)
        stats.tbl <- sprintf("#NAIVE_BAYES_STATS_TBL_%s_%s", self$id, unique.id)
        optparam.tbl <- sprintf("#NAIVE_BAYES_OPTPARAM_TBL_%s_%s", self$id, unique.id)
        tables <- list(param.tbl, model.tbl, stats.tbl, optparam.tbl)
        in.tables <- list(df, param.tbl)
        out.tables <- list(model.tbl, stats.tbl, optparam.tbl)
        param.data <- list(
          tuple("LAPLACE", NULL, self$alpha, NULL),
          tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),
          tuple("HAS_ID",
                as.integer(!is.null(key)),
                NULL, NULL),
          tuple("DISCRETIZATION",
                map.null(self$discretization,
                         self$discretization.map),
                NULL, NULL),
          tuple("MODEL_FORMAT",
                map.null(self$model.format,
                         self$model.format.map),
                NULL, NULL),
          tuple("RESAMPLING_METHOD", NULL, NULL, self$resampling.method),
          tuple("PARAM_SEARCH_STRATEGY", NULL, NULL,
                self$param.search.strategy),
          tuple("FOLD_NUM", self$fold.num, NULL, NULL),
          tuple("REPEAT_TIMES", self$repeat.times, NULL, NULL),
          tuple("TIMEOUT", self$timeout, NULL, NULL),
          tuple("RANDOM_SEARCH_TIMES", self$random.search.times, NULL, NULL),
          tuple("SEED", self$random.state, NULL, NULL),
          tuple("PROGRESS_INDICATOR_ID", NULL, NULL,
                self$progress.indicator.id)
        )
        if (!is.null(self$evaluation.metric)){
          tup <- tuple("EVALUATION_METRIC", NULL, NULL,
                       toupper(self$evaluation.metric))
          param.data <- append(param.data, list(tup))
        }
        if (!is.null(self$categorical.variable)) {
          for (each in self$categorical.variable) {
            temp.list <- tuple("CATEGORICAL_VARIABLE", NULL, NULL, each)
            param.data <- append(param.data, list(temp.list))
          }
        }
        if (length(self$parameter.values) > 0){
          str.values <- paste("{",
                              paste0(self$parameter.values[[1]],
                                     collapse = ","),
                              "}", sep = "")
          temp.tup <- tuple("LAPLACE_VALUES",
                            NULL, NULL, str.values)
          param.data <-
            append(param.data,  list(temp.tup))
        }
        if (length(self$parameter.range) > 0){
          range.temp <- self$parameter.range[[1]]
          cps <- ifelse(length(range.temp) == 2, ",,", ",")
          str.range <- paste("[",
                             paste0(range.temp,
                                    collapse = cps),
                             "]", sep = "")
          temp.tup <- tuple("LAPLACE_RANGE",
                            NULL, NULL, str.range)
          param.data <-
            append(param.data, list(temp.tup))
        }
        tryCatch({
          errorhelper(CreateTWithConnection(conn,
                      ParameterTable$new(param.tbl)$WithData(param.data)))
          errorhelper(CallPalAutoWithConnection(conn,
                                                "PAL_NAIVE_BAYES",
                                                in.tables,
                                                out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })

        self$model <- conn$table(model.tbl)
        self$statistics <- conn$table(stats.tbl)
        self$optim.param <- conn$table(optparam.tbl)
      }
    },
    score = function(data,
                     key,
                     features= NULL,
                     label= NULL,
                     alpha= NULL){
      if (is.null(data)){
        msg <- "Please provide the data for scoring."
        flog.error(msg)
        stop(msg)
      }
      if (is.null(self$model)){
        msg <- "Model is NULL, perform the fit first"
        flog.error(msg)
        stop(msg)
      }
      if (!inherits(data, "DataFrame")){
        msg <- "Data for score must be a DataFrame."
        flog.error(msg)
        stop(msg)
      }
      conn <- data$connection.context
      CheckConnection(data)
      cols <- data$columns
      key <- validateInput("key", key, cols, case.sensitive = TRUE, required = TRUE)
      cols <- cols[! cols %in% key]
      label <- validateInput("label", label, cols, case.sensitive = TRUE)
      if (is.null(label)){
        label <- cols[[length(cols)]]
      }
      cols <- cols[! cols %in% label]
      features <- validateInput("features", features, cols, case.sensitive = TRUE)
      if (is.null(features))
        features <- cols
      prediction <- predict(self, data, key = key, alpha = alpha,
                            features = features)
      prediction <- prediction$Select(list(key, "CLASS"))
      prediction <- prediction$rename.columns(list("ID_P", "PREDICTION"))
      actual <- data$Select(list(key, label))
      actual <- actual$rename.columns(list("ID_A", "ACTUAL"))
      joined <- actual$Join(prediction, "ID_P=ID_A")
      joined <- joined$Select(list("ACTUAL", "PREDICTION"))
      acc.score <- accuracy.score(conn,
                                  joined,
                                  label.true = "ACTUAL",
                                  label.pred = "PREDICTION")
      return(acc.score)
    }
  )
)
#' @title  Naive Bayes
#' @name hanaml.NaiveBayes
#' @description hanaml.NaiveBayes is a R wrapper for SAP HANA PAL Naive Bayes.
#' @details Naive Bayes is a classification algorithm based on Bayes theorem.
#' It estimates the class-conditional probability by assuming that
#' the attributes are conditionally independent of one another.
#' @seealso \code{\link{predict.NaiveBayes}}
#' @template args-data
#' @template args-key-optional
#' @template args-feature-multiple
#' @template args-label
#' @template args-formula
#' @param      alpha  \code{double, optional}\cr
#'            Laplace smoothing value. Set a positive value to enable Laplace smoothing
#'            for categorical variables and use that value as the smoothing parameter.
#'            Set value 0 to disable Laplace smoothing.\cr
#'            Defaults to 0.
#' @param      discretization  \code{('no', 'supervised'), optional}\cr
#'            Discretize continuous attributes.
#'            \itemize{
#'              \item{'no'}: disable discretization.
#'              \item{'supervised'}: use supervised discretization on
#'            all the continuous attributes.
#'            }
#'            Defaults to 'no'.
#' @param      model.format  \code{c('json', 'pmml'), optional}\cr
#'            Controls whether to output the model in JSON format or PMML format.
#'            \itemize{
#'              \item{'json'}: JSON format.
#'              \item{'pmml'}: PMML format. Defaults to json.}
#'            Defaults to 'json'.
#' @template args-cate-var
#' @template args-threadratio
#' @param  resampling.method   \code{character, optional}\cr
#'         Specifies the resampling values form below list.\cr
#'         Valid resampling methods include:\cr
#'         "cv", "stratified_cv", "bootstrap", "stratified_bootstrap".\cr
#'         If no value is specifier, neither model evaluation
#'         nor parameter selection is activated.
#' @param  evaluation.metric   \code{character, optional}\cr
#'         Specifies the evaluation metric for model evaluation or parameter selection.\cr
#'         Currently valid evaluation metrics include: "accuracy", "f1_score", "auc".\cr
#'         Mandatory for activating model evaluation/parameter selection.
#' @param  fold.num \code{integer, optional}\cr
#'         Specifies the fold number for the cross-validation(cv).
#'         Mandatory and valid only when \code{resampling.method} is 'cv' or 'stratified_cv'.
#' @template args-crossvalidation-group
#' @param parameter.range   \code{list, optional}\cr
#'      Specifies range of the following parameter for parameter selection:\cr
#'      \code{alpha}.\cr
#'      Parameter range should be specified by 3 numbers in the form of c(start, step, end).\cr
#'      Examples:\cr
#'      parameter.range <- list(alpha = c(0.01, 0.01, 0.1)), which means taking
#'      \code{alpha} values from 0.01 to 0.1 with 0.01 being the step size, i.e.
#'      0.01, 0.02, 0.03, ..., 0.09, 0.1.\cr
#'      If \code{param.search.strategy} is 'random', then the middle term,
#'      i.e. step has no effect and thus can be omitted.
#' @param parameter.values   \code{list, optional}\cr
#'       Specifies values of the following parameter for parameter selection:\cr
#'       \code{alpha}.\cr
#'       Example: parameter.values <- list(alpha = c(0.001, 0.003, 0.007, 0.01))
#'
#' @return
#' Returns a "NaiveBayes" object with following values:
#'\itemize{
#' \item{model: \code{DataFrame}\cr
#'    Naive Bayes model infomation.}
#' \item{statistics: \code{DataFrame}\cr
#'    Statistics infomation.}
#' \item{optim.param: \code{DataFrame}\cr
#'    Selected optimal parameters.}
#'
#'}
#' @note
#' The Laplace value (alpha) is only stored by JSON format models.
#' If the PMML format is chosen, you may need to set the Laplace value (alpha)
#' again in predict() and score().
#'
#' @section Examples:
#' Input DataFrame df:
#' \preformatted{
#' > df$Collect()
#'    ID  HOMEOWNER MARITALSTATUS  ANNUALINCOME DEFAULTEDBORROWER
#' 1   0        YES        Single         125.0                NO
#' 2   1         NO       Married         100.0                NO
#' 3   2         NO        Single          70.0                NO
#' 4   3        YES       Married         120.0                NO
#' 5   4         NO      Divorced          95.0               YES
#' 6   5         NO       Married          60.0                NO
#' 7   6        YES      Divorced         220.0                NO
#' 8   7         NO        Single          85.0               YES
#' 9   8         NO       Married          75.0                NO
#' 10  9         NO        Single          90.0               YES
#' }
#' Call the function:
#' \preformatted{
#' > nb <- hanaml.NaiveBayes(data = df, alpha = 1.0,
#'                           model.format = "pmml", thread.ratio = 0.2,
#'                           features = list('HOMEOWNER', 'MARITALSTATUS', 'ANNUALINCOME'),
#'                           label = "DEFAULTEDBORROWER")
#'
#' }
#' @keywords Classification
#' @export
hanaml.NaiveBayes <- function(data = NULL,
                              key = NULL,
                              features = NULL,
                              label = NULL,
                              formula = NULL,
                              alpha =NULL,
                              discretization = NULL,
                              model.format = NULL,
                              categorical.variable = NULL,
                              thread.ratio = NULL,
                              resampling.method = NULL,
                              evaluation.metric = NULL,
                              fold.num = NULL, repeat.times = NULL,
                              param.search.strategy = NULL,
                              random.search.times = NULL,
                              random.state = NULL,
                              timeout = NULL,
                              progress.indicator.id = NULL,
                              parameter.range = NULL,
                              parameter.values = NULL){
  NaiveBayes$new(data,
                 key,
                 features,
                 label,
                 formula,
                 alpha,
                 discretization,
                 model.format,
                 categorical.variable,
                 thread.ratio,
                 resampling.method,
                 evaluation.metric,
                 fold.num, repeat.times,
                 param.search.strategy,
                 random.search.times,
                 random.state,
                 timeout,
                 progress.indicator.id,
                 parameter.range,
                 parameter.values)
}


#' @title Make Predictions from a "NaiveBayes" Object
#' @name predict.NaiveBayes
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "NaiveBayes" object.
#' @export
#' @keywords Classification
#' @seealso \code{\link{hanaml.NaiveBayes}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr
#'  A "NaiveBayes" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @param    alpha \code{double, optional}\cr
#'                   Laplace smoothing value. Set a positive
#'                   value to enable Laplace smoothing
#'                   for categorical variables and use that
#'                   value as the smoothing parameter.
#'                   Set value 0 to disable Laplace smoothing.\cr
#'                   Defaults to the alpha value in the JSON model,
#'                   if there is one, or 0 otherwise.
#' @template args-verbose
#' @template args-threadratio
#' @note
#'         A non-zero Laplace value (alpha) is required if there exist discrete
#'         category values that only occur in the test set. It can be read from
#'         JSON models or from the parameter \emph{alpha} in predict().
#'         The Laplace value you set here takes precedence over the values
#'         read from JSON models.
#'
#' @section Examples:
#' Input DataFrame df2 for prediction:
#' \preformatted{
#' > df2$Collect()
#'    ID HOMEOWNER MARITALSTATUS  ANNUALINCOME
#' 1   0        NO       Married         120.0
#' 2   1       YES       Married         180.0
#' 3   2        NO        Single          90.0
#' }
#' Call the function and predict with a "NaiveBayes" object nb:
#' \preformatted{
#' > predict(nb, df2, "ID", alpha=1.0, verbose=True)
#'    ID CLASS  CONFIDENCE
#' 1   0    NO   -6.572353
#' 2   0   YES  -23.747252
#' 3   1    NO   -7.602221
#' 4   1   YES -169.133547
#' 5   2    NO   -7.133599
#' 6   2   YES   -4.648640
#' }
#' @return
#' Predicted values are returned as a DataFrame, structured as follows.
#' \itemize{
#'  \item{\code{ID} - with the same name and type as
#'  \emph{data}'s ID column.}
#'  \item{\code{CLASS} - predicted class name}
#'  \item{\code{CONFIDENCE} - confidence for
#'  the prediction of the sample, which is a
#'  logarithmic value of the posterior probabilities.}
#' }
predict.NaiveBayes <- function(model,
                               data,
                               key,
                               features = NULL,
                               alpha = NULL,
                               verbose = NULL,
                               thread.ratio = NULL){
  if (is.null(model$model)){
    msg <- "Model is NULL!"
    flog.error(msg)
    stop(msg)
  }
  if (!inherits(data, "DataFrame")){
    msg <- "Data for prediction must be a DataFrame."
    flog.error(msg)
    stop(msg)
  }
  conn <- data$connection.context
  CheckConnection(data)

  alpha <- validateInput("alpha", alpha, "numeric")
  verbose <- validateInput("verbose", verbose, "logical")
  thread.ratio <- validateInput("thread.ratio", thread.ratio, "numeric")
  cols <- data$columns
  key <- validateInput("key", key, cols, case.sensitive = TRUE, required = TRUE)
  cols <- cols[! cols %in% key]
  features <- validateInput("features", features, cols, case.sensitive = TRUE)
  if (is.null(features))
    features <- cols
  temp <- list(key)
  for (element in features)
    temp <- append(temp, element)
  df <- data$Select(temp)

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#NAIVE_BAYES_PARAMS_TBL_%s_%s", model$id, unique.id)
  result.tbl <- sprintf("#NAIVE_BAYES_RESULT_TBL_%s_%s", model$id, unique.id)
  tables <- list(param.tbl, result.tbl)
  in.tables <- list(df, model$model$name, param.tbl)
  out.tables <- list(result.tbl)
  param.data <- list(
    tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
    tuple("VERBOSE_OUTPUT", to.integer(verbose), NULL, NULL),
    tuple("LAPLACE", NULL, alpha, NULL)
  )
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                ParameterTable$new(param.tbl)$WithData(param.data))) #nolint
    errorhelper(CallPalAutoWithConnection(conn,
                                         "PAL_NAIVE_BAYES_PREDICT",
                                         in.tables,
                                         out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return (conn$table(result.tbl))
}

#' @export
summary.NaiveBayes <- function(object, ...){
    writeLines("NaiveBayes Model DataFrame:")
    print(object$model)
    writeLines("\n")
    writeLines("NaiveBayes Statistics DataFrame:")
    print(object$statistics)
    writeLines("\n")
}

#' @export
print.NaiveBayes <- function(x, ...){
  writeLines("Naive Bayes Model Attributes:\n")
  writeLines(paste("(NULL indicates not provided",
                   "by user and internal defaults are used)\n"))
  cat(sprintf("Laplace Value : %s", to.null(x$alpha)))
  writeLines("\n")
  cat(sprintf("Model Format : %s", to.null(x$model.format)))
  writeLines("\n")
  cat(sprintf("Categorical Variable :%s",
              to.null(x$categorical.variable)))
  writeLines("\n")
  cat(sprintf("Thread Ratio :%s", to.null(x$thread.ratio)))
  writeLines("\n")
  cat(sprintf("Discretization :%s", to.null(x$discretization)))
}
