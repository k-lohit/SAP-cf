RegressionBase <- R6Class(
  "RegressionBase",
  inherit = MlBase,
  public = list(
    decomposition.map = list(lu = 0, qr = 1, svd = 2, cholesky = 5),
    pmml.export.map = list("no" = 0, "single-row" = 1, "multi-row" = 2),
    model.format.map = list("coefficients" = 0, "pmml" = 1),
    degree = NULL,
    decomposition = NULL,
    adjusted.r2 = NULL,
    pmml.export = NULL,
    coefficients = NULL,
    fitted = NULL,
    model = NULL,
    statistics = NULL,
    pmml = NULL,
    initialize = function(data = NULL,
                          key = NULL,
                          features = NULL,
                          label = NULL,
                          formula = NULL,
                          degree = NULL,
                          decomposition = NULL,
                          adjusted.r2 = NULL,
                          pmml.export = NULL,
                          function.name){
      super$initialize()
      if (!is.null(data)){
        self$adjusted.r2 <- validateInput("adjusted.r2", adjusted.r2, "logical")
        self$pmml.export <- validateInput("pmml.export", pmml.export,
                                          self$pmml.export.map)
        self$decomposition <- validateInput("decomposition", decomposition,
                                            self$decomposition.map)
        # key check
        cols <- data$columns
        key <- validateInput("key", key, cols, case.sensitive = TRUE)
        # formula check
        if (!is.null(formula)) {
          if (inherits(formula, "formula")){
            parseformula <- ParseFormula(data, formula)
            features <- as.character(parseformula[[2]])
            features <- features[! features %in% key]
            if ((function.name != "PAL_EXPONENTIAL_REGRESSION")#nolint
                && (length(features) != 1)){#nolint
              msg <- sprintf("Please enter only one feature!")
              flog.error(msg)
              stop(msg)
            }
            label <- as.character(parseformula[[1]])
          } else {
            msg <- sprintf("Please enter right format of formula! label~features")
            flog.error(msg)
            stop(msg)
          }
        }
        #label and features check
        cols <- cols[! cols %in% key]
        label <- validateInput("label", label, cols, case.sensitive = TRUE)
        if (is.null(label)){
          label <- cols[[length(cols)]]
        }
        cols <- cols[! cols %in% label]
        features <- validateInput("features", features, cols, case.sensitive = TRUE)
        if (is.null(features)) {
          if (function.name == "PAL_EXPONENTIAL_REGRESSION") {
            features <- cols
          } else {
            features <- cols[[1]]
          }
        } else {
          if ((function.name != "PAL_EXPONENTIAL_REGRESSION")#nolint
              && (length(features) != 1)){#nolint
            msg <- sprintf("Please enter only one feature!")
            flog.error(msg)
            stop(msg)
          }
        }
        if (!inherits(data, "DataFrame")) {
          msg <- "If training data is not omitted, it must be DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn.context <- data$connection.context
        selected <- append(append(key, label), features)
        data <- data$Select(selected)
        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_REGRESSION_PARAM_TBL_%s_%s", self$id, unique.id)
        coef.tbl <- sprintf("#PAL_REGRESSION_COEF_TBL_%s_%s", self$id, unique.id)
        pmml.tbl <- sprintf("#PAL_REGRESSION_PMML_TBL_%s_%s", self$id, unique.id)
        fitted.tbl <- sprintf("#PAL_REGRESSION_FITTED_TBL_%s_%s", self$id, unique.id)
        stat.tbl <- sprintf("#PAL_REGRESSION_STATS_TBL_%s_%s", self$id, unique.id)
        # opt.param.tbl is only for polyregression
        opt.param.tbl <-
          sprintf("#PAL_POLYREGRESSION_OPTIMAL_PARAM_TBL_%s_%s", self$id, unique.id)

        if (function.name == "PAL_POLYNOMIAL_REGRESSION") {
          tables <- list(param.tbl, coef.tbl, pmml.tbl,
                         fitted.tbl, stat.tbl, opt.param.tbl)
          in.tables <- list(data, param.tbl)
          out.tables <- list(coef.tbl, pmml.tbl, fitted.tbl, stat.tbl, opt.param.tbl)
        } else {
          tables <- list(param.tbl, coef.tbl, fitted.tbl, stat.tbl, pmml.tbl)
          in.tables <- list(data, param.tbl)
          out.tables <- list(coef.tbl, fitted.tbl, stat.tbl, pmml.tbl)
        }

        param.rows <- list(
          tuple("ADJUSTED_R2", to.integer(self$adjusted.r2), NULL, NULL),
          tuple("PMML_EXPORT",
                map.null(self$pmml.export, self$pmml.export.map),#nolint
                NULL, NULL),
          tuple("ALG", map.null(self$decomposition, self$decomposition.map),#nolint
                NULL, NULL),
          tuple("SELECTED_FEATURES", NULL, NULL, paste(features, collapse = ",")),
          tuple("DEPENDENT_VARIABLE", NULL, NULL, label),
          tuple("HAS_ID", as.integer(!is.null(key)), NULL, NULL))
        if (function.name == "PAL_POLYNOMIAL_REGRESSION") {
          degree.rows <- list(tuple("POLYNOMIAL_NUM", self$degree, NULL, NULL))
          param.rows <- append(param.rows, degree.rows)
        }
        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
            (ParameterTable$new(param.tbl))$WithData(param.rows)))#nolint
          errorhelper(CallPalAutoWithConnection(conn.context,
            function.name, in.tables, out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        self$coefficients <- conn.context$table(coef.tbl)
        self$model <- self$coefficients
        self$fitted <- conn.context$table(fitted.tbl)
        self$statistics <- conn.context$table(stat.tbl)
        self$pmml <- conn.context$table(pmml.tbl)
        if ((isTRUE(self$pmml.export == "single-row")) || (isTRUE(self$pmml.export == "multi-row")))#nolint {
          self$model <- self$pmml
        }
    },
    predict = function(data,
                       key,
                       features = NULL,
                       thread.ratio = NULL,
                       model.format = NULL,
                       function.name){
      if (is.null(self$model)){
        msg <- "Model for prediction is NULL!"
        flog.error(msg)
        stop(msg)
      }
      if (!inherits(data, "DataFrame")){
        msg <- "Data for prediction must be a DataFrame."
        flog.error(msg)
        stop(msg)
      }
      CheckConnection(data)
      conn.context <- data$connection.context
      model.format <- validateInput("model.format", model.format,
                                    self$model.format.map)
      thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
      # assign key and features
      cols <- data$columns
      key <- validateInput("key", key, cols,
                           case.sensitive = TRUE, required = TRUE)
      cols <- cols[! cols %in% key]
      features <- validateInput("features", features,
                                cols, case.sensitive = TRUE)
      if (is.null(features)) {
        if (function.name == "PAL_EXPONENTIAL_REGRESSION_PREDICT") {
          features <- cols
        } else {
          features <- cols[[1]]
        }
      } else {
        if ((function.name != "PAL_EXPONENTIAL_REGRESSION_PREDICT")#nolint
            && (length(features) != 1)){#nolint
          msg <- sprintf("Please enter only one feature!")
          flog.error(msg)
          stop(msg)
        }
      }
      data <- data$Select(c(key, features))
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      param.tbl <- sprintf("#PAL_REGRESSION_PARAM_TBL_%s_%s",
                           self$id, unique.id)#nolint
      fitted.tbl <- sprintf("#PAL_REGRESSION_FITTED_TBL_%s_%s",
                            self$id, unique.id)#nolint
      in.tables <- list(data, self$model$name, param.tbl)
      tables <- list(param.tbl, fitted.tbl)
      out.tables <- list(fitted.tbl)
      param.rows <- list(tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
                         tuple("MODEL_FORMAT", map.null(model.format,
                                                        self$model.format.map),
                               NULL, NULL))

      tryCatch({
        errorhelper(CreateTWithConnection(conn.context,
          (ParameterTable$new(param.tbl))$WithData(param.rows))) #nolint
        errorhelper(CallPalAutoWithConnection(conn.context,
          function.name, in.tables, out.tables))
      },
      error = function(err){
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn.context, tables)
        stop(msg)
      })
      return (conn.context$table(fitted.tbl))
    },
    score = function(data,
                     key,
                     features = NULL,
                     label = NULL,
                     model.format = NULL,
                     function.name){
      model.format <- validateInput("model.format", model.format,
                                    self$model.format.map)
      if (!inherits(data, "DataFrame")) {
        msg <- "If training data is not omitted, it must be DataFrame."
        flog.error(msg)
        stop(msg)
      }

      if (is.null(self$model)) {
        msg <- "model of object is NULL!"
        flog.error(msg)
        stop(msg)
      }

      cols <- data$columns
      key <- validateInput("key", key, cols,
                           required = TRUE, case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      label <- validateInput("label", label, cols, case.sensitive = TRUE)
      if (is.null(label)){
        label <- cols[[length(cols)]]
      }
      cols <- cols[! cols %in% label]
      features <- validateInput("features", features, cols,
                               case.sensitive = TRUE)
      if (is.null(features)) {
        features <- cols[[1]]
      }

      prediction <- predict(data,
                            key,
                            features,
                            model.format,
                            function.name)
      prediction <- prediction$rename.columns(list("ID_P", "PREDICTION"))
      actual <- data$Select(list(key, label))
      actual <- actual$rename.columns(list("ID_A", "ACTUAL"))
      joined <- actual$Join(prediction, "ID_P=ID_A")
      joined <- joined$Select(list("ACTUAL", "PREDICTION"))
      r2.score <- r2.score(self$connection.context,
                           joined,
                           label.true = "ACTUAL",
                           label.pred = "PREDICTION")
      return(r2.score)
    }
  )
)
