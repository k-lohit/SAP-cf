KNNBase <- R6Class(
  "KNNBase",
  inherit = MlBase,
  public = list(
    metric.map = list(
      "manhattan" = 1,
      "euclidean" = 2,
      "minkowski" = 3,
      "chebyshev" = 4,
      "cosine" = 6
    ),
    algorithm.map = list("brute-force" = 0, "kd-tree" = 1),
    n.neighbors = NULL,
    metric = NULL,
    minkowski.power = NULL,
    algorithm = NULL,
    training.set = NULL,
    categorical.variable = NULL,
    category.weights = NULL,
    thread.ratio = NULL,
    string.variable = NULL,
    variable.weight = NULL,
    resampling.method = NULL,
    evaluation.metric = NULL,
    fold.num = NULL,
    repeat.times = NULL,
    param.search.strategy = NULL,
    random.search.times = NULL,
    random.state = NULL,
    timeout = NULL,
    progress.indicator.id = NULL,
    parameter.range = NULL,
    parameter.values = NULL,
    statistics = NULL,
    optim.param = NULL,
    model = NULL,
    initialize = function(data,
                          key,
                          features = NULL,
                          label = NULL,
                          functionality = NULL,
                          n.neighbors = NULL,
                          metric = NULL,
                          minkowski.power = NULL,
                          algorithm = NULL,
                          categorical.variable = NULL,
                          category.weights = NULL,
                          string.variable = NULL,
                          variable.weight = NULL,
                          resampling.method = NULL,
                          evaluation.metric = NULL,
                          fold.num = NULL,
                          repeat.times = NULL,
                          param.search.strategy = NULL,
                          random.search.times = NULL,
                          random.state = NULL,
                          timeout = NULL,
                          progress.indicator.id = NULL,
                          parameter.range = NULL,
                          parameter.values = NULL,
                          thread.ratio = NULL) {
      super$initialize()
      if (!is.null(data)){
        self$n.neighbors <- validateInput("n.neighbors", n.neighbors, "integer")
        self$metric <- validateInput("metric", metric, self$metric.map)
        if (!(list(self$metric) %in% c("minkowski")) && (!is.null(minkowski.power))){#nolint
          error.msg <- "Minkowski.power will only be valid if distance metric is Minkowski."
          flog.error(error.msg)
          stop(error.msg)
        }
        self$minkowski.power <-
          validateInput("minkowski.power", minkowski.power, "double")
        self$algorithm <- validateInput("algorithm", algorithm, self$algorithm.map)
        self$category.weights <-
          validateInput("category.weights", category.weights, "double")
        private$functionality <- functionality
        private$cv.flag <- length(c(resampling.method, evaluation.metric) == 2)
        self$string.variable <- validateInput("string.variable",
                                              string.variable,
                                              data$columns,
                                              case.sensitive = TRUE)
        if (length(variable.weight) != 0){
          validateInput("variable.weight",
                        names(variable.weight),
                        data$columns,
                        case.sensitive = TRUE)
          for (i in 1:length(variable.weight)){
            if (!is.numeric(variable.weight[[i]])){
              msg <- "The value of variable.weight should be numeric!"
              flog.error(msg)
              stop(msg)
            }
          }
          self$variable.weight <- variable.weight
        }

        attr.num <- private$check.data(data, key, features, label, categorical.variable)
        param.array <- list(
          tuple("K_NEAREST_NEIGHBOURS", self$n.neighbors, NULL, NULL),
          tuple("ATTRIBUTE_NUM", attr.num, NULL, NULL),
          tuple("MINKOWSKI_POWER", NULL, self$minkowski.power, NULL),
          tuple("FUNCTIONALITY", private$functionality, NULL, NULL),
          tuple("CATEGORY_WEIGHTS", NULL, self$category.weights, NULL),
          tuple("HAS_ID", 1, NULL, NULL),
          tuple("DISTANCE_LEVEL",
                map.null(self$metric, self$metric.map),
                NULL, NULL),
          tuple("METHOD",
                map.null(self$algorithm, self$algorithm.map),
                NULL, NULL))
        if (private$functionality == 0){
          if (!is.null(self$voting.type)){
            param.array <-
              append(param.array,
                     list(tuple("VOTING_TYPE",
                                self$voting.map[[self$voting.type]],
                                NULL, NULL)))
          }
        } else {
          if (!is.null(self$aggregate.type)){
            param.array <-
              append(param.array,
                     list(tuple("AGGREGATE_TYPE",
                                self$aggregate.map[[self$aggregate.type]],
                                NULL, NULL)))
          }
        }
        if (!is.null(self$categorical.variable)) {
          for (variable in self$categorical.variable) {
            temp.list <- tuple("CATEGORICAL_VARIABLE", NULL, NULL, variable)
            param.array <- append(param.array, tuple(temp.list))
          }
        }
        if (!is.null(self$string.variable)) {
          for (variable in self$string.variable) {
            temp.list <- tuple("STRING_VARIABLE", NULL, NULL, variable)
            param.array <- append(param.array, tuple(temp.list))
          }
        }
        if (!is.null(self$variable.weight)) {
          for (i in 1:length(self$variable.weight)) {
            temp.list <- tuple("VARIABLE_wEIGHT", NULL,
                               self$variable.weight[[i]], names(self$variable.weight[i]))
            param.array <- append(param.array, tuple(temp.list))
          }
        }
        vote <- ifelse(functionality == 0,
                       "voting.type",
                       "aggregate.type")
        if (functionality == 0){
          vote.map <- self$voting.map
        } else {
          vote.map <- self$aggregate.map
        }
        if (private$cv.flag){
          self$thread.ratio <- validateInput("thread.ratio", thread.ratio,
                                             "double")
          if (functionality == 0){
            resampling.list <- list("cv", "stratified_cv",
                                    "bootstrap",
                                    "stratified_bootstrap")
          } else {
            resampling.list <- list("cv", "bootstrap")
          }
          self$resampling.method <- validateInput("resampling.method",
                                                  resampling.method,
                                                  resampling.list,
                                                  case.sensitive = TRUE)
          self$repeat.times <- validateInput("repeat.times",
                                             repeat.times,
                                             "integer")
          self$fold.num <- validateInput("fold.num", fold.num, "integer")
          self$param.search.strategy <-
            validateInput("param.search.strategy",
                          param.search.strategy,
                          list("grid", "random"),
                          case.sensitive = TRUE)
          self$random.search.times <-
            validateInput("random.search.times",
                          random.search.times,
                          "integer")
          self$random.state <- validateInput("random.state", random.state,
                                             "integer")
          self$timeout <- validateInput("timeout", timeout, "integer")
          if (functionality == 0){
            metric.list <- list(accuracy = "ACCURACY",
                                f1_score = "F1_SCORE")
          } else {
            metric.list <- list(rmse = "RMSE")
          }
          self$evaluation.metric <-
            validateInput("evaluation.metric",
                          evaluation.metric,
                          metric.list,
                          required = !is.null(self$resampling.method))
          self$progress.indicator.id <- validateInput("progress.indicator.id",
                                                      progress.indicator.id,
                                                      "character")
          value.param <- list("metric", "minkowski.power",
                              "category.weights", "n.neighbors")
          if (functionality == 0){
            value.param <- c(value.param, "voting.type")
          } else {
            value.param <- c(value.param, "aggregate.type")
          }
          if (length(parameter.values) != 0){
            validateInput("Parameters for value specification",
                          names(parameter.values),
                          value.param,
                          case.sensitive = TRUE)
          }
          if (length(parameter.range) != 0){
            validateInput("Parameters for range specification",
                          names(parameter.range),
                          value.param[2:4],
                          case.sensitive = TRUE)
          }
          if ("metric" %in% names(parameter.values)){
            parameter.values[["metric"]] <-
              validateInput("Values of metric",
                            parameter.values[["metric"]],
                            self$metric.map)

          }
          if (vote %in% names(parameter.values)){
            parameter.values[[vote]] <-
              validateInput(sprintf("Values of %s", vote),
                            parameter.values[[vote]],
                            vote.map)
          }
          for (name in names(parameter.values)){
            if (!is.null(self[[name]])){
              msg <- paste(sprintf("Parameter '%s' cannot be specified", name),
                           "both inside and outside parameter.values")
              flog.error(msg)
              stop(msg)
            }
          }
          for (name in names(parameter.range)){
            if (!is.null(self[[name]])){
              msg <- paste(sprintf("Parameter '%s' cannot be specified", name),
                           "both inside and outside parameter.range")
              flog.error(msg)
              stop(msg)
            }
          }
          self$parameter.range <- parameter.range
          self$parameter.values <- parameter.values
          cv.param.array <- list(
            tuple("SEED", self$random.state, NULL, NULL),
            tuple("RESAMPLING_METHOD", NULL, NULL, self$resampling.method),
            tuple("PARAM_SEARCH_STRATEGY", NULL, NULL, self$param.search.strategy),
            tuple("FOLD_NUM", self$fold.num, NULL, NULL),
            tuple("REPEAT_TIMES", self$repeat.times, NULL, NULL),
            tuple("EVALUATION_METRIC", NULL, NULL,
                  map.null(self$evaluation.metric, metric.list)),
            tuple("TIMEOUT", self$timeout, NULL, NULL),
            tuple("RANDOM_SEARCH_TIMES", self$random.search.times, NULL, NULL),
            tuple("PROGRESS_INDICATOR_ID", NULL, NULL, self$progress.indicator.id),
            tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL))
          param.name.map <- list(n.neighbors = "K_NEAREST_NEIGHBOURS",
                                 metric = "DISTANCE_LEVEL",
                                 minkowski.power = "MINKOWSKI_POWER",
                                 category.weights = "CATEGORY_WEIGHTS",
                                 voting.type = "VOTING_TYPE",
                                 aggregate.type = "AGGREGATE_TYPE")
          if (length(self$parameter.values) > 0){
            for (i in 1:length(self$parameter.values)){
              param.name <- param.name.map[[names(parameter.values)[[i]]]]
              value.temp <- self$parameter.values[[i]]
              if (grepl("DISTA", param.name)){
                for (j in 1:length(value.temp)){
                  value.temp[[j]] <-
                    self$metric.map[[value.temp[[j]]]]
                }
              } else if (grepl("VOT", param.name)){
                for (j in 1:length(value.temp)){
                  value.temp[[j]] <-
                    self$voting.map[[value.temp[[j]]]]
                }
              } else if (grepl("AGGR", param.name)){
                for (j in 1:length(value.temp)){
                  value.temp[[j]] <-
                    self$aggregate.map[[value.temp[[j]]]]
                }
              }
              str.values <- paste("{",
                                  paste0(value.temp,
                                         collapse = ","),
                                  "}", sep = "")
              temp.tup <- tuple(paste0(param.name, "_VALUES"),
                                NULL, NULL, str.values)
              cv.param.array <-
                append(cv.param.array,  list(temp.tup))
            }
          }
          if (length(self$parameter.range) > 0){
            for (i in 1:length(self$parameter.range)){
              param.name <- param.name.map[[names(parameter.range)[[i]]]]
              range.temp <- self$parameter.range[[i]]
              cps <- ifelse(length(range.temp) == 2, ",,", ",")
              str.range <- paste("[",
                                 paste0(range.temp,
                                        collapse = cps),
                                 "]", sep = "")
              temp.tup <- tuple(paste0(param.name, "_RANGE"),
                                NULL, NULL, str.range)
              cv.param.array <-
                append(cv.param.array, list(temp.tup))
            }
          }
        }

        if (!inherits(data, "DataFrame")){
          msg <- "If training data is not omitted, it must be DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn.context <- data$connection.context
        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#KNN_CV_PARAM_TBL_%s_%s", self$id, unique.id)
        if (private$cv.flag){
          stats.tbl <- sprintf("#KNN_CV_STAT_TBL_%s_%s", self$id, unique.id)
          opt.param.tbl <- sprintf("#KNN_CV_OPT_PARAM_TBL_%s_%s", self$id, unique.id)
          tables <-
            list(param.tbl,
                 stats.tbl,
                 opt.param.tbl)
          in.tables <-
            list(self$training.set,
                 param.tbl)
          out.tables <-
            list(stats.tbl,
                 opt.param.tbl)
          tryCatch({
            errorhelper(CreateTWithConnection(conn.context,
              ParameterTable$new(param.tbl)$WithData(append(param.array,
                                                            cv.param.array))))#nolint
            errorhelper(CallPalAutoWithConnection(conn.context,
                                                  "PAL_KNN_CV",
                                                  in.tables,
                                                  out.tables))
          },
          error = function(err){
            msg <- paste("Error:", err$message)
            flog.error(msg)
            TryDropWithConnection(conn.context, tables)
            stop(msg)
          })
          self$statistics <- conn.context$table(stats.tbl)
          if (!is.null(self$param.search.strategy)){
            self$optim.param <- conn.context$table(opt.param.tbl)
          }
        }
        TryDropWithConnection(conn.context, param.tbl)
        CreateTWithConnection(conn.context,
                              ParameterTable$new(param.tbl)$WithData(param.array))
        if (!is.null(self$optim.param)){
          param.string <- "PARAM_NAME, INT_VALUE, DOUBLE_VALUE, STRING_VALUE"
          ExecuteLogged(conn.context$connection,
                      sprintf("INSERT INTO %s (%s) SELECT %s FROM %s",
                              param.tbl, param.string, param.string,
                              self$optim.param$name))
        }
        self$model <- list(self$training.set,
                           conn.context$table(param.tbl))
      }
    },
    predict = function(data, key, features = NULL,
                       stat.info = NULL, thread.ratio = NULL){
      if (is.null(self$model)){
        msg <- "Model for prediction is NULL!"
        flog.error(msg)
        stop(msg)
      }
      if (!inherits(data, "DataFrame")){
        msg <- "Data for prediction must be a DataFrame."
        flog.error(msg)
        stop(msg)
      }
      conn <- data$connection.context
      CheckConnection(data)

      stat.info <- validateInput("stat.info", stat.info, "logical")
      thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      cols <- data$columns
      key <- validateInput("key", key, cols, case.sensitive = TRUE,
                           required = TRUE)
      cols <- cols[! cols %in% key]
      features <- validateInput("features", features, cols, case.sensitive = TRUE)
      if (is.null(features))
        features <- cols
      if (length(self$model[[1]]$columns) - 2 != length(features)){
        msg <- "The number of features must be the same for both training data
    and prediction data."
        flog.error(msg)
        stop(msg)
      }
      data.temp <- list(key)
      for (element in features)
        data.temp <- append(data.temp, element)
      data <- data$Select(data.temp)
      data.tbl <- sprintf("#KNN_PREDICT_DATA_TBL_%s_%s", self$id, unique.id)
      param.tbl <- sprintf("#KNN_PREDICT_CONTROL_TBL_%s_%s", self$id, unique.id)
      param.df <- self$model[[2]]
      result.tbl <- sprintf("#KNN_CLASSIFICATION_RESULT_TBL_%s_%s",
                            self$id, unique.id)
      stat.tbl <- sprintf("#KNN_CLASSIFICATION_STAT_TBL_%s_%s",
                          self$id, unique.id)
      in.tables <- list(self$model[[1]], data, param.tbl)
      out.tables <- list(result.tbl, stat.tbl)
      tables <- c(out.tables)
      tryCatch({
        errorhelper(CreateTWithConnection(conn,
                                          ParameterTable$new(param.tbl)))
        param.string <- "PARAM_NAME, INT_VALUE, DOUBLE_VALUE, STRING_VALUE"
        ExecuteLogged(conn$connection,
                    sprintf("INSERT INTO %s (%s) SELECT %s FROM %s",
                            param.tbl, param.string, param.string,
                            param.df$name))
        if (!is.null(stat.info)){
          insert.stmt <- sprintf("'STAT_INFO', %s, NULL, NULL",
                                 as.integer(stat.info))
          ExecuteLogged(conn$connection,
                      sprintf("INSERT INTO %s VALUES (%s)",
                              param.tbl,
                              insert.stmt))
        }
        if (!is.null(thread.ratio)){
          insert.stmt <- sprintf("'THREAD_RATIO', NULL, %s, NULL",
                                 thread.ratio)
          ExecuteLogged(conn$connection,
                      sprintf("INSERT INTO %s VALUES (%s)",
                              param.tbl,
                              insert.stmt))
        }
        errorhelper(CallPalAutoWithConnection(conn,
                                              "PAL_KNN",
                                              in.tables,
                                              out.tables))
      },
      error = function(err){
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn, tables)
        stop(msg)
      })
      return(list(conn$table(result.tbl), conn$table(stat.tbl)))
    }
  ),
  private = list(
    functionality = NULL,
    cv.flag = NULL,
    check.data = function(data, key, features, label,
                          categorical.variable){
      if (!inherits(data, "DataFrame")) {
        msg <- "If training data is not omitted, it must be DataFrame."
        flog.error(msg)
        stop(msg)
      }
      col.left <- data$columns
      key <- validateInput("key", key, col.left,
                           case.sensitive = TRUE,
                           required = !isTRUE(private$cv.flag))
      col.left <- col.left[! col.left %in% key]
      self$categorical.variable <- validateInput("categorical.variable",
                                                 categorical.variable,
                                                 col.left,
                                                 case.sensitive = TRUE)
      if (is.null(label))
        label <- col.left[[length(col.left)]]
      label <- validateInput("label", label, col.left,
                             case.sensitive = TRUE)
      col.left <- col.left[! col.left %in% label]
      features <- validateInput("features", features, col.left,
                                case.sensitive = TRUE)
      if (is.null(features)){
        features <- col.left
      }
      temp <- list(key)
      for (element in label)
        temp <- append(temp, element)
      for (element in features)
        temp <- append(temp, element)
      training.df <- data$Select(temp)
      if (is.null(key)){
        self$training.set <- training.df$AddId("ID")
      } else {
        self$training.set <- training.df
      }
      return(length(features))
    }
  )
)


KNNClassifier <- R6Class(
  "KNNClassifier",
  inherit = KNNBase,
  public = list(
    voting.map = list("majority" = 0, "distance-weighted" = 1),
    voting.type = NULL,
    initialize = function(
      data,
      key = NULL,
      features = NULL,
      label = NULL,
      n.neighbors = NULL,
      voting.type = NULL,
      metric = NULL,
      minkowski.power = NULL,
      algorithm = NULL,
      categorical.variable = NULL,
      category.weights = NULL,
      string.variable = NULL,
      variable.weight = NULL,
      resampling.method = NULL,
      evaluation.metric = NULL,
      fold.num = NULL,
      repeat.times = NULL,
      param.search.strategy = NULL,
      random.search.times = NULL,
      random.state = NULL,
      timeout = NULL,
      progress.indicator.id = NULL,
      parameter.range = NULL,
      parameter.values = NULL,
      thread.ratio = NULL){
      self$voting.type <- validateInput("voting.type", voting.type,
                                        self$voting.map)
      super$initialize(data,
                       key,
                       features,
                       label,
                       0,
                       n.neighbors,
                       metric,
                       minkowski.power,
                       algorithm,
                       categorical.variable,
                       category.weights,
                       string.variable,
                       variable.weight,
                       resampling.method,
                       evaluation.metric,
                       fold.num,
                       repeat.times,
                       param.search.strategy,
                       random.search.times,
                       random.state,
                       timeout,
                       progress.indicator.id,
                       parameter.range,
                       parameter.values,
                       thread.ratio)

    },
    score = function(data, key,
                     features = NULL, label = NULL,
                     thread.ratio = NULL){
      if (is.null(data)){
        msg <- "Please provide the data for scoring."
        flog.error(msg)
        stop(msg)
      }
      if (is.null(self$training.set)){
        msg <- "Model is NULL, perform the fit first"
        flog.error(msg)
        stop(msg)
      }
      if (!inherits(data, "DataFrame")){
        msg <- "Data for score must be a DataFrame."
        flog.error(msg)
        stop(msg)
      }
      conn <- data$connection.context
      CheckConnection(data)

      cols <- data$columns
      key <- validateInput("key", key, cols, case.sensitive = TRUE, required = TRUE)
      cols <- cols[! cols %in% key]
      label <- validateInput("label", label, cols, case.sensitive = TRUE)
      if (is.null(label)){
        label <- cols[[length(cols)]]
      }
      cols <- cols[! cols %in% label]
      features <- validateInput("features", features, cols, case.sensitive = TRUE)
      if (is.null(features)){
        features <- cols
      }
      prediction <- predict(self, data, key, features,
                            FALSE, thread.ratio)
      prediction <- prediction$rename.columns(list("ID_P", "PREDICTION"))
      actual <- data$Select(list(key, label))
      actual <- actual$rename.columns(list("ID_A", "ACTUAL"))
      joined <- actual$Join(prediction, "ID_P=ID_A")
      joined <- joined$Select(list("ACTUAL", "PREDICTION"))
      dd <- accuracy.score(conn,
                           joined,
                           label.true = "ACTUAL",
                           label.pred = "PREDICTION")
      return(dd)
    }
  )
)

KNNRegressor <- R6Class(
  "KNNRegressor",
  inherit = KNNBase,
  public = list(
    aggregate.map = list("uniform" = 0,
                         "distance-weighted" = 1),
    aggregate.type = NULL,
    initialize = function(data,
                          key = NULL,
                          features = NULL,
                          label = NULL,
                          n.neighbors = NULL,
                          aggregate.type = NULL,
                          metric = NULL,
                          minkowski.power = NULL,
                          algorithm = NULL,
                          categorical.variable = NULL,
                          category.weights = NULL,
                          string.variable = NULL,
                          variable.weight = NULL,
                          resampling.method = NULL,
                          evaluation.metric = NULL,
                          fold.num = NULL,
                          repeat.times = NULL,
                          param.search.strategy = NULL,
                          random.search.times = NULL,
                          random.state = NULL,
                          timeout = NULL,
                          progress.indicator.id = NULL,
                          parameter.range = NULL,
                          parameter.values = NULL,
                          thread.ratio = NULL){
      self$aggregate.type <- validateInput("aggregate.type", aggregate.type,
                                           self$aggregate.map)
      super$initialize(data,
                       key, features, label,
                       1, n.neighbors, metric,
                       minkowski.power, algorithm,
                       categorical.variable,
                       category.weights,
                       string.variable,
                       variable.weight,
                       resampling.method,
                       evaluation.metric,
                       fold.num,
                       repeat.times,
                       param.search.strategy,
                       random.search.times,
                       random.state,
                       timeout,
                       progress.indicator.id,
                       parameter.range,
                       parameter.values,
                       thread.ratio)
    },
    score = function(data, key, feature = NULL, label = NULL,
                     thread.ratio = NULL){
      if (is.null(data)){
        msg <- "Please provide the data for scoring."
        flog.error(msg)
        stop(msg)
      }
      if (is.null(self$training.set)){
        msg <- "Model is NULL, perform the fit first"
        flog.error(msg)
        stop(msg)
      }
      if (!inherits(data, "DataFrame")){
        msg <- "Data for score must be a DataFrame."
        flog.error(msg)
        stop(msg)
      }
      conn <- data$connection.context
      CheckConnection(data)
      cols.left <- data$columns
      cols <- data$columns
      key <- validateInput("key", key, cols, case.sensitive = TRUE, required = TRUE)
      cols <- cols[! cols %in% key]
      label <- validateInput("label", label, cols, case.sensitive = TRUE)
      if (is.null(label)){
        label <- cols[[length(cols)]]
      }
      cols <- cols[! cols %in% label]
      features <- validateInput("features", features, cols,
                                case.sensitive = TRUE)
      if (is.null(features))
        features <- cols
      prediction <- predict(model, data, key,
                            features, FALSE, thread.ratio)
      prediction <- prediction$rename.columns(list("ID_P", "PREDICTION"))
      actual <- data$Select(list(key, label))
      actual <- actual$rename.columns(list("ID_A", "ACTUAL"))
      joined <- actual$Join(prediction, "ID_P=ID_A")
      joined <- joined$Select(list("ACTUAL", "PREDICTION"))
      r2.score <- r2.score(conn,
                           joined,
                           label.true = "ACTUAL",
                           label.pred = "PREDICTION")
      return(r2.score)
    }
  )
)


#' @title  K-Nearest Neighbor(KNN) Classifier
#' @name hanaml.KNNClassifier
#' @description hanaml.KNNClassifier is an R wrapper for SAP HANA PAL KNN algorithm for
#'  classification.
#' @seealso \code{\link{predict.KNNClassifier}}
#' @details K-Nearest Neighbor (KNN) is a memory-based classification or regression
#'  method with no explicit training phase. For classificatin purpose, it assumes that
#'  instances should have similar labels to their nearest neighbors.
#' @template args-data
#' @template args-key
#' @template args-feature-multiple
#' @template args-label
#' @param     n.neighbors \code{integer, optional}\cr
#'            Number of nearest neighbors.\cr
#'            Defaults to 1.
#' @param     voting.type \code{("majority", "distance-weighted"), optional}\cr
#'            Method used to vote for the most frequent label of the K
#'            nearest neighbors.\cr
#'            Defaults to 'distance-weighted'.
#' @param     metric \code{("manhattan", "euclidean", "minkowski", "chebyshev", "cosine"),
#'            optional}\cr
#'            Ways to compute the distance between data points.\cr
#'            Defaults to 'euclidean'.
#' @param     minkowski.power \code{double, optional}\cr
#'            When 'Minkowski' is used for metric, this parameter controls the value
#'            of power.\cr
#'            Only valid when \emph{metric} is "minkowski".
#'            Defaults to 3.0.
#' @param     algorithm \code{("brute-force", "kd-tree"), optional}\cr
#'            Algorithm used to compute the nearest neighbors.\cr
#'            When \emph{metric} is "cosine", using "kd-tree" searching will not have much help.\cr
#'            Defaults to 'brute-force'.
#' @template args-cate-var
#' @param     category.weights \code{double, optional}\cr
#'            Represents the weight of category attributes.\cr
#'            Defaults to 0.707.
#' @template args-string-variable
#' @template args-variable-weight
#' @param  resampling.method   \code{character, optional}\cr
#'         specifies the resampling values form below list. Valid options include:\cr
#'         \code{'cv',
#'         'stratified_cv',
#'         'bootstrap',
#'         'stratified_bootstrap'}\cr
#'         If no value is specified for this parameter, neither model evaluation
#'         nor parameter selection is activated.
#' @param  evaluation.metric   \code{c("accuracy", "f1_score"), optional}\cr
#'         Specifies the evaluation metric for model evaluation or parameter selection.\cr
#'         If not specified, neither model evaluation
#'         nor parameter selection is activated.\cr
#' @param  fold.num \code{integer, optional}\cr
#'         Specifies the fold number for the cross-validation(cv).
#'         Mandatory and valid only when \code{resampling.method} is 'cv' or 'stratified_cv'.
#' @param  repeat.times  \code{numeric, optional}\cr
#'         Specifies the number of repeat times for resampling.\cr
#'         Defaults to 1.
#' @param  param.search.strategy   \code{c('grid', 'random'), optional}\cr
#'         Specifies the method to activate parameter selection.
#'         If not specified, model selection shall not be triggered.
#' @param  random.search.times \code{integer, optional}\cr
#'         Specifies the number of times to randomly select candidate parameters for selection.
#'         Mandatory and valid only when \code{param.search.strategy} is 'random'.
#' @param  random.state \code{integer, optional}\cr
#'         Specifies the seed for random number generation, where 0 means current system time
#'         is used as seed, and other values are simply real seed values.
#' @param  timeout \code{integer, optional}\cr
#'         Specifies maximum running time for model evaluation or parameter selection in seconds.
#'         No timeout when 0 is specified.
#' @param  progress.indicator.id     \code{character, optional}\cr
#'         Sets an ID of progress indicator for model evaluation or parameter selection.\cr
#'         No progress indicator is active if no value is provided.
#' @param  parameter.values   \code{named list/vector, optional}\cr
#'         Specifies values of the following parameters for parameter selection:\cr
#'         \code{metric, voting.type, minkowski.power, category.weights, n.neighbors}.
#' @param  parameter.range   \code{named list/vector, optional}\cr
#'         Specifies range of the following parameters for parameter selection:\cr
#'         \code{minkowski.power, category.weights, n.neighbors}.\cr
#'         Parameter range should be specified by 3 numbers in the form of c(start, step, end).\cr
#'         Examples:\cr
#'         parameter.range <- list(n.neighbors = c(3, 1, 6)).\cr
#'         If \code{param.search.strategy} is 'random', then step has no effect
#'         and thus can be omitted.
#' @template args-threadratio
#' @return
#' A "KNNClassifier" object with the following attributes:\cr
#' \itemize{
#' \item{\code{statistics: DataFrame}} Statistics for model-evaluation/parameter-selection.
#'      Available only when model-evaluation/parameter selection is enabled.
#' \item{\code{optim.param: DataFrame}} Optimal parameters selected.
#'      Available only when parameter-selection is enabled.
#' }
#' @section Examples:
#' Training data:
#' \preformatted{
#' > df.train$Collect()
#'    ID X1   X2 X3  TYPE
#' 1   0  2    1  A     1
#' 2   1  3   10  A    10
#' 3   2  3   10  B    10
#' 4   3  3   10  C     1
#' 5   4  1 1000  C     1
#' 6   5  1 1000  A    10
#' 7   6  1 1000  B    99
#' 8   7  1  999  A    99
#' 9   8  1  999  B    10
#' 10  9  1 1000  C    10
#' }
#' Call the function:
#' \preformatted{
#' knc <- hanaml.KNNClassifier(data = df.train, key = "ID",
#'                             features = c("X1", "X2", "X3"),
#'                             label = "TYPE", n.neighbors = 3,
#'                             voting.type = "majority",
#'                             algorithm = "brute-force",
#'                             categorical.variable = c("X1"))
#' }
#' @keywords Classification
#' @export
hanaml.KNNClassifier <- function(data = NULL,
                                 key = NULL,
                                 features = NULL,
                                 label = NULL,
                                 n.neighbors = NULL,
                                 voting.type = NULL,
                                 metric = NULL,
                                 minkowski.power = NULL,
                                 algorithm = NULL,
                                 categorical.variable = NULL,
                                 category.weights = NULL,
                                 string.variable = NULL,
                                 variable.weight = NULL,
                                 resampling.method = NULL,
                                 evaluation.metric = NULL,
                                 fold.num = NULL,
                                 repeat.times = NULL,
                                 param.search.strategy = NULL,
                                 random.search.times = NULL,
                                 random.state = NULL,
                                 timeout = NULL,
                                 progress.indicator.id = NULL,
                                 parameter.range = NULL,
                                 parameter.values = NULL,
                                 thread.ratio = NULL){
  KNNClassifier$new(data, key, features, label,
                    n.neighbors, voting.type, metric,
                    minkowski.power, algorithm,
                    categorical.variable,
                    category.weights,
                    string.variable,
                    variable.weight,
                    resampling.method,
                    evaluation.metric,
                    fold.num,
                    repeat.times,
                    param.search.strategy,
                    random.search.times,
                    random.state,
                    timeout,
                    progress.indicator.id,
                    parameter.range,
                    parameter.values,
                    thread.ratio)
}

#' @title Make Predictions from a "KNNClassifier" Object
#' @name predict.KNNClassifier
#' @seealso \code{\link{hanaml.KNNClassifier}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr A "KNNClassifier" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @param     stat.info \code{logical, optional}\cr
#'            Controls whether to return a statistic information table containing
#'            the distance between each point in the prediction set and its
#'            k nearest neighbors in the training set.\cr
#'            If TRUE, the statistics table will be returned non-empty.\cr
#'            Defaults to TRUE.
#' @template args-threadratio
#' @return
#' Returns a list of DataFrame.\cr
#' \code{DataFrame 1}: Prediction results, structured as follows.
#' \itemize{
#'   \item{ID column, with same name and type as \emph{data}'s ID column.}
#'   \item{TARGET column, type NVARCHAR, predicted class labels or values.}
#' }
#'
#' \code{DataFrame 2}: Statistics of the prediction results.\cr
#' The distance between each point in `data` and its k nearest
#' neighbors in the training set. Only returned if \emph{stat.info} is TRUE.
#' \itemize{
#'   \item{TEST_ + \emph{data}'s ID name, with same type as \emph{data}'s
#'   ID column,
#' query data ID.}
#'   \item{K, type INTEGER, K number.}
#'   \item{TRAIN_ + training data's ID name, with same type as training
#' data's ID column, neighbor point's ID.}
#'   \item{DISTANCE, type DOUBLE, distance.}
#' }
#'
#' @section Examples:
#' DataFrame df.pred for prediction:
#' \preformatted{
#' > df.pred
#'    ID X1    X2 X3
#'  1  0  2     1  A
#'  2  1  1    10  C
#'  3  2  1    11  B
#'  4  3  3 15000  C
#'  5  4  2  1000  C
#'  6  5  1  1001  A
#'  7  6  1   999  A
#'  8  7  3   999  B
#' }
#' Call the function using a "KNNClassifier" Object knc:
#' \preformatted{
#' > res <- predict(model = knc,
#'                  data = df.pred,
#'                  key = "ID",
#'                  features = c("X1", "X2", "X3"),
#'                  stat.info = FALSE)
#' > res$Collect()
#'    ID TARGET
#' 1   0     10
#' 2   1     10
#' 3   2     10
#' 4   3     1
#' 5   4     1
#' 6   5     1
#' 7   6     10
#' 8   7     99
#' }
#' @keywords Classification
#' @export
predict.KNNClassifier <- function(model,
                                  data,
                                  key,
                                  features = NULL,
                                  stat.info = NULL,
                                  thread.ratio = NULL){
  model$predict(data, key, features, stat.info, thread.ratio)
}


#' @title  K-Nearest Neighbor(KNN) Regressor
#' @name hanaml.KNNRegressor
#' @description hanaml.KNNRegressor is an R wrapper for
#'  SAP HANA PAL KNN algorithm forregression.
#' @details K-Nearest Neighbor (KNN) is a memory-based classification or regression
#' method with no explicit training phase. For regression purpose, it assumes that
#' instances should have similar values to their nearest neighbors.
#' @seealso \code{\link{predict.KNNRegressor}}
#' @template args-data
#' @template args-key
#' @template args-feature-multiple
#' @template args-label
#' @param     n.neighbors \code{integer, optional}\cr
#'            Number of nearest neighbors.\cr
#'            Defaults to 1.
#' @param     aggregate.type \code{("uniform", "distance-weighted"), optional}\cr
#'            Method used for averaging the values of the K-nearest neighbors.
#'            Defaults to 'distance-weighted'.
#' @param     metric \code{("manhattan", "euclidean", "minkowski", "chebyshev", "cosine"),
#'            optional}\cr
#'            Ways to compute the distance between data points.\cr
#'            Defaults to 'euclidean'.
#' @param     minkowski.power \code{double, optional}\cr
#'            When 'Minkowski' is used for metric, this parameter controls the value
#'            of power.\cr
#'            Only valid when \emph{metric} is "minkowski".
#'            Defaults to 3.0.
#' @param     algorithm \code{("brute-force", "kd-tree"), optional}\cr
#'            Algorithm used to compute the nearest neighbors.\cr
#'            When \emph{metric} is "cosine", using "kd-tree" searching will not have much help.\cr
#'            Defaults to 'brute-force'.
#' @template args-cate-var
#' @param     category.weights \code{double, optional}\cr
#'            Represents the weight of category attributes.\cr
#'            Defaults to 0.707.
#' @template args-string-variable
#' @template args-variable-weight
#' @param  resampling.method   \code{character, optional}\cr
#'         specifies the resampling values form below list. Valid options include:\cr
#'         \code{"cv", "bootstrap"}\cr
#'         If no value is specified for this parameter, neither model evaluation
#'         nor parameter selection is activated.
#' @param  evaluation.metric   \code{character, optional}\cr
#'         Specifies the evaluation metric for model evaluation or parameter selection.\cr
#'         If not specified, neither model evaluation
#'         nor parameter selection is activated.\cr
#'         The only valid option is "rmse".
#' @param  fold.num \code{integer, optional}\cr
#'         Specifies the fold number for the cross-validation(cv).
#'         Mandatory and valid only when \code{resampling.method} is 'cv' or 'stratified_cv'.
#' @param  repeat.times  \code{numeric, optional}\cr
#'         Specifies the number of repeat times for resampling.\cr
#'         Defaults to 1.
#' @param  param.search.strategy   \code{c('grid', 'random'), optional}\cr
#'         Specifies the method to activate parameter selection.
#'         If not specified, model selection shall not be triggered.
#' @param  random.search.times \code{integer, optional}\cr
#'         Specifies the number of times to randomly select candidate parameters for selection.
#'         Mandatory and valid only when \code{param.search.strategy} is 'random'.
#' @param  random.state \code{integer, optional}\cr
#'         Specifies the seed for random number generation, where 0 means current system time
#'         is used as seed, and other values are simply real seed values.
#' @param  timeout \code{integer, optional}\cr
#'         Specifies maximum running time for model evaluation or parameter selection in seconds.
#'         No timeout when 0 is specified.
#' @param  progress.indicator.id     \code{character, optional}\cr
#'         Sets an ID of progress indicator for model evaluation or parameter selection.\cr
#'         No progress indicator is active if no value is provided.
#' @param  parameter.values   \code{named list/vector, optional}\cr
#'         Specifies values of the following parameters for parameter selection:\cr
#'         \code{metric, aggregate.type, minkowski.power, category.weights, n.neighbors}.
#' @param  parameter.range   \code{named list/vector, optional}\cr
#'         Specifies range of the following parameters for parameter selection:\cr
#'         \code{minkowski.power, category.weights, n.neighbors}.\cr
#'         Parameter range should be specified by 3 numbers in the form of c(start, step, end).\cr
#'         Examples:\cr
#'         parameter.range <- list(category.weights = c(0.5, 0.1, 1)).\cr
#'         If \code{param.search.strategy} is 'random', then the step has no effect
#'         and thus can be omitted.
#' @template args-threadratio
#' @return
#' A "KNNRegressor" object with the following attributes:\cr
#' \itemize{
#' \item{\code{statistics: DataFrame}} Statistics for model-evaluation/parameter-selection.
#'      Available only when model-evaluation/parameter selection enabled.
#' \item{\code{optim.param: DataFrame}} Optimal parameters selected.
#'      Available only when parameter selection is enabled.
#' }
#' @section Examples:
#' Training DataFrame df.train:
#' \preformatted{
#' > df.train$Collect()
#'    ID X1   X2 X3 VALUE
#' 1   0  2    1  A     1
#' 2   1  3   10  A    10
#' 3   2  3   10  B    10
#' 4   3  3   10  C     1
#' 5   4  1 1000  C     1
#' 6   5  1 1000  A    10
#' 7   6  1 1000  B    99
#' 8   7  1  999  A    99
#' 9   8  1  999  B    10
#' 10  9  1 1000  C    10
#' }
#' Call the function:
#' \preformatted{
#' knr <- hanaml.KNNRegressor(data = df.train, key = "ID",
#'                            features = c("X1", "X2", "X3"),
#'                            label = "VALUE", n.neighbors = 3,
#'                            aggregate.type = "uniform",
#'                            algorithm = "brute-force",
#'                            categorical.variable = c("X1"))
#' }
#' @keywords Regression
#' @export
hanaml.KNNRegressor <- function(data = NULL,
                                key = NULL,
                                features = NULL,
                                label = NULL,
                                n.neighbors = NULL,
                                aggregate.type = NULL,
                                metric = NULL,
                                minkowski.power = NULL,
                                algorithm = NULL,
                                categorical.variable = NULL,
                                category.weights = NULL,
                                string.variable = NULL,
                                variable.weight = NULL,
                                resampling.method = NULL,
                                evaluation.metric = NULL,
                                fold.num = NULL,
                                repeat.times = NULL,
                                param.search.strategy = NULL,
                                random.search.times = NULL,
                                random.state = NULL,
                                timeout = NULL,
                                progress.indicator.id = NULL,
                                parameter.range = NULL,
                                parameter.values = NULL,
                                thread.ratio = NULL){
  KNNRegressor$new(data, key, features,
                   label, n.neighbors, aggregate.type,
                   metric, minkowski.power, algorithm,
                   categorical.variable, category.weights,
                   string.variable,
                   variable.weight,
                   resampling.method,
                   evaluation.metric,
                   fold.num,
                   repeat.times,
                   param.search.strategy,
                   random.search.times,
                   random.state,
                   timeout,
                   progress.indicator.id,
                   parameter.range,
                   parameter.values,
                   thread.ratio)
}

#' @title Make Predictions from a "KNNRegressor" Object
#' @name predict.KNNRegressor
#' @seealso \code{\link{hanaml.KNNRegressor}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr A "KNNRegressor" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @param    stat.info \code{logical, optional}\cr
#'           Controls whether to return a statistic information table containing
#'           the distance between each point in the prediction set and its
#'           k nearest neighbors in the training set.\cr
#'           If TRUE, the statistics table will be returned non-empty.\cr
#'           Defaults to TRUE.
#' @template args-threadratio
#' @return
#' Returns a list of DataFrame.\cr
#' \code{DataFrame 1}: Prediction results, structured as follows.
#' \itemize{
#'    \item{ID column, with same name and type as \emph{data}'s ID column.}
#'    \item{TARGET column, type NVARCHAR, predicted class labels or values.}
#' }
#' \code{DataFrame 2}: Statistics of the prediction results.\cr
#'  The distance between each point in `data` and its k nearest
#'  neighbors in the training set. Only returned if \emph{stat.info} is TRUE.
#' \itemize{
#'    \item{TEST_ + \emph{data}'s ID name, with same type as \emph{data}'s
#'    ID column,
#'    query data ID.}
#'    \item{K, type INTEGER, K number.}
#'    \item{TRAIN_ + training data's ID name, with same type as training
#'     data's ID column, neighbor point's ID.}
#'    \item{DISTANCE, type DOUBLE, distance.}
#' }
#'
#' @section Examples:
#' DataFrame df.pred for prediction:
#' \preformatted{
#' > df.pred
#'    ID X1    X2 X3
#'  1  0  2     1  A
#'  2  1  1    10  C
#'  3  2  1    11  B
#'  4  3  3 15000  C
#'  5  4  2  1000  C
#'  6  5  1  1001  A
#'  7  6  1   999  A
#'  8  7  3   999  B
#' }
#' Call the function using a "KNNRegressor" Object knr:
#' \preformatted{
#' > res <- predict(model = knr,
#'                  data = df.pred,
#'                  key = "ID",
#'                  features = c("X1", "X2", "X3"),
#'                  stat.info = FALSE)
#' }
#' Output:
#' \preformatted{
#' > res$Collect()
#'    ID   TARGET
#' 1   0  7.00000
#' 2   1  7.00000
#' 3   2  7.00000
#' 4   3 36.66667
#' 5   4 36.66667
#' 6   5 36.66667
#' 7   6 39.66667
#' 8   7 69.33333
#' }
#' @keywords Regression
#' @export
predict.KNNRegressor <- function(model,
                                 data,
                                 key,
                                 features = NULL,
                                 stat.info = NULL,
                                 thread.ratio = NULL){
  model$predict(data, key, features, stat.info, thread.ratio)
}
