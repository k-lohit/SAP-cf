ALS <- R6Class(
  "ALS",
  inherit = MlBase,
  public = list(
    factors = NULL,
    lambda = NULL,
    max.iter = NULL,
    tol = NULL,
    exit.interval = NULL,
    implicit = NULL,
    linsolver = NULL,
    cg.max.iter = NULL,
    alpha = NULL,
    thread.ratio = NULL,
    resampling.method = NULL,
    evaluation.metric = NULL,
    fold.num = NULL,
    repeat.times = NULL,
    param.search.strategy = NULL,
    random.search.times = NULL,
    random.state = NULL,
    timeout = NULL,
    progress.indicator.id = NULL,
    parameter.range = NULL,
    parameter.values = NULL,
    model.meta = NULL,
    model.map = NULL,
    model.factors = NULL,
    iter.info = NULL,
    statistics = NULL,
    optim.param = NULL,
    model = NULL,
    initialize = function(data = NULL,
                          key = NULL,
                          used.cols = NULL,
                          factors = NULL,
                          lambda = NULL,
                          max.iter = NULL,
                          tol = NULL,
                          exit.interval = NULL,
                          implicit = NULL,
                          linsolver = NULL,
                          cg.max.iter = NULL,
                          alpha = NULL,
                          thread.ratio = NULL,
                          resampling.method = NULL,
                          evaluation.metric = NULL,
                          fold.num = NULL,
                          repeat.times = NULL,
                          param.search.strategy = NULL,
                          random.search.times = NULL,
                          random.state = NULL,
                          timeout = NULL,
                          progress.indicator.id = NULL,
                          parameter.range = NULL,
                          parameter.values = NULL){
      super$initialize()
      if (!is.null(data)){
        param.map <- list(factors = "FACTOR_NUMBER",
                          lambda = "REGULARIZATION",
                          alpha = "ALPHA")
        self$factors <- validateInput("factors", factors, "integer")
        self$lambda <- validateInput("lambda", lambda, "double")
        self$max.iter <- validateInput("max.iter", max.iter, "integer")
        self$tol <- validateInput("tol", tol, "double")
        self$exit.interval <- validateInput("exit.interval",
                                            exit.interval,
                                            "integer")
        self$implicit <- validateInput("implicit", implicit, "logical")
        self$linsolver <- validateInput("linsolver", linsolver,
                                        list(cholesky = 0,
                                             cg = 1))
        self$cg.max.iter <- validateInput("cg.max.iter", cg.max.iter,
                                       "integer")
        self$thread.ratio <- validateInput("thread.ratio", thread.ratio,
                                           "double")
        self$resampling.method <- validateInput("resampling.method",
                                                resampling.method,
                                                list(cv = "cv",
                                                     bootstrap = "bootstrap"))
        if (!is.null(evaluation.metric)){
          if (!is.character(evaluation.metric) ||
              tolower(evaluation.metric) != "rmse"){
            msg <- "Only 'rmse' is valid for evaluation.metric."
            flog.warn(msg)
            self$evaluation.metric <- "rmse"
          } else {
            self$evaluation.metric <- tolower(evaluation.metric)
          }
        }
        self$repeat.times <- validateInput("repeat.times",
                                           repeat.times,
                                           "integer")
        self$fold.num <-
          validateInput("fold.num", fold.num, "integer",
                        required = isTRUE(grepl("cv", self$resampling.method)))
        self$param.search.strategy <-
          validateInput("param.search.strategy",
                        param.search.strategy,
                        list(grid = "grid",
                             random = "random"))
        self$random.search.times <-
          validateInput("random.search.times", random.search.times, "integer",
                        required = isTRUE(self$param.search.strategy == "random"))
        self$random.state <- validateInput("random.state",
                                           random.state,
                                           "integer")
        self$timeout <- validateInput("timeout", timeout, "integer")
        self$progress.indicator.id <- validateInput("progress.indicator.id",
                                                    progress.indicator.id,
                                                    "character")
        if (length(parameter.values) != 0){
          validateInput("Parameters for value specification",
                        names(parameter.values),
                        list("factors", "lambda", "alpha"),
                        case.sensitive = TRUE)
        }
        if (length(parameter.range) != 0){
          validateInput("Parameters for range specification",
                        names(parameter.range),
                        list("factors", "lambda", "alpha"),
                        case.sensitive = TRUE)
        }
        self$parameter.range <- parameter.range
        self$parameter.values <- parameter.values
        cols <- data$columns
        key <- validateInput("key", key, cols, case.sensitive = TRUE)
        cols <- cols[! cols %in% key]
        used.cols <- validateInput("used.cols", used.cols, cols,
                                   case.sensitive = TRUE)
        if (is.null(used.cols)){
          used.cols <- cols[1:3]
        }
        if (length(used.cols) != 3){
          msg <- "Exactly three columns should be specified in used.cols."
          flog.error(msg)
          stop(msg)
        }
        if (length(names(used.cols)) == 0){
          selected  <- c(key, used.cols)
        } else {
          if (!setequal(names(used.cols),
                        list("user", "item",
                             "feedback"))){
            msg <- paste("Columns must be specified with the following",
                         "names(if there is any): user, item, feedback.")
            flog.error(msg)
            stop(msg)
          }
          selected <- c(key, used.cols[["user"]],
                        used.cols[["item"]],
                        used.cols[["feedback"]])
        }
        if (!inherits(data, "DataFrame")){
          msg <- "If training data is not omitted, it must be DataFrame."
          flog.error(msg)
          stop(msg)
        }
        CheckConnection(data)
        conn <- data$connection.context
        data <- data$Select(selected)
        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_LINEAR_REGRESSION_PARAM_TBL_%s_%s", self$id, unique.id)
        meta.tbl <- sprintf("#PAL_LINEAR_REGRESSION_MODEL_META_DATA_TBL_%s_%s", self$id, unique.id)
        map.tbl <- sprintf("#PAL_LINEAR_REGRESSION_MODEL_MAP_TBL_%s_%s", self$id, unique.id)
        factors.tbl <- sprintf("#PAL_LINEAR_REGRESSION_MODEL_FACTORS_TBL_%s_%s", self$id, unique.id)
        iter.tbl <- sprintf("#PAL_LINEAR_REGRESSION_ITERATION_INFO_TBL_%s_%s", self$id, unique.id)
        stat.tbl <- sprintf("#PAL_LINEAR_REGRESSION_STATS_TBL_%s_%s", self$id, unique.id)
        opt.param.tbl <- sprintf("#PAL_LINEAR_REGRESSION_OPTIMAL_PARAM_TBL_%s_%s", self$id, unique.id)
        param.rows <- list(
          tuple("FACTOR_NUMBER", self$factors, NULL, NULL),
          tuple("REGULARIZATION", NULL, self$lambda, NULL),
          tuple("MAX_ITERATION", self$max.iter, NULL, NULL),#nolint
          tuple("EXIT_THRESHOLD", NULL, self$tol, NULL),
          tuple("EXIT_INTERVAL", self$exit.interval, NULL, NULL),
          tuple("IMPLICIT_TRAIN", to.integer(self$implicit), NULL, NULL),
          tuple("LINEAR_SYSTEM_SOLVER",
                map.null(self$linsolver, list(cholesky = 0, cg = 1)),
                NULL, NULL),
          tuple("CG_MAX_ITERATION", self$cg.max.iter, NULL, NULL),
          tuple("ALPHA", NULL, self$alpha, NULL),
          tuple("THREAD_RATIO", NULL, self$thread.ratio, NULL),#nolint
          tuple("HAS_ID", as.integer(!is.null(key)), NULL, NULL),
          tuple("RESAMPLING_METHOD", NULL, NULL, self$resampling.method),
          tuple("PARAM_SEARCH_STRATEGY", NULL, NULL,
                self$param.search.strategy),
          tuple("FOLD_NUM", self$fold.num, NULL, NULL),
          tuple("REPEAT_TIMES", self$repeat.times, NULL, NULL),
          tuple("EVALUATION_METRIC", NULL, NULL, "RMSE"),
          tuple("TIMEOUT", self$timeout, NULL, NULL),
          tuple("RANDOM_SEARCH_TIMES", self$random.search.times, NULL, NULL),
          tuple("SEED", self$random.state, NULL, NULL),
          tuple("PROGRESS_INDICATOR_ID", NULL, NULL,
                self$progress.indicator.id)
          )
        if (length(self$parameter.values) > 0){
          for (i in 1:length(self$parameter.values)){
            param.name <- param.map[[names(self$parameter.values[i])]]
            str.values <- paste("{",
                                paste0(self$parameter.values[[i]],
                                       collapse = ","),
                                "}", sep = "")
            temp.tup <- tuple(paste0(param.name, "_VALUES"),
                              NULL, NULL, str.values)
            param.rows <-
              append(param.rows,  list(temp.tup))
          }
        }
        if (length(self$parameter.range) > 0){
          for (i in 1:length(self$parameter.range)){
            param.name <- param.map[[names(self$parameter.range[i])]]
            range.temp <- self$parameter.range[[i]]
            cps <- ifelse(length(range.temp) == 2, ",,", ",")
            str.range <- paste("[",
                               paste0(range.temp,
                                      collapse = cps),
                               "]", sep = "")
            temp.tup <- tuple(paste0(param.name, "_RANGE"),
                              NULL, NULL, str.range)
            param.rows <-
              append(param.rows, list(temp.tup))
          }
        }
        tables <- list(param.tbl, meta.tbl, map.tbl, factors.tbl,
                       iter.tbl, stat.tbl, opt.param.tbl)
        in.tables <- list(data, param.tbl)
        out.tables <- list(meta.tbl, map.tbl, factors.tbl,
                           iter.tbl, stat.tbl, opt.param.tbl)
        tryCatch({
          errorhelper(CreateTWithConnection(conn,(ParameterTable$new(param.tbl))$WithData(param.rows))) #nolint
          errorhelper(CallPalAutoWithConnection(conn, "PAL_ALS", in.tables, out.tables))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })

        self$model.meta <- conn$table(meta.tbl)
        self$model.map <- conn$table(map.tbl)
        self$model.factors <- conn$table(factors.tbl)
        self$iter.info <- conn$table(iter.tbl)
        self$statistics <- conn$table(stat.tbl)
        self$optim.param <- conn$table(opt.param.tbl)
        self$model <- list(self$model.meta,
                           self$model.map,
                           self$model.factors)
      }
    }
  )
)

#' @title Alternating Least Squares
#' @name hanaml.ALS
#' @description
#' Alternating least squares (ALS) is a powerful matrix factorization algorithm for
#' building both explicit and implicit feedback based recommender systems.
#' @seealso \code{\link{predict.ALS}}
#' @param     data \code{DataFrame}\cr
#'            Input data for ALS model training. It must contain the following three columns:
#'            \itemize{
#'            \item{user name/ID column}
#'            \item{item name/ID column}
#'            \item{column of user feedback for item}
#'            }
#' @template args-key-optional
#' @param     used.cols \code{list/vector of character, optional}\cr
#'            Specifies the three columns of \emph{data} that are used for training ALS model.\cr
#'            Should arranged in the order of: user, item and feedback.\cr
#'            Otherwise, the list/vector must be named, shown as follows:
#'            \itemize{
#'              used.cols <- list(user = xxx, item = xxx, feedback = xxx)
#'            }
#'            Default to the first three non-ID columns if not provided.
#' @param     factors \code{integer, optional}\cr
#'            Number of factor vectors in the matrix decomposition model of ALS.\cr
#'            Defautls to 8.
#' @param     random.state \code{integer, optional}\cr
#'            Specifies the seed for random number generator.\cr
#'            0 means using current system time as the seed.
#' @param     lambda \code{double, optional}\cr
#'            Amount of penalization appled to the L2 regularization of the decomposed factors.\cr
#'            Defaults to 1e-2.
#' @param     max.iter \code{integer, optional}\cr
#'            Maximum number of iterations for the ALS algorithm.\cr
#'            Defaults to 20.
#' @param     tol \code{double, optional}\cr
#'            Specfies the exit threshold, i.e. if the value of cost function is
#'            decreased less than this value since the last check, then the algorithm exits.\cr
#'            Should be no less than 0, where 0 means not checking the value of cost function and
#'            the algorithm only exits when reaching the maximum number of iterations.\cr
#'            Defaults to 0.
#' @param     exit.interval \code{integer, optional}\cr
#'            Specifies the interval between consecutive checking of the exit criterion(i.e. tolerance).\cr
#'            Larger number means fewer additional evaluations of the cost function.\cr
#'            Valid only when \code{tol} is nonzero.\cr
#'            Defaults to 5.
#' @param     implicit \code{logical, optional}\cr
#'            Specifies whether to train the ALS model implicitly(TRUE) or explicitly(FALSE).cr
#'            Default to FALSE.
#' @param     linsolver \code{("cholesky", "cd"), optional}\cr
#'            Specifies the solver for solving the corresponding linear systems in ALS model.\cr
#'            Defaults to "cholesky", while "cg" is recommended when \code{factors} is large.
#' @param     cg.max.iter \code{integer, optional}\cr
#'            Specifies the maximum number of iterations for solving a liear system using the "cg" solver.\cr
#'            Valid only when \code{linsolver} is "cg".\cr
#'            Defaults to 3.
#' @param     alpha  \code{numeric, optional}\cr
#'            Specifies a value when computing the confidence level in implicit ALS.\cr
#'            Valid only when \code{implicit} is TRUE.\cr
#'            Defaults to 1.0.
#' @template args-threadratio
#' @param     resampling.method   \code{character, optional}\cr
#'            specifies the resampling values form below list.
#'            Valid options include: \code{"cv", "bootstrap"}.\cr
#'            If no value is specified for this parameter, neither model evaluation
#'            nor parameter selection is activated.
#' @param     evaluation.metric   \code{character, optional}\cr
#'            Specifies the evaluation metric for model evaluation or parameter selection.\cr
#'            Currently the only valid option is "rmse".\cr
#'            Defaults to "rmse".
#' @param     fold.num \code{integer, optional}\cr
#'            Specifies the fold number for the cross-validation(cv).
#'            Mandatory and valid only when \code{resampling.method} is "cv".\cr
#'            Defautls to 1.
#' @param     repeat.times  \code{numeric, optional}\cr
#'            Specifies the number of repeat times for resampling.\cr
#'            Defaults to 1.
#' @param     param.search.strategy   \code{c('grid', 'random'), optional}\cr
#'            Specifies the method to activate parameter selection.
#'            If not specified, model selection shall not be triggered.
#' @param     random.search.times \code{integer, optional}\cr
#'            Specifies the number of times to randomly select candidate parameters for selection.
#'            Mandatory and valid only when \code{param.search.strategy} is 'random'.
#' @param     timeout \code{integer, optional}\cr
#'            Specifies maximum running time for model evaluation or parameter selection in seconds.
#'            No timeout when 0 is specified.
#' @param     progress.indicator.id     \code{character, optional}\cr
#'            Sets an ID of progress indicator for model evaluation or parameter selection.\cr
#'            No progress indicator is active if no value is provided.
#' @param     parameter.values   \code{list, optional}\cr
#'            Specifies values of the following parameters for parameter selection:\cr
#'            \code{factors, lambda, alpha}.
#' @param     parameter.range   \code{list, optional}\cr
#'            Specifies range of the following parameters for parameter selection:\cr
#'            \code{factors, lambda, alpha}.\cr
#'            Parameter range should be specified by 3 numbers in the form of c(start, step, end).\cr
#'            Examples:\cr
#'            parameter.range <- list(factors = c(10, 1, 20)).\cr
#'            If \code{param.search.strategy} is 'random', then step has no effect
#'            and thus can be omitted.
#' @return
#' A "ALS" object with the following attributes:
#' \itemize{
#'  \item{model.meta: \code{DataFrame}}\cr
#'        ALS model metadata content.
#'  \item{model.map: \code{DataFrame}}\cr
#'        ALS model map content.
#'  \item{model.factors: \code{DataFrame}}\cr
#'        ALS model decomposition factors.
#'  \item{iter.info: \code{DataFrame}}\cr
#'        Information of ALS iterations.
#'  \item{statistics: \code{DataFrame}}\cr
#'        Statistical information of the ALS model.
#'  \item{optim.param: \code{DataFrame}}\cr
#'        Optimal parameters selected.
#'        Avaliable only when parameter selection is triggered.
#'}
#'
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    USER     MOVIE RATING
#' 1     A    Movie1    4.8
#' 2     A    Movie2    4.0
#' 3     A    Movie4    4.0
#' 4     A    Movie5    4.0
#' 5     A    Movie6    4.8
#' 6     A    Movie8    3.8
#' 7     A Bad_Movie    2.5
#' 8     B    Movie2    4.8
#' ......
#' 35    E    Movie6    4.2
#' 36    E    Movie7    3.5
#' 37    E    Movie8    3.5
#' }
#' Call the function:
#' \preformatted{
#' als <- hanaml.ALS(data = data,
#'                   factors = 2,
#'                   lambda = 1e-2,
#'                   max.iter = 20,
#'                   thread.ratio = 0,
#'                   random.state = 1)
#' }
#' Output:
#' \preformatted{
#' > als$model.map$Collect()
#'    ID       MAP
#' 1   0         A
#' 2   1         B
#' 3   2         C
#' 4   3         D
#' 5   4         E
#' 6   5    Movie1
#' 7   6    Movie2
#' 8   7    Movie4
#' 9   8    Movie5
#' 10  9    Movie6
#' 11 10    Movie8
#' 12 11 Bad_Movie
#' 13 12    Movie3
#' 14 13    Movie7
#'
#' > als$iter.info$Collect()
#'   ITERATION                  COST               RMSE
#' 1        20   0.14724755464106934 0.1086315164152475
#'}
#' @keywords Recommender System
#' @export
hanaml.ALS <- function(data = NULL,
                       key = NULL,
                       used.cols = NULL,
                       factors = NULL,
                       lambda = NULL,
                       max.iter = NULL,
                       tol = NULL,
                       exit.interval = NULL,
                       implicit = NULL,
                       linsolver = NULL,
                       cg.max.iter = NULL,
                       alpha = NULL,
                       thread.ratio = NULL,
                       resampling.method = NULL,
                       evaluation.metric = NULL,
                       fold.num = NULL,
                       repeat.times = NULL,
                       param.search.strategy = NULL,
                       random.search.times = NULL,
                       random.state = NULL,
                       timeout = NULL,
                       progress.indicator.id = NULL,
                       parameter.range = NULL,
                       parameter.values = NULL){
  ALS$new(data,
          key,
          used.cols,
          factors,
          lambda,
          max.iter,
          tol,
          exit.interval,
          implicit,
          linsolver,
          cg.max.iter,
          alpha,
          thread.ratio,
          resampling.method,
          evaluation.metric,
          fold.num,
          repeat.times,
          param.search.strategy,
          random.search.times,
          random.state,
          timeout,
          progress.indicator.id,
          parameter.range,
          parameter.values)
}

#' @title Make Predictions from an "ALS"  Object
#' @name predict.ALS
#' @description Similar to other predict methods, this function
#' predicts fitted values from a fitted "ALS" object.
#' @seealso \code{\link{hanaml.ALS}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr An "ALS" object for prediction.
#' @template args-data
#' @template args-key
#' @param     used.cols \code{list/vector of character, optional}\cr
#'            Specifies the three columns of \emph{data} that are used for model prediction.\cr
#'            Should arranged in the order of: user, item.\cr
#'            Otherwise, the list/vector must be named, shown as follows:
#'            \itemize{
#'              used.cols <- list(user = xxx, item = xxx)
#'            }
#'            Default to the first two non-ID columns if not provided..
#' @template args-threadratio
#' @param     ... Reserved parameter.
#' @return
#' Predicted values are returned as a DataFrame, structured as follows.
#' \itemize{
#'   \item{ID column, with same name and type as `data`'s ID column.}
#'   \item{user column, representing user names/IDs.}
#'   \item{item column, represnetiing item names/IDs.}
#'   \item{PREDICTION column, predicted feedback of user to item.}
#'}
#'
#' @section Examples:
#' Perform the predict on DataFrame data2 using "ALS" object als:
#' \preformatted{
#' > data2$Collect()
#'   ID USER     MOVIE
#' 1  1    A    Movie3
#' 2  2    A    Movie7
#' 3  3    B    Movie1
#' 4  4    B    Movie6
#' 5  5    C    Movie3
#' 6  6    D    Movie2
#' 7  7    D    Movie5
#' 8  8    E Bad_Movie
#' }
#' Call the function and obtain the result:
#' \preformatted{
#' > pred.res <- predict(als, data = data2,
#'                       key = "ID",
#'                       used.cols = c(user = "USER"))
#' > pred.res$Collect()
#'   ID USER     MOVIE PREDICTION
#' 1  1    A    Movie3   3.868747
#' 2  2    A    Movie7   2.870243
#' 3  3    B    Movie1   5.787559
#' 4  4    B    Movie6   5.837218
#' 5  5    C    Movie3   3.323575
#' 6  6    D    Movie2   4.156372
#' 7  7    D    Movie5   4.325851
#' 8  8    E Bad_Movie   2.545807
#' }
#' @keywords Recommender System
#' @export
predict.ALS <- function(model,
                        data,
                        key,
                        used.cols = NULL,
                        thread.ratio = NULL, ...){
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  CheckConnection(data)
  conn <- data$connection.context
  if (!is.null(model$model)){
    predict.model <- model$model
  } else{
    msg <- "Model is NULL. Perform a fit first."
    flog.error(msg = msg)
    stop(msg)
  }
  thread.ratio <- validateInput("thread.ratio",
                                thread.ratio,
                                "double")
  cols <- data$columns
  key <- validateInput("key", key, cols,
                       required = TRUE,
                       case.sensitive = TRUE)
  cols <- cols[! cols %in% key]
  used.cols <- validateInput("used.cols", used.cols, cols,
                             case.sensitive = TRUE)
  if (is.null(used.cols)){
    used.cols <- cols[1:2]
    names(used.cols) <- c("user", "item")
  }
  if (length(used.cols) != 2){
    msg <- paste("Exactly two columns need to be specified",
                 "for use.cols in ALS prediction.")
    flog.error(msg)
    stop(msg)
  }
  if (is.null(names(used.cols))){
    names(used.cols) <- c("user", "item")
  }
  validateInput("Names of used.cols", names(used.cols),
                list("user", "item"),
                case.sensitive = TRUE)
  data.list <- list(key)
  data.list <- c(data.list, used.cols[["user"]], used.cols[["item"]])
  data <- data$Select(data.list)
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_ALS_PREDICT_PARAM_TBL_%s_%s", model$id, unique.id)
  result.tbl <- sprintf("#PAL_ALS_PREDICT_RESULT_TBL_%s_%s", model$id, unique.id)
  param.rows <- list(tuple("THREAD_RATIO", NULL, model$thread.ratio, NULL))
  tables <- list(param.tbl, result.tbl)
  in.tables <- list(data)
  for (mode in predict.model){
    in.tables <- c(in.tables, mode$name)
  }
  in.tables <- c(in.tables, param.tbl)
  out.tables <- list(result.tbl)
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                                      ParameterTable$new(param.tbl)$WithData(param.rows)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_ALS_PREDICT",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return (conn$table(result.tbl))
}
