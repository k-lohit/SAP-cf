#' @title Fast Dynamic Time Warping
#' @name hanaml.FastDTW
#' @description hanaml.FastDTW is a R wrapper
#' for SAP HANA PAL FAST DTW.\cr
#' Note that this is a new function in SAP HANA SPS05 and Cloud.
#' @details
#' Dynamic Time Warping is a method for measuring similarity between two
#' time series, which may vary in their speed. It can be used for pattern
#' matching and anomaly detection.\cr
#' Fast DTW is a twisted version of DTW to accelerate the computation when
#' the size of the time series is huge. It recursively reduces the
#' size of the time series and calculate the DTW path on the reduced version,
#' then refine the DTW path on the original ones.
#' It may lose some accuracy of actual DTW distance in exchange for the
#' acceleration of
#' computing.
#' @param data \code{DataFrame}\cr
#' DataFrame containting the time serie data structured as follows:
#' \itemize{
#'   \item{ID of time series : \code{INTEGER or CHARACTER}}\cr
#'   \item{Timestamps of time series \code{INTEGER or CHARACTER}} \cr
#'   \item{cloumns for time series data \code{INTEGER or DOUBLE}}
#'   }
#' @template args-threadratio
#' @param      radius \code{integer}\cr
#'            Parameter used for fast DTW algorithm. It is for balancing DTW
#'            accuracy and runtime. The bigger, the more accuracy but slower.
#'            Must be positive.

#'            Defaults to 3.0.
#' @param      distance.level \code{{"manhattan", "euclidean", "minkowski",
#' "chebyshev", "cosine"}, optional}\cr
#'            Specifies the method used to compute distance between two points.
#'            \itemize{
#'                \item{\code{"manhattan"} manhattan norm (l1 norm)}
#'                \item{\code{"euclidean"} euclidean norm (l2 norm)}
#'                \item{\code{"minkowski"} minkowski norm (p-norm)}
#'                \item{\code{"chebyshev"} chebyshev norm (maximum norm)}
#'                \item{\code{"cosine"} Cosine Similarity}
#'            }
#'            Defaults to "euclidean".
#' @param      minkowski.power \code{double, optional}\cr
#'            Only valid when \emph{distance.level} is "minkowski".\cr
#'            Specifies the power value of minkowski p-norm.\cr
#'            Defaults to 3.0.
#' @param     save.alignment \code{logical, optional}\cr
#'            Specifies whether or not to output
#'            alignment information.\cr
#'            Defaults to FALSE.
#' @return
#' Returns a list of DataFrames.
#' \itemize{
#'   \item{\code{DataFrame} Result for fast dtw, structured as follows:
#'   \itemize{
#'     \item{LEFT_<ID column name of input table>} : ID of one time series
#'     \item{RIGHT_<ID column name of input table>} : ID of another time series
#'     \item{DISTANCE}: DTW distance of the two time series
#'    }
#'   }
#'   \item{\code{DataFrame} Alignment(optimal match) between input time-series, structured as:
#'   \itemize{
#'     \item{LEFT_<ID column name of input table>} : ID of one time series
#'     \item{RIGHT_<ID column name of input table>} : ID of another time series
#'     \item{LEFT_INDEX} : Corresponding to index of timestamps of time series with
#'    ID of 1st column
#'     \item{RIGHT_INDEX} : Corresponding to index of timestamps of time series
#'     with ID of 2nd column
#'    }
#'  }
#'  \item{\code{DataFrame} Statistics for time series, structured as follows:
#'  \itemize{
#'    \item{STAT_NAME} : Statistics name
#'    \item{STAT_VALUE} : Statistics value
#'   }
#'   }
#'  }
#'
#'
#' @section Examples:
#' Input DataFrame:
#' \preformatted{
#' > data$Collect()
#'    ID TIMESTAMP ATTR1 ATTR2
#' 1   1         1     1   5.2
#' 2   1         2     2   5.1
#' 3   1         3     3   2.0
#' 4   1         4     4   0.3
#' 5   1         5     5   1.2
#' 6   2         1     7   2.0
#' 7   2         2     6   1.4
#' 8   2         3     1   0.9
#' 9   2         4     3   1.2
#' 10  2         5     2  10.2
#' 11  2         6     5   2.3
#' 12  2         7     4   4.5
#' }
#' Call the function:
#' \preformatted{
#' > result <- hanaml.FastDTW(data=data,radius = 5, thread.ratio = 1,
#'                            distance.level = "euclidean", save.alignment = TRUE)
#' }
#' Results:
#' \preformatted{
#' > result[[1]]$Collect()
#'   LEFT_ID RIGHT_ID DISTANCE
#' 1       1        2  29.2764
#'
#' > result[[2]]$Collect()
#'   LEFT_ID RIGHT_ID LEFT_INDEX RIGHT_INDEX
#' 1       1        2          0           0
#' 2       1        2          1           1
#' 3       1        2          2           2
#' 4       1        2          2           3
#' 5       1        2          2           4
#' 6       1        2          3           5
#' 7       1        2          4           6
#' }
#' @keywords Statistics
#' @export
hanaml.FastDTW <- function(
  data,
  radius,
  distance.level = NULL,
  minkowski.power = NULL,
  save.alignment = NULL,
  thread.ratio = NULL) {
  distance.level.map <- list(
    "manhattan" = 1,
    "euclidean" = 2,
    "minkowski" = 3,
    "chebyshev" = 4,
    "cosine" = 6
  )
  distance.level <- validateInput(
    "method", distance.level, distance.level.map, case.sensitive = TRUE)
  radius <- validateInput("radius", radius, "integer", required = TRUE)
  if (radius < 0) {
    msg <- "The radius value must be positive!"
    flog.error(msg)
    stop(msg)
  }
  minkowski.power  <- validateInput("minkowski.power",
                                    minkowski.power,
                                    "numeric")
  if (!is.null(minkowski.power) && !is.null(distance.level)) {
    if (distance.level != "minkowski") {
      error.msg <- paste("minkowski.power is valid only",
                         "when distance.level is minkowski.")
      flog.error(error.msg)
      stop(error.msg)
    }
  }
  thread.ratio <- validateInput("thread.ratio", thread.ratio, "numeric")
  if (!is.null(thread.ratio)) {
    if (thread.ratio < 0 || thread.ratio > 1) {
      msg <- "The thread.ratio value range is from 0 to 1!"
      flog.error(msg)
      stop(msg)
    }
  }
  save.alignment <- validateInput("save.alignment",
                                  save.alignment,
                                  "logical")

  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame."
    flog.error(msg)
    stop(msg)
  }
  conn <- data$connection.context
  CheckConnection(data)
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_DTW_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_DTW_RESULT_TBL_%s", unique.id)
  alignment.tbl <- sprintf("#PAL_DTW_ALIGNMENT_TBL_%s", unique.id)
  stat.tbl <- sprintf("#PAL_DTW_STAT_TBL_%s", unique.id)
  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl, alignment.tbl, stat.tbl)
  tables <- c(param.tbl, out.tables)
  param.array <- list(tuple("RADIUS", radius, NULL, NULL),
                      tuple("DISTANCE_METHOD",
                            map.null(distance.level, distance.level.map),
                            NULL, NULL),
                      tuple("MINKOWSKI_POWER", NULL, minkowski.power, NULL),
                      tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
                      tuple("SAVE_ALIGNMENT", to.integer(save.alignment),
                            NULL, NULL))
  tryCatch({
    errorhelper(CreateTWithConnection(
      conn, ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_FAST_DTW",
                                          in.tables,
                                          out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err$message)
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  result <- lapply(out.tables, conn$table)
  return(result)
}
