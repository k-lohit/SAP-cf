#' @title Multi-Dimensional Scaling
#' @name hanaml.MDS
#' @description hanaml.MDS is a R wrapper for SAP HANA PAL Multi-dimensional scaling algorithm.
#' @details This function serves as a tool for dimensional reduction or data visualization.
#' The function embeds the samples in N-dimension in a lower K-dimensional space
#' by applying a non-linear transformation – classical multidimensional scaling.
#' The characteristic of this transformation is that it is able,
#' or does the best it could, to preserve the distances between entities
#' after reducing to a lower dimension.
#' @template args-data
#' @template args-key
#' @param matrix.type \code{character}\cr
#' \itemize{The type of the input table:
#'  \item{\code{"observation.feature"}: Observation-feature matrixc.}
#'  \item{\code{"dissimilarity"}: Dissimilarity matrix.}}
#' @param features \code{character or list of characters, optional}\cr
#' Specifies the attribute columns to apply scaling to.\cr
#' Defaults to all non-ID columns.
#' @template args-threadratio
#' @param dim \code{integer, optional}\cr
#' The number of dimension that the input dataset is to be reduced to.\cr
#' Defaults to 2.
#' @param metric \code{chracter, optional}\cr
#' \itemize{
#' The type of distance during the calculation of dissimilarity matrix:\cr
#' \item{\code{"manhattan"}: Manhattan distance.}
#' \item{\code{"euclidean"}: Euclidean distance.}
#' \item{\code{"minkowski"}: Minkowski distance.}
#' }
#' Only valid when matrix.type = "observation.feature".\cr
#' Defaults to "euclidean".
#' @param minkowski.power \code{double, optional}\cr
#' When you use the Minkowski distance, this parameter controls the value
#' of power.\cr
#' Only valid if matrix.type = "observation.feature" and metric = "minkowski".\cr
#' Defaults to 3.
#' @return
#' Returns a list of DataFrame:
#' \itemize{
#' \item{DataFrame 1}\cr
#'  Sampling results, structured as follows:
#'  \itemize{
#'    \item{DATA_ID}: name as shown in input DataFrame.
#'    \item{DIMENSION}: dimension.
#'    \item{VALUE}: value
#'  }
#' \item{DataFrame 2}\cr
#'  Statistic results, structured as follows:
#'  \itemize{
#'    \item{STAT_NAME}:  statistic name.
#'    \item{STAT_VALUE}: statistic value.
#'  }
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#'  > data$collect()
#'    ID        X1        X2        X3        X4
#'  1  1 0.0000000 0.9047814 0.9085961 0.9103063
#'  2  2 0.9047814 0.0000000 0.2514457 0.5975016
#'  3  3 0.9085961 0.2514457 0.0000000 0.4403572
#'  4  4 0.9103063 0.5975016 0.4403572 0.0000000
#' }
#'
#' Call the function:
#' \preformatted{
#' > mds <- hanaml.MDS(data,
#'                     key = 'ID',
#'                     matrix.type = "dissimilarity",
#'                     thread.ratio = 0.5)
#' }
#' Output:
#' \preformatted{
#' > mds$labels$Collect()
#'     ID   DIMENSION   VALUE
#'   1  1         1  0.65191741
#'   2  1         2 -0.01585861
#'   3  2         1 -0.21773716
#'   4  2         2 -0.25319456
#'   5  3         1 -0.24990695
#'   6  3         2 -0.07294968
#'   7  4         1 -0.18427330
#'   8  4         2  0.34200285
#' }
#' @keywords Preprocessing
#' @export
hanaml.MDS <- function(data,
                       matrix.type,
                       key,
                       features = NULL,
                       thread.ratio = NULL,
                       dim = NULL, #k
                       metric = NULL, #distance level
                       minkowski.power = NULL) {
  matrix.type.map <- list(observation.feature = 0, dissimilarity = 1)
  metric.map <- list(manhattan = 1, euclidean = 2, minkowski = 3)
  matrix.type <-
    validateInput("matrix.type", matrix.type, matrix.type.map, required = TRUE)
  thread.ratio <- validateInput("thread.ratio", thread.ratio, "double")
  dim <- validateInput("dim", dim, "integer")
  metric <- validateInput("metric", metric, metric.map)
  if (!is.null(metric) && matrix.type != "observation.feature") {
    msg <- "`metric` is only valid when `matrix.type` is 'observation.feature'."
    flog.error(msg)
    stop(msg)
  }

  minkowski.power <- validateInput("minkowski.power", minkowski.power, "double")

  if (!is.null(minkowski.power) &&
      (matrix.type != "observation.feature" ||
       metric != "minkowski")) {
    msg <- paste("Minkowski power only valid when matrix type is",
                 "observation.feature and metric is minkowski.")
    flog.error(msg)
    stop(msg)
  }

  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  conn <- data$connection.context
  CheckConnection(data)

  cols <- data$columns
  key <- validateInput("key", key, cols, case.sensitive = TRUE, required = TRUE)
  cols <- cols[!cols %in% key]
  features <- validateInput("features", features, cols, case.sensitive = TRUE)
  if (is.null(features)) {
    features <- cols
  }
  data <- data$Select(list(key, features))
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_MDS_PARAMETER_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_MDS_RESULT_TBL_%s", unique.id)
  statistic.tbl <- sprintf("#PAL_MDS_STATISTIC_TBL_%s", unique.id)
  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl, statistic.tbl)
  tables <- list(param.tbl, result.tbl, statistic.tbl)

  param.array <- list(
    tuple("INPUT_TYPE", map.null(matrix.type, matrix.type.map), NULL, NULL),
    tuple("K", NULL, dim, NULL),
    tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
    tuple("DISTANCE_LEVEL", map.null(metric, metric.map), NULL, NULL),
    tuple("MINKOWSKI_POWER", NULL, minkowski.power, NULL)
  )
  tryCatch({
    errorhelper(CreateTWithConnection(conn,
                ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(conn,
                                          "PAL_MDS",
                                          in.tables,
                                          out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(list(conn$table(result.tbl),
              conn$table(statistic.tbl)))
}
