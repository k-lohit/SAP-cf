UnifiedClassification <- R6Class(
  "UnifiedClassification",
  inherit = MlBase,
  public = list(
    params = NULL,
    func = NULL,
    model = NULL,
    importance = NULL,
    statistics = NULL,
    optimal.param = NULL,
    confusion.matrix = NULL,
    metrics = NULL,
    attribution.map = list("no" = 0,
                           "saabas" = 1,
                           "shap" = 2),
    initialize = function(data = NULL,
                          func = NULL,
                          key = NULL,
                          features = NULL,
                          label = NULL,
                          purpose = NULL,
                          formula = NULL,
                          partition.method = NULL,
                          stratified.column = NULL,
                          partition.random.state = NULL,
                          training.percent = NULL,
                          training.size = NULL,
                          ntiles = NULL,
                          output.partition.result = NULL,
                          background.size = NULL,
                          background.random.state = NULL,
                          ...) {
      super$initialize()
      if (!is.null(data)) {
        self$func <- validateInput("func", func, private$func.list,
                                   required = TRUE)
        private$real.func <- self$func
        if (self$func == "logisticregression") {
          if ("multi.class" %in% names(list(...))) {
            if (list(...)$multi.class == TRUE) {
              private$real.func <- "multiclass_logisticregression"
            }
          }
        }
        self$params <- list(func = self$func)
        partition.method <- validateInput("partition.method", partition.method,
                                          private$partition.map)
        self$params <- append(self$params, list(...))
        private$pal.params <- list()
        if (isTRUE(grepl("random", self$func))) {
          func.map <- private$map.list[[private$func.list[[self$func]]]]
        } else {
          func.map <- append(private$map.list[[private$func.list[[self$func]]]],
                             private$cv.map)
        }
        param.names <- names(self$params)
        valid.names <- names(func.map)
        if (length(self$params) > 1) {
          for (i in c(2:length(self$params))) {
            par.name <- param.names[i]
            if (! par.name %in% valid.names) {
              msg <- paste("Unrecognized parameter name:",
                           par.name)
              flog.error(msg)
              stop(msg)
            }
            map.value <- func.map[[par.name]]
            if (length(map.value) == 2) {
              constr <- map.value[[2]]
            } else {
              constr <- map.value[[3]]
            }
            par.val <- self$params[[i]]
            if (map.value[[2]] == "list") {
              if (typeof(self$params[[i]]) %in% c("double",
                                                  "integer",
                                                  "character")) {
                if (length(self$params[[i]]) > 1) {#nolint
                  par.val <-  as.list(self$params[[i]])
                }
              }
            }
            if (map.value[[2]] == "list" && is.character(par.val)) {
              par.val <- as.list(par.val)
            }
            par.val <- validateInput(par.name, par.val, constr)
            if (length(map.value) == 3) {
              par.val <-  map.value[[3]][[par.val]]
            }
            private$pal.params[[map.value[[1]]]] <- list(par.val,
                                                         map.value[[2]])
          }
        }
        cols <- data$columns
        stratified.column <- validateInput("stratified.column",
                                           stratified.column, cols,
                                           case.sensitive = TRUE)
        key <- validateInput("key", key, cols,
                             case.sensitive = TRUE)
        stratified.column <- validateInput("stratified.column",
                                           stratified.column,
                                           cols,
                                           case.sensitive = TRUE)
        cols <- cols[! cols %in% key]
        if (is.null(formula)) {
          purpose <- validateInput("purpose", purpose, cols,
                                   case.sensitive = TRUE,
                                   required = isTRUE(grepl("user",
                                                           partition.method)))
          cols <- cols[! cols %in% purpose]
          label <- validateInput("label", label, cols,
                                 case.sensitive = TRUE)
          if (is.null(label)) {
            label <- cols[[length(cols)]]
          }
          cols <- cols[! cols %in% label]
          features <- validateInput("features", features, cols,
                                    case.sensitive = TRUE)
          if (is.null(features)) {
            features <- cols
          }
        } else {
          FeatureLabels <- ParseFormula(data, formula)
          label <- FeatureLabels[[1]]
          label <- validateInput("label", label, cols,
                                 case.sensitive = TRUE)
          cols <- cols[! cols %in% label]
          features <- FeatureLabels[[2]]
          features <- features[! features %in% c(key, purpose)]
          features <- validateInput("features", features, cols,
                                    case.sensitive = TRUE)
        }
        partition.random.state <- validateInput("partition.random.state",
                                                partition.random.state,
                                                "integer")
        training.percent <- validateInput("training.percent",
                                          training.percent,
                                          "numeric")
        training.size <- validateInput("training.size",
                                       training.size,
                                       "integer")
        ntiles <- validateInput("ntiles", ntiles, "integer")
        output.partition.result <- validateInput("output.partition.result",
                                                 output.partition.result,
                                                 "logical")
        background.size <- validateInput("background.size",
                                         background.size,
                                         "integer")
        background.random.state <- validateInput("background.random.state",
                                                 background.random.state,
                                                 "integer")
        CheckConnection(data)
        conn.context <- data$connection.context
        input.df <- data$Select(c(key, features, label, purpose))
        label.t <- data$dtypes(label)[[1]][[2]]
        private$real.func <- self$func
        if (self$func == "logisticregression") {
          if ("multi.class" %in% names(self$params)) {
            if (isTRUE(self$params$multi.class)) {
              private$real.func <- "multiclass_logisticregression"
            }
          }
        }
        param.rows <- list(tuple("FUNCTION", NULL, NULL,
                                 private$func.list[[private$real.func]]),
                           tuple("KEY", as.integer(!is.null(key)),
                                 NULL, NULL))
        param.rows <-
          append(param.rows,
                 list(tuple("PARTITION_METHOD", map.null(partition.method,
                                                         private$partition.map),
                            NULL, NULL),
                      tuple("PARTITION_RANDOM_SEED", partition.random.state,
                            NULL, NULL),
                      tuple("PARTITION_STRATIFIED_VARIABLE", NULL,
                            NULL, stratified.column),
                      tuple("PARTITION_TRAINING_PERCENT", NULL,
                            training.percent, NULL),
                      tuple("PARTITION_TRAINING_SIZE", training.size,
                            NULL, NULL),
                      tuple("NTILES", ntiles, NULL, NULL),
                      tuple("OUTPUT_PARTITION_RESULT",
                            to.integer(output.partition.result),
                            NULL, NULL),
                      tuple("BACKGROUND_SIZE", background.size,
                            NULL, NULL),
                      tuple("BACKGROUND_SAMPLING_SEED", background.random.state,
                            NULL, NULL)))
        pal.names <- names(private$pal.params)
        for (i in seq(1, length(private$pal.params))) {
          var.name <- pal.names[i]
          var.info <- private$pal.params[[var.name]]
          if (var.info[[2]] == "integer") {
            param.rows <- append(param.rows,
                                 list(tuple(var.name,
                                            var.info[[1]],
                                            NULL, NULL)))
          } else if (var.info[[2]] == "logical") {
            param.rows <- append(param.rows,
                                 list(tuple(var.name,
                                            to.integer(var.info[[1]]),
                                            NULL, NULL)))
          } else if (var.info[[2]] == "numeric") {
            param.rows <- append(param.rows,
                                 list(tuple(var.name,
                                            NULL,
                                            var.info[[1]],
                                            NULL)))
          } else if (var.info[[2]] == "character") {
            param.rows <- append(param.rows,
                                 list(tuple(var.name,
                                            NULL, NULL,
                                            var.info[[1]])))
          } else if (var.name %in% c("CATEGORICAL_VARIABLE",
                                     "REF_METRIC")) {
            for (val in var.info[[1]]) {
              val <- ifelse(grepl(var.name,
                                  "REF_"),
                            toupper(val),
                            val)
              param.rows <- append(param.rows,
                                   list(tuple(var.name,
                                              NULL, NULL,
                                              val)))
            }
          } else if (var.name == "_BIN_") {
            for (j in seq(length(var.info[[1]]))) {
              param.rows <-
                append(param.rows,
                       list(tuple(paste0(names(var.info[[1]][j]),
                                         var.name),
                                  var.info[[1]][[j]],
                                  NULL, NULL)))
            }
          } else if (isTRUE(grepl("PRIOR", var.name))) {
            if (self$func == "decisiontree") {
              for (j in seq(length(var.info[[1]]))) {
                param.rows <-
                  append(param.rows,
                         list(tuple(paste0(names(var.info[[1]][j]),
                                           "_PRIOR_"), NULL,
                                    var.info[[1]][[j]], NULL)))
              }
            } else if (isTRUE(grepl("INT", label.t))) {
              for (j in seq(length(var.info[[1]]))) {
                if (is.tuple(var.info[[1]][[j]])) {
                  class.name <- var.info[[1]][[j]][[1]]
                  prior.prob <- var.info[[1]][[j]][[2]]
                } else {
                  class.names <- names(var.info[[1]][j])
                  prior.prob <- var.info[[1]][[j]]
                }
                param.rows <-
                  append(param.rows,
                         list(tuple("PRIOR", class.name,
                                    prior.prob, NULL)))
              }
            } else {
              for (j in seq(length(var.info[[1]]))) {
                if (is.tuple(var.info[[1]][[j]])) {
                  class.name <- var.info[[1]][[j]][[1]]
                  prior.prob <- var.info[[1]][[j]][[2]]
                } else {
                  class.name <- names(var.info[[1]][j])
                  prior.prob <- var.info[[1]][[j]]
                }
                param.rows <-
                  append(param.rows,
                         list(tuple("PRIOR", NULL,
                                    prior.prob,
                                    class.name)))
              }
            }
          } else if (var.name == "STRATA") {
            if (isTRUE(grepl("INT", label.t))) {
              for (j in seq(length(var.info[[1]]))) {
                if (is.tuple(var.info[[1]][[j]])) {
                  class.name <- var.info[[1]][[j]][[1]]
                  spfrn <- var.info[[1]][[j]][[2]]
                } else {
                  class.name <- names(var.info[[1]][j])
                  spfrn <- var.info[[1]][[j]]
                }
                param.rows <-
                  append(param.rows,
                         list(tuple("STRATA", class.name,
                                    spfrn, NULL)))
              }
            } else {
              for (j in seq(1, length(var.info[[1]]))) {
                if (is.tuple(var.info[[1]][[j]])) {
                  class.name <- var.info[[1]][[j]][[1]]
                  spfrn <- var.info[[1]][[j]][[2]]
                } else {
                  class.names <- names(var.info[[1]][j])
                  spfrn <- var.info[[1]][[j]]
                }
                param.rows <-
                  append(param.rows,
                         list(tuple("STRATA", NULL,
                                    spfrn,
                                    class.name)))
              }
            }
          } else if (grepl("HIDDEN_LAYER", var.name)) {
            str.val <- paste0("\"", paste(var.info[[1]],
                                          collapse = ","),
                              "\"")
            param.rows <-
              append(param.rows,
                     list(tuple("HIDDEN_LAYER_SIZE",
                                NULL, NULL,
                                str.val)))
          } else if (var.name == "_VALUES") {
            for (j in seq(length(var.info[[1]]))) {
              cv.var.name <- names(var.info[[1]][j])
              if (! cv.var.name %in% names(func.map)) {
                msg <- paste("Invalid parameter name",
                             cv.var.name)
                flog.error(msg)
                stop(msg)
              }
              if (isTRUE(grepl("activation", cv.var.name))) {
                actv.map <- private$map.list[["MLP"]]$activation[[3]]
                val.vec <- c()
                for (actv in var.info[[1]][[j]]) {
                  if (! actv %in% names(actv.map)) {
                    msg <- paste("Invalid activation", actv,
                                 "in parameter.values.")
                    flog.error(msg)
                    stop(msg)
                  }
                  val.vec <- append(val.vec,
                                    actv.map[[actv]])
                }
                param.rows <-
                  append(param.rows,
                         list(tuple(paste0(func.map[[cv.var.name]][[1]],
                                           "_OPTIONS"),
                                    NULL, NULL,
                                    paste0("{",
                                           paste(val.vec, collapse = ", "),
                                           "}"))))
              } else if (isTRUE(grepl("hidden", cv.var.name))) {
                layer.str <- c()
                for (sz in var.info[[1]][[j]]) {
                  layer.str <- c(layer.str,
                                 paste0("\"",
                                        paste(sz, collapse = ","),
                                        "\""))
                }
                layer.str <- paste0("{",
                                    paste(layer.str,
                                          collapse = ", "),
                                    "}")
                param.rows <-
                  append(param.rows,
                         list(tuple("HIDDEN_LAYER_SIZE_OPTIONS",
                                    NULL, NULL, layer.str)))
              } else {
                param.rows <-
                  append(param.rows,
                         list(tuple(paste0(func.map[[cv.var.name]][[1]],
                                           "_VALUES"),
                                    NULL, NULL,
                                    paste0("{",
                                           paste(var.info[[1]][[j]],
                                                 collapse = ", "),
                                           "}"))))
              }
            }
          } else if (var.name == "_RANGE") {
            for (j in seq(length(var.info[[1]]))) {
              cv.var.name <- names(var.info[[1]][j])
              if (! cv.var.name %in% names(func.map)) {
                msg <- paste("Invalid parameter name",
                             cv.var.name)
                flog.error(msg)
                stop(msg)
              }
              pal.var.name <- paste0(func.map[[cv.var.name]][[1]],
                                     "_RANGE")
              sep <- ifelse(length(var.info[[1]][[j]]) == 2,
                            ",, ", ", ")
              param.rows <-
                append(param.rows,
                       list(tuple(pal.var.name,
                                  NULL, NULL,
                                  paste0("[",
                                         paste(var.info[[1]][[j]],
                                               collapse = sep),
                                         "]"))))
            }
          }
        }
        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#UNIFIED_CLASSIFICATION_PARAM_%s_%s",
                             self$id, unique.id)
        model.tbl <- sprintf("#UNIFIED_CLASSIFICATION_MODEL_%s_%s",
                             self$id, unique.id)
        imp.tbl <- sprintf("#UNIFIED_CLASSIFICATION_IMP_%s_%s",
                           self$id, unique.id)
        stats.tbl <- sprintf("#UNIFIED_CLASSIFICATION_STATS_%s_%s",
                             self$id, unique.id)
        optimal.param.tbl <- sprintf("#UNIFIED_CLASSIFICATION_OPT_PARAM_%s_%s",
                                     self$id, unique.id)
        cm.tbl <-
          sprintf(paste0("#UNIFIED_CLASSIFICATION_",
                         "CONFUSION_MATRIX_%s_%s"),
                  self$id, unique.id)
        metrics.tbl <- sprintf("#UNIFIED_CLASSIFICATION_METRICS_TBL_%s_%s",
                               self$id, unique.id)
        ph1.tbl <- sprintf("#UNIFIED_CLASSIFICATION_PH1_%s_%s",
                           self$id, unique.id)
        ph2.tbl <- sprintf("#UNIFIED_CLASSIFICATION_PH2_%s_%s",
                           self$id, unique.id)
        out.tables <- list(model.tbl, imp.tbl, stats.tbl,
                           optimal.param.tbl, cm.tbl,
                           metrics.tbl, ph1.tbl, ph2.tbl)
        in.tables <- list(input.df, param.tbl)
        tables <- c(param.tbl, out.tables)
        tryCatch({
          errorhelper(CreateTWithConnection(conn.context,
                                            (ParameterTable$new(param.tbl))$WithData(param.rows)))
          errorhelper(CallPalAutoWithConnection(conn.context,
                                                "PAL_UNIFIED_CLASSIFICATION",
                                                in.tables, out.tables))
        },
        error = function(err) {
          msg <- paste("Error:", err$message)
          flog.error(msg)
          TryDropWithConnection(conn.context, tables)
          stop(msg)
        })
        self$model <- conn.context$table(model.tbl)
        self$importance <- conn.context$table(imp.tbl)
        self$statistics <- conn.context$table(stats.tbl)
        self$optimal.param <- conn.context$table(optimal.param.tbl)
        self$confusion.matrix <- conn.context$table(cm.tbl)
        self$metrics <- conn.context$table(metrics.tbl)
      }
    },
    predict = function(data, key,
                       features = NULL,
                       thread.ratio = NULL,
                       verbose = NULL,
                       func = NULL,
                       multi.class = NULL,
                       alpha = NULL,
                       block.size = NULL,
                       missing.replacement = NULL,
                       class.map0 = NULL,
                       class.map1 = NULL,
                       categorical.variable = NULL,
                       attribution.method = NULL,
                       top.k.attributions = NULL,
                       sample.size = NULL,
                       random.state = NULL) {
      if (is.null(self$model)) {
        msg <- "Model for prediction is NULL!"
        flog.error(msg)
        stop(msg)
      }
      if (is.null(self$func)) {
        func <- validateInput("func", func, private$func.list,
                              required = TRUE)
        real.func <- func
        if (grepl("logi",
                  func) && isTRUE(multi.class == TRUE)) {
          real.func <- "multiclass_logisticregression"
        }
      } else {
        real.func <- self$func
        if (self$func == "logisitcregression") {
          if ("multi.class" %in% names(self$params)) {
            if (self$params$multi.class == TRUE) {
              real.func <- "multiclass_logiticregression"
            }
          }
        }
      }
      missing.replacement.map <- list(
        "feature.marginalized" = 1,
        "instance.marginalized" = 2
      )
      conn.context <- data$connection.context
      if (!inherits(data, "DataFrame")) {
        msg <- "Data for prediction must be a DataFrame."
        flog.error(msg)
        stop(msg)
      }
      CheckConnection(data)
      verbose <- validateInput("verbose", verbose, "logical")
      thread.ratio <- validateInput("thread.ratio", thread.ratio,
                                    "numeric")
      cols <- data$columns
      key <- validateInput("key", key, cols, required = TRUE,
                           case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      features <- validateInput("features", features, cols,
                                case.sensitive = TRUE)
      if (is.null(features)) {
        features <- cols
      }
      alpha <- validateInput("alpha", alpha, "numeric")
      class.map0 <- validateInput("class.map0", class.map0, "character")
      class.map1 <- validateInput("class.map1", class.map1, "character")
      categorical.variable <- validateInput("categorical.variable",
                                            categorical.variable,
                                            features,
                                            case.sensitive = TRUE)
      temp.params <-list(class.map0 = class.map0,
                         class.map1 = class.map1,
                         categorical.variable = categorical.variable)
      for (param in names(temp.params)) {
        param.val <- temp.params[[param]]
        if (is.null(param.val) && param %in% names(self$params)) {
          param.val <- self$params[[param]]
          assign(param, param.val) # re-assign the value
        }
      }
      block.size <- validateInput("block.size", block.size, "integer")
      missing.replacement <- validateInput("missing.replacement",
                                           missing.replacement,
                                           missing.replacement.map)
      attribution.method <- validateInput("attribution.method",
                                          attribution.method,
                                          self$attribution.map)
      top.k.attributions <- validateInput("top.k.attributions",
                                          top.k.attributions,
                                          "integer")
      sample.size <- validateInput("sample.size", sample.size, "integer")
      random.state <- validateInput("random.state", random.state, "integer")
      data <- data$Select(c(key, features))
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      param.tbl <- sprintf("#UNIFIED_CLASSIFICATION_PREDICT_PARAMS_%s_%s",
                           self$id, unique.id)
      result.tbl <- sprintf(paste0("#UNIFIED_CLASSIFICATION_PREDICT",
                                   "_RESULT_TBL_%s_%s"),
                            self$id, unique.id)
      ph.tbl <- sprintf(paste0("#UNIFIED_CLASSIFICATION_PREDICT",
                               "_PH_TBL_%s_%s"),
                        self$id, unique.id)
      tables <- list(param.tbl, result.tbl, ph.tbl)
      in.tables <- list(data, self$model$name, param.tbl)
      out.tables <- list(result.tbl, ph.tbl)
      param.data <- list(
        tuple("FUNCTION", NULL, NULL,
              private$func.list[[real.func]]),
        tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
        tuple("VERBOSE", to.integer(verbose), NULL, NULL),
        tuple("ALPHA", NULL, alpha, NULL),
        tuple("BLOCK_SIZE", block.size, NULL, NULL),
        tuple("MISSING_REPLACEMENT",
              map.null(missing.replacement,
                       missing.replacement.map),
              NULL, NULL),
        tuple("CLASS_MAP0", NULL, NULL, class.map0),
        tuple("CLASS_MAP1", NULL, NULL, class.map1),
        tuple("FEATURE_ATTRIBUTION_METHOD",
              map.null(attribution.method, self$attribution.map),
              NULL, NULL),
        tuple("TOP_K_ATTRIBUTIONS", top.k.attributions,
              NULL, NULL),
        tuple("SAMPLESIZE", sample.size, NULL, NULL),
        tuple("SEED", random.state, NULL, NULL)
      )
      if (!is.null(categorical.variable)) {
        for (cate in categorical.variable) {
          param.data <- c(param.data,
                          list(tuple("CATEGORICAL_VARIABLE",
                                     NULL, NULL, cate)))
        }
      }
      tryCatch({
        errorhelper(CreateTWithConnection(conn.context,
                                          (ParameterTable$new(param.tbl))$WithData(param.data))) #nolint
        errorhelper(CallPalAutoWithConnection(conn.context,
                                              "PAL_UNIFIED_CLASSIFICATION_PREDICT",#nolint
                                              in.tables, out.tables))
      },
      error = function(err) {
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn.context, tables)
        stop(msg)
      })
      result <- conn.context$table(result.tbl)
      return(result)
    },
    score = function(data, key,
                     features = NULL,
                     label = NULL,
                     max.result.num = NULL,
                     ntiles = NULL,
                     thread.ratio = NULL,
                     func = NULL,
                     multi.class = NULL,
                     alpha = NULL,
                     block.size = NULL,
                     missing.replacement = NULL,
                     class.map0 = NULL,
                     class.map1 = NULL,
                     categorical.variable = NULL,
                     attribution.method = NULL,
                     top.k.attributions = NULL,
                     sample.size = NULL,
                     random.state = NULL) {
      if (is.null(self$model)) {
        msg <- "Model for score is NULL!"
        flog.error(msg)
        stop(msg)
      }
      conn.context <- data$connection.context
      if (!inherits(data, "DataFrame")) {
        msg <- "Data for score must be a DataFrame."
        flog.error(msg)
        stop(msg)
      }
      if (is.null(self$func)) {
        func <- validateInput("func", func, private$func.list,
                              required = TRUE)
        real.func <- func
        if (grepl("logi",
                  func) && isTRUE(multi.class == TRUE)) {
          real.func <- "multiclass_logisticregression"
        }
      } else {
        real.func <- self$func
        if (self$func == "logisitcregression") {
          if ("multi.class" %in% names(self$params)) {
            if (self$params$multi.class == TRUE) {
              real.func <- "multiclass_logiticregression"
            }
          }
        }
      }
      max.result.num <- validateInput("max.result.num", max.result.num,
                                      "integer")
      ntiles <- validateInput("ntiles", ntiles, "integer")
      thread.ratio <- validateInput("thread.ratio", thread.ratio,
                                    "numeric")
      cols <- data$columns
      key <- validateInput("key", key, cols, required = TRUE,
                           case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      label <- validateInput("label", label, cols, case.sensitive = TRUE)
      if (is.null(label)) {
        label <- cols[[length(cols)]]
      }
      cols <- cols[! cols %in% label]
      features <- validateInput("features", features, cols,
                                case.sensitive = TRUE)
      if (is.null(features)) {
        features <- cols
      }
      alpha <- validateInput("alpha", alpha, "numeric")
      class.map0 <- validateInput("class.map0", class.map0, "character")
      class.map1 <- validateInput("class.map1", class.map1, "character")
      categorical.variable <- validateInput("categorical.variable",
                                            categorical.variable,
                                            features,
                                            case.sensitive = TRUE)
      temp.params <- list(class.map0 = class.map0,
                          class.map1 = class.map1,
                          categorical.variable = categorical.variable)
      for (param in names(temp.params)) {
        param.val <- temp.params[[param]]
        if (is.null(param.val) && param %in% names(self$params)) {
          param.val <- self$params[[param]]
          assign(param, param.val) # re-assign the value
        }
      }
      block.size <- validateInput("block.size", block.size, "integer")
      missing.replacement.map <- list(
        "feature.marginalized" = 1,
        "instance.marginalized" = 2
      )
      missing.replacement <- validateInput("missing.replacement",
                                           missing.replacement,
                                           missing.replacement.map)
      attribution.method <- validateInput("attribution.method",
                                          attribution.method,
                                          self$attribution.map)
      top.k.attributions <- validateInput("top.k.attributions",
                                          top.k.attributions,
                                          "integer")
      sample.size <- validateInput("sample.size", sample.size, "integer")
      random.state <- validateInput("random.state", random.state, "integer")
      CheckConnection(data)
      data <- data$Select(c(key, features, label))
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      param.tbl <- sprintf("#UNIFIED_CLASSIFICATION_SCORE_PARAMS_%s_%s",
                           self$id, unique.id)
      result.tbl <-
        sprintf(paste0("#UNIFIED_CLASSIFICATION_SCORE",
                       "_RESULT_TBL_%s_%s"),
                self$id, unique.id)
      stats.tbl <-
        sprintf(paste0("#UNIFIED_CLASSIFICATION_SCORE",
                       "_STAT_TBL_%s_%s"),
                self$id, unique.id)
      cm.tbl <-
        sprintf(paste0("#UNIFIED_CLASSIFICATION_SCORE",
                       "_CM_TBL_%s_%s"),
                self$id, unique.id)
      metrics.tbl <-
        sprintf("#UNIFIED_CLASSIFICATION_SCORE_METRICS_TBL_%s_%s",
                self$id, unique.id)
      private$real.func <- self$func
      if (self$func == "logisitcregression") {
        if ("multi.class" %in% names(self$params)) {
          if (self$params$multi.class == TRUE) {
            private$real.func <- "multiclass_logiticregression"
          }
        }
      }
      tables <- list(param.tbl, result.tbl)
      in.tables <- list(data, self$model$name, param.tbl)
      out.tables <- list(result.tbl, stats.tbl, cm.tbl, metrics.tbl)
      param.data <- list(
        tuple("FUNCTION", NULL, NULL,
              private$func.list[[real.func]]),
        tuple("LABEL", NULL, NULL, label),
        tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
        tuple("MAX_RESULT_NUM", max.result.num, NULL, NULL),
        tuple("NTILES", ntiles, NULL, NULL),
        tuple("ALPHA", NULL, alpha, NULL),
        tuple("BLOCK_SIZE", block.size, NULL, NULL),
        tuple("MISSING_REPLACEMENT",
              map.null(missing.replacement,
                       missing.replacement.map),
              NULL, NULL),
        tuple("CLASS_MAP0", NULL, NULL, class.map0),
        tuple("CLASS_MAP1", NULL, NULL, class.map1),
        tuple("FEATURE_ATTRIBUTION_METHOD",
              map.null(attribution.method,
                       self$attribution.map),
              NULL, NULL),
        tuple("TOP_K_ATTRIBUTIONS", top.k.attributions,
              NULL, NULL),
        tuple("SAMPLESIZE", sample.size, NULL, NULL),
        tuple("SEED", random.state, NULL, NULL))
      if (!is.null(categorical.variable)) {
        for (cate in categorical.variable) {
          param.data <- c(param.data,
                          list(tuple("CATEGORICAL_VARIABLE",
                                     NULL, NULL, cate)))
        }
      }
      tryCatch({
        errorhelper(CreateTWithConnection(conn.context,
                                          (ParameterTable$new(param.tbl))$WithData(param.data)))#nolint
        errorhelper(CallPalAutoWithConnection(conn.context,
                                              "PAL_UNIFIED_CLASSIFICATION_SCORE",
                                              in.tables, out.tables))
      },
      error = function(err) {
        msg <- paste("Error:", err$message)
        flog.error(msg)
        TryDropWithConnection(conn.context, tables)
        stop(msg)
      })
      result <- conn.context$table(result.tbl)
      statistics <- conn.context$table(stats.tbl)
      cm <- conn.context$table(cm.tbl)
      metrics <- conn.context$table(metrics.tbl)
      return(list(result, statistics, cm, metrics))
    }
  ),
  private = list(
    real.func = NULL,
    pal.params = list(),
    func.list = list(decisiontree = "DT",
                     hgbt = "HGBT",
                     svm = "SVM",
                     logisticregression = "LOGR",
                     multiclass_logisticregression = "M_LOGR",
                     naivebayes = "NB",
                     randomforest = "RDT",
                     randomdecisiontrees = "RDT",
                     mlp = "MLP"),
    partition.map = list(no = 0, user.defined = 1, stratified = 2),
    cv.map = list(resampling.method = list("RESAMPLING_METHOD",
                                           "character",
                                           list(cv = "cv",
                                                bootstrap = "bootstrap",
                                                stratified_cv = "cv",
                                                stratified_bootstrap = "stratified_bootstrap")),#nolint
                  param.search.strategy = list("PARAM_SEARCH_STRATEGY",
                                               "character",
                                               list(grid = "grid",
                                                    random = "random")),
                  random.state = list("SEED", "integer"),
                  fold.num = list("FOLD_NUM", "integer"),
                  repeat.times = list("REPEAT_TIMES", "integer"),
                  random.search.times = list("RANDOM_SEARCH_TIMES",
                                             "integer"),
                  timeout = list("TIMEOUT", "integer"),
                  progress.indicator.id = list("PROGRESS_INDICATOR_ID",
                                               "character"),
                  parameter.values = list("_VALUES", "list"),
                  parameter.range = list("_RANGE", "list")),
    map.list = list(
      "DT" = list(
        "algorithm" = list("ALGORITHM", "integer",
                           list(c45 = 1, chaid = 2, cart = 3)),
        "allow.missing.dependent" = list("ALLOW_MISSING_LABEL", "logical"),
        "percentage" = list("PERCENTAGE", "numeric"),
        "min.records.of.parent" = list("MIN_RECORDS_PARENT", "integer"),
        "min.records.of.leaf" = list("MIN_RECORDS_LEAF", "integer"),
        "max.depth" = list("MAX_DEPTH", "integer"),
        "split.threshold" = list("SPLIT_THRESHOLD", "numeric"),
        "discretization.type" = list("DISCRETIZATION_TYPE", "integer",
                                     list("mdlpc" = 0, "equal.freq" = 1)),
        "max.branch" = list("MAX_BRANCH", "integer"),
        "merge.threshold" = list("MERGE_THRESHOLD", "numeric"),
        "use.surrogate" = list("USE_SURROGATE", "logical"),
        "model.format" = list("MODEL_FORMAT", "integer",
                              list("json" = 1, "pmml" = 2)),
        "thread.ratio" = list("THREAD_RATIO", "numeric"),
        "bins" = list("_BIN_", "list"),
        "priors" = list("_PRIOR_", "list"),
        "categorical.variable" = list("CATEGORICAL_VARIABLE", "list"),
        "evaluation.metric" = list("EVALUATION_METRIC", "character",
                                   list(error_rate = "ERROR_RATE",
                                        nll = "NLL",
                                        auc = "AUC"))),
      "RDT" = list(
        "n.estimators" = list("N_ESTIMATORS", "integer"),
        "max.features" = list("MAX_FEATURES", "integer"),
        "min.samples.leaf" = list("MIN_SAMPLES_LEAF", "integer"),
        "max.depth" = list("MAX_DEPTH", "integer"),
        "split.threshold" = list("SPLIT_THRESHOLD", "numeric"),
        "random.state" = list("SEED", "integer"),
        "thread.ratio" = list("THREAD_RATIO", "numeric"),
        "allow.missing.dependent" = list("ALLOW_MISSING_LABEL", "logical"),
        "sample.fraction" = list("SAMPLE_FRACTION", "numeric"),
        "categorical.variable" = list("CATEGORICAL_VARIABLE", "list"),
        "strata" = list("STRATA", "list"),
        "priors" = list("PRIOR", "list")),
      "HGBT" = list(
        "n.estimators" = list("N_ESTIMATORS", "integer"),
        "random.state" = list("SEED", "integer"),
        "subsample" = list("SUBSAMPLE", "numeric"),
        "max.depth" = list("MAX_DEPTH", "integer"),
        "split.threshold" = list("SPLIT_THRESHOLD", "numeric"),
        "learning.rate" = list("LEARNING_RATE", "numeric"),
        "split.method" = list("SPLIT_METHOD", "character",
                              list(exact = "exact",
                                   sketch = "sketch",
                                   sampling = "sampling")),
        "sketch.eps" = list("SKETCH_ESP", "numeric"),
        "min.sample.weight.leaf" = list("MIN_SAMPLES_WEIGHT_LEAF",
                                        "numeric"),
        "reference.metric" = list("REF_METRIC", "list"),
        "min.samples.leaf" = list("MIN_SAMPLES_LEAF", "integer"),
        "max.w.in.split" = list("MAX_W_IN_SPLIT", "numeric"),
        "col.subsample.split" = list("COL_SUBSAMPLE_SPLIT", "numeric"),
        "col.subsample.tree" = list("COL_SUBSAMPLE_TREE", "numeric"),
        "lambda" = list("LAMBDA", "numeric"),
        "alpha" = list("ALPHA", "numeric"),
        "base.score" = list("BASE_SCORE", "numeric"),
        "categorical.variable" = list("CATEGORICAL_VARIABLE", "list"),
        "thread.ratio" = list("THREAD_RATIO", "list"),
        "evaluation.metric" = list("EVALUATION_METRIC", "character",
                                   list(error_rate = "ERROR_RATE",
                                        nll = "NLL",
                                        auc = "AUC"))),
      "LOGR" = list(
        "multi.class" = list("M_", "logical"),
        "max.iter" = list("MAX_ITER", "integer"),
        "enet.alpha" = list("ALPHA", "numeric"),
        "enet.lambda" = list("LAMB", "numeric"),
        "tol" = list("TOL", "numeric"),
        "solver" = list("METHOD", "integer",
                        list(auto = -1, newton = 0, cyclical = 2,
                             lbfgs = 3, stochastic = 4, proximal = 6)),
        "epsilon" = list("EPSILON", "numeric"),
        "standardize" = list("STANDARDIZE", "logical"),
        "max.pass.number" = list("MAX_PASS_NUMBER", "integer"),
        "sgd.batch.number" = list("SGD_BATCH_NUMBER", "integer"),
        "precompute" = list("PRECOMPUTE", "logical"),
        "handle.missing" = list("HANDLE_MISSING", "logical"),
        "categorical.variable" = list("CATEGORICAL_VARIABLE", "list"),
        "lbfgs.m" = list("LBFGS_M", "integer"),
        "class.map0" = list("CLASS_MAP0", "character"),
        "class.map1" = list("CLASS_MAP1", "character"),
        "evaluation.metric" = list("EVALUATION_METRIC", "character",
                                   list(accuracy = "ACCURACY",
                                        nll = "NLL",
                                        auc = "AUC",
                                        f1_score = "F1_SCORE"))),
      "MLP" = list(
        "activation" = list("ACTIVATION",
                            "integer",
                            list("tanh" = 1,
                                 "linear" = 2,
                                 "sigmoid-asymmetric" = 3,
                                 "sigmoid-symmetric" = 4,
                                 "gaussian-asymmetric" = 5,
                                 "gaussian-symmetric" = 6,
                                 "elliot-asymmetric" = 7,
                                 "elliot-symmetric" = 8,
                                 "sin-asymmetric" = 9,
                                 "sin-symmetric" = 10,
                                 "cos-asymmetric" = 11,
                                 "cos-symmetric" = 12,
                                 "relu" = 13)),
        "output.activation" = list("OUTPUT_ACTIVATION",
                                   "integer",
                                   list("tanh" = 1,
                                        "linear" = 2,
                                        "sigmoid-asymmetric" = 3,
                                        "sigmoid-symmetric" = 4,
                                        "gaussian-asymmetric" = 5,
                                        "gaussian-symmetric" = 6,
                                        "elliot-asymmetric" = 7,
                                        "elliot-symmetric" = 8,
                                        "sin-asymmetric" = 9,
                                        "sin-symmetric" = 10,
                                        "cos-asymmetric" = 11,
                                        "cos-symmetric" = 12,
                                        "relu" = 13)),
        "hidden.layer.size" = list("HIDDEN_LAYER_SIZE", "list"),
        "max.iter" = list("MAX_ITER", "integer"),
        "training.style" = list("TRAINING_STYLE", "integer",
                                list("batch" = 0,
                                     "stochastic" = 1)),
        "learning.rate" = list("LEARNING_RATE", "numeric"),
        "momentum" = list("MOMENTUM", "numeric"),
        "batch.size" = list("BATCH_SIZE", "integer"),
        "normalization" = list("NORMALIZATION", "integer",
                               list("no" = 0,
                                    "z-transform" = 1,
                                    "scalar" = 2)),
        "weight.init" = list("WEIGHT_INIT",
                             "integer",
                             list("all-zeros" = 0,
                                  "normal" = 1,
                                  "uniform" = 2,
                                  "variance-scale-normal" = 3,
                                  "variance-scale-uniform" = 4)),
        "thread.ratio" = list("THREAD_RATIO", "numeric"),
        "categorical.variable" = list("CATEGORICAL_VARIABLE", "list"),
        "evaluation.metric" = list("EVALUATION_METRIC", "character",
                                   list(accuracy = "ACCURACY",
                                        nll = "NLL",
                                        auc_1vsrest = "AUC_1VsRest",
                                        auc_pairwise = "AUC_pairwise",
                                        f1_score = "F1_SCORE"))),
      "NB" = list(
        "alpha" = list("ALPHA", "numeric"),
        "discretization" = list("DISCRETIZATION", "integer",
                                list("no" = 0, "supervised" = 1)),
        "model.format" = list("MODEL_FORMAT", "integer",
                              list("json" = 0, "pmml" = 1)),
        "thread.ratio" = list("THREAD_RATIO", "numeric"),
        "categorical.variable" = list("CATEGORICAL_VARIABLE", "list"),
        "evaluation.metric" = list("EVALUATION_METRIC", "character",
                                   list(accuracy = "ACCURACY",
                                        auc = "AUC",
                                        f1_score = "F1_SCORE"))),
      "SVM" = list(
        "c" = list("SVM_C", "numeric"),
        "kernel" = list("KERNEL_TYPE", "integer",
                        list("linear" = 0,
                             "poly" = 1,
                             "rbf" = 2,
                             "sigmoid" = 3)),
        "degree" = list("POLY_DEGREE", "integer"),
        "gamma" = list("RBF_GAMMA", "numeric"),
        "coef.lin" = list("COEF_LIN", "numeric"),
        "coef.const" = list("COEF_CONST", "numeric"),
        "probability" = list("PROBABILITY", "logical"),
        "shrink" = list("SHRINK", "integer", "logical"),
        "tol" = list("TOL", "numeric"),
        "evaluation.seed" = list("EVALUATION_SEED", "integer"),
        "scale.info" = list("SCALE_INFO", "integer",
                            list("no" = 0,
                                 "standardization" = 1,
                                 "rescale" = 2)),
        "handle.missing" = list("HANDLE_MISSING", "logical"),
        "category.weight" = list("CATEGORY_WEIGHT", "numeric"),
        "categorical.variable" = list("CATEGORICAL_VARIABLE", "list"),
        "compression" = list("COMPRESSION", "logical"),
        "max.bits" = list("MAX_BITS", "integer"),
        "max.quantization.iter" = list("MAX_QUANTIZATION_ITER", "integer"),
        "evaluation.metric" = list("EVALUATION_METRIC", "character",
                                   list(accuracy = "ACCURACY",
                                        nll = "NLL",
                                        auc = "AUC",
                                        f1_score = "F1_SCORE"))))
  )
)

#' @title Unified Classficiation
#' @name hanaml.UnifiedClassification
#' @description hanaml.UnifiedClassification is an R wrapper for SAP HANA PAL Unified Classification.\cr
#' Note that this function is a new function in SAP HANA SPS05 and Cloud.
#' @seealso \code{\link{predict.UnifiedClassification}}
#' @param func \code{character}\cr
#'   The functionality for unified classification.\cr
#'   Valid values are as follows:\cr
#'   "DecisionTree", "RandomDecisionTrees", "HGBT",
#'   "LogisticRegression", "NaiveBayes", "SVM", "MLP".
#' @template args-data
#' @template args-key-optional
#' @template args-feature-multiple
#' @param label \code{character, optional}\cr
#'   Name of the column which specifies the dependent variable.\cr
#'   If not specified, defaults to the last non-purpose column.
#' @param purpose \code{character, optional}\cr
#'   Name of the column which specified user-defined data partition.\cr
#'   Mandatory if \emph{partition.method} is "user.defined".
#' @template args-formula
#' @param partition.method \code{character, optional}\cr
#'   Specified the method for partitioning the training data.\cr
#'   Valid options include: "no", "user.defined", "stratified".\cr
#'   Defaults to "no" if not specified (i.e. no data partition).
#' @param stratified.column \code{character, optional}\cr
#'   Specifies the name of the column used for stratified partition.\cr
#'   Mandatory when \emph{partition.method} is set to "stratified".
#' @param partition.random.state \code{character, optional}\cr
#'   Specifies the random seed for stratified partition.
#'   Defaults to 0(system time).
#' @param training.percent \code{numeric, optional}\cr
#'   Specifies the percentage of data used for training.\cr
#'   Defaults to 0.8.
#' @param training.size \code{integer, optional}\cr
#'   Specifies the number of samples in \emph{data} used for training.\cr
#'   If \emph{training.percent} is set, then this parameter has no effect.
#' @param ntiles \code{integer, optional}\cr
#'   Specifies the population tiles in metrics output.\cr
#'   The value should be no less than 1 and no larger than the row size of the
#'   input data.
#' @param output.partition.result \code{logical, optional}\cr
#'   Controls whether to output the partition result of \code{data} or not.\cr
#'   Defaults to FALSE.
#' @param background.size \code{integer, optional}\cr
#'   Specifies the row size of background data.\cr
#'   It should not be larger than the row size of \emph{data}.
#'   Valid only for the following cases:
#'   \itemize{
#'   \item{\emph{func} is "NaiveBayes", "SVM", or "MLP";}
#'   \item{\emph{func} is "LogisticRegression" and \emph{multi.class} is True.}
#'   }
#'   Defaults to 0.\cr
#'   New parameter for SAP HANA Cloud.
#' @param background.random.state \code{integer, optional}\cr
#'   Specifies the seed for random number generator in the background sampling.
#'   \itemize{
#'     \item{0}: Uses the current time (in second) as seed
#'     \item{Others}: Uses the specified value as seed
#'   }
#'   Defaults to 0.\cr
#'   New parameter for SAP HANA Cloud.
#' @param ... \cr
#'   Specifies other parameters for training a classification model with the functionality
#'   specified in \emph{func}.\cr
#'   Please see the documentation of corresponding functionalities for more detail.\cr
#'   \code{\link{hanaml.DecisionTreeClassifier}, \link{hanaml.RDTClassifier},
#'         \link{hanaml.MLPClassifier}, \link{hanaml.HGBTClassifier},
#'         \link{hanaml.NaiveBayes}, \link{hanaml.LogisticRegression},
#'         \link{hanaml.SVC}}
#'   However, some parameters will be disabled. The disable parameters are listed as follows:\cr
#'   \itemize{
#'   \item{\bold{DecisionTree:}  \emph{output.rules, output.confusion.matrix}}
#'   \item{\bold{RDT:}  \emph{calculate.oob}}
#'   \item{\bold{HGBT:}  \emph{calculate.importance, calculate.cm}}
#'   \item{\bold{LogisticRegression:}  \emph{pmml.export}}
#'   }
#' @return
#' Returns an "UnifiedClassification" object with the following attributes and methods:\cr
#' \cr
#'      \bold{model}  \code{DataFrame}\cr
#'          \itemize{
#'             \item{\code{ROW_INDEX} - model row index}
#'             \item{\code{PART_INDEX} -  data partition index}
#'             \item{\code{MODEL_CONTENT} - model content}}
#'
#'      \bold{importance}  \code{DataFrame}\cr
#'          \itemize{
#'             \item{\code{VARIABLE_NAME} - Independent variable name}
#'             \item{\code{IMPORTANCE} - Variable importance}}
#'      \bold{optimal.param}  \code{DataFrame}\cr
#'          \itemize{
#'             \item{\code{PARM_NAME} - parameter name}
#'             \item{\code{INT_VALUE} -  integer value}
#'             \item{\code{DOUBLE_VALUE} - double value}
#'             \item{\code{STRING_VALUE} - character value}
#'         }
#'      \bold{statistics}   \code{DataFrame}\cr
#'          \itemize{
#'             \item{\code{STAT_NAME} - Statistics name}
#'             \item{\code{STAT_VALUE} -  Statistics value}
#'         }
#'      \bold{confusion.matrix}  \code{DataFrame}\cr
#'          \itemize{
#'             \item{\code{ACTUAL_CLASS} - The actual class name}
#'             \item{\code{PREDICTED_CLASS} -  The predicted class name}
#'             \item{\code{COUNT} - Number of records}}
#'      \bold{metrics}  \code{DataFrame}\cr
#'          \itemize{
#'            \item{\code{NAME} - Metric name}
#'            \item{\code{X} - X value}
#'            \item{\code{Y} - Y value}}
#'      \bold{score()}  \code{Function}\cr
#'      Parameters:
#'      \itemize{
#'      \item{data \code{DataFrame}\cr Input data for calculating score metrics.}
#'      \item{key \code{character}\cr Specifies name of the ID column for input data.}
#'      \item{features \code{list/vector of characters, optional}\cr Specifies names of the feature columns, i.e.
#'            independent columns.\cr Defaults to all non-key, non-label columns if not provided.}
#'      \item{label \code{character, optional}\cr Specifies name of dependent column in the input data.\cr
#'            Defaults to the final last non-key column if not provided.}
#'      \item{max.result.num \code{integer, optional}\cr Specifies the output number of prediction results.}
#'      \item{ntiles \code{integer, optional}\cr Specifies the population tiles in metrics output.\cr
#'            The value should be no less than 1 and no larger than the row size of the input data.\cr
#'            Defaults to 1.}
#'      \item{thread.ratio \code{numeric, optional}\cr Specifies the ratio of total number of threads that
#'            can be used by the score function.\cr
#'            Defaults to 1.0.}
#'      \item{func \code{character, optional}\cr The functionality for unified classification model.\cr
#'            Mandatory only when the \emph{func} attribute of \emph{model} is NULL.\cr
#'            Valid values are as follows:\cr
#'            "DecisionTree", "RandomDecisionTrees", "HGBT",
#'            "LogisticRegression", "NaiveBayes", "SVM", "MLP".}
#'      \item{multi.class \code{logical, optional}\cr
#'            If the functionality of the unified classification model is LogisticRegression,\cr
#'            then this parameter indicates whether or not the classification mdoel is\cr
#'            binary-class case or multiple-class case.\cr
#'            Valid only when \emph{func} is set to be "LogisticRegression".}
#'      \item{alpha \code{double, optional}\cr
#'            Specifies the value of Laplace smoothing.\cr
#'            A positive value will enable Laplace smoothing for categorical variables
#'            with that value being the smoothing parameter.\cr
#'            Set the value to 0 to disable Laplace smoothing .\cr
#'            Defaults to the alpha value in the JSON model if there is one, and 0 otherwise.}
#'      \item{block.size \code{integer, optional}\cr
#'            Specifies the number of data loaded per time during scoring.
#'            \itemize{
#'             \item{0}: load all data once
#'             \item{Other positive Values}: the specified number
#'            }
#'            Valid only when the trained classification model is for Random Decision Trees.\cr
#'            Defaults to 0.}
#'      \item{missing.replacement \code{character, optional}\cr
#'            Specifies the strategy for replacement of missing values in prediction data.
#'            \itemize{
#'             \item{'feature.marginalized'}: marginalizes each missing feature out independently
#'             \item{'instance.marginalized'}: marginalizes all missing features in an instance as a
#'              whole corresponding to each category}
#'            Valid only when the trained classification model is for Random Decision Trees or
#'            Hybrid Gradient Boosting Tree(HGBT).\cr
#'            Defaults to 'feature.marginalized'.}
#'      \item{class.map0 \code{character, optional}\cr
#'            Specifies the label value which will be mapped to 0 in logistic regression.\cr
#'            Mandatory and valid only for binary logistic regression models
#'            when the label variable is of type VARCHAR or NVARCHAR.\cr
#'            Defaults to the value of \code{class.map0} in the model training phase.}
#'      \item{class.map1 \code{character, optional}\cr
#'            Specifies the label value which will be mapped to 1 in logistic regression.\cr
#'            Mandatory and valid only for binary logistic regression models
#'            when the label variable is of type VARCHAR or NVARCHAR.\cr
#'            Defaults to the value of \code{class.map1} in the model training phase.}
#'      \item{categorical.variable \code{character or list of characters, optional}\cr
#'            Indicates features that should be treated as categorical variable.\cr
#'            The default behavior is dependent on what input is given:
#'            \itemize{
#'             \item{'VARCHAR' and 'NVARCHAR'}: categorical.\cr
#'             \item{'INTEGER' and 'DOUBLE'}: continuous.\cr
#'            }
#'            VALID only for variables of type "INTEGER",omitted otherwise.\cr
#'            Default to the value of \code{categorical.variable} in the model training phase.}
#'      \item{attribution.method \code{character, optional}\cr
#'            Specifies which method to use in model reasoning:
#'            \itemize{
#'             \item{"no"}: no reasoning
#'             \item{"saabas"}: SAABAS reasoning
#'             \item{"shap"}: SHAP reasoning
#'            }
#'            Valid only for tree-based classification models.\cr
#'            Defaults to "shap".}
#'      \item{top.k.attributions \code{character, optional}\cr
#'            Output the  attributions of top k features which contribute the most.\cr
#'            Defaults to 10.}
#'      \item{sample.size \code{integer, optional}\cr
#'            Specifies the number of sampled combinations of features.\cr
#'            If set to 0, the value is determined by algorithm heuristically.\cr
#'            Valid only when the trained classification model is for Naive Bayes,
#'            Support Vector Machine(SVM), Multilayer Perceptron or Multi-class Logistic Regression.\cr
#'            Defaults to 0.}
#'      \item{random.state \code{integer, optional}\cr
#'            Specifies the seed for random number generator.
#'            \itemize{
#'             \item{0}: Uses the current time (in second) as seed;
#'             \item{Others}: Uses the specified value as seed.}
#'            Valid only when the trained classification model is for Naive Bayes,
#'            Support Vector Machine(SVM), Multilayer Perceptron(MLP) or Multi-class Logistic Regression.\cr
#'            Defaults to 0.}
#'      }
#' @section Examples:
#' \preformatted{
#' > df.fit.dt
#'     OUTLOOK TEMP HUMIDITY WINDY       CLASS PURPOSE
#' 1     Sunny   75       70   Yes        Play       1
#' 2     Sunny   80       90   Yes Do not Play       1
#' 3     Sunny   85       91    No Do not Play       1
#' 4     Sunny   72       95    No Do not Play       2
#' 5     Sunny   73       70    No        Play       1
#' 6  Overcast   72       90   Yes        Play       1
#' 7  Overcast   83       78    No        Play       1
#' 8  Overcast   64       65   Yes        Play       1
#' 9  Overcast   81       75    No        Play       2
#' 10     Rain   71       80   Yes Do not Play       1
#' 11     Rain   65       70   Yes Do not Play       1
#' 12     Rain   75       80    No        Play       1
#' 13     Rain   68       80    No        Play       1
#' 14     Rain   70       96    No        Play       2
#'
#' > uc.dt <- hanaml.UnifiedClassification(func = 'DecisionTree',
#'                                         data = df.fit.dt,
#'                                         partition.method = 'user.defined',
#'                                         purpose = "PURPOSE",
#'                                         algorithm = 'c45',
#'                                         model.format = 'json',
#'                                         min.records.of.parent = 2,
#'                                         min.records.of.leaf = 1,
#'                                         priors = list("Play" = 0.5,
#'                                                       "Do not Play" = 0.5),
#'                                         thread.ratio = 0.4,
#'                                         resampling.method = 'cv',
#'                                         evaluation.metric = 'auc',
#'                                         fold.num = 5,
#'                                         progress.indicator.id = 'CV',
#'                                         param.search.strategy = 'grid',
#'                                         parameter.values = list(split.threshold = c(1e-3 , 1e-4, 1e-5)))
#'
#' > uc.dt$statistics
#'    STAT_NAME         STAT_VALUE  CLASS_NAME
#' 1        AUC 0.6666666666666666        <NA>
#' 2     RECALL                  0 Do not Play
#' 3  PRECISION                  0 Do not Play
#' 4   F1_SCORE                  0 Do not Play
#' 5    SUPPORT                  1 Do not Play
#' 6     RECALL                  1        Play
#' 7  PRECISION 0.6666666666666666        Play
#' 8   F1_SCORE                0.8        Play
#' 9    SUPPORT                  2        Play
#' 10  ACCURACY 0.6666666666666666        <NA>
#' 11     KAPPA                  0        <NA>
#' }
#' @keywords Unified Interface
#' @export
hanaml.UnifiedClassification <- function(data = NULL,
                                         func = NULL,
                                         key = NULL,
                                         features = NULL,
                                         label = NULL,
                                         purpose = NULL,
                                         formula = NULL,
                                         partition.method = NULL,
                                         stratified.column = NULL,
                                         partition.random.state = NULL,
                                         training.percent = NULL,
                                         training.size = NULL,
                                         ntiles = NULL,
                                         output.partition.result = NULL,
                                         background.size = NULL,
                                         background.random.state = NULL,
                                         ...) {
  UnifiedClassification$new(data = data, func = func, key = key,
                            features = features, label = label,
                            purpose = purpose, formula = formula,
                            partition.method = partition.method,
                            stratified.column = stratified.column,
                            partition.random.state = partition.random.state,
                            training.percent = training.percent,
                            training.size = training.size,
                            ntiles = ntiles,
                            output.partition.result = output.partition.result,
                            background.size = background.size,
                            background.random.state = background.random.state,
                            ...)
}

#' @title Make Predictions from a "UnifiedClassification" Object
#' @name predict.UnifiedClassification
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "UnifiedClassification" object.
#' @seealso \code{\link{hanaml.UnifiedClassification}}
#' @format \code{\link{S3}} methods
#' @param  model \code{R6Class}\cr
#'  A "UnifiedClassification" object for prediction.
#' @template args-data
#' @template args-key
#' @template args-feature-predict
#' @template args-threadratio-1
#' @template args-verbose
#' @param func \code{character, optional}\cr
#'   The functionality for unified classification model.\cr
#'   Mandatory only when the \emph{func} attribute of \emph{model} is NULL.\cr
#'   Valid values are as follows:\cr
#'   "DecisionTree", "RandomDecisionTrees", "HGBT",
#'   "LogisticRegression", "NaiveBayes", "SVM", "MLP".\cr
#'   Defaults to \code{model$func}.
#' @param multi.class \code{logical, optional}\cr
#'   If the functionality of the unified classification model is LogisticRegression,\cr
#'   then this parameter indicates whether or not the classification mdoel is
#'   binary-class case or multiple-class case.\cr
#'   Valid only when \emph{func} is set to be "LogisticRegression".
#' @param alpha \code{double, optional}\cr
#'   Specifies the value of Laplace smoothing.\cr
#'   A positive value will enable Laplace smoothing for categorical variables
#'   with that value being the smoothing parameter.\cr
#'   Set the value to 0 to disable Laplace smoothing .\cr
#'   Defaults to the alpha value in the JSON model if there is one, and 0 otherwise.
#' @param block.size \code{integer, optional}\cr
#'   Specifies the number of data loaded per time during scoring.
#'   \itemize{
#'    \item{0}: load all data once
#'    \item{Other positive Values}: the specified number
#'   }
#'   Valid only when \code{func} is "RandomDecisionTrees"(case insensitive).\cr
#'   Defaults to 0.
#' @param missing.replacement \code{character, optional}\cr
#'   Specifies the strategy for replacement of missing values in prediction data.
#'   \itemize{
#'    \item{'feature.marginalized'}: marginalizes each missing feature out independently
#'    \item{'instance.marginalized'}: marginalizes all missing features in an instance as a
#'          whole corresponding to each category
#'   }
#'   Valid only when \code{func} is "RandomDecisionTrees" or "HGBT".\cr
#'   Defaults to 'feature.marginalized'.
#' @param class.map0 \code{character, optional}\cr
#'   Specifies the label value which will be mapped to 0 in logistic regression.\cr
#'   Mandatory and valid only for logistic regression models when the label variable is of type VARCHAR or NVARCHAR.\cr
#'   Defaults to the value of \code{class.map0} in the model training phase.
#' @param class.map1 \code{character, optional}\cr
#'   Specifies the label value which will be mapped to 1 in logistic regression.\cr
#'   Mandatory and valid only for logistic regression models when the label variable is of type VARCHAR or NVARCHAR.\cr
#'   Defaults to the value of \code{class.map1} in the model training phase.
#' @param categorical.variable \code{character or list of characters, optional}\cr
#'   Indicates features that should be treated as categorical variable.\cr
#'   The behavior is dependent on what input is given:
#'   \itemize{
#'     \item{'VARCHAR' and 'NVARCHAR'}: categorical.\cr
#'     \item{'INTEGER' and 'DOUBLE'}: continuous.\cr
#'   }
#'   VALID only for variables of type "INTEGER",omitted otherwise.\cr
#'   Default to the value of \code{categorical.variable} in the model training phase.
#' @param attribution.method \code{character, optional}\cr
#'   Specifies which method to use in model reasoning:
#'   \itemize{
#'     \item{"no"}: no reasoning
#'     \item{"saabas"}: SAABAS reasoning
#'     \item{"shap"}: SHAP reasoning
#'   }
#'   Valid only for tree-based classification models.\cr
#'   Defaults to "shap".
#' @param top.k.attributions \code{character, optional}\cr
#'   Output the  attributions of top k features which contribute the most.
#'   Defaults to 10.
#' @param sample.size \code{integer, optional}\cr
#'   Specifies the number of sampled combinations of features.\cr
#'   If set to 0, the value is determined by algorithm heuristically.\cr
#'   Valid only when the trained classification model is for Naive Bayes, Support Vector Machine(SVM),
#'   Multilayer Perceptron or Multi-class Logistic Regression.\cr
#'   Defaults to 0.
#' @param random.state \code{integer, optional}\cr
#'   Specifies the seed for random number generator.
#'   \itemize{
#'     \item{0}: Uses the current time (in second) as seed;
#'     \item{Others}: Uses the specified value as seed.
#'   }
#'   Valid only when the trained classification model is for Naive Bayes, Support Vector Machine(SVM),
#'   Multilayer Perceptron(MLP) or Multi-class Logistic Regression.\cr
#'   Defaults to 0.
#' @return
#' Predicted values are returned as a DataFrame, structured as follows.
#' \itemize{
#'   \item{ID column name}
#'   \item{SCORE}
#'   \item{CONFIDENCE}
#'   \item{REASON CODE}
#' }
#' @section Examples:\cr
#' Input data for prediction:
#' \preformatted{
#' > df.predict
#'   ID  OUTLOOK   TEMP HUMIDITY WINDY
#' 1  0 Overcast     75   -10000   Yes
#' 2  1     Rain     78       70   Yes
#' 3  2    Sunny -10000       NA   Yes
#' 4  3    Sunny     69       70   Yes
#' 5  4     Rain     NA       70   Yes
#' 6  5     <NA>     70       70   Yes
#' 7  6      ***     70       70   Yes
#' }
#' Call the predict() function:
#' \preformatted{
#' > res <- predict(model = uc.dt,
#'                  data = df.predict,
#'                  key = "ID",
#'                  func = "DecisionTree")
#' }
#' Check the result:
#' \preformatted{
#' > res$Collect()[1:3]
#'   ID       SCORE CONFIDENCE
#' 1  0        Play  1.0000000
#' 2  1 Do not Play  1.0000000
#' 3  2        Play  0.5000000
#' 4  3        Play  0.5000000
#' 5  4        Play  0.6363636
#' 6  5        Play  0.5000000
#' 7  6        Play  0.5000000
#' }
#' @keywords Unified Interface
#' @export
predict.UnifiedClassification <- function(model,
                                          data,
                                          key,
                                          features = NULL,
                                          thread.ratio = NULL,
                                          verbose = NULL,
                                          func = NULL,
                                          multi.class = NULL,
                                          alpha = NULL,
                                          block.size = NULL,
                                          missing.replacement = NULL,
                                          class.map0 = NULL,
                                          class.map1 = NULL,
                                          categorical.variable = NULL,
                                          attribution.method = NULL,
                                          top.k.attributions = NULL,
                                          sample.size = NULL,
                                          random.state = NULL) {
  model$predict(data = data,
                key = key,
                features = features,
                thread.ratio = thread.ratio,
                verbose = verbose,
                func = func,
                multi.class = multi.class,
                alpha = alpha,
                block.size = block.size,
                missing.replacement = missing.replacement,
                class.map0 = class.map0,
                class.map1 = class.map1,
                categorical.variable = categorical.variable,
                attribution.method = attribution.method,
                top.k.attributions = top.k.attributions,
                sample.size = sample.size,
                random.state = random.state)
}
