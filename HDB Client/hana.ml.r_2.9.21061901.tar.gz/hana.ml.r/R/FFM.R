FFMBase <-  R6Class(
  "FFMBase",
  inherit = MlBase,
  public = list(
    model = NULL,
    model.meta = NULL,
    coefficient = NULL,
    stat = NULL,
    cv = NULL,
    param.array = NULL,
    data = NULL,
    categorical.variable = NULL,
    delimiter = NULL,
    ordering = NULL,
    normalize = NULL,
    include.constant = NULL,
    include.linear = NULL,
    early.stop = NULL,
    factor.num = NULL,
    train.ratio = NULL,
    learning.rate = NULL,
    random.state = NULL,
    max.iter = NULL,
    linear.lambda = NULL,
    poly2.lambda = NULL,
    sgd.tol = NULL,
    sgd.exit.interval = NULL,
    handle.missing = NULL,
    handle.missing.map = list("remove" = 1, "replace" = 2),
    initialize = function(
      data = NULL,
      task = NULL,
      key = NULL,
      features = NULL,
      label = NULL,
      categorical.variable = NULL,
      delimiter = NULL,
      ordering = NULL,
      normalize = NULL,
      include.constant = NULL,
      include.linear = NULL,
      early.stop = NULL,
      factor.num = NULL,
      train.ratio = NULL,
      learning.rate = NULL,
      random.state = NULL,
      max.iter = NULL,
      linear.lambda = NULL,
      poly2.lambda = NULL,
      sgd.tol = NULL,
      sgd.exit.interval = NULL,
      handle.missing = NULL) {
      super$initialize()
      if (!is.null(data)) {
        private$task <- task
        self$factor.num <- validateInput("factor.num",
                                         factor.num,
                                         "integer")
        self$random.state <- validateInput(
          "random.state", random.state, "integer")

        self$learning.rate <- validateInput(
          "learning.rate", learning.rate, "numeric")
        self$linear.lambda <- validateInput(
          "linear.lambda", linear.lambda, "numeric")
        self$poly2.lambda <- validateInput(
          "poly2.lambda", poly2.lambda, "numeric")
        self$max.iter <- validateInput("max.iter", max.iter, "integer")
        if (!is.null(train.ratio)) {
          self$train.ratio <- validateInput(
            "train.ratio", train.ratio, "numeric")
          if (self$train.ratio < 0 || self$train.ratio > 1) {
            msg <- "The train.ratio value range is from 0 to 1!"
            flog.error(msg)
            stop(msg)
          }
        }
        self$sgd.exit.interval <- validateInput(
          "sgd.exit.interval", sgd.exit.interval, "integer")
        self$sgd.tol <- validateInput(
          "sgd.tol", sgd.tol, "numeric")
        private$IsPositiveValue(learning.rate)
        private$IsPositiveValue(linear.lambda)
        private$IsPositiveValue(poly2.lambda)
        private$IsPositiveValue(factor.num)
        private$IsPositiveValue(max.iter)
        private$IsPositiveValue(sgd.exit.interval)
        private$IsPositiveValue(sgd.tol)
        if (is.numeric(ordering)) {
          ordering <- as.list(ordering)
        }
        self$ordering  <-  validateInput("ordering", ordering,
                                         "list")
        self$delimiter <- validateInput("delimiter", delimiter,
                                        "character")
        self$normalize <- validateInput("normalize", normalize,
                                        "logical")
        self$include.constant <- validateInput("include.constant",
                                               include.constant,
                                               "logical")
        if (private$task == "ranking") {
          self$include.constant <-  TRUE
        }
        self$include.linear <- validateInput(
          "include.linear", include.linear, "logical")
        self$early.stop <- validateInput("early.stop", early.stop, "logical")
        self$handle.missing <- validateInput("handle.missing",
                                             handle.missing,
                                             self$handle.missing.map)
        cols <-  data$columns
        key <- validateInput("key", key, cols,
                             case.sensitive = TRUE)
        cols <- cols[!cols %in% key]
        categorical.variable <-
          validateInput("categorical.variable",
                        categorical.variable,
                        cols, case.sensitive = TRUE)
        label <- validateInput("label", label, cols,
                               case.sensitive = TRUE)
        if (is.null(label)) {
          label <- cols[[length(cols)]]
        }
        label.t <- data$dtypes(label)[[1]][[1]]
        if (grepl("INT", label.t) && label %in% categorical.variable) {
          label.t <- "NVARCHAR"
        }
        if (private$task == "regression") {
          if (label.t %in% c("VARCHAR", "NVARCHAR")) {
            msg <- paste("Label column is categorical,",
                         "not suitable for regression task.")
            flog.error(msg)
            stop(msg)
          }
        } else if (private$task == "ranking") {
          if (label.t %in% c("DOUBLE", "INTEGER")) {
            msg <- paste("Label column is not continuous,",
                         "not suitable for ranking task.")
            flog.error(msg)
            stop(msg)
          }
        }
        cols <- cols[! cols %in%  label]
        features <- validateInput("features", features,
                                  cols, case.sensitive = TRUE)
        if (is.null(features)) {
          features <- cols
        }
        if (!inherits(data, "DataFrame")) {
          msg  <-  "data must be a DataFrame."
          flog.error(msg)
          stop(msg)
        }
        conn  <-  data$connection.context
        CheckConnection(data)
        data <-  data$Select(c(unlist(features), label))#ID removal
        param.array <- list(
          tuple("TRAIN_RATIO", NULL, self$train.ratio, NULL),
          tuple("TASK", NULL, NULL, private$task),
          tuple("K_NUM", self$factor.num, NULL, NULL),
          tuple("DELIMITER",  NULL, NULL,  self$delimiter),
          tuple("LEARNING_RATE", NULL, self$learning.rate, NULL),
          tuple("LINEAR_LAMBDA", NULL, self$linear.lambda, NULL),
          tuple("POLY2_LAMBDA", NULL, self$poly2.lambda, NULL),
          tuple("MAX_ITERATION", self$max.iter, NULL, NULL),
          tuple("CONVERGENCE_CRITERION", NULL, self$sgd.tol, NULL),
          tuple("CONVERGENCE_INTERVAL", self$sgd.exit.interval, NULL, NULL),
          tuple("SEED", self$random.state, NULL, NULL),
          tuple("NORMALISE", to.integer(self$normalize), NULL, NULL),
          tuple("INCLUDE_CONSTANT", to.integer(self$include.constant),
                NULL, NULL),
          tuple("INCLUDE_LINEAR", to.integer(self$include.linear), NULL, NULL),
          tuple("EARLY_STOP", to.integer(self$early.stop), NULL, NULL),
          tuple("HAS_ID", 0,  NULL, NULL),
          tuple("HANDLE_MISSING", map.null(self$handle.missing,
                                           self$handle.missing.map),
                NULL, NULL))
        if (!is.null(self$ordering)) {
          param.array <- append(param.array,
                                list(tuple("ORDERING", NULL, NULL,
                                           paste(self$ordering,
                                                 collapse = ", "))))
        }
        if (length(categorical.variable) != 0) {
          for (col in categorical.variable) {
            param.array <- append(param.array,
                                  list(tuple("CATEGORICAL_VARIABLE",
                                             NULL, NULL, col)))
          }
        }
        unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
        param.tbl <- sprintf("#PAL_PARAM_TBL_%s_%s",
                             self$id, unique.id)
        model.meta.tbl <- sprintf("#PAL_MODEL_META_TBL_%s_%s",
                                  self$id, unique.id)
        coefficient.tbl <- sprintf("#PAL_COEFFICIENT_TBL_%s_%s",
                                   self$id, unique.id)
        stat.tbl <- sprintf("#PAL_STAT_TBL_%s_%s", self$id, unique.id)
        cv.tbl <- sprintf("#PAL_CV_TBL_%s_%s", self$id, unique.id)
        in.tables <- list(data, param.tbl)
        out.tables <- list(model.meta.tbl, coefficient.tbl,
                           stat.tbl, cv.tbl)
        tables <- c(param.tbl, out.tables)
        tryCatch({
          errorhelper(CreateTWithConnection(conn,
            ParameterTable$new(param.tbl)$WithData(param.array)))#nolint
          errorhelper(CallPalAutoWithConnection(conn,
            "PAL_FFM", in.tables, out.tables))
        },
        error = function(err) {
          msg <- paste("Error:", err$message)
          flog.error(msg)
          TryDropWithConnection(conn, tables)
          stop(msg)
        })
        self$model.meta <- conn$table(model.meta.tbl)
        self$coefficient <- conn$table(coefficient.tbl)
        self$stat <- conn$table(stat.tbl)
        self$cv <- conn$table(cv.tbl)
        self$model <- list(self$model.meta, self$coefficient)
      }
    },
    predict = function(
      data = NULL,
      key = NULL,
      features = NULL,
      thread.ratio = NULL,
      handle.missing = NULL) {
      model.meta <- self$model[[1]]
      coefficient <- self$model[[2]]
      if (is.null(data)) {
        msg <- "data is NULL!"
        flog.error(msg)
        stop(msg)
      }
      cols <- data$columns
      key <- validateInput("key", key, cols,
                           case.sensitive = TRUE,
                           required = TRUE)
      cols <- cols[!cols %in% key]
      if (is.null(features)) {
        features <- cols
      }
      handle.missing <- validateInput("handle.missing",
                                      handle.missing,
                                      handle.missing.map)
      thread.ratio <- validateInput("thread.ratio", thread.ratio,
                                    "numeric")
      if (!is.null(thread.ratio)) {
        if (thread.ratio < 0 || thread.ratio > 1) {
          msg <- "The thread.ratio value range is from 0 to 1!"
          flog.error(msg)
          stop(msg)
        }
      }
      if (!inherits(data, "DataFrame")) {
        msg  <-  "data must be a DataFrame."
        flog.error(msg)
        stop(msg)
      }
      conn <- data$connection.context
      CheckConnection(data)
      data <- data$Select(c(key, features))
      param.array <- list(
        tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
        tuple("HANDLE_MISSING", map.null(handle.missing,
                                         self$handle.mssing.map),
              NULL, NULL)
      )
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      param.tbl <- sprintf("#PAL_FFM_PARAMETER_TBL_%s", unique.id)
      result.tbl <- sprintf("#PAL_FFM_RESULT_TBL_%s", unique.id)
      in.tables <- list(
        data, model.meta, coefficient, param.tbl
      )
      out.tables <- list(result.tbl)
      tables <- c(param.tbl, out.tables)
      tryCatch({
        errorhelper(CreateTWithConnection(
          conn, ParameterTable$new(param.tbl)$WithData(param.array))) #nolint
        errorhelper(CallPalAutoWithConnection(
          conn, "PAL_FFM_PREDICT", in.tables, out.tables))
      },
      error = function(err) {
        msg <- paste("Error:", err$message)
        flog.error(msg)
        TryDropWithConnection(conn, tables)
        stop(msg)
      })
      return(conn$table(result.tbl))
    }
  ),
  private = list(
    task = NULL,
    IsPositiveValue = function(value) {
      if (!is.null(value)) {
        if (inherits(value, "numeric")) {
          if (value < 0) {
            msg <- sprintf("Invalid input! %s is less than 0.",
                           deparse(substitute(param.name)))
            flog.error(msg)
            stop(msg)
          }
        }
      }
    }
  )
)

FFMClassifier <- R6Class(
  "FFMClassifier",
  inherit = FFMBase,
  public = list(
    initialize = function(
      data = NULL,
      key = NULL,
      features = NULL,
      label = NULL,
      categorical.variable = NULL,
      delimiter = NULL,
      normalize = NULL,
      include.constant = NULL,
      include.linear = NULL,
      early.stop = NULL,
      factor.num = NULL,
      train.ratio = NULL,
      learning.rate = NULL,
      random.state = NULL,
      max.iter = NULL,
      linear.lambda = NULL,
      poly2.lambda = NULL,
      sgd.tol = NULL,
      sgd.exit.interval = NULL,
      handle.missing = NULL) {
      super$initialize(data,
                       "classification",
                       key,
                       features,
                       label,
                       categorical.variable,
                       delimiter,
                       NULL,
                       normalize,
                       include.constant,
                       include.linear,
                       early.stop,
                       factor.num,
                       train.ratio,
                       learning.rate,
                       random.state,
                       max.iter,
                       linear.lambda,
                       poly2.lambda,
                       sgd.tol,
                       sgd.exit.interval,
                       handle.missing)
    }
  )
)

FFMRegressor <-  R6Class(
  "FFMRegressor",
  inherit = FFMBase,
  public = list(
    initialize = function(
      data = NULL,
      key = NULL,
      features = NULL,
      label = NULL,
      categorical.variable = NULL,
      delimiter = NULL,
      normalize = NULL,
      include.constant = NULL,
      include.linear = NULL,
      early.stop = NULL,
      factor.num = NULL,
      train.ratio = NULL,
      learning.rate = NULL,
      random.state = NULL,
      max.iter = NULL,
      linear.lambda = NULL,
      poly2.lambda = NULL,
      sgd.tol = NULL,
      sgd.exit.interval = NULL,
      handle.missing = NULL) {
      super$initialize(data = data,
                       task = "regression",
                       key = key,
                       features = features,
                       label = label,
                       categorical.variable = categorical.variable,
                       delimiter = delimiter,
                       ordering = NULL,
                       normalize = normalize,
                       include.constant = include.constant,
                       include.linear = include.linear,
                       early.stop = early.stop,
                       factor.num = factor.num,
                       train.ratio = train.ratio,
                       learning.rate = learning.rate,
                       random.state = random.state,
                       max.iter = max.iter,
                       linear.lambda = linear.lambda,
                       poly2.lambda = poly2.lambda,
                       sgd.tol = sgd.tol,
                       sgd.exit.interval = sgd.exit.interval,
                       handle.missing = handle.missing)
    }
  )
)


FFMRanker <-  R6Class(
  "FFMRanker",
  inherit = FFMBase,
  public = list(
    initialize = function(
      data = NULL,
      key = NULL,
      features = NULL,
      label = NULL,
      categorical.variable = NULL,
      delimiter = NULL,
      ordering = NULL,
      normalize = NULL,
      include.constant = TRUE,
      include.linear = NULL,
      factor.num = NULL,
      train.ratio = NULL,
      learning.rate = NULL,
      random.state = NULL,
      max.iter = NULL,
      linear.lambda = NULL,
      poly2.lambda = NULL,
      sgd.tol = NULL,
      sgd.exit.interval = NULL,
      early.stop = NULL,
      handle.missing = NULL) {
      super$initialize(data = data,
                       task = "ranking",
                       key = key,
                       features = features,
                       label = label,
                       categorical.variable = categorical.variable,
                       delimiter = delimiter,
                       ordering = ordering,
                       normalize = normalize,
                       include.constant = include.constant,
                       include.linear = include.linear,
                       early.stop = early.stop,
                       factor.num = factor.num,
                       train.ratio = train.ratio,
                       learning.rate = learning.rate,
                       random.state = random.state,
                       max.iter = max.iter,
                       linear.lambda = linear.lambda,
                       poly2.lambda = poly2.lambda,
                       sgd.tol = sgd.tol,
                       sgd.exit.interval = sgd.exit.interval,
                       handle.missing = handle.missing)
    }
  )
)


#' @title Field-Aware Factorization Machine for classification
#' @name hanaml.FFMClassifier
#' @seealso \code{\link{hanaml.FFMRegressor}, \link{hanaml.FFMRanker}, \link{predict.FFMClassifier}}
#' @description hanaml.FFMClassifier is an R wrapper
#' for SAP HANA PAL FFM for classification.
#' @details
#' FFM has been proven to be a powerful tool for CTR and CVR prediction task.
#' Based on FM models that reduce weights for sparse higher-order interactions
#' to vectors using matrix factorization, the Field-Aware Factorization Machine
#' introduces the concept of field, with which we represent a group of similar
#' features, e.g., the field of user properties includes gender, age,
#' occupation, etc. \cr
#' By making factor vectors related not only to features but
#' also to fields, the model has to learn a vector representation
#' for each field.
#' By doing so, we increase the complexity of the model to O(kn^2) where n is
#' the number of data, and k is the factor number, i.e., length of the factor
#' vectors.\cr
#' In practice, we consider features spanned from the same categorical
#' variable as of the same field. It is noted that FFM is most suited
#' to
#' categorical features. A numeric feature is either regarded as a
#' single field or
#' discretized to categorical. If all features are numeric and treated
#' as every single
#' feature, which means each field consists of only one feature,
#' FFM degenerates to FM.\cr
#' FFM can be applied to a variety of prediction tasks,
#' for example, binary classification, regression, and ranking.
#' @param data \code{DataFrame}\cr
#' DataFrame containting data the data for factorization.
#' @template args-key-optional
#' @template args-feature-multiple
#' @template args-label
#' @template args-cate-var
#' @param      factor.num \code{integer, optional}\cr
#'            length of factor vectors.\cr
#'            Defaults to 4
#' @param      delimiter \code{character, optional}\cr
#'            The delimiter to separate string features. For example,
#'            "China, USA" indicates two feature values "China"
#'            and "USA".
#'            Valid only for string feature.\cr
#'            Default to "," (comma)
#' @param      learning.rate \code{double, optional}\cr
#'            Secifies the learning rate/ step size for optimization
#'            process.\cr
#'            Defaults to 0.2.
#' @param     train.ratio \code{double, optional}\cr
#'            The ratio of training data set, and the remaining data
#'            set for validation. For example, 0.8 indicates that
#'            80% for training, and the remaining 20% for validation.\cr
#'            0.8 if number of instances not less than 40, 1.0 otherwise.
#' @param      normalize \code{logical, optional}\cr
#'            Specifies whether to normalize each instance so
#'            that its L1 norm is 1.\cr
#'            Defaults to TRUE.
#' @param      include.linear \code{logical, optional}\cr
#'            Specifies whether or not to include the linear weights in FFM model.\cr
#'            Defaults to TRUE.
#' @param      include.constant \code{logical, optional}\cr
#'            Specifies whether or not to include the constant part in FFM model.\cr
#'            Defaults to TRUE.
#' @param      linear.lambda \code{double, optional}\cr
#'            Specifies the penalization assigned to the L2 regularization term for linear weights.\cr
#'            Defaults to 1e-5.
#' @param      poly2.lambda \code{double, optional}\cr
#'            Specifies the penalization assigned to the L2 regularization term for quadratic factors.\cr
#'            Defaults to 1e-5.
#' @param      random.state \code{double, optional}\cr
#'            Specifies the seed for random number generation,
#'            where 0 means current system time
#'            is used as seed, and other values are simply real
#'            seed values.\cr
#'            Defaults to 0.
#' @param     max.iter \code{integer, optional}\cr
#'            Specifies the maximum number of iterations for
#'            optimization process.\cr
#'            Defaults to 20.
#' @param     sgd.tol \code{double, optional}\cr
#'            Specifies the stopping creteria for SGD algorithm.\cr
#'            The algorithm exits when the cost function has not
#'            decreased more than sgd.tol in sgd.exit.interval steps.\cr
#'            Defaults to 1e-5.
#' @param     sgd.exit.interval \code{double, optional}\cr
#'            Specifies the stop creteria for SGD algorithm.\cr
#'            The algorithm exits when the cost function has not
#'            decreased more than sgd.tol in sgd.exit.interval steps.\cr
#'            Defaults to 5.
#' @param     early.stop \code{logical, optional}\cr
#'            Specifies whether or not to early stop the SGD
#'            optimisation.
#'            Always TRUE, if \code{train.ratio} is less than 1.
#'            Defaults to TRUE.
#' @param      handle.missing \code{c("remove", "replace"), optional}
#'             Specifies how to handle missing features of \code{data}:
#'             \itemize{
#'               \item{\code{"remove"} remove missing rows}
#'               \item{\code{"replace"} replace missing rows with 0}
#'             }
#'
#' @return
#' A "FFMClassifier" object with the following attributes:\cr
#' \itemize{
#' \item \code{meta: DataFrame}\cr meta data of the
#' trained model.
#' \item \code{coef: DataFrame}\cr coefficient of the
#' trained model
#' \item \code{stats: DataFrame}\cr statistical information about the
#' trained model.
#' }
#' @section Examples:
#'\preformatted{
#' > data$Head(5)
#'   USER  MOVIE TIMESTAMP       CTR
#' 1    A Movie1         3     Click
#' 2    A Movie2         3     Click
#' 3    A Movie4         1 Not click
#' 4    A Movie5         2     Click
#' 5    A Movie6         3     Click
#'}
#' Call the function:
#' \preformatted{
#' > FFMClsf <- hanaml.FFMClassifier(data = data, task = "ranking",
#'                                   categorical.variable = "TIMESTAMP",
#'                                   delimiter = ",", factor.num = 4,
#'                                   early.stop = TRUE, learning.rate = 0.2,
#'                                   max.iter = 20, train.ratio = 0.8,
#'                                   linear.lambda = 1e-5,
#'                                   poly2.lambda = 1e-6, random.state = 1)
#' }
#' Output:
#' \preformatted{
#' > FFMClsf$coefficient$Head(5)
#'   COEFF_INDEX FEATURE FIELD  K COEFFICIENT
#' 1           0       c  <NA> NA -0.03166240
#' 2           1  USER:A  <NA> NA -0.13690224
#' 3           2  USER:B  <NA> NA -0.04620829
#' 4           3  USER:C  <NA> NA  0.10801253
#' 5           4  USER:D  <NA> NA -0.04806942
#'}
#' @keywords Recommender system
#' @export

hanaml.FFMClassifier <- function(data = NULL,
                                 key = NULL,
                                 features = NULL,
                                 label = NULL,
                                 categorical.variable = NULL,
                                 delimiter = NULL,
                                 normalize = NULL,
                                 include.constant = NULL,
                                 include.linear = NULL,
                                 early.stop = NULL,
                                 factor.num = NULL,
                                 train.ratio = NULL,
                                 learning.rate = NULL,
                                 random.state = NULL,
                                 max.iter = NULL,
                                 linear.lambda = NULL,
                                 poly2.lambda = NULL,
                                 sgd.tol = NULL,
                                 sgd.exit.interval = NULL,
                                 handle.missing = NULL) {
  FFMClassifier$new(data = data,
                    key = key,
                    features = features,
                    label = label,
                    categorical.variable = categorical.variable,
                    delimiter = delimiter,
                    normalize = normalize,
                    include.constant = include.constant,
                    include.linear = include.linear,
                    early.stop = early.stop,
                    factor.num = factor.num,
                    train.ratio = train.ratio,
                    learning.rate = learning.rate,
                    random.state = random.state,
                    max.iter = max.iter,
                    linear.lambda = linear.lambda,
                    poly2.lambda = poly2.lambda,
                    sgd.tol = sgd.tol,
                    sgd.exit.interval = sgd.exit.interval,
                    handle.missing = handle.missing)
}

#' @title Make Predictions from an "FFMClassifier" Object
#' @name predict.FFMClassifier
#' @seealso \code{\link{hanaml.FFMClassifier}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr A "FFMClassifier" object for prediction.
#' @param data \code{DataFrame}\cr
#' DataFrame containting data of user-item interaction and global
#' side features for prediction.
#' @template args-key
#' @template args-threadratio
#' @param      features \code{list of characters, optional}\cr
#'            Name of feature columns.\cr
#'            If not provided, it defaults all non-ID columns of
#'            \emph{data}.
#' @param handle.missing \code{c("remove", "replace"), optional}\cr
#' Specifies how to handle missing features of \code{data}:
#' \itemize{
#' \item{\code{"remove"} remove missing rows}
#' \item{\code{"replace"} replace missing rows with 0}
#' }
#'
#' @return
#' \code{DataFrame}\cr
#'    Prediction made by the model, structured as follows:
#'    \itemize{
#'      \item{ID}: id
#'      \item{SCORE}: Predict value
#'      \item{CONFIDENCE}: the confidence of a category (NULL for "regression")
#'    }
#'
#'
#' @section Examples:
#' \preformatted{
#' > data$Collect()
#'   ID USER  MOVIE TIMESTAMP
#' 1  1    A Movie0         3
#' 2  2    A Movie4         1
#' 3  3    B Movie3         2
#' 4  4    B   <NA>         5
#' 5  5    C Movie2         2
#' 6  6    F Movie4         3
#' 7  7    D Movie2         2
#' 8  8    D Movie4         1
#' 9  9    E Movie7         4
#'}
#' Call the function:
#' \preformatted{
#' > cres <- predict.FFMClassifier(model = FFMClsf,
#'                                 data = data.pred.df.fit,
#'                                 thread.ratio = 1)}
#' Output:
#' \preformatted{
#' > cres$Head(5)
#'   ID     SCORE CONFIDENCE
#' 1  1 Not click  0.5435375
#' 2  2 Not click  0.5454705
#' 3  3     Click  0.5427368
#' 4  4     Click  0.5194578
#' 5  5     Click  0.5110010
#'}
#' @keywords Recommender system
#' @export
predict.FFMClassifier <- function(
  model=NULL,
  data=NULL,
  key = NULL,
  features = NULL,
  handle.missing = NULL,
  thread.ratio = NULL) {
  result <- model$predict(data = data,
                          key = key,
                          features = features,
                          thread.ratio = thread.ratio,
                          handle.missing = handle.missing)
}


#' @title Field-Aware Factorization Machine for regression
#' @name hanaml.FFMRegressor
#' @seealso \code{\link{hanaml.FFMClassifier}, \link{hanaml.FFMRanker}, \link{predict.FFMRegressor}}
#' @description hanaml.FFMRegressor is an R wrapper
#' for SAP HANA PAL FFM for regression.
#' @details
#' FFM has been proven to be a powerful tool for CTR and CVR prediction task.
#' Based on FM models that reduce weights for sparse higher-order interactions
#' to vectors using matrix factorization, the Field-Aware Factorization Machine
#' introduces the concept of field, with which we represent a group of similar
#' features, e.g., the field of user properties includes gender, age,
#' occupation, etc. \cr
#' By making factor vectors related not only to features but
#' also to fields, the model has to learn a vector representation
#' for each field.
#' By doing so, we increase the complexity of the model to O(kn^2) where n is
#' the number of data, and k is the factor number, i.e., length of the factor
#' vectors.\cr
#' In practice, we consider features spanned from the same categorical
#' variable as of the same field. It is noted that FFM is most suited
#' to
#' categorical features. A numeric feature is either regarded as a
#' single field or
#' discretized to categorical. If all features are numeric and treated
#' as every single
#' feature, which means each field consists of only one feature,
#' FFM degenerates to FM.\cr
#' FFM can be applied to a variety of prediction tasks,
#' for example, binary classification, regression, and ranking.
#' @param data \code{DataFrame}\cr
#' DataFrame containting data the data for factorization.
#' @template args-key-optional
#' @template args-feature-multiple
#' @template args-label
#' @template args-cate-var
#' @param      factor.num \code{integer, optional}\cr
#'            length of factor vectors.\cr
#'            Defaults to 4.
#' @param      delimiter \code{character, optional}\cr
#'            The delimiter to separate string features. For example,
#'            "China, USA" indicates two feature values "China"
#'            and "USA".\cr
#'            Valid only for string feature.
#'            Default to "," (comma)
#' @param      learning.rate \code{double, optional}\cr
#'            Secifies the learning rate/ step size for optimization
#'            process.\cr
#'            Defaults to 0.2
#' @param      train.ratio \code{double, optional}\cr
#'            The ratio of training data set, and the remaining data
#'            set for validation. For example, 0.8 indicates that
#'            80% for training, and the remaining 20% for validation.\cr
#'            0.8 if number of instances not less than 40, 1.0 otherwise.
#' @param      normalize \code{logical, optional}\cr
#'            Specifies whether to normalize each instance so
#'            that its L1 norm is 1.
#'            Defaults to TRUE.
#' @param      include.linear \code{logical, optional}\cr
#'            Specifies whether or not to include the linear weights in FFM model.\cr
#'            Defaults to TRUE.
#' @param      include.constant \code{logical, optional}\cr
#'            Specifies whether or not to include the constant part in FFM model.\cr
#'            Defaults to TRUE.
#' @param      linear.lambda \code{double, optional}\cr
#'            Specifies the penalization assigned to the L2 regularization term for linear weights.\cr
#'            Defaults to 1e-5
#' @param      poly2.lambda \code{double, optional}\cr
#'            Specifies the penalization assigned to the L2 regularization term for quadratic factors.\cr
#'            Defaults to 1e-5
#' @param      random.state \code{double, optional}\cr
#'            Specifies the seed for random number generation,
#'            where 0 means current system time
#'            is used as seed, and other values are simply real
#'            seed values.\cr
#'            Defaults to 0.
#' @param     max.iter \code{integer, optional}\cr
#'            Specifies the maximum number of iterations for
#'            optimization process.
#'            Defaults to 20.
#' @param     sgd.tol \code{double, optional}\cr
#'            Specifies the stopping creteria for SGD algorithm.\cr
#'            The algorithm exits when the cost function has not
#'            decreased more than sgd.tol in sgd.exit.interval steps.\cr
#'            Defaults to 1e-5.
#' @param     sgd.exit.interval \code{double, optional}\cr
#'            Specifies the stop creteria for SGD algorithm.\cr
#'            The algorithm exits when the cost function has not
#'            decreased more than sgd.tol in sgd.exit.interval steps.\cr
#'            Defaults to 5.
#' @param     early.stop \code{logical, optional}\cr
#'            Specifies whether or not to early stop the SGD
#'            optimisation.
#'            Always TRUE, if \code{train.ratio} is less than 1.\cr
#'            Defaults to TRUE.
#' @param      handle.missing \code{c("remove", "replace"), optional}\cr
#'             Specifies how to handle missing features of \code{data}:
#'             \itemize{
#'               \item{\code{"remove"} remove missing rows}
#'               \item{\code{"replace"} replace missing rows with 0}
#'             }
#'
#' @return
#' A "FFMRegressor" object with the following attributes:\cr
#' \itemize{
#' \item \code{meta: DataFrame}\cr meta data of the
#' trained model.
#' \item \code{coef: DataFrame}\cr coefficient of the
#' trained model.
#' \item \code{stats: DataFrame}\cr statistical information about the
#' trained model.
#' }
#' @section Examples:
#'\preformatted{
#' > data$Head(5)$Collect()
#'   ID USER  MOVIE TIMESTAMP RATING
#' 1  1    A Movie1         3      0
#' 2  2    A Movie2         3      5
#' 3  3    A Movie4         1      0
#' 4  4    A Movie5         2      1
#' 5  5    A Movie6         3      2
#' }
#' Call the function:
#' \preformatted{
#' FFMRgsr <- hanaml.FFMRegressor(data = data,
#'                                categorical.variable = "TIMESTAMP",
#'                                delimiter = ",",
#'                                factor.num = 4,
#'                                early.stop = TRUE,
#'                                learning.rate = 0.2,
#'                                max.iter = 20,
#'                                train.ratio = 0.8,
#'                                linear.lambda = 1e-5,
#'                                poly2.lambda = 1e-6,
#'                                random.state = 1)
#' }
#' Output:
#' \preformatted{
#' > FFMRegressor$coefficient$Head(5)$Collect()
#'   COEFF_INDEX FEATURE FIELD  K COEFFICIENT
#' 1           0       c  <NA> NA   1.0909289
#' 2           1  USER:A  <NA> NA  -0.2668773
#' 3           2  USER:B  <NA> NA   0.7964915
#' 4           3  USER:C  <NA> NA   0.2470971
#' 5           4  USER:D  <NA> NA   0.5147259
#'}
#' @keywords Recommender system
#' @export
#'
hanaml.FFMRegressor <- function(data = NULL,
                                key = NULL,
                                features = NULL,
                                label = NULL,
                                categorical.variable = NULL,
                                delimiter = NULL,
                                normalize = NULL,
                                include.constant = NULL,
                                include.linear = NULL,
                                early.stop = NULL,
                                factor.num = NULL,
                                train.ratio = NULL,
                                learning.rate = NULL,
                                random.state = NULL,
                                max.iter = NULL,
                                linear.lambda = NULL,
                                poly2.lambda = NULL,
                                sgd.tol = NULL,
                                sgd.exit.interval = NULL,
                                handle.missing = NULL) {
  FFMRegressor$new(data = data,
                   key = key,
                   features = features,
                   label = label,
                   categorical.variable = categorical.variable,
                   delimiter = delimiter,
                   normalize = normalize,
                   include.constant = include.constant,
                   include.linear = include.linear,
                   early.stop = early.stop,
                   factor.num = factor.num,
                   train.ratio = train.ratio,
                   learning.rate = learning.rate,
                   random.state = random.state,
                   max.iter = max.iter,
                   linear.lambda = linear.lambda,
                   poly2.lambda = poly2.lambda,
                   sgd.tol = sgd.tol,
                   sgd.exit.interval = sgd.exit.interval,
                   handle.missing = handle.missing)
}

#' @title Make Predictions from an "FFMRegressor" Object
#' @name predict.FFMRegressor
#' @seealso \code{\link{hanaml.FFMRegressor}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr A "FFMRegressor" object for prediction.
#' @param data \code{DataFrame}\cr
#' DataFrame containting data of user-item interaction and global
#' side features for prediction.
#' @template args-key
#' @template args-threadratio
#' @param   features \code{list of characters, optional}\cr
#'            Name of feature columns in \emph{data}.\cr
#'            If not provided, it defaults all non-ID columns of
#'            \emph{data}.
#' @param handle.missing \code{c("remove", "replace"), optional}\cr
#' Specifies how to handle missing features of \code{data}:
#' \itemize{
#' \item{\code{"remove"} remove missing rows}
#' \item{\code{"replace"} replace missing rows with 0}
#' }
#'
#' @return
#' \code{DataFrame}\cr
#'  Prediction made by the model, structured as follows:
#'  \itemize{
#'    \item{ID}: id
#'    \item{SCORE}: Predict value
#'    \item{CONFIDENCE}: the confidence of a category (NULL for "regression")
#'  }
#'
#'
#' @section Examples:
#'\preformatted{
#' > data$Collect()
#'   ID USER  MOVIE TIMESTAMP
#' 1  1    A Movie0         3
#' 2  2    A Movie4         1
#' 3  3    B Movie3         2
#' 4  4    B   <NA>         5
#' 5  5    C Movie2         2
#' 6  6    F Movie4         3
#' 7  7    D Movie2         2
#' 8  8    D Movie4         1
#' 9  9    E Movie7         4
#' }
#' Call the function:
#' \preformatted{
#' > reg.result <- predict.FFMRegressor(model = FFMRgsr,
#'                                      data = data.pred.df.fit,
#'                                      thread.ratio = 1)}
#' Output:
#' \preformatted{
#'   ID               SCORE CONFIDENCE
#' 1  1   2.978197866860172         NA
#' 2  2 0.43883354766746385         NA
#' 3  3   3.765106298778723         NA
#' 4  4  1.8874204073998788         NA
#' 5  5   3.588371752514674         NA
#' }
#' @keywords Recommender system
#' @export
predict.FFMRegressor <- function(
  model,
  data,
  key,
  features = NULL,
  handle.missing = NULL,
  thread.ratio = NULL) {
  result <- model$predict(data = data,
                          key = key,
                          features = features,
                          thread.ratio = thread.ratio,
                          handle.missing = handle.missing)
}

#' @title Field-Aware Factorization Machine for Ranking
#' @name hanaml.FFMRanker
#' @seealso \code{\link{hanaml.FFMClassifier}, \link{hanaml.FFMRegressor}, \link{predict.FFMRanker}}
#' @description hanaml.FFMRanker is an R wrapper
#' for SAP HANA PAL FFM for ranking problem.
#' @details
#' FFM has been proven to be a powerful tool for CTR and CVR prediction task.
#' Based on FM models that reduce weights for sparse higher-order interactions
#' to vectors using matrix factorization, the Field-Aware Factorization Machine
#' introduces the concept of field, with which we represent a group of similar
#' features, e.g., the field of user properties includes gender, age,
#' occupation, etc. \cr
#' By making factor vectors related not only to features but
#' also to fields, the model has to learn a vector representation
#' for each field.
#' By doing so, we increase the complexity of the model to O(kn^2) where n is
#' the number of data, and k is the factor number, i.e., length of the factor
#' vectors.\cr
#' In practice, we consider features spanned from the same categorical
#' variable as of the same field. It is noted that FFM is most suited
#' to
#' categorical features. A numeric feature is either regarded as a
#' single field or
#' discretized to categorical. If all features are numeric and treated
#' as every single
#' feature, which means each field consists of only one feature,
#' FFM degenerates to FM.\cr
#' FFM can be applied to a variety of prediction tasks,
#' for example, binary classification, regression, and ranking.
#' @template args-data
#' @template args-key-optional
#' @template args-feature-multiple
#' @template args-label
#' @template args-cate-var
#' @param     factor.num \code{integer, optional}\cr
#'            length of factor vectors.\cr
#'            Defaults to 4.
#' @param     delimiter \code{character, optional}\cr
#'            The delimiter to separate string features. For example,
#'            "China, USA" indicates two feature values "China"
#'            and "USA".
#'            Valid only for string feature.\cr
#'            Default to "," (comma)
#' @param     ordering \code{list/vector of characters/integers, optional}\cr
#'            Specifies the orders of categorical variable in ascending order.\cr
#'            By default, characters are ordered alphabetically, while integers
#'            ordered numerically.\cr
#'            No default value.
#' @param     learning.rate \code{double, optional}\cr
#'            Secifies the learning rate/ step size for optimization
#'            process.\cr
#'            Defaults to 0.2.
#' @param     train.ratio \code{double, optional}\cr
#'            The ratio of training data set, and the remaining data
#'            set for validation. For example, 0.8 indicates that
#'            80% for training, and the remaining 20% for validation.\cr
#'            0.8 if number of instances not less than 40, 1.0 otherwise.
#' @param      normalize \code{logical, optional}\cr
#'            Specifies whether to normalize each instance so
#'            that its L1 norm is 1.\cr
#'            Defaults to TRUE.
#' @param      include.linear \code{logical, optional}\cr
#'            Specifies whether or not to include the linear weights in FFM model.\cr
#'            Defaults to TRUE.
#' @param      include.constant \code{logical, optional}\cr
#'            Specifies whether or not to include the constant part in FFM model.\cr
#'            Defaults to TRUE.
#' @param      linear.lambda \code{double, optional}\cr
#'            Specifies the penalization assigned to the L2 regularization term for linear weights.\cr
#'            Defaults to 1e-5.
#' @param      poly2.lambda \code{double, optional}\cr
#'            Specifies the penalization assigned to the L2 regularization term for quadratic factors.\cr
#'            Defaults to 1e-5.
#' @param      random.state \code{double, optional}\cr
#'            Specifies the seed for random number generation,
#'            where 0 means current system time
#'            is used as seed, and other values are simply real
#'            seed values.\cr
#'            Defaults to 0.
#' @param     max.iter \code{integer, optional}\cr
#'            Specifies the maximum number of iterations for
#'            optimization process.\cr
#'            Defaults to 20.
#' @param     sgd.tol \code{double, optional}\cr
#'            Specifies the stopping creteria for SGD algorithm.\cr
#'            The algorithm exits when the cost function has not
#'            decreased more than sgd.tol in sgd.exit.interval steps.\cr
#'            Defaults to 1e-5.
#' @param     sgd.exit.interval \code{double, optional}\cr
#'            Specifies the stop creteria for SGD algorithm.\cr
#'            The algorithm exits when the cost function has not
#'            decreased more than sgd.tol in sgd.exit.interval steps.\cr
#'            Defaults to 5.
#' @param     early.stop \code{logical, optional}\cr
#'            Specifies whether or not to early stop the SGD
#'            optimisation.
#'            Always TRUE, if \code{train.ratio} is less than 1.\cr
#'            Defaults to TRUE.
#' @param     handle.missing \code{c("remove", "replace"), optional}\cr
#'             Specifies how to handle missing features of \code{data}:
#'             \itemize{
#'               \item{\code{"remove"} remove missing rows}
#'               \item{\code{"replace"} replace missing rows with 0}
#'             }
#'
#' @return
#' A "FFMRanker" object with the following attributes:\cr
#' \itemize{
#' \item \code{meta: DataFrame}\cr meta data of the
#' trained model.
#' \item \code{coef: DataFrame}\cr coefficient of the
#' trained model
#' \item \code{stats: DataFrame}\cr statistical information about the
#' trained model.
#' }
#' @section Examples:
#'\preformatted{
#' > data$Head(5)$Collect()
#'   ID USER  MOVIE TIMESTAMP      RANK
#' 1  1    A Movie1         3    medium
#' 2  2    A Movie2         3  too high
#' 3  3    A Movie4         1    medium
#' 4  4    A Movie5         2   too low
#' 5  5    A Movie6         3       low
#'}
#' Call the function:
#' \preformatted{
#' FFMRank <- hanaml.FFMRanker(data = data,
#'                             categorical.variable = "TIMESTAMP",
#'                             ordering = list("too low", "low",
#'                                             "medium", "high",
#'                                             "too high"),
#'                             delimiter = ",", factor.num = 4,
#'                             early.stop = TRUE, learning.rate = 0.2,
#'                             max.iter = 20, train.ratio = 0.8,
#'                             linear.lambda = 1e-5,
#'                             poly2.lambda = 1e-6, random.state = 1)
#' }
#' Output:
#' \preformatted{
#' > FFMRank$coefficient$Head(5)$Collect()
#'   COEFF_INDEX         FEATURE FIELD  K COEFFICIENT
#' 1           0   c:too low|low  <NA> NA -0.30807566
#' 2           1    c:low|medium  <NA> NA  0.62193219
#' 3           2   c:medium|high  <NA> NA  1.47438523
#' 4           3 c:high|too high  <NA> NA  2.50841306
#' 5           4          USER:A  <NA> NA -0.03842879
#'
#'}
#' @keywords Recommender system
#' @export

hanaml.FFMRanker <- function(data = NULL,
                             key = NULL,
                             features = NULL,
                             label = NULL,
                             categorical.variable = NULL,
                             delimiter = NULL,
                             ordering = NULL,
                             normalize = NULL,
                             include.constant = NULL,
                             include.linear = NULL,
                             early.stop = NULL,
                             factor.num = NULL,
                             train.ratio = NULL,
                             learning.rate = NULL,
                             random.state = NULL,
                             max.iter = NULL,
                             linear.lambda = NULL,
                             poly2.lambda = NULL,
                             sgd.tol = NULL,
                             sgd.exit.interval = NULL,
                             handle.missing = NULL) {
  FFMRanker$new(data = data,
                key = key,
                features = features,
                label = label,
                categorical.variable = categorical.variable,
                delimiter = delimiter,
                ordering = ordering,
                normalize = normalize,
                include.constant = include.constant,
                include.linear = include.linear,
                early.stop = early.stop,
                factor.num = factor.num,
                train.ratio = train.ratio,
                learning.rate = learning.rate,
                random.state = random.state,
                max.iter = max.iter,
                linear.lambda = linear.lambda,
                poly2.lambda = poly2.lambda,
                sgd.tol = sgd.tol,
                sgd.exit.interval = sgd.exit.interval,
                handle.missing = handle.missing)
}

#' @title Make Predictions from an "FFMRanker" Object
#' @name predict.FFMRanker
#' @seealso \code{\link{hanaml.FFMRanker}}
#' @format \code{\link{S3}} methods
#' @param model \code{R6Class object}\cr A "FFMRanker" object for prediction.
#' @param data \code{DataFrame}\cr
#' DataFrame containting data of user-item interaction and global
#' side features for prediction.
#' @template args-key
#' @template args-threadratio
#' @param   features \code{list of characters, optional}\cr
#'            Name of feature columns in \emph{data}.\cr
#'            If not provided, it defaults all non-ID columns of
#'            \emph{data}.
#' @param handle.missing \code{c("remove", "replace"), optional}\cr
#' Specifies how to handle missing features of \code{data}:
#' \itemize{
#' \item{\code{"remove"} remove missing rows}
#' \item{\code{"replace"} replace missing rows with 0}
#' }
#'
#' @return
#' \code{DataFrame}\cr
#' Prediction made by the model, structured as follows:
#' \itemize{
#'    \item{ID}: id
#'    \item{SCORE}: Predict value
#'    \item{CONFIDENCE}: the confidence of a category
#' }
#' @section Examples:
#'\preformatted{
#' > data$Collect()
#'   ID USER  MOVIE TIMESTAMP
#' 1  1    A Movie0         3
#' 2  2    A Movie4         1
#' 3  3    B Movie3         2
#' 4  4    B   <NA>         5
#' 5  5    C Movie2         2
#' 6  6    F Movie4         3
#' 7  7    D Movie2         2
#' 8  8    D Movie4         1
#' 9  9    E Movie7         4
#' }
#' Call the function:
#' \preformatted{
#' > ranking.result <- predict.FFMRanker(model = FFMrank,
#'                                       data = data.pred.df.fit,
#'                                       thread.ratio = 1)}
#' Output:
#' \preformatted{
#' > ranking.result$Collect()
#'   ID    SCORE CONFIDENCE
#' 1  1     high  0.2942058
#' 2  2   medium  0.2098934
#' 3  3  too low  0.3166094
#' 4  4     high  0.2196706
#' 5  5 too high  0.2225450
#' 6  6     high  0.3856211
#' 7  7  too low  0.4076951
#' 8  8  too low  0.2952001
#' 9  9     high  0.2826328
#' }
#' @keywords Recommender system
#' @export
predict.FFMRanker <- function(
  model,
  data,
  key,
  features = NULL,
  handle.missing = NULL,
  thread.ratio = NULL) {
  result <- model$predict(data = data,
                          key = key,
                          features = features,
                          thread.ratio = thread.ratio,
                          handle.missing = handle.missing)
}
