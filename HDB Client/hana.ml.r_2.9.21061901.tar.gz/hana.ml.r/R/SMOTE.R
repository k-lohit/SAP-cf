#' @title Synthetic Minority Over-sampling Technique
#' @name hanaml.SMOTE
#' @description hanaml.SMOTE is a R wrapper
#' for SAP HANA PAL SMOTE.\cr
#' Note that this is a new function in SAP HANA SPS05 and Cloud.
#' @seealso \code{\link{hanaml.SMOTETomek}}
#' @details
#' SMOTE is a sampling method that oversamples the minority class to prepare the
#' dataset for further applications. It creates new instances by taking each
#' minority class sample and building convex combinations with the k nearest
#' neighboring samples of the minority class.
#' @template args-data
#' @template args-threadratio
#' @template args-key-optional
#' @template args-feature-multiple
#' @param     label \code{character}\cr
#'            Specifies the dependent variable by name.
#' @param     n.neighbors \code{integer, optional}\cr
#'            Specifies the number of nearest neighbours.  \cr
#'            Defaults to 1.
#' @param     random.state \code{double, optional}\cr
#'            Specifies the seed for random number generation, where 0 means
#'            current system time is used as seed, and other values are simply
#'            real seed values. Defaults to 0.
#' @param     minority.class \code{character, optional}\cr
#'            Specifies the targeted minority class value in the dependent
#'            variable column. When minority.class is not specified, all
#'            classes except majority class will be re-sampled to match the
#'            majority class sample amount.
#' @param     smote.amount \code{integer, optional}\cr
#'            only valid when minority.class is presented by user.
#'            Specifies the number of nearest neighbours.
#'            When not speciedied, the algorithm will generated samples until
#'            the minority class sample amount matches the majority class
#'            sample amount
#' @param     algorithm \code{c("brute-force", "kd-tree"), optional}\cr
#'            Specifies the searching algorithms for finding the nearest neighbors.
#'            \itemize{
#'                \item{\code{"brute-force"} use brute-force method}
#'                \item{\code{"kd-tree"} use kd-tree searching}
#'
#'            }
#'            Defaults to "brute-force".
#' @return
#' \itemize{
#'   \item{\code{DataFrame}}\cr
#'   Return dataset after sampling.
#'    The Output Table has the same structure as defined in the Input Table.\cr
#'  }
#'
#'@section Examples:
#'\preformatted{
#' > data.df$Collect()
#'    X1   X2   X3 TYPE
#' 1   2    1 3.50    1
#' 2   3   10 7.60    1
#' 3   3   10 5.50    2
#' 4   3   10 4.70    1
#' 5   7 1000 8.50    1
#' 6   8 1000 9.40    2
#' 7   6 1000 0.34    1
#' 8   8  999 7.40    2
#' 9   7  999 3.50    1
#' 10  6 1000 7.00    1
#'}
#' Call the function:
#' \preformatted{
#' > result <- hanaml.SMOTE(data=data.df, thread.ratio = 1, random.state = 1,
#'                          label = "TYPE", minority.class = "2",
#'                          smote.amount = 200, n.neighbors = 2,
#'                          algorithm = "kd-tree")
#' }
#' Results:
#' \preformatted{
#' > result$Collect()
#'    X1        X2       X3 TYPE
#' 1   2    1.0000 3.500000    1
#' 2   3   10.0000 7.600000    1
#' 3   3   10.0000 5.500000    2
#' 4   3   10.0000 4.700000    1
#' 5   7 1000.0000 8.500000    1
#' 6   8 1000.0000 9.400000    2
#' 7   6 1000.0000 0.340000    1
#' 8   8  999.0000 7.400000    2
#' 9   7  999.0000 3.500000    1
#' 10  6 1000.0000 7.000000    1
#' 11  8  973.1091 7.350260    2
#' 12  7  888.0711 8.959068    2
#' 13  8  999.0567 7.513491    2
#' 14  8  999.5123 8.424672    2
#' 15  4  131.5100 5.733437    2
#' 16  5  340.7139 6.135345    2
#' }
#' @keywords Preprocessing
#' @export




hanaml.SMOTE <- function(
  data,
  key = NULL,
  features = NULL,
  label = NULL,
  thread.ratio = NULL,
  random.state = NULL,
  n.neighbors = NULL,
  minority.class = NULL,
  smote.amount = NULL,
  algorithm = NULL) {
  cols <-  data$columns
  key <- validateInput("key", key, cols, case.sensitive = TRUE)
  cols <- cols[!cols %in% key]
  label  <-  validateInput("label", label, cols,
                           required =  TRUE,
                           case.sensitive = TRUE)
  cols <- cols[! cols %in% label]
  features <- validateInput("features", features, cols,
                            case.sensitive = TRUE)
  if (is.null(features)) {
    features <- cols
  }
  algorithm.map  <-  list(
    "brute-force" = 0,
    "kd-tree" = 1
  )
  algorithm  <-  validateInput("algorithm", algorithm, algorithm.map)
  smote.amount  <-  validateInput("smote.amount", smote.amount, "integer")
  n.neighbors  <-  validateInput("n.neighbors", n.neighbors, "integer")
  random.state  <-  validateInput("random.state", random.state, "integer")
  smote.amount <-  validateInput("smote.amount", smote.amount, "integer")
  if (!is.null(smote.amount) && is.null(minority.class)) {
    if (is.null(minority.class)) {
      error.msg  <-  paste("smote.amount is ineffective since minority.class",
                           "is not specified!")
      flog.warn(error.msg)
    }
  }
  if (!is.null(thread.ratio)) {
    thread.ratio  <-  validateInput("thread.ratio", thread.ratio, "double")
    if (thread.ratio < 0 || thread.ratio > 1) {
      msg  <-  "The thread.ratio value range is from 0 to 1!"
      flog.error(msg)
      stop(msg)
    }
  }
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  conn <- data$connection.context
  CheckConnection(data)
  data <- data$Select(c(features, label))
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_SMOTE_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_SMOTE_RESULT_TBL_%s", unique.id)
  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl)
  tables  <-  c(param.tbl, out.tables)
  param.array  <-  list(
    tuple("DEPENDENT_VARIABLE", NULL, NULL, label),
    tuple("METHOD", map.null(algorithm, algorithm.map), NULL, NULL),
    tuple("RANDOM_SEED", random.state, NULL, NULL),
    tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
    tuple("K_NEAREST_NEIGHBOURS", n.neighbors, NULL, NULL),
    tuple("SMOTE_AMOUNT", smote.amount, NULL, NULL),
    tuple("MINORITY_CLASS", NULL, NULL, minority.class)
  )
  tryCatch({
    errorhelper(CreateTWithConnection(
      conn, ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(
      conn, "PAL_SMOTE", in.tables, out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err$message)
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(conn$table(result.tbl))
}



#' @title SMOTETomek
#' @name hanaml.SMOTETomek
#' @description hanaml.SMOTETomek is a R wrapper
#' for SAP HANA PAL SMOTETomek.\cr
#' Note that this is a new function in SAP HANA SPS05 and Cloud.
#' @details
#' SMOTETomek combines over-sampling and under-sampling using SMOTE and Tomek links.
#' @seealso \code{\link{hanaml.SMOTE}, \link{hanaml.TomekLinks}}
#' @template args-data
#' @template args-threadratio
#' @template args-key-optional
#' @template args-feature-multiple
#' @param     label \code{character}\cr
#'            Specifies the dependent variable by name.
#' @param     n.neighbors \code{integer, optional}\cr
#'            Specifies the number of nearest neighbours.  \cr
#'            Defaults to 1.
#' @param     random.state \code{double, optional}\cr
#'            Specifies the seed for random number generation, where 0 means
#'            current system time is used as seed, and other values are simply
#'            real seed values. Defaults to 0.
#' @param     minority.class \code{character, optional}\cr
#'            Specifies the targeted minority class value in the dependent
#'            variable column. When minority.class is not specified, all
#'            classes except majority class will be re-sampled to match the
#'            majority class sample amount.
#' @param     smote.amount \code{integer, optional}\cr
#'            only valid when minority.class is presented by user.
#'            Specifies the number of nearest neighbors.
#'            When not specified, the algorithm will generated samples until
#'            the minority class sample amount matches the majority class
#'            sample amount
#' @param     algorithm \code{c("brute-force", "kd-tree"), optional}\cr
#'            Specifies the searching algorithms for finding the nearest neighbors.
#'            \itemize{
#'                \item{\code{"brute-force"} use brute-force method}
#'                \item{\code{"kd-tree"} use kd-tree searching}
#'
#'            }
#'            Defaults to "brute-force".
#' @param     sampling.strategy \code{c("majority", "non-minority", "non-majority", "all"), optioanl}\cr
#'            Specifies the samping strategy to resample the input dataset.
#'             \itemize{
#'                 \item{\code{"majority"}  resamples only the majority class}
#'                 \item{\code{"non-minority"} resamples all classes but the minority one}
#'                 \item{\code{"non-majority"} resamples all classes but the majority one}
#'                 \item{\code{"all"} resamples all classes}
#'             }
#'             Defaults to "majority".
#' @return
#' \code{DataFrame}\cr
#'  DataFrame for the output table.\cr
#'  The output table has the same structure as defined in the input table.
#'
#'@section Examples:
#'\preformatted{
#' > data.df$Collect()
#'    X1   X2   X3 TYPE
#' 1   2    1 3.50    1
#' 2   3   10 7.60    1
#' 3   3   10 5.50    2
#' 4   3   10 4.70    1
#' 5   7 1000 8.50    1
#' 6   8 1000 9.40    2
#' 7   6 1000 0.34    1
#' 8   8  999 7.40    2
#' 9   7  999 3.50    1
#' 10  6 1000 7.00    1
#'}
#' Call the function:
#' \preformatted{
#' > result = hanaml.SMOTETomek(data=data.df, thread.ratio = 1, random.state = 1,
#'                              label = "TYPE", minority.class = "2",
#'                              smote.amount = 200, n.neighbors = 2,
#'                              algorithm = "kd-tree", sampling.strategy = "all")
#' }
#' Results:
#' \preformatted{
#' > result$Collect()
#'    X1        X2       X3 TYPE
#' 1   2    1.0000 3.500000    1
#' 2   3   10.0000 7.600000    1
#' 3   3   10.0000 5.500000    2
#' 4   3   10.0000 4.700000    1
#' 5   7 1000.0000 8.500000    1
#' 6   8 1000.0000 9.400000    2
#' 7   6 1000.0000 0.340000    1
#' 8   8  999.0000 7.400000    2
#' 9   7  999.0000 3.500000    1
#' 10  6 1000.0000 7.000000    1
#' 11  8  973.1091 7.350260    2
#' 12  7  888.0711 8.959068    2
#' 13  8  999.0567 7.513491    2
#' 14  8  999.5123 8.424672    2
#' 15  4  131.5100 5.733437    2
#' 16  5  340.7139 6.135345    2
#' }
#' @keywords Preprocessing
#' @export


hanaml.SMOTETomek <- function(
  data,
  key = NULL,
  features = NULL,
  label = NULL,
  thread.ratio = NULL,
  random.state = NULL,
  n.neighbors = NULL,
  minority.class = NULL,
  smote.amount = NULL,
  algorithm = NULL,
  sampling.strategy = NULL) {
  strategy.map <- list("majority" = 0, "non-minority" = 1, "non-majority" = 2, "all" = 3)
  cols <-  data$columns
  key <- validateInput("key", key, cols, case.sensitive = TRUE)
  cols <- cols[!cols %in% key]
  label  <-  validateInput("label", label, cols,
                           required =  TRUE,
                           case.sensitive = TRUE)
  cols <- cols[! cols %in% label]
  features <- validateInput("features", features, cols,
                            case.sensitive = TRUE)
  if (is.null(features)) {
    features <- cols
  }
  algorithm.map  <-  list(
    "brute-force" = 0,
    "kd-tree" = 1
  )
  algorithm  <-  validateInput("algorithm", algorithm, algorithm.map)
  smote.amount  <-  validateInput("smote.amount", smote.amount, "integer")
  n.neighbors  <-  validateInput("n.neighbors", n.neighbors, "integer")
  random.state  <-  validateInput("random.state", random.state, "integer")
  smote.amount <-  validateInput("smote.amount", smote.amount, "integer")
  sampling.strategy <- validateInput("sampling.strategy", sampling.strategy,
                                     strategy.map)
  if (!is.null(smote.amount) && is.null(minority.class)) {
    if (is.null(minority.class)) {
      error.msg  <-  paste("smote.amount is ineffective since minority.class",
                           "is not specified!")
      flog.warn(error.msg)
    }
  }
  if (!is.null(thread.ratio)) {
    thread.ratio  <-  validateInput("thread.ratio", thread.ratio, "double")
    if (thread.ratio < 0 || thread.ratio > 1) {
      msg  <-  "The thread.ratio value range is from 0 to 1!"
      flog.error(msg)
      stop(msg)
    }
  }
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  conn <- data$connection.context
  CheckConnection(data)
  data <- data$Select(c(features, label))
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_SMOTETOMEK_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_SMOTETOMEK_RESULT_TBL_%s", unique.id)
  in.tables <- list(data, param.tbl)
  out.tables <- list(result.tbl)
  tables  <-  c(param.tbl, out.tables)
  param.array  <-  list(
    tuple("DEPENDENT_VARIABLE", NULL, NULL, label),
    tuple("METHOD", map.null(algorithm, algorithm.map), NULL, NULL),
    tuple("RANDOM_SEED", random.state, NULL, NULL),
    tuple("THREAD_RATIO", NULL, thread.ratio, NULL),
    tuple("K_NEAREST_NEIGHBOURS", n.neighbors, NULL, NULL),
    tuple("SMOTE_AMOUNT", smote.amount, NULL, NULL),
    tuple("MINORITY_CLASS", NULL, NULL, minority.class),
    tuple("SAMPLING_STRATEGY", map.null(sampling.strategy,
                                        strategy.map),
          NULL, NULL)
  )
  tryCatch({
    errorhelper(CreateTWithConnection(
      conn, ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(
      conn, "PAL_SMOTETOMEK", in.tables, out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err$message)
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(conn$table(result.tbl))
}
