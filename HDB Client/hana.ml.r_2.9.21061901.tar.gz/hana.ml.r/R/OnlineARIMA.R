OnlineARIMA <- R6Class(
  "OnlineARIMA",
  inherit = MlBase,
  public = list(
    fitted = NULL,
    model = NULL,
    order = NULL,
    learning.rate=NULL,
    epsilon=NULL,
    output.fitted = NULL,
    random.state=NULL,
    random.initialization=NULL,
    conn.context = NULL,
    initialize = function(order = NULL,
                          learning.rate=NULL,
                          epsilon=NULL,
                          output.fitted = NULL,
                          random.state=NULL,
                          random.initialization=NULL){
      super$initialize()

      self$order <- validateInput("order", unlist(order), c("integer","numeric"))
      if (!is.null(order) && length(order)!= 3){
        msg <- "order must contain exactly 3 integers for p, d, m!"
        flog.error(msg)
        stop(msg)
      }
      self$learning.rate <-  validateInput("learning.rate", learning.rate, "numeric")
      self$epsilon <- validateInput("epsilon", epsilon, "numeric")
      self$output.fitted <- validateInput("output.fitted", output.fitted, "logical")
      self$random.state <- validateInput("random.state", random.state, "integer")
      self$random.initialization <- validateInput("random.initialization", random.initialization, "logical")
    },
    fit = function(data,
                   key = NULL,
                   endog = NULL,
                   learning.rate = NULL,
                   epsilon = NULL,
                   ...){

      CheckConnection(data)
      conn.context <- data$connection.context
      self$conn.context <- conn.context

      if (!is.null(self$model)){
        if(!is.null(learning.rate)){
          self$learning.rate <- validateInput("learning.rate", learning.rate, "numeric")
          ExecuteLogged(conn.context$connection, sprintf("UPDATE %s SET VALUE='%s' WHERE KEY='lrate'", self$model$name, learning.rate))
        }

        if(!is.null(epsilon)){
          self$epsilon <- validateInput("epsilon", epsilon, "numeric")
          ExecuteLogged(conn.context$connection, sprintf("UPDATE %s SET VALUE='%s' WHERE KEY='epsilon'", self$model$name, epsilon))
        }
      }

      cols <- data$columns
      if (is.null(key)){
        key <- cols[[1]]
      }
      key <- validateInput("key", key, cols, case.sensitive = TRUE)
      cols <- cols[! cols %in% key]
      if (is.null(endog)){
        endog <- cols[[1]]
      }
      endog <- validateInput("endog", endog, cols, case.sensitive = TRUE)

      if (!inherits(data, "DataFrame") ) {
        msg <- "If training data is not omitted, it must be DataFrame."
        flog.error(msg)
        stop(msg)
      }
      data <- data$Select(c(key, endog))

      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      param.tbl <-
        sprintf("#PAL_ONLINE_ARIMA_PARAM_TBL_%s_%s", self$id, unique.id)#nolint
      model.tbl <-
        sprintf("#PAL_ONLINE_ARIMA_MODEL_TBL_%s_%s", self$id, unique.id)#nolint
      fitted.tbl <-
        sprintf("#PAL_ONLINE_ARIMA_FITTED_TBL_%s_%s", self$id, unique.id)#nolint
      input.model.tbl <- sprintf("#PAL_ONLINE_ARIMA_MODEL_IN_TBL_%s_%s", self$id, unique.id)
      TryDropWithConnection(conn.context, input.model.tbl)
      ExecuteLogged(conn.context$connection, paste("CREATE LOCAL TEMPORARY COLUMN TABLE",
                                                 input.model.tbl,
                                                 "(\"KEY\" NVARCHAR(100),",
                                                 "\"VALUE\" NVARCHAR(5000))"))
      if (!is.null(self$model)){
        tryCatch({
          ExecuteLogged(conn.context$connection, sprintf("INSERT INTO %s SELECT * FROM (%s)", input.model.tbl, self$model$select.statement))
        },
        error = function(err){
          msg <- paste("Error:", err[["message"]])
          flog.error(msg)
          TryDropWithConnection(conn.context, input.model.tbl)
          stop(msg)
        }
        )
      }

      param.rows <- list(
        tuple("P", self$order[1], NULL, NULL),
        tuple("D", self$order[2], NULL, NULL),
        tuple("M", self$order[3], NULL, NULL),
        tuple("OUTPUT_FITTED", to.integer(self$output.fitted), NULL, NULL),
        tuple("LEARNING_RATE", NULL, self$learning.rate, NULL),
        tuple("EPSILON", NULL, self$epsilon, NULL),
        tuple("SEED", self$random.state, NULL, NULL),
        tuple("RANDOM_INITIALIZATION", to.integer(self$random.initialization), NULL, NULL)
      )

      tables <- list(param.tbl, input.model.tbl, model.tbl, fitted.tbl)
      in.tables <- list(data, param.tbl, input.model.tbl)
      out.tables <- list(model.tbl, fitted.tbl)

      tryCatch({
        errorhelper(CreateTWithConnection(conn.context,
                                          (ParameterTable$new(param.tbl))$WithData(param.rows))) #nolint
        errorhelper(CallPalAutoWithConnection(conn.context,
                                              "PAL_ONLINE_ARIMA", in.tables, out.tables))
      },
      error = function(err){
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn.context, tables)
        stop(msg)
      })
      self$model <- conn.context$table(model.tbl)
      self$fitted <- conn.context$table(fitted.tbl)

      TryDropWithConnection(conn.context, input.model.tbl)
    }
  )
)

#' @title  Online ARIMA
#' @name hanaml.OnlineARIMA
#' @description hanaml.OnlineARIMA is a R wrapper
#' for SAP HANA PAL Online ARIMA. Note that this is a new function in SAP HANA SPS05 and Cloud.
#' @details
#' Online ARIMA implements an online learning method to estimate the parameters of ARIMA models
#' by reformulating it into a full information online optimization task (without random noise terms),
#' which has no limitations of depending on noise terms and accessing the entire large-scale dataset in advance.
#' @seealso \code{\link{predict.OnlineARIMA}}
#' @param     order \code{list/vector of integer, optional}\cr
#'            Indicate the order (p, d, m).\cr
#'            \itemize{
#'              \item{p}: value of the auto regression order.
#'              \item{d}: value of the differentiation order.
#'              \item{m}: extended order needed to transform all moving-averaging term to AR term.
#'            }
#'            Defaults to (1, 0, 0).
#' @param     learning.rate \code{double, optional}\cr
#'            Learning rate. Must be greater than zero.\cr
#'            Default value is calculated according to order(p, d, m).
#' @param     epsilon \code{double, optional}\cr
#'            Convergence criterion.\cr
#'            Default value is calculated according to learning.rate, p and m in the order.
#' @param     output.fitted \code{logical, optional}\cr
#'            Output fitted result and residuals if TRUE.\cr
#'            Defaults to TRUE.
#' @param     random.state \code{integer, optional}\cr
#'            Specifies the seed for random number generator.
#'            \itemize{
#'              \item{0}: use the current time (in second) as seed.
#'              \item{Others}: use the specified value as seed.}
#'            Default to 0.
#' @param     random.initialization  \code{logical, optional}\cr
#'            Whether randomly generate initial state.
#'            \itemize{
#'              \item{FALSE}: set all to zero.
#'              \item{TRUE}: use random values.}
#'            Defaults to FALSE.
#'
#' @section Methods:
#' \describe{
#'    \code{fit(data = NULL, key = NULL, endog = NULL, learning.rate = NULL, epsilon = NULL, ...)}\cr\cr
#'    The fit function of OnlineARIMA object.\cr\cr
#'
#'    \emph{Usage:\cr
#'    onlinearima <- hanaml.OnlineARIMA(order=c(4,0,8), output.fitted=TRUE, learning.rate=0.00001)\cr
#'    onlinearima$fit(data)}\cr\cr
#'
#'    \emph{Arguments:}
#'    \itemize{
#'     \item{\code{data, DataFrame}\cr Input data.}
#'     \item{\code{key, character, optional}\cr The timestamp column of data.\cr The type of key column is int.\cr
#'                 Defaults to the first column of data if not provided.}
#'     \item{\code{endog, character, optional}\cr The endogenous variable, i.e. time series.\cr
#'                Defaults to the first non-key column of data if not provided.}
#'     \item{\code{learning.rate, double, optional}\cr Learning rate. Must be greater than zero.\cr
#'                 Default value is calculated according to order(p, d, m).}
#'     \item{\code{epsilon, double, optional}\cr Convergence criterion.\cr
#'            Default value is calculated according to learning.rate, p and m in the order.}
#'     \item{...\cr Reserved parameter.}}
#' }
#'
#' @return
#' Returns an "OnlineARIMA" object and then invoke the fit function will obtain the following attributes:
#' \itemize{
#' \item{model: \code{DataFrame}}\cr
#'      Fitted model.
#' \item{fitted: \code{DataFrame}}\cr
#'      Predicted dependent variable values for training data.
#'      Set to NULL if the training data has no row IDs.
#' }
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'     TIMESTAMP     Y
#' 1           1   450
#' 2           2   806
#' 3           3   647
#' 4           4 -3300
#' 5           5  5308
#' ......
#' }
#' Create a OnlineARIMA object without the data:
#' \preformatted{
#' > onlinearima <- hanaml.OnlineARIMA(order=c(4,0,8), output.fitted=TRUE, learning.rate=0.00001)
#' }
#' Invoke fit function:
#' \preformatted{
#' > onlinearima$fit(data)
#' }
#' Output:
#' \preformatted{
#' > onlinearima$model
#'       KEY        VALUE
#' 1   lrate        1e-05
#' 2  fitted            1
#' 3       d            0
#' 4      mp           12
#' 5 epsilon      2.4e-09
#'  .......
#' > onlinearima$fitted
#'     TIMESTAMP        FITTED    RESIDUALS
#' 1           1    900.000000   -450.00000
#' 2           2   1612.000000   -806.00000
#' 3           3   1182.976801   -535.97680
#' 4           4  -6855.679157   3555.67916
#' ......
#' }
#' New coming input DataFrame data2:
#' \preformatted{
#' > data2$Collect()
#'      TIMESTAMP      Y
#' 1         101    386
#' 2         102  -7807
#' 3         103   3374
#' 4         104   6074
#' 5         105    241
#' ......
#' }
#' Invoke the fit function again, \code{learning.rate} and \code{epsilon} could be re-assigned:
#' \preformatted{
#' onlinearima$fit(data2)
#' }
#' Output:
#' \preformatted{
#' > onlinearima$model
#'       KEY        VALUE
#' 1   lrate        1e-05
#' 2  fitted            1
#' 3       d            0
#' 4      mp           12
#' 5 epsilon      2.4e-09
#'  .......
#' > onlinearima$fitted
#'     TIMESTAMP       FITTED    RESIDUALS
#' 1         101    772.0000   -386.000000
#' 2         102 -15662.6630   7855.663020
#' 3         103   7509.2051  -4135.205060
#' 4         104  13960.8733  -7886.873345
#' 5         105  -1702.2340   1943.234045
#' .....
#' }
#'
#' @keywords TimeSeries
#' @export
hanaml.OnlineARIMA <- function(order = NULL,
                               learning.rate = NULL,
                               epsilon = NULL,
                               output.fitted = TRUE,
                               random.state = NULL,
                               random.initialization = NULL) {
  OnlineARIMA$new(order,
                  learning.rate,
                  epsilon,
                  output.fitted,
                  random.state,
                  random.initialization)
}


#' @title Make Predictions from an "OnlineARIMA" Object
#' @name predict.OnlineARIMA
#' @description Similar to other predict methods, this function
#'  predicts fitted values from a fitted "OnlineARIMA" object.
#' @seealso \code{\link{hanaml.OnlineARIMA}}
#' @format \code{\link{S3}} methods
#' @param     model \code{R6Class object}\cr
#'            A "OnlineARIMA" object for prediction.
#' @param     forecast.length \code{integer, optional}\cr
#'            Number of points to forecast.\cr
#'            Defaults to NULL.
#' @param     ... Reserved parameter.
#' @return
#' Predicted values are returned as a DataFrame.
#'
#' @section Examples:
#' Call the function and obtain the result:
#' \preformatted{
#' > predict(model = onlinearima, forecast.length = 1)
#'   ID     FORECAST
#' 1  0    1370.6701
#' }
#' @keywords TimeSeries
#' @export
predict.OnlineARIMA <- function(model,
                                forecast.length = NULL,
                                ...){
  if (is.null(model$model)) {
    msg <- "model of object is empty!"
    flog.error(msg)
    stop(msg)
  }

  forcast.length <- validateInput("forecast.length",
                                  forecast.length,
                                  "integer")
  conn.context <- model$conn.context
  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_ONLINE_ARIMA_PARAM_TBL_%s_%s", model$id, unique.id)
  res.tbl <- sprintf("#PAL_ONLINE_ARIMA_RESULT_TBL_%s_%s", model$id, unique.id)


  in.tables <- list(model$model$name, param.tbl)
  tables <- list(param.tbl, res.tbl)
  out.tables <- list(res.tbl)
  param.rows <- list(tuple("FORECAST_LENGTH", forecast.length, NULL, NULL))

  tryCatch({
    errorhelper(CreateTWithConnection(conn.context,
                                      (ParameterTable$new(param.tbl))$WithData(param.rows))) #nolint
    errorhelper(CallPalAutoWithConnection(conn.context,
                                          "PAL_ONLINE_ARIMA_FORECAST", in.tables, out.tables))
  },
  error = function(err){
    msg <- paste("Error:", err[["message"]])
    flog.error(msg)
    TryDropWithConnection(conn.context, tables)
    stop(msg)
  })

  return(conn.context$table(res.tbl))
}
