#' @title Weighted Score Table
#' @name hanaml.WST
#' @description hanaml.WST is a R wrapper
#' for SAP HANA PAL WEIGHTED SCORE TABLE
#' @details
#' A weighted score table is a method of evaluating alternatives when the
#' importance of each criterion differs.
#' In a weighted score table, each alternative is given a score for each
#' criterion. These scores are then weighted by the importance of each
#' criterion. All of an alternative's weighted scores are then added together
#' to calculate its total weighted score. The alternative with the highest
#' total score should be the best alternative. A function defined by weighted
#' score tables is a linear combination of functions of a variable:
#' \ifelse{html}{\out{f(x<sub>1</sub>,...,x<sub>n</sub>) = w<sub>1</sub>f<sub>1</sub>(x<sub>1</sub>) + ... + w<sub>n</sub>f<sub>n</sub>(x<sub>n</sub>)}}{\eqn{f(x_1,...,x_n) = w_1 \times f_1(x_1) + ... + w_n\times f_n(x_n)}}
#' @template args-data
#' @template args-key-first
#' @template args-feature-multiple
#' @param map \code{DataFrame}\cr
#' Every attribute (except ID) in the input data table maps to two columns
#' in the map Function table: Key column and Value column. The Value column
#' must be of double type.
#' @param weights \code{DataFrame}\cr
#' This table has three columns.
#' When the data table has n attributes (except ID), the weights table will
#' have n rows.
#' @template args-threadratio
#' @return
#' \code{DataFrame}\cr  Weighted score table result, structured as:
#'   \itemize{
#'     \item{ID}: ID (correspond to input table)
#'     \item{SCORE}: Result value.
#' }
#' @section Examples:
#'\preformatted{
#' > data$Collect()
#'      ITEM  VALUE
#' 1   item1  15.40
#' 2   item2 200.40
#' 3   item3 280.40
#' 4   item4 100.90
#' 5   item5  40.40
#' 6   item6  25.60
#' 7   item7  18.40
#' 8   item8  10.50
#' 9   item9  96.15
#' 10 item10   9.40
#'
#' > map$Collect()
#'   GENDER VAL1 INCOME VAL2 HEIGHT VAL3
#' 1   male  2.0      0    0   1.50    0
#' 2 female  1.5   5500    1   1.60    1
#' 3   <NA>  0.0   9000    2   1.71    2
#' 4   <NA>  0.0  12000    3   1.80    3
#'
#' > weights$Collect()
#'   WEIGHT ISDIS ROWNUM
#' 1    0.5     1      2
#' 2    2.0    -1      4
#' 3    1.0    -1      4
#' }
#' Call the function:
#' \preformatted{
#' > result -> hanaml.WST(data = data, map = map, weights = weights,
#'                        thread.ratio = 0.5)
#' }
#' Results:
#' \preformatted{
#' > result$Collect()
#'    ID SCORE
#' 1   0  3.00
#' 2   1  8.00
#' 3   2  2.75
#' 4   3  8.00
#' 5   4  1.75
#' 6   5  7.75
#' 7   6  2.00
#' 8   7  4.00
#' 9   8  5.75
#' 10  9  7.75
#' }
#' @keywords Miscellaneous
#' @export

hanaml.WST  <-  function(data,
                         key = NULL,
                         features = NULL,
                         map = NULL,
                         weights = NULL,
                         thread.ratio = NULL) {
  cols  <-  data$columns
  if (is.null(key)) {
    key  <-  cols[[1]]
  }
  key <- validateInput("key", key, cols,
                       case.sensitive = TRUE)

  cols <- cols[! cols %in% key]
  features <- validateInput("features", features, cols,
                            case.sensitive = TRUE)
  if (is.null(features)) {
    features  <-  cols
  }
  temp <- list(key)
  temp <- append(temp, features)
  feature.num  <-  length(features)
  if (length(map$columns) != 2 * feature.num) {
    msg <- paste("invalid map DataFrame! Every attribute of data",
                 "table except the key maps to two columns.")
    flog.error(msg)
    stop(msg)
  }
  if (length(weights$columns) != 3) {
    msg <- "invalid weights DataFrame! weights must have three columns."
    flog.error(msg)
    stop(msg)
  }
  if (!is.null(thread.ratio)) {
    thread.ratio <- validateInput("thread.ratio", thread.ratio, "numeric")
    if (thread.ratio < 0 || thread.ratio > 1) {
      msg <- "The thread.ratio value range is from 0 to 1!"
      flog.error(msg)
      stop(msg)
    }
  }
  if (!inherits(data, "DataFrame")) {
    msg <- "data must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  if (!inherits(map, "DataFrame")) {
    msg <- "map must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  if (!inherits(weights, "DataFrame")) {
    msg <- "weights must be given as a DataFrame"
    flog.error(msg)
    stop(msg)
  }
  conn <- data$connection.context
  CheckConnection(data)
  data  <-  data$Select(temp)

  unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
  param.tbl <- sprintf("#PAL_ENTROPY_PARAM_TBL_%s", unique.id)
  result.tbl <- sprintf("#PAL_RESULT_TBL_%s", unique.id)

  in.tables <- list(data, map, weights, param.tbl)
  out.tables <- list(result.tbl)
  tables  <-  c(param.tbl, out.tables)
  param.array <-
    list(tuple("THREAD_RATIO", NULL, thread.ratio, NULL))
  tryCatch({
    errorhelper(CreateTWithConnection(
      conn, ParameterTable$new(param.tbl)$WithData(param.array)))
    errorhelper(CallPalAutoWithConnection(
      conn, "PAL_WEIGHTED_TABLE", in.tables, out.tables))
  },
  error = function(err) {
    msg <- paste("Error:", err$message)
    flog.error(msg)
    TryDropWithConnection(conn, tables)
    stop(msg)
  })
  return(conn$table(result.tbl))
}
