AUC <- R6Class(
  "AUC",
  inherit = MlBase,
  public = list(
    positive.label = NULL,
    auc = NULL,
    roc = NULL,
    initialize = function(data,
                          key = NULL,
                          positive.label = NULL,
                          output.threshold = NULL){
      super$initialize()
      conn <- data$connection.context
      key <- validateInput("key", key, "character")
      positive.label <- validateInput("positive.label", positive.label, "character")
      output.threshold <- validateInput("output.threshold",
                                        output.threshold,
                                        "logical")
      cols <- data$columns
      if (!is.null(key)){
        id.col <- list(key)
        cols <- cols[! cols %in% key]
      } else {
        id.col <- list()
      }
      if (!inherits(data, "DataFrame")) {
        msg <- "data parameter passed as a DataFrame is not of type DataFrame"
        flog.error(msg)
        stop()
      }
      CheckConnection(data)
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      param.tbl <- sprintf("#AUC_PARAMS_TBL_%s_%s", self$id, unique.id)
      auc.tbl <- sprintf("#AUC_TBL_%s_%s", self$id, unique.id)
      roc.tbl <- sprintf("#AUC_ROC_TBL_%s_%s", self$id, unique.id)
      in.tables <-
        list(data,
             param.tbl)
      out.tables <-
        list(auc.tbl,
             roc.tbl)
      tables <- c(param.tbl, out.tables)
      param.data <- list(
        tuple("POSITIVE_LABEL", NULL, NULL, self$positive.label))
      proced <- "PAL_AUC"
      if (isTRUE(output.threshold)) {
        proced <- "PAL_ROC_AUC"
      }
      tryCatch({
        if (!is.null(positive.label)) {
          errorhelper(CreateTWithConnection(conn,
            (ParameterTable$new(param.tbl))$WithData(param.data))) #nolint
        }else {
          errorhelper(CreateTWithConnection(conn,
            ParameterTable$new(param.tbl))) #nolint
        }
        errorhelper(CallPalAutoWithConnection(conn,
                                              proced,
                                              in.tables,
                                              out.tables))
      },
      error = function(err){
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn,
                              tables)
        stop(msg)
      })
      self$auc <- conn$table(auc.tbl)$Collect()[[2]]
      self$roc <- conn$table(roc.tbl)
    }
  )
)

#' @title  Area Under Curve (AUC)
#' @name hanaml.AUC
#' @description hanaml.AUC is a R wrapper for SAP HANA PAL AUC.
#' @details Area under curve (AUC) is a traditional method to evaluate
#' the performance of classification algorithms. Basically, it can
#' evaluate binary classifiers, but it can also be extended to
#' multiple-class condition easily.
#' @seealso \code{\link{hanaml.MulticlassAUC}}
#' @param   data \code{DataFrame}\cr
#' DataFrame containing the data. structured as follows:
#' \itemize{
#' \item{\code{ID:} column with index.}
#' \item{\code{True Class:} true data point.}
#' \item{\code{Classifier:} computed probability that the
#' data point belongs to the positive class.}
#' }
#' @template args-key
#' @param positive.label \code{character, optional}\cr
#' If original label is not 0 or 1, specifies the
#' label value which will be mapped to 1.
#' @param output.threshold \code{logical, optional}\cr
#' Specifies whether or not to output threshold values for roc table.\cr
#' Default to FALSE.
#' @return
#' Return an "AUC" object with following values:
#' \itemize{
#' \item{\code{auc, double}
#' The area under the receiver operating characteristic curve.}
#' \item{\code{roc, DataFrame}
#' False positive rate and true positive rate,
#' structured as follows:\cr
#' \itemize{
#'       \item{\code{ID, type INTEGER}  column with index}
#'        \item{\code{FPR, type DOUBLE} representing false positive rate.}
#'        \item{\code{TPR, type DOUBLE} representing true positive rate.}
#'        \item{\code{THRESHOLD, type DOUBLE} representing the corresponding
#'              threshold value, available only when \code{output.threshold} is set TRUE.}
#'     }
#'   }
#' }
#'
#' @section Examples:
#' Input DataFrame data:
#' \preformatted{
#' > data$Collect()
#'    ID  ORIGINAL  PREDICT
#' 1   1         0     0.07
#' 2   2         0     0.01
#' 3   3         0     0.85
#' 4   4         0     0.30
#' 5   5         0     0.50
#' 6   6         1     0.50
#' 7   7         1     0.20
#' 8   8         1     0.80
#' 9   9         1     0.20
#' 10 10         1     0.95
#' }
#' Compute Area Under Curve:
#' \preformatted{
#' > auc <- hanaml.AUC(data = data)
#' }
#' Output:
#' \preformatted{
#' > auc$auc
#'  0.66
#'
#' > auc$roc$Collect()
#'
#'    ID  FPR  TPR
#' 1   0  1.0  1.0
#' 2   1  0.8  1.0
#' 3   2  0.6  1.0
#' 4   3  0.6  0.6
#' 5   4  0.4  0.6
#' 6   5  0.2  0.4
#' 7   6  0.2  0.2
#' 8   7  0.0  0.2
#' 9   8  0.0  0.0
#' }
#' @keywords Classification
#' @export
hanaml.AUC <- function(data, key = NULL, positive.label = NULL,
                       output.threshold = NULL){
  AUC$new(data, key, positive.label, output.threshold)
}


MulticlassAUC <- R6Class(
  "MulticlassAUC",
  inherit = MlBase,
  public = list(
    auc = NULL,
    roc = NULL,
    initialize = function(data.original,
                          data.predict,
                          key = NULL){

      super$initialize()
      conn <- data.original$connection.context
      key <- validateInput("key", key, "character")
      cols.original <- data.original$columns
      if (!is.null(key)){
        id.col <- list(key)
        cols.original <- cols.original[! cols %in% key]
      } else {
        id.col <- list()
      }

      cols.predict <- data.predict$columns
      if (!is.null(key)){
        id.col <- list(key)
        cols.predict <- cols.predict[! cols %in% key]
      } else {
        id.col <- list()
      }

      if (!inherits(data.original, "DataFrame")) {
        msg <- "data original is not of type DataFrame, please provide DataFrame to proceed"
        flog.error(msg)
        stop(msg)
      }
      if (!inherits(data.predict, "DataFrame")) {
        msg <- "data predict is not of type DataFrame, please provide DataFrame to proceed"
        flog.error(msg)
        stop(msg)
      }
      CheckConnection(data.original)
      CheckConnection(data.predict)
      unique.id <- toupper(gsub("-", "_", UUIDgenerate()))
      param.tbl <- sprintf("#AUC_MULTI_PARAMS_TBL_%s_%s", self$id, unique.id)
      auc.tbl <- sprintf("#AUC_MULTI_TBL_%s_%s", self$id, unique.id)
      roc.tbl <- sprintf("#AUC_ROC_MULTI_TBL_%s_%s", self$id, unique.id)
      in.tables <-
        list(data.original,
             data.predict,
             param.tbl)
      out.tables <-
        list(auc.tbl,
             roc.tbl)
      tables <- c(param.tbl, out.tables)
      tryCatch({
        errorhelper(CreateTWithConnection(conn,
          ParameterTable$new(param.tbl))) #nolint
        errorhelper(CallPalAutoWithConnection(conn,
          "PAL_MULTICLASS_AUC", in.tables, out.tables))
      },
      error = function(err){
        msg <- paste("Error:", err[["message"]])
        flog.error(msg)
        TryDropWithConnection(conn, tables)
        stop(msg)
      })
      self$auc <- conn$table(auc.tbl)$Collect()[[2]]
      self$roc <- conn$table(roc.tbl)
    })
)

#' @title  Area Under Curve with Multi-class
#' @name hanaml.MulticlassAUC
#' @description    hanaml.MulticlassAUC is a R wrapper
#'  for SAP HANA PAL multi-class AUC.
#' @seealso \code{\link{hanaml.AUC}}
#' @keywords Classification
#' @param    data.original  \code{DataFrame}\cr
#' True class data, structured as follows:
#'  \itemize{
#'  \item{\code{ID, INTEGER} - column with index.}
#'  \item{\code{True Class, INTEGER}-true data point.}
#'   }
#'
#' @param    data.predict   \code{DataFrame}\cr
#' True class data, structured as follows:
#' \itemize{
#' \item{\code{ID, INTEGER} - column with index.}
#' \item{\code{True Class, INTEGER} - true data point.}
#'  \item{\code{Classifier, DOUBLE} - Classifier-computed probability that
#' the data point belongs to that particular class.}
#'}
#' @template args-key
#' @note
#'    For each data point ID, there should be one row for each possible class.
#'
#' @return
#' Return a "MulticlassAUC" object with following values:\cr
#'  auc : \code{double}\cr
#'  The area under the receiver operating characteristic curve.\cr
#'
#'  roc : \code{DataFrame}\cr
#'  False positive rate and true positive rate, structured as follows:
#'   \itemize{
#'    \item{\code{ID} INTEGER,column with index}
#'     \item{\code{FPR} DOUBLE, representing false positive rate.}
#'     \item{\code{TPR} DOUBLE, representing true positive rate.}
#'       }
#'
#' @section Examples:
#' Input DataFrame data.original and data.predict:
#' \preformatted{
#' > data.original$Collect()
#'     ID  ORIGINAL
#' 1   1         1
#' 2   2         1
#' 3   3         1
#' 4   4         2
#' 5   5         2
#' 6   6         2
#' 7   7         3
#' 8   8         3
#' 9   9         3
#' 10 10         3
#'
#' > data.predict$Collect()
#'     ID  PREDICT  PROB
#' 1    1        1  0.90
#' 2    1        2  0.05
#' 3    1        3  0.05
#' ......
#' 27   9        3  0.70
#' 28  10        1  0.20
#' 29  10        2  0.20
#' 30  10        3  0.60
#' }
#' Compute Area Under Curve for multi class:
#' \preformatted{
#' >  multiauc <- hanaml.MulticlassAUC(data.original = data.original,
#'                                     data.predict = data.predict)
#' }
#' Output:
#' \preformatted{
#' > multiauc$auc
#'  1
#'
#' > multiauc$roc$Collect()
#'     ID   FPR  TPR
#' 1    0  1.00  1.0
#' 2    1  0.90  1.0
#' 3    2  0.65  1.0
#' 4    3  0.25  1.0
#' 5    4  0.20  1.0
#' 6    5  0.00  1.0
#' 7    6  0.00  0.9
#' 8    7  0.00  0.7
#' 9    8  0.00  0.3
#' 10   9  0.00  0.1
#' 11  10  0.00  0.0
#' }
#' @export
hanaml.MulticlassAUC <- function(data.original, data.predict,  key = NULL ){
  MulticlassAUC$new(data.original, data.predict, key)
}
