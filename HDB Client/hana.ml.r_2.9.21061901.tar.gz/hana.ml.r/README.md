
<!-- README.md is generated from README.Rmd. Please edit that file -->

# hana.ml.r <img src="man/figures/SAP_R_grad.jpg" align="right" alt="" width="120" />

Welcome to R machine learning client for SAP HANA (hana.ml.r) \!

This library enables R data scientists to access SAP HANA data and build
machine learning models using the data directly in SAP HANA.

### Overview

R machine learning client for SAP HANA provides a set of client-side R
functions for accessing and querying SAP HANA data, and a set of
functions for developing machine learning models.

R machine learning client for SAP HANA consists of two main parts:

  - A set of machine learning APIs for different algorithms in SAP HANA
    Predictive Analysis Library (PAL).

  - SAP HANA DataFrame, which provides a set of methods for analyzing
    data in SAP HANA without bringing the data to the client.

This R hana.ml.r library uses JDBC/ODBC to access SAP HANA.

### Getting Started

Install hana.ml.r, please refer to Installation page for obtaining the
hana.ml.r tar.gz file:

``` r
install.packages("path to hana.ml.r-XXX.tar.gz", repos=NULL, type="source")
```

### Quick Start

First, please set up a JDBC/ODBC connection to SAP HANA:

``` r
library(hana.ml.r)
conn.jdbc <- hanaml.ConnectionContext(dsn = <host>:<port>,
                                      username = 'xxxx',
                                      password = 'xxxx',
                                      odbc = FALSE,
                                      jdbcDriverPath = <path to jdbcDriver>,
                                      ...)
```

OR:

``` r
conn.odbc <- hanaml.ConnectionContext(dsn = <ODBC data source name>,
                                      username = 'xxxx',
                                      password = 'xxxx',
                                      odbc = TRUE,
                                      ...)
```

For SAP HANA port number, please refer to the following rules:

  - For HANA tenant databases, use the port number 3**NN**13 (where
    **NN** is the SAP instance number - e.g. 30013).
  - For HANA system databases in a multitenant system, the port number
    is 3**NN**13.
  - For HANA single-tenant databases, the port number is 3**NN**15.

Returns a DataFrame referenced to a SAP HANA table:

``` r
df <- conn$table(table='MY_TABLE', schema='MY_SCHEMA')
```

Convert to a R data.frame:

``` r
r.df <- df$Collect()
```

Convert to a HANA DataFrame from a R data.frame:

``` r
df <- ConvertToHANADataFrame(conn,
                             data = r.df,
                             table = 'temp_tbl',
                             force = TRUE,
                             native = FALSE,
                             col.types = list(ds = "DATE"))
```

An example to call hanaml.UnifiedClassification function:

``` r
uc.dt <- hanaml.UnifiedClassification(func = 'DecisionTree',
                                      data = df,
                                      partition.method = 'user.defined',
                                      purpose = "PURPOSE",
                                      algorithm = 'c45',
                                      model.format = 'json',
                                      min.records.of.parent = 2,
                                      min.records.of.leaf = 1,
                                      priors = list("Play" = 0.5,
                                                    "Do not Play" = 0.5),
                                      thread.ratio = 0.4,
                                      resampling.method = 'cv',
                                      evaluation.metric = 'auc',
                                      fold.num = 5,
                                      progress.indicator.id = 'CV',
                                      param.search.strategy = 'grid',
                                      parameter.values = list(split.threshold = c(1e-3 , 1e-4, 1e-5)))
```

Call the predict function:

``` r
predict(uc.dt, data = predict.df, key='ID', verbose=False)
```

### License

R machine learning client for SAP HANA is provided via the [SAP
Developer License
Agreement](https://tools.hana.ondemand.com/developer-license-3_1.txt)

By using this software, you agree that the following text is
incorporated into the terms of the Developer Agreement:

If you are an existing SAP customer for On Premise software, your use of
this current software is also covered by the terms of your software
license agreement with SAP, including the Use Rights, the current
version of which can be found at [SAP Software Use
Rights](https://www.sap.com/about/agreements/product-use-and-support-terms.html?tag=agreements:product-use-support-terms/on-premise-software/software-use-rights)
