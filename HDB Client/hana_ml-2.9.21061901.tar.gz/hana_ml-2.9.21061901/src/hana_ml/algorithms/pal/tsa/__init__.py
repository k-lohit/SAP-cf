"""
This module contains supported PAL time series algorithms.
"""
__all__ = ['arima']
