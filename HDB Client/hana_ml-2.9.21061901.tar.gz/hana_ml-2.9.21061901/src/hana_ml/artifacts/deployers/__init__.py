"""
Artifacts deployers.
"""
from .amdp import AMDPDeployer, gen_pass_key
